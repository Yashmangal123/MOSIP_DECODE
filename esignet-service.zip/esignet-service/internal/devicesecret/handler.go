/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

package devicesecret

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"

	applog "github.com/mosip/esignet/internal/log"
)

// Session API routes. They are registered on the eSignet mux behind the same security middleware as the
// client-management and key-management APIs, so the caller must present a bearer token with the
// appropriate scope (see docs/api.md - "Identity and session management").
const (
	// SessionsPath lists and filters device SSO sessions.
	SessionsPath = "GET /v1/esignet/device-sso/sessions"
	// SessionPath reads a single session.
	SessionPath = "GET /v1/esignet/device-sso/sessions/{sessionId}"
	// RevokeSessionPath revokes one session.
	RevokeSessionPath = "POST /v1/esignet/device-sso/sessions/{sessionId}/revoke"
	// RevokeSubjectSessionsPath revokes every session of a subject (cross-application sign-out).
	RevokeSubjectSessionsPath = "POST /v1/esignet/device-sso/sessions/revoke"
)

// subjectHeader carries the authenticated subject of an end-user-initiated request. It is set by the
// identity-facing gateway that authenticates the caller; an end user can only ever act on their own
// sessions because the store filters by it.
const subjectHeader = "X-ESignet-Subject-Id"

// Handler exposes the device SSO session management API.
type Handler struct {
	svc    *Service
	logger *applog.Logger
}

// NewHandler builds the session API handler.
func NewHandler(svc *Service, logger *applog.Logger) *Handler {
	return &Handler{svc: svc, logger: logger.Named("deviceSSOSessionHandler")}
}

// RegisterRoutes registers the session API on mux, wrapped in the supplied middleware.
func (h *Handler) RegisterRoutes(mux *http.ServeMux, middleware func(http.Handler) http.Handler) {
	wrap := func(handler http.HandlerFunc) http.HandlerFunc {
		wrapped := middleware(handler)
		return func(w http.ResponseWriter, r *http.Request) { wrapped.ServeHTTP(w, r) }
	}
	mux.HandleFunc(SessionsPath, wrap(h.handleListSessions))
	mux.HandleFunc(SessionPath, wrap(h.handleGetSession))
	mux.HandleFunc(RevokeSessionPath, wrap(h.handleRevokeSession))
	mux.HandleFunc(RevokeSubjectSessionsPath, wrap(h.handleRevokeSubjectSessions))
}

// sessionEnvelope is the MOSIP-style response envelope used by the rest of the eSignet APIs.
type sessionEnvelope struct {
	Response     interface{} `json:"response,omitempty"`
	Errors       []apiError  `json:"errors,omitempty"`
	ResponseTime string      `json:"responsetime,omitempty"`
}

type apiError struct {
	ErrorCode string `json:"errorCode"`
	Message   string `json:"message"`
}

func writeJSON(w http.ResponseWriter, status int, payload interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}

func writeError(w http.ResponseWriter, status int, code, message string) {
	writeJSON(w, status, sessionEnvelope{Errors: []apiError{{ErrorCode: code, Message: message}}})
}

// handleListSessions returns the sessions matching the optional subject and clientId query filters.
func (h *Handler) handleListSessions(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	query := r.URL.Query()
	subject := query.Get("subject")
	if headerSubject := r.Header.Get(subjectHeader); headerSubject != "" {
		// An end-user token may only ever see its own sessions.
		subject = headerSubject
	}
	clientID := query.Get("clientId")

	limit := defaultListLimit
	if raw := query.Get("limit"); raw != "" {
		parsed, err := strconv.Atoi(raw)
		if err != nil || parsed <= 0 {
			writeError(w, http.StatusBadRequest, "invalid_request", "limit must be a positive integer")
			return
		}
		limit = parsed
	}

	sessions, err := h.svc.ListSessions(ctx, subject, clientID, limit)
	if err != nil {
		h.logger.Error(ctx, "failed to list device sso sessions", applog.Error(err))
		writeError(w, http.StatusInternalServerError, "internal_error", "Failed to list sessions")
		return
	}
	writeJSON(w, http.StatusOK, sessionEnvelope{Response: sessions})
}

// handleGetSession returns a single session.
func (h *Handler) handleGetSession(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	sessionID := r.PathValue("sessionId")
	if sessionID == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "sessionId is required")
		return
	}
	session, err := h.svc.GetSession(ctx, sessionID)
	if errors.Is(err, ErrSessionNotFound) {
		writeError(w, http.StatusNotFound, "session_not_found", "Session does not exist")
		return
	}
	if err != nil {
		h.logger.Error(ctx, "failed to read device sso session", applog.Error(err))
		writeError(w, http.StatusInternalServerError, "internal_error", "Failed to read session")
		return
	}
	// An end-user caller may only read their own session.
	if headerSubject := r.Header.Get(subjectHeader); headerSubject != "" &&
		!strings.EqualFold(headerSubject, session.Subject) {
		writeError(w, http.StatusForbidden, "access_denied", "Session belongs to another user")
		return
	}
	writeJSON(w, http.StatusOK, sessionEnvelope{Response: session})
}

// handleRevokeSession revokes one session. Revocation is enforced by the provider: the next Native SSO
// exchange that presents a secret bound to this session is rejected.
func (h *Handler) handleRevokeSession(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	sessionID := r.PathValue("sessionId")
	if sessionID == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "sessionId is required")
		return
	}
	subject := r.Header.Get(subjectHeader)
	if err := h.svc.RevokeSession(ctx, sessionID, subject); err != nil {
		if errors.Is(err, ErrSessionNotFound) {
			writeError(w, http.StatusNotFound, "session_not_found", "Session does not exist or is not active")
			return
		}
		h.logger.Error(ctx, "failed to revoke device sso session", applog.Error(err))
		writeError(w, http.StatusInternalServerError, "internal_error", "Failed to revoke session")
		return
	}
	h.logger.Info(ctx, "device sso session revoked", applog.String("sessionId", sessionID))
	writeJSON(w, http.StatusOK, sessionEnvelope{Response: map[string]interface{}{
		"sessionId": sessionID,
		"status":    StatusRevoked,
	}})
}

// handleRevokeSubjectSessions revokes every active session of a subject.
func (h *Handler) handleRevokeSubjectSessions(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	subject := r.Header.Get(subjectHeader)
	if subject == "" {
		subject = r.URL.Query().Get("subject")
	}
	if subject == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "subject is required")
		return
	}
	count, err := h.svc.RevokeAllSessions(ctx, subject)
	if err != nil {
		h.logger.Error(ctx, "failed to revoke device sso sessions", applog.Error(err))
		writeError(w, http.StatusInternalServerError, "internal_error", "Failed to revoke sessions")
		return
	}
	h.logger.Info(ctx, "device sso sessions revoked",
		applog.Int("count", count))
	writeJSON(w, http.StatusOK, sessionEnvelope{Response: map[string]interface{}{
		"revokedCount": count,
	}})
}

// ExpireStale is a helper for background cleanup wiring.
func (h *Handler) ExpireStale(ctx context.Context) {
	if _, err := h.svc.ExpireStaleSessions(ctx); err != nil {
		h.logger.Warn(ctx, "failed to expire stale device sso sessions", applog.Error(err))
	}
}
