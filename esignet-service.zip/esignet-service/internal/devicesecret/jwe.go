/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

package devicesecret

import (
	"context"
	"errors"
	"fmt"

	"github.com/go-jose/go-jose/v4"

	"github.com/mosip/esignet/internal/config"
	"github.com/mosip/esignet/internal/keymanager"
)

// errNoEncryptionKey is returned when neither the dedicated device-secret key nor the fallback cache
// encryption key exists in the key manager.
var errNoEncryptionKey = errors.New("no device secret encryption key is provisioned")

// encryptionKey resolves the AES key used to encrypt device secrets.
//
// The device secret is encrypted with a dedicated symmetric key (reference id
// keymanager.RefIDDeviceSecretEncrypt). Deployments that have not yet added that reference id to
// KEYMANAGER_SYMMETRIC_KEY_ALLOWED_REF_IDS fall back to the cache-encryption key that eSignet always
// provisions, so a local run works out of the box; the fallback is logged by the caller.
func (s *Service) encryptionKey(ctx context.Context) ([]byte, error) {
	if _, keyBytes, _, err := s.keyMgr.ResolveCurrentSymmetricKey(ctx, config.OIDCServiceAppID,
		keymanager.RefIDDeviceSecretEncrypt); err == nil && len(keyBytes) > 0 {
		s.usingDedicatedKey = true
		return keyBytes, nil
	}
	if _, keyBytes, _, err := s.keyMgr.ResolveCurrentSymmetricKey(ctx, config.OIDCServiceAppID,
		keymanager.RefIDCacheEncrypt); err == nil && len(keyBytes) > 0 {
		s.usingDedicatedKey = false
		return keyBytes, nil
	}
	return nil, errNoEncryptionKey
}

// encryptJWE wraps the signed JWT in a compact JWE (RFC 7516) using AES-256-GCM with the direct key
// management mode. The result is the device_secret returned to the client: opaque to the client, and
// readable only by this authorization server.
func (s *Service) encryptJWE(ctx context.Context, signedJWT string) (string, error) {
	key, err := s.encryptionKey(ctx)
	if err != nil {
		return "", err
	}
	encrypter, err := jose.NewEncrypter(
		jose.A256GCM,
		jose.Recipient{Algorithm: jose.DIRECT, Key: key},
		// Compression is deliberately disabled: compressing attacker-influenced plaintext before
		// encryption is the CRIME/BREACH pattern (RFC 8725 section 3.4).
		&jose.EncrypterOptions{Compression: jose.NONE},
	)
	if err != nil {
		return "", fmt.Errorf("build JWE encrypter: %w", err)
	}
	object, err := encrypter.Encrypt([]byte(signedJWT))
	if err != nil {
		return "", fmt.Errorf("encrypt device secret: %w", err)
	}
	return object.CompactSerialize()
}

// decryptJWE reverses encryptJWE: it authenticates the JWE (so any tampering is detected) and returns
// the signed JWT it carries.
func (s *Service) decryptJWE(ctx context.Context, deviceSecret string) (string, error) {
	key, err := s.encryptionKey(ctx)
	if err != nil {
		return "", err
	}
	object, err := jose.ParseEncrypted(deviceSecret,
		[]jose.KeyAlgorithm{jose.DIRECT}, []jose.ContentEncryption{jose.A256GCM})
	if err != nil {
		return "", fmt.Errorf("parse device secret JWE: %w", err)
	}
	plaintext, err := object.Decrypt(key)
	if err != nil {
		return "", fmt.Errorf("decrypt device secret: %w", err)
	}
	return string(plaintext), nil
}
