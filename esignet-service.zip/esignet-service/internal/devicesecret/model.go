/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

// Package devicesecret implements the eSignet side of OpenID Connect Native SSO for Mobile Apps 1.0:
// the Device Secret Provider consumed by the ThunderID engine, the persistent record of the
// authentication sessions a device secret is bound to, and the administrative session API.
//
// The device secret is a signed-then-encrypted JWT. The signature (ES256, eSignet's OIDC service
// signing key) makes the value tamper-evident, and the encryption (RSA-OAEP-256 + A256GCM under the
// OIDC service component master key) makes it opaque to clients, as section 3.2 of the specification
// requires ("the AS MUST adequately protect the value such as using a JWE"). Neither the private
// signing key nor the decryption key ever leaves eSignet's key manager.
package devicesecret

import (
	"bytes"
	"encoding/json"
	"time"
)

// Device secret claim names. These are the claims the specification requires the authorization server
// to bind into the secret (MOSIP Native SSO task 4a), plus the standard JWT claims.
const (
	// claimIss is the issuer: the eSignet issuer URL.
	claimIss = "iss"
	// claimSub is the authenticated end-user identifier.
	claimSub = "sub"
	// claimAud is the client the secret was issued to.
	claimAud = "aud"
	// claimCnf carries the DPoP key thumbprint, {"jkt": "..."}.
	claimCnf = "cnf"
	// claimJkt is the key inside cnf.
	claimJkt = "jkt"
	// claimAuthID identifies the completed authentication.
	claimAuthID = "auth_id"
	// claimClientID is the OAuth client identifier.
	claimClientID = "client_id"
	// claimScope is the space-delimited granted scope set.
	claimScope = "scope"
	// claimACR is the completed authentication context reference.
	claimACR = "acr"
	// claimClaims carries the consented identity claims.
	claimClaims = "claims"
	// claimSID is the authentication session identifier shared with the id_token's sid.
	claimSID = "sid"
	// claimJti is the unique identifier of this secret.
	claimJti = "jti"
	// claimIat / claimExp are standard JWT timestamps.
	claimIat = "iat"
	claimExp = "exp"
	// claimTyp marks the JWT as a device secret so it cannot be replayed as another token type.
	claimTyp = "typ"
	// typDeviceSecret is the value of claimTyp.
	typDeviceSecret = "device-secret+jwt"
)

// Session statuses recorded in the device SSO session table.
const (
	// StatusActive marks a session that can still be used for Native SSO.
	StatusActive = "ACTIVE"
	// StatusRevoked marks a session revoked by the user or an administrator.
	StatusRevoked = "REVOKED"
	// StatusExpired marks a session past its expiry.
	StatusExpired = "EXPIRED"
)

// sessionRecord is one row of the device SSO session table: the server-side state a device secret is
// bound to. The secret itself is never stored, only the digest used to detect value reuse.
type sessionRecord struct {
	SessionID  string
	ClientID   string
	AuthID     string
	Subject    string
	ACR        string
	Scopes     []string
	DPoPJkt    string
	SecretHash string
	Status     string
	CreatedAt  time.Time
	ExpiresAt  time.Time
	RevokedAt  *time.Time
}

// deviceSecretClaims is the decoded claim set of a device secret. It is used internally after the
// signature and encryption have been verified.
type deviceSecretClaims struct {
	Issuer   string                 `json:"iss"`
	Subject  string                 `json:"sub"`
	Audience string                 `json:"aud"`
	AuthID   string                 `json:"auth_id"`
	ClientID string                 `json:"client_id"`
	Scope    string                 `json:"scope"`
	ACR      string                 `json:"acr"`
	Claims   map[string]interface{} `json:"claims"`
	Session  string                 `json:"sid"`
	Conf     struct {
		Jkt string `json:"jkt"`
	} `json:"cnf"`
	Jti       string `json:"jti"`
	IssuedAt  int64  `json:"iat"`
	ExpiresAt int64  `json:"exp"`
	Typ       string `json:"typ"`
}

// SessionResponse is the administrative representation of a device SSO session. It deliberately
// omits the secret digest and every value that could be used to reconstruct a device secret.
type SessionResponse struct {
	SessionID string   `json:"sessionId"`
	ClientID  string   `json:"clientId"`
	Subject   string   `json:"subject"`
	AuthID    string   `json:"authId,omitempty"`
	ACR       string   `json:"acr,omitempty"`
	Scopes    []string `json:"scopes"`
	Status    string   `json:"status"`
	// DPoPThumbprint is the cnf.jkt of the session. It is a public key thumbprint (not key material)
	// and is what binds the session to a device-held key.
	DPoPThumbprint string     `json:"dpopThumbprint,omitempty"`
	CreatedAt      time.Time  `json:"createdAt"`
	ExpiresAt      time.Time  `json:"expiresAt"`
	RevokedAt      *time.Time `json:"revokedAt,omitempty"`
}

// SessionsListResponse is the response of the session listing API.
type SessionsListResponse struct {
	TotalResults int               `json:"totalResults"`
	Sessions     []SessionResponse `json:"sessions"`
}

// toSessionResponse converts a stored session into its API representation.
func toSessionResponse(record sessionRecord) SessionResponse {
	scopes := make([]string, len(record.Scopes))
	copy(scopes, record.Scopes)
	return SessionResponse{
		SessionID:      record.SessionID,
		ClientID:       record.ClientID,
		Subject:        record.Subject,
		AuthID:         record.AuthID,
		ACR:            record.ACR,
		Scopes:         scopes,
		Status:         record.Status,
		DPoPThumbprint: record.DPoPJkt,
		CreatedAt:      record.CreatedAt,
		ExpiresAt:      record.ExpiresAt,
		RevokedAt:      record.RevokedAt,
	}
}

// marshalClaims encodes claims without HTML escaping so the signed payload is byte-stable.
func marshalClaims(claims map[string]interface{}) ([]byte, error) {
	var buf bytes.Buffer
	encoder := json.NewEncoder(&buf)
	encoder.SetEscapeHTML(false)
	if err := encoder.Encode(claims); err != nil {
		return nil, err
	}
	// json.Encoder appends a newline; the JWS payload must not carry it.
	out := buf.Bytes()
	if n := len(out); n > 0 && out[n-1] == '\n' {
		out = out[:n-1]
	}
	return out, nil
}
