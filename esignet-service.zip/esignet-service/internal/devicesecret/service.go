/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

package devicesecret

import (
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"slices"
	"strings"
	"time"

	"github.com/google/uuid"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"

	"github.com/mosip/esignet/internal/clientmgmt"
	"github.com/mosip/esignet/internal/config"
	"github.com/mosip/esignet/internal/engine/shared"
	"github.com/mosip/esignet/internal/keymanager"
	"github.com/mosip/esignet/internal/keymanager/signature"
	applog "github.com/mosip/esignet/internal/log"
)

const (
	// ScopeDeviceSSO is the OpenID Connect Native SSO scope. It is repeated here (rather than imported
	// from the engine's internal constant, which is not importable) so client eligibility and scope
	// bookkeeping do not depend on engine internals.
	ScopeDeviceSSO = "device_sso"

	// additionalConfigNativeSSONativeClients is the client additional_config key listing additional
	// client ids that may redeem a device secret issued to this client, on top of the clients in the
	// same relying-party family. It lets a deployment model "same vendor certificate" explicitly when
	// its relying-party ids are not grouped that way.
	additionalConfigNativeSSONativeClients = "native_sso_allowed_clients"

	// additionalConfigAllowedAuthorizationScopes is the client additional_config key that lists the
	// authorization scopes a client may request (MOSIP "allowed_authorization_scopes").
	additionalConfigAllowedAuthorizationScopes = "allowed_authorization_scopes"

	// maxListLimit caps the page size of the administrative session listing.
	maxListLimit = 200

	// defaultListLimit is used when the caller does not ask for a page size.
	defaultListLimit = 50
)

// Config holds the tunables of the device secret provider.
type Config struct {
	// SecretValidityPeriod is the lifetime of an issued device secret.
	SecretValidityPeriod time.Duration
	// SessionValidityPeriod is the lifetime of the authentication session a device secret is bound
	// to. A device secret can never outlive its session.
	SessionValidityPeriod time.Duration
	// RequireSameRelyingParty requires the client redeeming a device secret to belong to the same
	// relying party (vendor family) as the client the secret was issued to. This is the default and
	// is what makes "apps signed by the same vendor" enforceable at the authorization server.
	RequireSameRelyingParty bool
}

// Service implements providers.DeviceSecretProvider for the ThunderID engine, backed by eSignet's key
// manager for signing and encryption and by PostgreSQL for session state.
type Service struct {
	store     *store
	clientSvc *clientmgmt.Service
	sigSvc    *signature.Service
	keyMgr    *keymanager.Service
	cfg       *config.AppConfig
	dsCfg     Config
	logger    *applog.Logger
	// usingDedicatedKey records whether the dedicated device-secret encryption key is in use (true) or
	// the cache-encryption fallback (false). Set during key resolution; informational only.
	usingDedicatedKey bool
}

// NewService builds the device secret provider.
func NewService(db *sql.DB, clientSvc *clientmgmt.Service, sigSvc *signature.Service,
	keyMgr *keymanager.Service, appCfg *config.AppConfig, dsCfg Config) *Service {
	if dsCfg.SecretValidityPeriod <= 0 {
		dsCfg.SecretValidityPeriod = time.Hour
	}
	if dsCfg.SessionValidityPeriod <= 0 {
		dsCfg.SessionValidityPeriod = 24 * time.Hour
	}
	if dsCfg.SessionValidityPeriod < dsCfg.SecretValidityPeriod {
		dsCfg.SessionValidityPeriod = dsCfg.SecretValidityPeriod
	}
	return &Service{
		store:     newStore(db),
		clientSvc: clientSvc,
		sigSvc:    sigSvc,
		keyMgr:    keyMgr,
		cfg:       appCfg,
		dsCfg:     dsCfg,
		logger:    applog.GetLogger().Named("deviceSecretProvider"),
	}
}

// GenerateDeviceSecret implements providers.DeviceSecretProvider. It mints a signed-then-encrypted
// JWT bound to the session, the DPoP key of the device and the client that obtained it, records the
// session server-side and returns the ds_hash to embed in the id_token.
func (s *Service) GenerateDeviceSecret(ctx context.Context,
	request *providers.DeviceSecretRequest) (*providers.DeviceSecretResponse, *tidcommon.ServiceError) {
	if request == nil || request.ClientID == "" || request.Subject == "" {
		return nil, shared.InvalidRequestError
	}

	// The device secret must be bound to a device key: without cnf.jkt it could be replayed by anyone
	// who obtains it, which defeats the purpose of the Native SSO handoff.
	if request.DPoPJkt == "" {
		s.logger.Warn(ctx, "refusing to issue a device secret without a DPoP thumbprint",
			applog.String("clientId", request.ClientID))
		return nil, shared.InvalidRequestError
	}

	sessionID := request.SessionID
	if sessionID == "" {
		sessionID = uuid.NewString()
	}

	now := time.Now().UTC()
	validity := s.dsCfg.SecretValidityPeriod
	if request.ValidityPeriod > 0 {
		validity = time.Duration(request.ValidityPeriod) * time.Second
	}
	expiresAt := now.Add(validity)

	// Session state may already exist for this sid (for example the login flow minted it as the token
	// family id). Reuse its creation time so the session lifetime is not extended by a rotation.
	createdAt := now
	if existing, err := s.store.getSession(ctx, sessionID); err == nil {
		createdAt = existing.CreatedAt
	} else if !errors.Is(err, ErrSessionNotFound) {
		s.logger.Error(ctx, "failed to read device sso session", applog.Error(err))
		return nil, shared.InternalServerError
	}
	sessionExpiry := createdAt.Add(s.dsCfg.SessionValidityPeriod)
	if sessionExpiry.Before(expiresAt) {
		// The secret can never outlive its session, otherwise a valid secret could reference a session
		// the server already considers dead.
		expiresAt = sessionExpiry
	}

	claims := map[string]interface{}{
		claimIss:      s.cfg.Issuer,
		claimSub:      request.Subject,
		claimAud:      request.ClientID,
		claimAuthID:   request.AuthID,
		claimClientID: request.ClientID,
		claimScope:    strings.Join(request.Scopes, " "),
		claimACR:      request.ACR,
		claimSID:      sessionID,
		claimJti:      uuid.NewString(),
		claimIat:      now.Unix(),
		claimExp:      expiresAt.Unix(),
		claimTyp:      typDeviceSecret,
		claimCnf:      map[string]interface{}{claimJkt: request.DPoPJkt},
	}
	if len(request.Claims) > 0 {
		claims[claimClaims] = request.Claims
	}

	deviceSecret, svcErr := s.signAndEncrypt(ctx, claims)
	if svcErr != nil {
		return nil, svcErr
	}

	secretHash := secretDigest(deviceSecret)
	record := sessionRecord{
		SessionID:  sessionID,
		ClientID:   request.ClientID,
		AuthID:     request.AuthID,
		Subject:    request.Subject,
		ACR:        request.ACR,
		Scopes:     request.Scopes,
		DPoPJkt:    request.DPoPJkt,
		SecretHash: secretHash,
		Status:     StatusActive,
		CreatedAt:  createdAt,
		ExpiresAt:  expiresAt,
	}
	if err := s.store.upsertSession(ctx, record); err != nil {
		s.logger.Error(ctx, "failed to record device sso session", applog.Error(err))
		return nil, shared.InternalServerError
	}

	s.logger.Info(ctx, "device secret issued",
		applog.String("clientId", request.ClientID),
		applog.String("sessionId", sessionID),
		applog.Int("scopeCount", len(request.Scopes)))

	return &providers.DeviceSecretResponse{
		DeviceSecret: deviceSecret,
		DSHash:       secretHash,
		ExpiresIn:    int64(time.Until(expiresAt).Seconds()),
		SessionID:    sessionID,
	}, nil
}

// ValidateDeviceSecret implements providers.DeviceSecretProvider. A presentation that fails any check
// returns Valid=false (reported to the client as invalid_grant); a ServiceError is reserved for
// infrastructure failures so the engine can answer server_error and fail closed.
func (s *Service) ValidateDeviceSecret(ctx context.Context,
	request *providers.DeviceSecretValidationRequest) (*providers.DeviceSecretValidationResponse,
	*tidcommon.ServiceError) {
	if request == nil || request.DeviceSecret == "" {
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}

	claims, svcErr := s.decryptAndVerify(ctx, request.DeviceSecret)
	if svcErr != nil {
		// A decryption/verification failure is an invalid secret, not a server fault: the engine maps
		// a nil ServiceError + Valid=false to invalid_grant.
		s.logger.Debug(ctx, "device secret rejected: cannot decrypt or verify",
			applog.String("errorCode", svcErr.Code))
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}

	if claims.Typ != typDeviceSecret {
		s.logger.Debug(ctx, "device secret rejected: wrong typ")
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}
	if claims.Issuer != s.cfg.Issuer {
		s.logger.Debug(ctx, "device secret rejected: issuer mismatch")
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}
	now := time.Now().UTC()
	if claims.ExpiresAt <= now.Unix() {
		s.logger.Debug(ctx, "device secret rejected: expired",
			applog.String("sessionId", claims.Session))
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}
	if claims.Conf.Jkt == "" {
		s.logger.Debug(ctx, "device secret rejected: not DPoP bound")
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}
	if claims.Session == "" || claims.ClientID == "" || claims.Subject == "" {
		s.logger.Debug(ctx, "device secret rejected: missing required claims")
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}

	record, err := s.store.getSession(ctx, claims.Session)
	if errors.Is(err, ErrSessionNotFound) {
		s.logger.Debug(ctx, "device secret rejected: unknown session",
			applog.String("sessionId", claims.Session))
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}
	if err != nil {
		s.logger.Error(ctx, "failed to read device sso session", applog.Error(err))
		return nil, shared.InternalServerError
	}

	// The session is the authority: a revoked or expired session invalidates every secret bound to it,
	// including secrets whose own exp has not passed yet.
	if record.Status != StatusActive || record.RevokedAt != nil {
		s.logger.Debug(ctx, "device secret rejected: session revoked",
			applog.String("sessionId", record.SessionID))
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}
	if !record.ExpiresAt.After(now) {
		s.logger.Debug(ctx, "device secret rejected: session expired",
			applog.String("sessionId", record.SessionID))
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}

	// The presented value must be the secret most recently issued for the session. An older secret
	// (after a rotation) is stale, and an unknown value means the token was not minted by this server.
	presentedDigest := secretDigest(request.DeviceSecret)
	if subtle.ConstantTimeCompare([]byte(presentedDigest), []byte(record.SecretHash)) != 1 {
		s.logger.Debug(ctx, "device secret rejected: value does not match the session",
			applog.String("sessionId", record.SessionID))
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}

	// The secret's own claims must agree with the stored session (defence in depth against a secret
	// minted for a different session under the same sid).
	if claims.ClientID != record.ClientID || claims.Subject != record.Subject {
		s.logger.Debug(ctx, "device secret rejected: claims do not match the session")
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}

	// Client sharing policy: only clients of the same vendor family may redeem the secret.
	if svcErr := s.enforceSharingPolicy(ctx, record.ClientID, request.RequestingClientID); svcErr != nil {
		s.logger.Debug(ctx, "device secret rejected: sharing policy",
			applog.String("clientId", request.RequestingClientID))
		return &providers.DeviceSecretValidationResponse{Valid: false}, nil
	}

	scopes := splitScopes(claims.Scope)

	return &providers.DeviceSecretValidationResponse{
		Valid:     true,
		ClientID:  record.ClientID,
		AuthID:    record.AuthID,
		SessionID: record.SessionID,
		Subject:   record.Subject,
		Scopes:    scopes,
		ACR:       record.ACR,
		Claims:    claims.Claims,
		DPoPJkt:   record.DPoPJkt,
		ExpiresAt: record.ExpiresAt.Unix(),
		DSHash:    secretDigest(request.DeviceSecret),
	}, nil
}

// enforceSharingPolicy decides whether requestingClientID may redeem a secret issued to ownerClientID.
// Both clients must exist and be active. The requesting client must additionally be allowed to perform
// a token exchange and to request device_sso; when RequireSameRelyingParty is set (the default) both
// clients must belong to the same relying party, which is how "signed by the same vendor" is modelled.
func (s *Service) enforceSharingPolicy(ctx context.Context, ownerClientID, requestingClientID string) *tidcommon.ServiceError {
	if requestingClientID == "" {
		return shared.InvalidRequestError
	}
	if requestingClientID == ownerClientID {
		return nil
	}

	requesting, err := s.clientSvc.GetActiveClient(ctx, requestingClientID)
	if err != nil {
		return nil // unknown/inactive client: the caller reports Valid=false
	}
	owner, err := s.clientSvc.GetActiveClient(ctx, ownerClientID)
	if err != nil {
		return nil
	}

	if !clientAllowsNativeSSO(requesting) || !clientAllowsNativeSSO(owner) {
		return nil
	}

	// An explicit allow-list on the issuing client always permits the exchange.
	if allowed := allowedClients(owner.AdditionalConfig); slices.Contains(allowed, requestingClientID) {
		return nil
	}
	if !s.dsCfg.RequireSameRelyingParty {
		return nil
	}
	if owner.RpID == "" || owner.RpID != requesting.RpID {
		return nil
	}
	return nil
}

// clientAllowsNativeSSO reports whether the client may take part in Native SSO: device_sso must be in
// its allowed authorization scopes and it must be permitted to use the token exchange grant type.
func clientAllowsNativeSSO(client clientmgmt.ClientResponse) bool {
	if !slices.Contains(shared.AllowedAuthorizationScopes(client.AdditionalConfig), ScopeDeviceSSO) {
		return false
	}
	for _, grantType := range client.GrantTypes {
		if grantType == string(providers.GrantTypeTokenExchange) {
			return true
		}
	}
	return false
}

// allowedClients reads the explicit Native SSO allow-list from additional_config.
func allowedClients(additionalConfig map[string]any) []string {
	if additionalConfig == nil {
		return nil
	}
	raw, ok := additionalConfig[additionalConfigNativeSSONativeClients]
	if !ok {
		return nil
	}
	switch value := raw.(type) {
	case []string:
		return value
	case []any:
		out := make([]string, 0, len(value))
		for _, item := range value {
			if asString, ok := item.(string); ok {
				out = append(out, asString)
			}
		}
		return out
	default:
		return nil
	}
}

// signAndEncrypt produces the device secret: a compact JWS signed with eSignet's OIDC service signing
// key, then wrapped in a compact JWE encrypted to the OIDC service encryption key. Both operations go
// through the key manager, so key material stays in the keystore/HSM.
func (s *Service) signAndEncrypt(ctx context.Context, claims map[string]interface{}) (string, *tidcommon.ServiceError) {
	payload, err := marshalClaims(claims)
	if err != nil {
		s.logger.Error(ctx, "failed to encode device secret claims", applog.Error(err))
		return "", shared.InternalServerError
	}

	signed, err := s.sigSvc.JWSSign(ctx, signature.JWSSignRequest{
		ApplicationID: config.OIDCServiceAppID,
		ReferenceID:   keymanager.RefIDECSECP256R1Sign,
		DataToSign:    base64.RawURLEncoding.EncodeToString(payload),
	})
	if err != nil {
		s.logger.Error(ctx, "failed to sign device secret", applog.Error(err))
		return "", shared.InternalServerError
	}

	encrypted, err := s.encryptJWE(ctx, signed.JWTSignedData)
	if err != nil {
		s.logger.Error(ctx, "failed to encrypt device secret", applog.Error(err))
		return "", shared.InternalServerError
	}
	if !s.usingDedicatedKey {
		s.logger.Warn(ctx, "device secrets are encrypted with the cache-encryption key; provision a "+
			"dedicated DEVICE_SECRET_ENCRYPT symmetric key and add it to KEYMANAGER_SYMMETRIC_KEY_ALLOWED_REF_IDS")
	}
	return encrypted, nil
}

// decryptAndVerify reverses signAndEncrypt: it decrypts the JWE with the OIDC service key, verifies the
// JWS signature with the OIDC service signing key and decodes the claims.
func (s *Service) decryptAndVerify(ctx context.Context, deviceSecret string) (*deviceSecretClaims,
	*tidcommon.ServiceError) {
	decrypted, err := s.decryptJWE(ctx, deviceSecret)
	if err != nil {
		return nil, shared.InvalidRequestError
	}

	verified, err := s.sigSvc.JWSVerify(ctx, signature.JWSVerifyRequest{
		ApplicationID:    config.OIDCServiceAppID,
		ReferenceID:      keymanager.RefIDECSECP256R1Sign,
		JWTSignatureData: decrypted,
	})
	if err != nil || !verified.SignatureValid {
		return nil, shared.InvalidRequestError
	}

	payload, err := payloadOf(decrypted)
	if err != nil {
		return nil, shared.InvalidRequestError
	}

	var claims deviceSecretClaims
	if err := json.Unmarshal(payload, &claims); err != nil {
		return nil, shared.InvalidRequestError
	}
	return &claims, nil
}

// payloadOf returns the decoded payload segment of a compact JWS.
func payloadOf(jws string) ([]byte, error) {
	parts := strings.Split(jws, ".")
	if len(parts) != 3 {
		return nil, fmt.Errorf("malformed JWS: expected 3 segments, got %d", len(parts))
	}
	return base64.RawURLEncoding.DecodeString(parts[1])
}

// secretDigest is the ds_hash construction: base64url(SHA-256(device_secret)), unpadded. It binds the
// id_token to the exact secret value without exposing the secret, and lets the server detect a stale or
// foreign value without storing it in plaintext.
func secretDigest(deviceSecret string) string {
	sum := sha256.Sum256([]byte(deviceSecret))
	return base64.RawURLEncoding.EncodeToString(sum[:])
}

// ListSessions returns the device SSO sessions matching the filters, for the identity dashboard and the
// administrative console.
func (s *Service) ListSessions(ctx context.Context, subject, clientID string, limit int) (
	*SessionsListResponse, error) {
	if limit <= 0 {
		limit = defaultListLimit
	}
	if limit > maxListLimit {
		limit = maxListLimit
	}
	records, err := s.store.listSessions(ctx, subject, clientID, limit)
	if err != nil {
		return nil, err
	}
	sessions := make([]SessionResponse, 0, len(records))
	for _, record := range records {
		sessions = append(sessions, toSessionResponse(record))
	}
	return &SessionsListResponse{TotalResults: len(sessions), Sessions: sessions}, nil
}

// GetSession returns a single session by id.
func (s *Service) GetSession(ctx context.Context, sessionID string) (*SessionResponse, error) {
	record, err := s.store.getSession(ctx, sessionID)
	if err != nil {
		return nil, err
	}
	response := toSessionResponse(record)
	return &response, nil
}

// RevokeSession revokes one session. An empty subject means "administrator action"; otherwise the
// session must belong to the subject.
func (s *Service) RevokeSession(ctx context.Context, sessionID, subject string) error {
	return s.store.revokeSession(ctx, sessionID, subject)
}

// RevokeAllSessions revokes every active session of a subject.
func (s *Service) RevokeAllSessions(ctx context.Context, subject string) (int, error) {
	return s.store.revokeSessionsForSubject(ctx, subject)
}

// ExpireStaleSessions flips expired sessions to EXPIRED. It is safe to call on any request path.
func (s *Service) ExpireStaleSessions(ctx context.Context) (int, error) {
	return s.store.markExpiredSessions(ctx, time.Now().UTC())
}
