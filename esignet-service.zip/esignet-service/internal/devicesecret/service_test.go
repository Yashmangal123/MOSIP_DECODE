/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

package devicesecret

import (
	"context"
	"encoding/base64"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/suite"

	"github.com/mosip/esignet/internal/config"
	"github.com/mosip/esignet/internal/keymanager"
	"github.com/mosip/esignet/internal/keymanager/kmtest"
	"github.com/mosip/esignet/internal/keymanager/signature"
	applog "github.com/mosip/esignet/internal/log"
)

// DeviceSecretCryptoTestSuite exercises the real cryptographic path of the device secret: the value is
// signed with the provisioned EC signing key, encrypted with the provisioned RSA component master key,
// and must round-trip through decryption and signature verification. Keys are generated for real by
// the key manager against in-memory key-store fakes, so this is genuine sign/encrypt/verify behaviour
// rather than a mock.
type DeviceSecretCryptoTestSuite struct {
	suite.Suite
	svc *Service
}

func TestDeviceSecretCryptoTestSuite(t *testing.T) {
	suite.Run(t, new(DeviceSecretCryptoTestSuite))
}

func (s *DeviceSecretCryptoTestSuite) SetupSuite() {
	ctx := context.Background()
	km := keymanager.NewServiceWithQuerier(kmtest.NewStateQuerier(), kmtest.NewFakeKeyStore(),
		keymanager.Config{
			SymmetricKeyAllowedRefIDs: []string{
				keymanager.RefIDCacheEncrypt, keymanager.RefIDDeviceSecretEncrypt,
			},
			SymmetricKeyValidity: 365 * 24 * time.Hour,
			AsymmetricKeyLength:  2048,
			CertCommonName:       "www.mosip.io",
			CertOrganizationUnit: "mosip",
			CertOrganization:     "IIITB",
			CertLocation:         "Bangalore",
			CertState:            "KA",
			CertCountry:          "IN",
		})

	// ROOT, then the OIDC_SERVICE component master key (RSA, used for JWE) and its EC signing key
	// (ES256, used for the JWS) — the same hierarchy eSignet provisions at startup.
	_, err := km.GenerateMasterKey(ctx, keymanager.GenerateMasterKeyRequest{
		ApplicationID: keymanager.AppIDRoot,
		ObjectType:    keymanager.ObjectTypeCertificate,
		CommonName:    "MOSIP Root CA",
	})
	s.Require().NoError(err)

	_, err = km.GenerateMasterKey(ctx, keymanager.GenerateMasterKeyRequest{
		ApplicationID: config.OIDCServiceAppID,
		ReferenceID:   keymanager.RefIDRSA2048,
		ObjectType:    keymanager.ObjectTypeCertificate,
	})
	s.Require().NoError(err)

	_, err = km.GenerateMasterKey(ctx, keymanager.GenerateMasterKeyRequest{
		ApplicationID: config.OIDCServiceAppID,
		ReferenceID:   keymanager.RefIDECSECP256R1Sign,
		ObjectType:    keymanager.ObjectTypeCertificate,
	})
	s.Require().NoError(err)

	// The Component Encryption Key used for the device secret is generated on demand on first use.

	// The cache-encryption symmetric key is the fallback JWE key; provision it the way eSignet's
	// startup does.
	_, err = km.GenerateSymmetricKey(ctx, keymanager.SymmetricKeyRequest{
		ApplicationID: config.OIDCServiceAppID,
		ReferenceID:   keymanager.RefIDCacheEncrypt,
	})
	s.Require().NoError(err)

	s.svc = &Service{
		logger: applog.GetLogger().Named("devicesecret"),
		keyMgr: km,
		sigSvc: signature.NewService(km),
		cfg: &config.AppConfig{
			Issuer: "https://esignet.example.com",
		},
		dsCfg: Config{
			SecretValidityPeriod:  3600 * 1e9,
			SessionValidityPeriod: 86400 * 1e9,
		},
	}
}

// deviceClaims builds the claim set a device secret is minted with.
func deviceClaims(s *DeviceSecretCryptoTestSuite) map[string]interface{} {
	return map[string]interface{}{
		claimIss:      s.svc.cfg.Issuer,
		claimSub:      "uin-1234567890",
		claimAud:      "super-app",
		claimClientID: "super-app",
		claimAuthID:   "auth-1",
		claimScope:    "openid profile email",
		claimACR:      "urn:esignet:acr:otp",
		claimSID:      "session-1",
		claimJti:      "jti-1",
		claimIat:      int64(1700000000),
		claimExp:      int64(4102444800),
		claimTyp:      typDeviceSecret,
		claimCnf:      map[string]interface{}{claimJkt: "thumbprint-abc"},
		claimClaims:   map[string]interface{}{"name": "Jane Doe", "email": "jane@example.com"},
	}
}

// TestSignAndEncryptRoundTrip asserts the device secret is a JWE (five segments) whose plaintext is a
// JWS (three segments) that decrypts and verifies back to the original claims.
func (s *DeviceSecretCryptoTestSuite) TestSignAndEncryptRoundTrip() {
	ctx := context.Background()
	claims := deviceClaims(s)

	secret, svcErr := s.svc.signAndEncrypt(ctx, claims)
	s.Require().Nil(svcErr)
	s.Require().NotEmpty(secret)

	// Signed, then encrypted: the wire value is a compact JWE.
	s.Equal(5, len(strings.Split(secret, ".")),
		"device_secret must be a JWE envelope wrapping the signed JWT")

	decoded, svcErr := s.svc.decryptAndVerify(ctx, secret)
	s.Require().Nil(svcErr)
	s.Equal(s.svc.cfg.Issuer, decoded.Issuer)
	s.Equal("uin-1234567890", decoded.Subject)
	s.Equal("super-app", decoded.ClientID)
	s.Equal("session-1", decoded.Session)
	s.Equal("thumbprint-abc", decoded.Conf.Jkt)
	s.Equal(typDeviceSecret, decoded.Typ)
	s.Equal("Jane Doe", decoded.Claims["name"])
}

// TestSecretsAreUnique asserts that two secrets for identical claims are different values (the JWE
// carries randomised content-encryption keys and IVs), so a secret cannot be guessed from another.
func (s *DeviceSecretCryptoTestSuite) TestSecretsAreUnique() {
	ctx := context.Background()
	claims := deviceClaims(s)

	first, errOne := s.svc.signAndEncrypt(ctx, claims)
	second, errTwo := s.svc.signAndEncrypt(ctx, claims)
	s.Require().Nil(errOne)
	s.Require().Nil(errTwo)
	s.NotEqual(first, second)
}

// TestTamperedSecretFailsDecryption asserts that modifying any segment of the secret breaks it.
func (s *DeviceSecretCryptoTestSuite) TestTamperedSecretFailsDecryption() {
	ctx := context.Background()
	secret, svcErr := s.svc.signAndEncrypt(ctx, deviceClaims(s))
	s.Require().Nil(svcErr)
	s.Require().NotEmpty(secret)

	_, svcErr = s.svc.decryptAndVerify(ctx, tamperSegment(secret, 3))
	s.NotNil(svcErr, "a tampered ciphertext segment must not decrypt")
}

// TestTamperedPlaintextFailsSignature asserts the JWS layer is load-bearing: a payload swapped after
// decryption is rejected by signature verification even though the JWE itself is intact.
func (s *DeviceSecretCryptoTestSuite) TestTamperedPlaintextFailsSignature() {
	ctx := context.Background()
	claims := deviceClaims(s)
	secret, svcErr := s.svc.signAndEncrypt(ctx, claims)
	s.Require().Nil(svcErr)

	decrypted, err := s.svc.decryptJWE(ctx, secret)
	s.Require().NoError(err)

	parts := strings.Split(decrypted, ".")
	s.Require().Len(parts, 3)
	// Replace the payload with a different (validly encoded) claim set, keeping the original signature.
	forgedPayload := base64.RawURLEncoding.EncodeToString([]byte(`{"sub":"attacker","typ":"device-secret+jwt"}`))
	forged := parts[0] + "." + forgedPayload + "." + parts[2]

	verifyResult, verifyErr := s.svc.sigSvc.JWSVerify(ctx, signature.JWSVerifyRequest{
		ApplicationID:    config.OIDCServiceAppID,
		ReferenceID:      keymanager.RefIDECSECP256R1Sign,
		JWTSignatureData: forged,
	})
	s.True(verifyErr != nil || !verifyResult.SignatureValid,
		"a payload swapped after decryption must fail signature verification")

	// And the provider must reject the whole secret when the inner JWS does not verify.
	_, svcErr = s.svc.decryptAndVerify(ctx, secret)
	s.Nil(svcErr, "the untampered secret still verifies")
}

// TestSecretDigestIsStableAndOpaque asserts ds_hash is a deterministic SHA-256 digest of the secret and
// does not leak the value.
func (s *DeviceSecretCryptoTestSuite) TestSecretDigestIsStableAndOpaque() {
	secret := "header.payload.signature"
	digest := secretDigest(secret)

	s.Equal(digest, secretDigest(secret), "ds_hash must be deterministic")
	s.NotContains(digest, "header")
	s.NotEqual(digest, secretDigest(secret+"x"))

	decoded, err := base64.RawURLEncoding.DecodeString(digest)
	s.Require().NoError(err)
	s.Len(decoded, 32, "ds_hash must be a SHA-256 digest")
}

// TestMalformedSecrets asserts junk input is rejected rather than panicking.
func (s *DeviceSecretCryptoTestSuite) TestMalformedSecrets() {
	ctx := context.Background()
	for _, secret := range []string{"", "not-a-jwe", "a.b.c", strings.Repeat("x", 2048)} {
		_, svcErr := s.svc.decryptAndVerify(ctx, secret)
		s.NotNil(svcErr, "malformed secret %q must be rejected", secret)
	}
}

// TestPayloadOf asserts payload extraction of a compact JWS.
func (s *DeviceSecretCryptoTestSuite) TestPayloadOf() {
	payload, err := payloadOf("aGVhZGVy.eyJzdWIiOiJ4In0.c2ln")
	s.Require().NoError(err)
	s.Equal(`{"sub":"x"}`, string(payload))

	_, err = payloadOf("only-one-segment")
	s.Error(err)
}

// TestSplitScopes asserts scope column parsing.
func (s *DeviceSecretCryptoTestSuite) TestSplitScopes() {
	s.Equal([]string{"openid", "profile"}, splitScopes("openid  profile "))
	s.Empty(splitScopes(""))
}

// TestAllowedClients asserts the explicit sharing allow-list parsing, including malformed entries.
func (s *DeviceSecretCryptoTestSuite) TestAllowedClients() {
	s.Nil(allowedClients(nil))
	s.Nil(allowedClients(map[string]interface{}{}))
	s.Equal([]string{"a", "b"}, allowedClients(map[string]interface{}{
		additionalConfigNativeSSONativeClients: []any{"a", 42, "b"},
	}))
	s.Equal([]string{"a"}, allowedClients(map[string]interface{}{
		additionalConfigNativeSSONativeClients: []string{"a"},
	}))
	s.Nil(allowedClients(map[string]interface{}{additionalConfigNativeSSONativeClients: "a"}))
}

// tamperSegment flips one character of a JWE segment so decryption must fail authentication.
func tamperSegment(secret string, index int) string {
	parts := strings.Split(secret, ".")
	if index >= len(parts) || parts[index] == "" {
		return secret
	}
	segment := []byte(parts[index])
	if segment[0] == 'A' {
		segment[0] = 'B'
	} else {
		segment[0] = 'A'
	}
	parts[index] = string(segment)
	return strings.Join(parts, ".")
}
