/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

package devicesecret

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"
)

// ErrSessionNotFound is returned when a session id has no record.
var ErrSessionNotFound = errors.New("device sso session not found")

// store owns the persistence of device SSO sessions. The table is declared in
// db_scripts/mosip_esignet/ddl/esignet-device_sso_session.sql and created by the migration in
// db_upgrade_script/mosip_esignet/sql (see docs/database.md).
//
// The queries are written by hand rather than generated with sqlc: this table is created by a new
// migration in this fork and adding it to the sqlc configuration would require regenerating every
// generated file in the repository. The column list is deliberately small and the queries are pinned
// to named parameters so the generated clientmgmt layer stays untouched.
type store struct {
	db *sql.DB
}

func newStore(db *sql.DB) *store {
	return &store{db: db}
}

// upsertSession records (or replaces) the session a device secret is bound to. A repeated issuance
// for the same session id (secret rotation) refreshes the digest and expiry of the existing row
// instead of creating a second session, so a device never accumulates competing sessions.
func (s *store) upsertSession(ctx context.Context, record sessionRecord) error {
	const query = `
		INSERT INTO device_sso_session (
			session_id, client_id, auth_id, subject_id, acr, scopes, dpop_jkt, secret_hash,
			session_status, cr_dtimes, expiry_dtimes
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
		ON CONFLICT (session_id) DO UPDATE SET
			secret_hash    = EXCLUDED.secret_hash,
			scopes         = EXCLUDED.scopes,
			acr            = EXCLUDED.acr,
			dpop_jkt       = EXCLUDED.dpop_jkt,
			expiry_dtimes  = EXCLUDED.expiry_dtimes,
			upd_dtimes     = now()
		WHERE device_sso_session.session_status = 'ACTIVE'`

	_, err := s.db.ExecContext(ctx, query,
		record.SessionID, record.ClientID, record.AuthID, record.Subject, record.ACR,
		strings.Join(record.Scopes, " "), record.DPoPJkt, record.SecretHash,
		StatusActive, record.CreatedAt, record.ExpiresAt)
	if err != nil {
		return fmt.Errorf("upsert device sso session: %w", err)
	}
	return nil
}

// getSession loads a session by id. A missing row yields ErrSessionNotFound.
func (s *store) getSession(ctx context.Context, sessionID string) (sessionRecord, error) {
	const query = `
		SELECT session_id, client_id, auth_id, subject_id, COALESCE(acr, ''), scopes, dpop_jkt,
		       secret_hash, session_status, cr_dtimes, expiry_dtimes, revoked_dtimes
		FROM device_sso_session
		WHERE session_id = $1`

	var record sessionRecord
	var scopes string
	var revokedAt sql.NullTime
	err := s.db.QueryRowContext(ctx, query, sessionID).Scan(
		&record.SessionID, &record.ClientID, &record.AuthID, &record.Subject, &record.ACR, &scopes,
		&record.DPoPJkt, &record.SecretHash, &record.Status, &record.CreatedAt, &record.ExpiresAt,
		&revokedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return sessionRecord{}, ErrSessionNotFound
	}
	if err != nil {
		return sessionRecord{}, fmt.Errorf("get device sso session: %w", err)
	}
	record.Scopes = splitScopes(scopes)
	if revokedAt.Valid {
		revoked := revokedAt.Time
		record.RevokedAt = &revoked
	}
	return record, nil
}

// listSessions returns the sessions matching the optional subject and client filters, newest first.
func (s *store) listSessions(ctx context.Context, subject, clientID string, limit int) (
	[]sessionRecord, error) {
	query := `
		SELECT session_id, client_id, auth_id, subject_id, COALESCE(acr, ''), scopes, dpop_jkt,
		       secret_hash, session_status, cr_dtimes, expiry_dtimes, revoked_dtimes
		FROM device_sso_session
		WHERE ($1 = '' OR subject_id = $1)
		  AND ($2 = '' OR client_id = $2)
		ORDER BY cr_dtimes DESC
		LIMIT $3`

	rows, err := s.db.QueryContext(ctx, query, subject, clientID, limit)
	if err != nil {
		return nil, fmt.Errorf("list device sso sessions: %w", err)
	}
	defer func() { _ = rows.Close() }()

	sessions := make([]sessionRecord, 0)
	for rows.Next() {
		var record sessionRecord
		var scopes string
		var revokedAt sql.NullTime
		if err := rows.Scan(&record.SessionID, &record.ClientID, &record.AuthID, &record.Subject,
			&record.ACR, &scopes, &record.DPoPJkt, &record.SecretHash, &record.Status,
			&record.CreatedAt, &record.ExpiresAt, &revokedAt); err != nil {
			return nil, fmt.Errorf("scan device sso session: %w", err)
		}
		record.Scopes = splitScopes(scopes)
		if revokedAt.Valid {
			revoked := revokedAt.Time
			record.RevokedAt = &revoked
		}
		sessions = append(sessions, record)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate device sso sessions: %w", err)
	}
	return sessions, nil
}

// revokeSession marks one session revoked. subject restricts the operation to the owner of the
// session: an end-user initiated revocation passes the authenticated subject, while an administrator
// action passes an empty subject. Returns ErrSessionNotFound when the session does not exist or does
// not belong to subject.
func (s *store) revokeSession(ctx context.Context, sessionID, subject string) error {
	const query = `
		UPDATE device_sso_session
		SET session_status = $1, revoked_dtimes = now(), upd_dtimes = now()
		WHERE session_id = $2
		  AND session_status = $3
		  AND ($4 = '' OR subject_id = $4)`

	result, err := s.db.ExecContext(ctx, query, StatusRevoked, sessionID, StatusActive, subject)
	if err != nil {
		return fmt.Errorf("revoke device sso session: %w", err)
	}
	affected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("revoke device sso session: %w", err)
	}
	if affected == 0 {
		return ErrSessionNotFound
	}
	return nil
}

// revokeSessionsForSubject revokes every active session of a subject and reports how many were
// revoked. This is the cross-application session revocation path: all Native SSO sessions of the user
// die together, which invalidates every device secret derived from them.
func (s *store) revokeSessionsForSubject(ctx context.Context, subject string) (int, error) {
	const query = `
		UPDATE device_sso_session
		SET session_status = $1, revoked_dtimes = now(), upd_dtimes = now()
		WHERE subject_id = $2 AND session_status = $3`

	result, err := s.db.ExecContext(ctx, query, StatusRevoked, subject, StatusActive)
	if err != nil {
		return 0, fmt.Errorf("revoke device sso sessions: %w", err)
	}
	affected, err := result.RowsAffected()
	if err != nil {
		return 0, fmt.Errorf("revoke device sso sessions: %w", err)
	}
	return int(affected), nil
}

// markExpiredSessions flips sessions past their expiry to EXPIRED and reports how many changed. It is
// called opportunistically on validation so the table cannot accumulate stale ACTIVE rows even when
// no cleanup job runs; a scheduled cleanup is still provisioned (see db migration comments).
func (s *store) markExpiredSessions(ctx context.Context, now time.Time) (int, error) {
	const query = `
		UPDATE device_sso_session
		SET session_status = $1, upd_dtimes = now()
		WHERE session_status = $2 AND expiry_dtimes <= $3`

	result, err := s.db.ExecContext(ctx, query, StatusExpired, StatusActive, now)
	if err != nil {
		return 0, fmt.Errorf("expire device sso sessions: %w", err)
	}
	affected, err := result.RowsAffected()
	if err != nil {
		return 0, fmt.Errorf("expire device sso sessions: %w", err)
	}
	return int(affected), nil
}

// splitScopes splits the space-delimited scope column into a slice, dropping empty values.
func splitScopes(scopes string) []string {
	fields := strings.Fields(scopes)
	out := make([]string, 0, len(fields))
	for _, field := range fields {
		if field != "" {
			out = append(out, field)
		}
	}
	return out
}
