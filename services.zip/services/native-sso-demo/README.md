# Native SSO demo (the part you can click)

This is a **runnable demonstration of OpenID Connect Native SSO**: a real login page, two "apps" that
behave like mobile apps on one phone, a real one-time code sent to a real inbox, and RFC 8693 token
exchange using `device_secret`.

It answers the question "where do I log in as a citizen?" — at <http://localhost:8091>.

```
Citizen → Super App → eSignet login page (real OTP) → consent → code
                                       ↓
                  token endpoint: access_token, id_token, refresh_token,
                  device_secret (JWT, typ "sso-session+jwt") + session_data
                                       ↓
Child App → token endpoint: grant_type=token-exchange,
            subject_token = <the device_secret>, subject_token_type=…:jwt
                                       ↓
                        own tokens for the same session, no code
```

The shape is copied from the engine, not invented: `docs/upstream-native-sso.md` lists where
`thunderid-engine` implements exactly this (`BuildDeviceSecret`, `ValidateDeviceSecret`,
`handleDeviceSecretGrant`, `typ = sso-session+jwt`).

## Run it (two terminals)

**Terminal 1 — the platform service** (identity + OTP delivery); see `../platform/README.md`:

```bash
cd ../platform
set -a && . ./.env && set +a        # PostgreSQL, SMTP and the internal API key
go run ./cmd/platform               # http://localhost:8090
```

**Terminal 2 — the Native SSO demo:**

```bash
cd services/native-sso-demo
cp .env.example .env                 # then edit the two values marked CHANGE_ME
set -a && . ./.env && set +a
go run .
```

Open **<http://localhost:8091>**.

## What to do on screen

1. **Open Super App** → *Sign in with eSignet*.
2. Type the email address (or UIN) of a citizen registered in the platform, e.g. the one you created with
   `platform add-user`. Press **Send my code**.
3. Check your inbox — the code comes from the platform's SMTP provider. Enter it.
4. Read the consent screen. `device_sso` is listed: it is what allows the second app to skip the code.
   Press **Allow**.
5. You land back in the Super App, signed in. The right-hand panel shows the tokens, `sid`, the
   `session_data` (`flow_identifier`, `session_handle`) and the `device_secret` JWT.
6. Press **Open Child App** → **Continue with this device**. No code is requested: the app sends a
   token exchange with the `device_secret` as the `subject_token`.
7. Both apps now show the **same `sid`** — one session, two apps. That is Native SSO.

Try the failure paths too: restart the demo (which drops the session) and press **Continue with this
device** again — the answer is `interaction_required`, which is exactly what a real app checks to decide
"show the login screen again". `POST /oauth2/revoke` with a refresh token kills the session immediately and
produces the same answer.

## Configuration

Every value comes from the environment — nothing is hardcoded.

| Variable | Default | Meaning |
| --- | --- | --- |
| `SSO_ADDR` | `:8091` | listen address |
| `SSO_ISSUER` | `http://localhost:8091` | issuer URL used in tokens |
| `SSO_PLATFORM_URL` | `http://127.0.0.1:8090` | platform service (identity + OTP) |
| `SSO_PLATFORM_API_KEY` | — **required** | value of the platform's `PLATFORM_API_KEY` |
| `SSO_CLIENT_SECRET` | — **required** | signs the demo tokens; any long random string |
| `SSO_DEVICE_SECRET_VALIDITY` | `1h` | lifetime of a `device_secret` |
| `SSO_SESSION_VALIDITY` | `24h` | lifetime of the `sid` |
| `SSO_LAB_OTP` | *(unset)* | **tests only**: fixed code, no e-mail is sent |

Generate the signing key with `openssl rand -base64 32`.

## Replaying it with curl

```bash
# 1. authorization request (PKCE verifier "verifier-...", challenge computed with SHA-256)
curl -s "localhost:8091/oauth2/authorize?client_id=super-app&response_type=code\
&redirect_uri=http%3A%2F%2Flocalhost%3A8091%2Fapp%2Fcallback%3Fclient%3Dsuper-app\
&scope=openid%20profile%20email%20device_sso&state=s1\
&code_challenge=$(printf %s verifier-1234567890abcdef | openssl dgst -sha256 -binary | base64 | tr '+/' '-_' | tr -d '=')\
&code_challenge_method=S256"

# 2. send and verify the code (sid comes from the page above)
curl -s -X POST localhost:8091/oauth2/login -d "sid=<sid>&step=send&identifier=you@example.com"
curl -s -X POST localhost:8091/oauth2/login -d "sid=<sid>&step=verify&otp=<code>"

# 3. consent -> 302 with code
curl -si -X POST localhost:8091/oauth2/consent -d "sid=<sid>&action=allow" | grep -i location

# 4. redeem the code: note device_secret (a JWT), session_data and sid in the answer
curl -s -X POST localhost:8091/oauth2/token -d "grant_type=authorization_code&client_id=super-app\
&code=<code>&redirect_uri=http://localhost:8091/app/callback?client=super-app&code_verifier=verifier-1234567890abcdef"

# 5. second app redeems the device_secret — no code, no user interaction
curl -s -X POST localhost:8091/oauth2/token \
  -d "grant_type=urn:ietf:params:oauth:grant-type:token-exchange&client_id=child-app\
&subject_token=<id_token>&subject_token_type=urn:ietf:params:oauth:token-type:id_token\
&device_secret=<device_secret>&scope=openid profile"

# 6. call userinfo with the exchanged token
curl -s localhost:8091/oauth2/userinfo -H "Authorization: Bearer <access_token>"
```

## "No e-mail is arriving"

Run the built-in check — it prints the exact reason, in order:

```bash
go run . --check you@example.com
```

It verifies the internal API key, the platform health, and whether the platform accepted the message.
Then look at what the mail provider said:

```bash
psql "postgres://platform:platform@127.0.0.1:5432/esignet_platform?sslmode=disable" \
  -Atc "select delivery_status, error_code, cr_dtimes from platform.otp_delivery order by cr_dtimes desc limit 3;"
```

| `error_code` | Meaning | Fix |
| --- | --- | --- |
| `auth_failed` | the SMTP provider rejected the credentials | make a **new** Gmail App Password and restart the platform |
| `provider_rejected` | the provider refused this message (sender not verified, DLT, quota) | verify the From domain / raise the quota |
| `timeout` | the relay did not answer | check network / host / port |
| `smtp_permanent_failure` | 5xx from the relay | read the platform log line for the server's reply |

A `400 {"error":{"code":"otp_send_failed"}}` from the platform means *the message never left* — it is never
a silent success.

## Tests

```bash
go test ./... -v
```

Covers: the full flow, the `sso-session+jwt` typ and `session_data`, `sid` in the id token, the exchange
keeping the same `sid`, refresh-token rotation, revocation → `interaction_required`, an id token or a
tampered secret presented as a subject token, `actor_token`, non-access `requested_token_type`, scope
widening, `device_sso` refused inside an exchange, PKCE mismatch, code reuse, client binding, and every
authorize-time validation.

## This is a reference implementation, not eSignet

| | here | production eSignet |
| --- | --- | --- |
| signing | HS256 with a shared secret | RS256/PS512 via the key manager |
| storage | in memory | the engine's session store (`esignet.device_sso_session` in our migration) |
| sessions | demo sessions | eSignet authentication sessions (`sid` = token family) |
| consent/login UI | demo pages | eSignet's own UI using the OTP API |

The protocol behaviour — `device_sso` as a token-endpoint modifier, a `sso-session+jwt` device secret
carrying `session_data`, redemption as the `subject_token` of a token exchange, `interaction_required` when
the session cannot be used silently — is the engine's own behaviour, documented with source references in
`../../docs/upstream-native-sso.md`.
