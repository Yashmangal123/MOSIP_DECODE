module github.com/mosip/esignet-native-sso-demo

go 1.22
