package main

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// ---------------------------------------------------------------------------
// crypto helpers used by the JWT code in main.go
// ---------------------------------------------------------------------------

func hmacSHA256(key, message []byte) []byte {
	mac := hmac.New(sha256.New, key)
	mac.Write(message)
	return mac.Sum(nil)
}

// subtleCompare returns 1 when a == b, 0 otherwise, in constant time.
func subtleCompare(a, b string) int {
	if hmac.Equal([]byte(a), []byte(b)) {
		return 1
	}
	return 0
}

// ---------------------------------------------------------------------------
// demo application registry
// ---------------------------------------------------------------------------

type demoClient struct {
	ID          string
	Name        string
	Description string
	// Scopes the app is allowed to ask for.
	AllowedScopes []string
}

func (s *server) clients() map[string]demoClient {
	common := []string{"openid", "profile", "email", "phone", "device_sso"}
	return map[string]demoClient{
		"super-app": {
			ID: "super-app", Name: "MOSIP Super App",
			Description:   "The primary app on the phone. Signs the citizen in and receives the device_secret.",
			AllowedScopes: common,
		},
		"child-app": {
			ID: "child-app", Name: "Child App (e.g. Health)",
			Description:   "A second app on the same device. Never asks for a code: it redeems the device_secret.",
			AllowedScopes: common,
		},
	}
}

// redirectURI is the registered callback for a client.
func (s *server) redirectURI(clientID string) string {
	return s.cfg.issuer + "/app/callback?client=" + url.QueryEscape(clientID)
}

// redirectURIOK accepts the registered callback for a client on the host that served the request, so
// the demo works on localhost, behind nginx, or through a preview tunnel without reconfiguration.
func (s *server) redirectURIOK(r *http.Request, clientID, candidate string) bool {
	parsed, err := url.Parse(candidate)
	if err != nil || parsed.Path != "/app/callback" {
		return false
	}
	if parsed.Query().Get("client") != clientID {
		return false
	}
	if parsed.Scheme != "http" && parsed.Scheme != "https" {
		return false
	}
	return parsed.Host == r.Host
}

// ---------------------------------------------------------------------------
// GET /oauth2/authorize
// ---------------------------------------------------------------------------

func (s *server) handleAuthorize(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	clientID := q.Get("client_id")
	client, ok := s.clients()[clientID]
	if !ok {
		s.renderError(w, http.StatusBadRequest, "unknown_client",
			fmt.Sprintf("client_id %q is not registered with this authorization server", clientID))
		return
	}
	if q.Get("response_type") != "code" {
		s.redirectError(w, r, "unsupported_response_type", "only response_type=code is supported")
		return
	}
	if !s.redirectURIOK(r, clientID, q.Get("redirect_uri")) {
		s.renderError(w, http.StatusBadRequest, "invalid_redirect_uri",
			fmt.Sprintf("redirect_uri must be %s (the host of this request is honoured, so the same "+
				"deployment works behind a proxy or a tunnel)", s.redirectURI(clientID)))
		return
	}
	scopes := splitScopes(q.Get("scope"))
	if !contains(scopes, "openid") {
		s.redirectError(w, r, "invalid_scope", "the openid scope is required")
		return
	}
	for _, sc := range scopes {
		if !contains(client.AllowedScopes, sc) {
			s.redirectError(w, r, "invalid_scope", "scope not allowed for this client: "+sc)
			return
		}
	}
	// RFC 7636: native apps must use PKCE. Enforced here so the demo shows the real shape.
	challenge, method := q.Get("code_challenge"), q.Get("code_challenge_method")
	if challenge == "" || (method != "S256" && method != "plain") {
		s.redirectError(w, r, "invalid_request", "PKCE code_challenge with method S256 is required")
		return
	}

	req := &authRequest{
		ID: newID(), ClientID: clientID, RedirectURI: q.Get("redirect_uri"),
		Scope: scopes, State: q.Get("state"), CodeChallenge: challenge, CodeMethod: method,
		CreatedAt: s.store.now(),
	}
	s.store.mu.Lock()
	s.store.requests[req.ID] = req
	s.store.mu.Unlock()

	s.renderLogin(w, req, "", "", "")
}

// handleLogin drives the two login steps: send the code, then verify it.
func (s *server) handleLogin(w http.ResponseWriter, r *http.Request) {
	form, ok := s.decodeForm(w, r)
	if !ok {
		return
	}
	s.store.mu.Lock()
	req, exists := s.store.requests[form["sid"]]
	s.store.mu.Unlock()
	if !exists {
		s.renderError(w, http.StatusBadRequest, "expired_request",
			"This sign-in attempt expired. Start again from the app.")
		return
	}

	switch form["step"] {
	case "send":
		identifier := strings.TrimSpace(strings.ToLower(form["identifier"]))
		if identifier == "" {
			s.renderLogin(w, req, "", "Enter your email address or UIN.", "")
			return
		}
		// Lab mode exists only for automated tests; a normal run always mails a real code.
		if s.cfg.labOTP != "" {
			s.store.mu.Lock()
			req.TransactionID = "lab-" + req.ID[:8]
			req.Identifier = identifier
			s.store.mu.Unlock()
			s.renderOTP(w, req, "••••••", "lab mode", "")
			return
		}
		masked, err := s.sendOTP(r.Context(), identifier)
		if err != nil {
			s.log.Warn("otp send failed", "error", err.Error())
			s.renderLogin(w, req, identifier, err.Error(), "")
			return
		}
		s.store.mu.Lock()
		req.TransactionID = masked.transactionID
		req.Identifier = identifier
		s.store.mu.Unlock()
		s.renderOTP(w, req, masked.destination, masked.provider, "")

	case "verify":
		code := strings.TrimSpace(form["otp"])
		if s.cfg.labOTP != "" {
			if code != s.cfg.labOTP {
				s.renderOTP(w, req, "••••••", "lab mode", "That code is not correct.")
				return
			}
			s.store.mu.Lock()
			req.UIN = req.Identifier
			req.AuthenticatedAt = s.store.now()
			s.store.mu.Unlock()
			s.renderConsent(w, req)
			return
		}
		uin, err := s.verifyOTP(r.Context(), req.TransactionID, code)
		if err != nil {
			s.renderOTP(w, req, "••••••", "email", err.Error())
			return
		}
		s.store.mu.Lock()
		req.UIN = uin
		req.AuthenticatedAt = s.store.now()
		s.store.mu.Unlock()
		s.renderConsent(w, req)

	default:
		s.renderError(w, http.StatusBadRequest, "invalid_request", "unknown step")
	}
}

// handleConsent finishes the request: it creates the session and redirects with a code.
func (s *server) handleConsent(w http.ResponseWriter, r *http.Request) {
	form, ok := s.decodeForm(w, r)
	if !ok {
		return
	}
	s.store.mu.Lock()
	req, exists := s.store.requests[form["sid"]]
	s.store.mu.Unlock()
	if !exists || req.AuthenticatedAt.IsZero() {
		s.renderError(w, http.StatusBadRequest, "expired_request", "This sign-in attempt expired.")
		return
	}
	if form["action"] != "allow" {
		s.redirectError(w, r, "access_denied", "The citizen declined to share their details")
		return
	}

	now := s.store.now()
	sess := &session{
		ID: newID(), Subject: req.UIN, Identifier: req.Identifier, ClientID: req.ClientID,
		Scopes: req.Scope, ACR: "urn:mosip:acr:otp", CreatedAt: now, ExpiresAt: now.Add(s.cfg.sessionValidity),
		// flow_identifier names the flow the session belongs to (the client that ran it);
		// session_handle is what a device secret carries to resume it.
		FlowID: req.ClientID, Handle: randomToken(18),
	}
	code := randomToken(24)
	entry := &codeEntry{
		Code: code, ClientID: req.ClientID, RedirectURI: req.RedirectURI, SessionID: sess.ID,
		Scope: req.Scope, CodeChallenge: req.CodeChallenge, CodeMethod: req.CodeMethod,
		ExpiresAt: now.Add(3 * time.Minute),
	}
	s.store.mu.Lock()
	s.store.sessions[sess.ID] = sess
	s.store.byHandle[sess.Handle] = sess.ID
	s.store.bySubject[sess.Subject] = append(s.store.bySubject[sess.Subject], sess.ID)
	s.store.codes[code] = entry
	delete(s.store.requests, req.ID)
	s.store.mu.Unlock()

	s.log.Info("authorization granted", "client_id", req.ClientID, "sub", req.UIN, "sid", sess.ID,
		"scope", joinScopes(req.Scope))

	location := req.RedirectURI + "&code=" + url.QueryEscape(code)
	if req.State != "" {
		location += "&state=" + url.QueryEscape(req.State)
	}
	http.Redirect(w, r, location, http.StatusFound)
}

// ---------------------------------------------------------------------------
// POST /oauth2/token
// ---------------------------------------------------------------------------

func (s *server) handleToken(w http.ResponseWriter, r *http.Request) {
	form, ok := s.decodeForm(w, r)
	if !ok {
		return
	}
	switch form["grant_type"] {
	case "authorization_code":
		s.grantAuthorizationCode(w, form)
	case "urn:ietf:params:oauth:grant-type:token-exchange":
		s.grantTokenExchange(w, form)
	case "refresh_token":
		s.grantRefreshToken(w, form)
	case "":
		writeOAuthError(w, http.StatusBadRequest, "invalid_request", "grant_type is required")
	default:
		writeOAuthError(w, http.StatusBadRequest, "unsupported_grant_type",
			"supported: authorization_code, refresh_token, urn:ietf:params:oauth:grant-type:token-exchange")
	}
}

// grantAuthorizationCode exchanges a code for tokens, and — when device_sso was granted — for the
// device secret: a signed JWT that names the SSO sessions of the sign-in so that other apps on the same
// device can resume them without showing a login screen.
func (s *server) grantAuthorizationCode(w http.ResponseWriter, form map[string]string) {
	clientID := form["client_id"]
	if _, ok := s.clients()[clientID]; !ok {
		writeOAuthError(w, http.StatusUnauthorized, "invalid_client", "unknown client_id")
		return
	}
	s.store.mu.Lock()
	entry, ok := s.store.codes[form["code"]]
	if ok {
		delete(s.store.codes, form["code"]) // single use, even if the rest of the request fails
	}
	var sess *session
	if ok {
		sess = s.store.sessions[entry.SessionID]
	}
	s.store.mu.Unlock()

	switch {
	case !ok || entry == nil:
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "unknown or already used authorization code")
		return
	case s.store.now().After(entry.ExpiresAt):
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "the authorization code expired")
		return
	case entry.ClientID != clientID:
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "the code was issued to another client")
		return
	case entry.RedirectURI != form["redirect_uri"]:
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "redirect_uri does not match the request")
		return
	case sess == nil:
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "the session no longer exists")
		return
	}
	// PKCE verification (RFC 7636).
	verifier := form["code_verifier"]
	if verifier == "" {
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "code_verifier is required (PKCE)")
		return
	}
	switch entry.CodeMethod {
	case "S256":
		if subtleCompare(pkceChallenge(verifier), entry.CodeChallenge) != 1 {
			writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "PKCE verification failed")
			return
		}
	case "plain":
		if subtleCompare(verifier, entry.CodeChallenge) != 1 {
			writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "PKCE verification failed")
			return
		}
	}

	refresh := s.issueRefreshToken(sess, clientID, entry.Scope)
	writeJSON(w, http.StatusOK, s.tokenResponse(sess, clientID, entry.Scope, refresh, true))
}

// grantTokenExchange exchanges a device secret for tokens (OpenID Connect Native SSO 1.0 §4).
//
// The subject token *is* the device secret: a JWT whose typ is "sso-session+jwt" and whose session_data
// names the sessions the sign-in kept. Nothing else in the request identifies the user, so a request
// without a valid secret cannot be exchanged at all.
func (s *server) grantTokenExchange(w http.ResponseWriter, form map[string]string) {
	clientID := form["client_id"]
	if _, ok := s.clients()[clientID]; !ok {
		writeOAuthError(w, http.StatusUnauthorized, "invalid_client", "unknown client_id")
		return
	}
	if form["actor_token"] != "" {
		writeOAuthError(w, http.StatusBadRequest, "invalid_request",
			"a device secret cannot be exchanged with an actor_token")
		return
	}
	if requested := form["requested_token_type"]; requested != "" &&
		requested != "urn:ietf:params:oauth:token-type:access_token" {
		writeOAuthError(w, http.StatusBadRequest, "invalid_request",
			"only an access token can be requested with a device secret")
		return
	}
	if typ := form["subject_token_type"]; typ != "" && typ != "urn:ietf:params:oauth:token-type:jwt" {
		writeOAuthError(w, http.StatusBadRequest, "invalid_request",
			"subject_token_type must be urn:ietf:params:oauth:token-type:jwt")
		return
	}

	claims, err := s.validateDeviceSecret(form["subject_token"])
	if err != nil {
		writeOAuthError(w, http.StatusBadRequest, "invalid_request", "Invalid subject_token: "+err.Error())
		return
	}

	s.store.mu.Lock()
	sess := s.store.sessionForHandle(claims.SessionHandle)
	s.store.mu.Unlock()
	if sess == nil || s.store.now().After(sess.ExpiresAt) {
		// The session behind the secret is gone: the app must show a login screen again.
		writeOAuthError(w, http.StatusBadRequest, "interaction_required",
			"The SSO session cannot be used without user interaction")
		return
	}
	if sess.Subject != claims.Subject {
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant",
			"The device secret's session does not belong to its subject")
		return
	}
	requested := splitScopes(form["scope"])
	if len(requested) == 0 {
		requested = sess.Scopes
	}
	if contains(requested, "device_sso") {
		writeOAuthError(w, http.StatusBadRequest, "invalid_scope",
			"device_sso is a token-endpoint scope modifier and cannot be requested in a token exchange")
		return
	}
	if !subset(requested, sess.Scopes) {
		writeOAuthError(w, http.StatusBadRequest, "invalid_scope",
			"the requested scope exceeds the scopes granted to the session")
		return
	}

	refresh := s.issueRefreshToken(sess, clientID, requested)
	s.log.Info("device secret exchanged", "client_id", clientID, "sid", sess.ID, "sub", sess.Subject,
		"scope", joinScopes(requested))
	resp := s.tokenResponse(sess, clientID, requested, refresh, false)
	resp["issued_token_type"] = "urn:ietf:params:oauth:token-type:access_token"
	resp["subject_token_type"] = form["subject_token_type"]
	writeJSON(w, http.StatusOK, resp)
}

// grantRefreshToken rotates a refresh token.
func (s *server) grantRefreshToken(w http.ResponseWriter, form map[string]string) {
	clientID := form["client_id"]
	s.store.mu.Lock()
	rt, ok := s.store.refresh[form["refresh_token"]]
	if ok {
		delete(s.store.refresh, form["refresh_token"])
	}
	var sess *session
	if ok {
		sess = s.store.sessions[rt.SessionID]
	}
	s.store.mu.Unlock()

	switch {
	case !ok:
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "unknown or already used refresh token")
		return
	case s.store.now().After(rt.ExpiresAt):
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "the refresh token expired")
		return
	case rt.ClientID != clientID:
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "the refresh token was issued to another client")
		return
	case sess == nil:
		writeOAuthError(w, http.StatusBadRequest, "invalid_grant", "the session no longer exists")
		return
	}
	next := s.issueRefreshToken(sess, clientID, rt.Scope)
	writeJSON(w, http.StatusOK, s.tokenResponse(sess, clientID, rt.Scope, next, false))
}

// handleRevoke revokes the session a token belongs to (RFC 7009 shape).
func (s *server) handleRevoke(w http.ResponseWriter, r *http.Request) {
	form, ok := s.decodeForm(w, r)
	if !ok {
		return
	}
	token := form["token"]
	revoked := false
	s.store.mu.Lock()
	if rt, exists := s.store.refresh[token]; exists {
		delete(s.store.refresh, token)
		revoked = true
		if sess, ok := s.store.sessions[rt.SessionID]; ok {
			delete(s.store.byHandle, sess.Handle)
			delete(s.store.sessions, rt.SessionID)
			s.store.bySubject[sess.Subject] = removeString(s.store.bySubject[sess.Subject], rt.SessionID)
		}
	}
	s.store.mu.Unlock()
	if !revoked {
		if claims, err := parseJWT(s.cfg.clientSecret, token); err == nil {
			if sid, _ := claims["sid"].(string); sid != "" {
				s.store.mu.Lock()
				if sess, ok := s.store.sessions[sid]; ok {
					delete(s.store.byHandle, sess.Handle)
					delete(s.store.sessions, sid)
					s.store.bySubject[sess.Subject] = removeString(s.store.bySubject[sess.Subject], sid)
					revoked = true
				}
				s.store.mu.Unlock()
			}
		}
	}
	s.log.Info("token revoked", "revoked", revoked)
	// RFC 7009 §2.2: always 200, whatever the token was.
	w.WriteHeader(http.StatusOK)
}

// tokenResponse builds the body shared by the code, exchange and refresh grants.
func (s *server) tokenResponse(sess *session, clientID string, scope []string, refresh string,
	withDeviceSecret bool) map[string]any {
	resp := map[string]any{
		"access_token": s.accessToken(sess, clientID, scope),
		"token_type":   "Bearer",
		"expires_in":   int(s.cfg.accessTokenTTL.Seconds()),
		"id_token":     s.idToken(sess, clientID),
		"scope":        joinScopes(scope),
		"sid":          sess.ID,
	}
	if refresh != "" {
		resp["refresh_token"] = refresh
	}
	if withDeviceSecret && contains(scope, "device_sso") {
		secret, expiresIn, err := s.buildDeviceSecret(sess)
		if err == nil {
			resp["device_secret"] = secret
			resp["device_secret_expires_in"] = expiresIn
			resp["session_data"] = []map[string]string{{
				"flow_identifier": sess.FlowID,
				"session_handle":  sess.Handle,
			}}
			s.log.Info("device secret issued", "client_id", clientID, "sid", sess.ID,
				"session_handle", sess.Handle, "typ", deviceSecretType)
		}
	}
	return resp
}

// buildDeviceSecret mints the device secret: a signed JWT whose typ says what it is and whose
// session_data names the sessions of this sign-in.
func (s *server) buildDeviceSecret(sess *session) (string, int, error) {
	now := time.Now().UTC()
	ttl := s.cfg.secretValidity
	claims := map[string]any{
		"iss": s.cfg.issuer,
		"sub": sess.Subject,
		"aud": s.cfg.issuer,
		"iat": now.Unix(),
		"nbf": now.Unix(),
		"exp": now.Add(ttl).Unix(),
		"jti": newID(),
		"session_data": []map[string]string{{
			"flow_identifier": sess.FlowID,
			"session_handle":  sess.Handle,
		}},
	}
	return signJWTWithType(s.cfg.clientSecret, claims, deviceSecretType), int(ttl.Seconds()), nil
}

// validateDeviceSecret checks a device secret presented back to this server.
func (s *server) validateDeviceSecret(token string) (deviceSecretClaims, error) {
	if token == "" {
		return deviceSecretClaims{}, errors.New("the device secret is missing")
	}
	header, err := decodeJWTHeader(token)
	if err != nil {
		return deviceSecretClaims{}, err
	}
	if header["typ"] != deviceSecretType {
		return deviceSecretClaims{}, fmt.Errorf("not a device secret: expected typ %q", deviceSecretType)
	}
	claims, err := parseJWT(s.cfg.clientSecret, token)
	if err != nil {
		return deviceSecretClaims{}, err
	}
	sub, _ := claims["sub"].(string)
	if sub == "" {
		return deviceSecretClaims{}, errors.New("the device secret has no subject")
	}
	entries, _ := claims["session_data"].([]any)
	if len(entries) == 0 {
		return deviceSecretClaims{}, errors.New("the device secret carries no session_data")
	}
	out := deviceSecretClaims{Subject: sub}
	for _, raw := range entries {
		entry, _ := raw.(map[string]any)
		handle, _ := entry["session_handle"].(string)
		flow, _ := entry["flow_identifier"].(string)
		if handle != "" {
			out.Sessions = append(out.Sessions, deviceSSOSession{FlowID: flow, Handle: handle})
		}
	}
	if len(out.Sessions) == 0 {
		return deviceSecretClaims{}, errors.New("the device secret carries no usable session")
	}
	out.SessionHandle = out.Sessions[0].Handle
	return out, nil
}

// sessionForHandle resolves the session a device secret names.
func (s *store) sessionForHandle(handle string) *session {
	if id, ok := s.byHandle[handle]; ok {
		return s.sessions[id]
	}
	return nil
}

// issueRefreshToken mints and stores a rotating refresh token.
func (s *server) issueRefreshToken(sess *session, clientID string, scope []string) string {
	token := randomToken(32)
	s.store.mu.Lock()
	s.store.refresh[token] = &refreshToken{
		Token: token, SessionID: sess.ID, ClientID: clientID, Scope: scope,
		ExpiresAt: s.store.now().Add(s.cfg.refreshTokenTTL),
	}
	s.store.mu.Unlock()
	return token
}

// accessToken builds the signed access token for a session.
func (s *server) accessToken(sess *session, clientID string, scopes []string) string {
	now := time.Now().UTC()
	return signJWT(s.cfg.clientSecret, map[string]any{
		"iss": s.cfg.issuer, "sub": sess.Subject, "aud": clientID, "client_id": clientID,
		"scope": joinScopes(scopes), "sid": sess.ID, "acr": sess.ACR, "amr": []string{"otp"},
		"iat": now.Unix(), "exp": now.Add(s.cfg.accessTokenTTL).Unix(), "jti": newID(),
		"token_use": "access",
	})
}

// idToken builds the signed id token for a session.
func (s *server) idToken(sess *session, clientID string) string {
	now := time.Now().UTC()
	return signJWT(s.cfg.clientSecret, map[string]any{
		"iss": s.cfg.issuer, "sub": sess.Subject, "aud": clientID, "azp": clientID,
		"sid": sess.ID, "acr": sess.ACR, "amr": []string{"otp"},
		"auth_time": sess.CreatedAt.Unix(), "iat": now.Unix(), "exp": now.Add(s.cfg.accessTokenTTL).Unix(),
		"token_use": "id",
	})
}

// ---------------------------------------------------------------------------
// GET /oauth2/userinfo
// ---------------------------------------------------------------------------

func (s *server) handleUserInfo(w http.ResponseWriter, r *http.Request) {
	auth := r.Header.Get("Authorization")
	if !strings.HasPrefix(strings.ToLower(auth), "bearer ") {
		w.Header().Set("WWW-Authenticate", `Bearer error="invalid_token"`)
		writeOAuthError(w, http.StatusUnauthorized, "invalid_token", "a Bearer access token is required")
		return
	}
	claims, err := parseJWT(s.cfg.clientSecret, strings.TrimSpace(auth[7:]))
	if err != nil {
		w.Header().Set("WWW-Authenticate", `Bearer error="invalid_token"`)
		writeOAuthError(w, http.StatusUnauthorized, "invalid_token", err.Error())
		return
	}
	sub, _ := claims["sub"].(string)
	info := map[string]any{"sub": sub, "acr": claims["acr"], "amr": claims["amr"], "sid": claims["sid"]}
	if scope, _ := claims["scope"].(string); contains(splitScopes(scope), "profile") {
		if profile, err := s.fetchProfile(r.Context(), sub); err == nil {
			for _, key := range []string{"name", "given_name", "family_name", "email", "phone_number",
				"birthdate", "gender", "locale"} {
				if v, ok := profile[key]; ok {
					info[key] = v
				}
			}
		}
	}
	writeJSON(w, http.StatusOK, info)
}

// ---------------------------------------------------------------------------
// calls into the platform service
// ---------------------------------------------------------------------------

type otpSent struct {
	transactionID string
	destination   string
	provider      string
}

func (s *server) platformCall(ctx context.Context, method, path string, body any, out any) error {
	payload, err := json.Marshal(body)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, method, s.cfg.platformURL+path, strings.NewReader(string(payload)))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Platform-Api-Key", s.cfg.platformKey)
	resp, err := s.client.Do(req)
	if err != nil {
		return fmt.Errorf("the identity service is unreachable: %w", err)
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode != http.StatusOK {
		var errBody struct {
			Error struct {
				Message string `json:"message"`
			} `json:"error"`
		}
		_ = json.Unmarshal(raw, &errBody)
		message := errBody.Error.Message
		if message == "" {
			message = fmt.Sprintf("identity service returned HTTP %d", resp.StatusCode)
		}
		return errors.New(message)
	}
	if out == nil {
		return nil
	}
	return json.Unmarshal(raw, out)
}

// sendOTP asks the platform to mail a one-time code to the identifier.
func (s *server) sendOTP(ctx context.Context, identifier string) (otpSent, error) {
	channel := "email"
	if !strings.Contains(identifier, "@") {
		channel = "sms"
	}
	var result struct {
		TransactionID string `json:"transactionId"`
		Masked        string `json:"maskedDestination"`
		Provider      string `json:"provider"`
	}
	if err := s.platformCall(ctx, http.MethodPost, "/internal/otp/send",
		map[string]any{"identifier": identifier, "channel": channel, "purpose": "native_sso_signin"}, &result); err != nil {
		return otpSent{}, err
	}
	return otpSent{transactionID: result.TransactionID, destination: result.Masked, provider: result.Provider}, nil
}

// verifyOTP checks the code and returns the citizen's UIN.
func (s *server) verifyOTP(ctx context.Context, transactionID, code string) (string, error) {
	var result struct {
		Verified bool   `json:"verified"`
		UIN      string `json:"uin"`
	}
	if err := s.platformCall(ctx, http.MethodPost, "/internal/otp/verify",
		map[string]any{"transactionId": transactionID, "otp": code}, &result); err != nil {
		return "", err
	}
	if !result.Verified || result.UIN == "" {
		return "", errors.New("the code could not be verified")
	}
	return result.UIN, nil
}

// fetchProfile loads the citizen's profile from the platform.
func (s *server) fetchProfile(ctx context.Context, uin string) (map[string]any, error) {
	out := map[string]any{}
	err := s.platformCall(ctx, http.MethodGet, "/internal/identity/users/"+url.PathEscape(uin), nil, &out)
	return out, err
}

func short(s string) string {
	if len(s) <= 10 {
		return s
	}
	return s[:10] + "…"
}

// base64URL is exported for the UI templates that display decoded token parts.
func base64URL(raw string) string { return base64.RawURLEncoding.EncodeToString([]byte(raw)) }

// deviceSecretType is the JWT typ of a device secret, the same value the engine uses
// (internal/system/jose/jwt/constants.go: TokenTypeDeviceSecret).
const deviceSecretType = "sso-session+jwt"

// deviceSSOSession is one session_data entry: which flow the session belongs to, and its handle.
type deviceSSOSession struct {
	FlowID string
	Handle string
}

// deviceSecretClaims is the validated content of a device secret.
type deviceSecretClaims struct {
	Subject       string
	SessionHandle string
	Sessions      []deviceSSOSession
}
