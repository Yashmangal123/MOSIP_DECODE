package main

import "fmt"

// appScript returns the browser code for the two demo apps. It is plain ES2017 — no framework, no
// build step — and it holds nothing secret: the apps are public clients that use PKCE.
func appScript() string {
	return `<script>
(function () {
  var root = document.getElementById('app');
  var clientId = root.getAttribute('data-client');
  var authorizeURL = root.getAttribute('data-authorize');
  var logEl = document.getElementById('log');

  function log(line) {
    if (!logEl) return;
    if (logEl.textContent === '(nothing yet)') logEl.textContent = '';
    logEl.textContent += line + '\n';
    logEl.scrollTop = logEl.scrollHeight;
  }
  function esc(v) {
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function store(key, value) {
    if (value === null) sessionStorage.removeItem(key); else sessionStorage.setItem(key, JSON.stringify(value));
  }
  function load(key) {
    try { return JSON.parse(sessionStorage.getItem(key) || 'null'); } catch (e) { return null; }
  }
  function b64url(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  async function sha256(text) {
    var digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return b64url(new Uint8Array(digest));
  }

  // startSignIn creates the PKCE verifier and sends the user to the authorization endpoint.
  async function startSignIn() {
    var verifier = b64url(crypto.getRandomValues(new Uint8Array(32)));
    store('pkce:' + clientId, verifier);
    var challenge = await sha256(verifier);
    var state = b64url(crypto.getRandomValues(new Uint8Array(12)));
    store('state:' + clientId, state);
    var target = authorizeURL + '&state=' + encodeURIComponent(state) + '&code_challenge=' + challenge +
                 '&code_challenge_method=S256';
    log('GET ' + target);
    location.href = target;
  }

  function tokenBlock(tokens) {
    return '<pre>' + esc(JSON.stringify(tokens, null, 2)) + '</pre>';
  }

  async function userinfo(tokens) {
    log('GET /oauth2/userinfo (Bearer ' + tokens.access_token.slice(0, 18) + '…)');
    var res = await fetch('/oauth2/userinfo', { headers: { Authorization: 'Bearer ' + tokens.access_token } });
    var body = await res.json();
    log('  -> ' + res.status + ' ' + JSON.stringify(body));
    return body;
  }

  // ---------- Super App ----------
  async function renderSuperApp() {
    var tokens = load('sso:super-app');
    if (!tokens) {
      root.innerHTML = '<h3>Super App</h3><p class="muted small">Not signed in on this device.</p>' +
        '<p style="margin-top:18px"><button id="signin">Sign in with eSignet</button></p>' +
        '<p class="note small">You will get a real one-time code by e-mail.</p>';
      document.getElementById('signin').onclick = startSignIn;
      document.getElementById('state').innerHTML = '<p class="muted small">No session on this device yet.</p>';
      return;
    }
    var claims = decodeJWT(tokens.id_token);
    var profile = await userinfo(tokens);
    root.innerHTML = '<h3>Welcome, ' + esc(profile.name || claims.sub) + '</h3>' +
      '<p class="badge">signed in with OTP</p>' +
      '<div class="kv">' +
      '<span>UIN (sub)</span><span>' + esc(claims.sub) + '</span>' +
      '<span>sid</span><span><code>' + esc(tokens.sid).slice(0, 14) + '…</code></span>' +
      '<span>scope</span><span>' + esc(tokens.scope) + '</span>' +
      '<span>device_secret</span><span>' + (tokens.device_secret ? 'issued (JWT, ' + tokens.device_secret.length + ' chars)' : 'not issued') + '</span>' +
      '</div><p class="row" style="margin-top:16px"><a class="btn green" href="/app?client=child-app">Open Child App</a>' +
      '<button class="ghost" id="reset">Forget this device</button></p>';
    document.getElementById('reset').onclick = function () {
      store('sso:super-app', null); store('sso:child-app', null); location.reload();
    };
    document.getElementById('state').innerHTML =
      '<div class="kv"><span>client_id</span><span>super-app</span>' +
      '<span>sid</span><span><code>' + esc(tokens.sid) + '</code></span>' +
      '<span>device_secret typ</span><span><code>sso-session+jwt</code></span>' +
      '<span>session_data</span><span><code>' + esc(JSON.stringify(tokens.session_data || [])) + '</code></span>' +
      '<span>device_secret expires in</span><span>' + esc(tokens.device_secret_expires_in) + ' s</span>' +
      '<span>granted</span><span>' + esc(tokens.scope) + '</span></div>' +
      '<p class="note small">The device_secret lives only in this browser session. It is what lets the ' +
      'second app sign in without a code.</p>';
    document.getElementById('tokens').innerHTML = tokenBlock(tokens);
    log('device_secret = ' + tokens.device_secret);
    log('  header      = ' + JSON.stringify(decodeJWTHeader(tokens.device_secret)));
  }

  // ---------- Child App ----------
  async function renderChildApp() {
    var tokens = load('sso:child-app');
    var superTokens = load('sso:super-app');
    var existing = document.getElementById('state');
    if (tokens) {
      var claims = decodeJWT(tokens.id_token);
      var profile = await userinfo(tokens);
      root.innerHTML = '<h3>Welcome, ' + esc(profile.name || claims.sub) + '</h3>' +
        '<p class="badge">signed in — no code requested</p>' +
        '<div class="kv"><span>UIN (sub)</span><span>' + esc(claims.sub) + '</span>' +
        '<span>sid</span><span><code>' + esc(tokens.sid).slice(0, 14) + '…</code></span></div>' +
        '<p class="row" style="margin-top:16px"><button class="ghost" id="reset">Sign out of this app</button></p>';
      document.getElementById('reset').onclick = function () { store('sso:child-app', null); location.reload(); };
      existing.innerHTML = '<div class="kv"><span>client_id</span><span>child-app</span>' +
        '<span>sid</span><span><code>' + esc(tokens.sid) + '</code></span>' +
        '<span>grant</span><span>urn:ietf:params:oauth:grant-type:token-exchange</span></div>' +
        '<p class="note small">Same <code>sid</code> as the Super App: one session, two apps.</p>';
      document.getElementById('tokens').innerHTML = tokenBlock(tokens);
      return;
    }
    if (!superTokens || !superTokens.device_secret) {
      root.innerHTML = '<h3>Child App</h3><p class="muted small">This app cannot sign in on its own — ' +
        'there is no device secret on this phone yet.</p><p style="margin-top:16px">' +
        '<a class="btn" href="/app?client=super-app">Sign in with the Super App first</a></p>';
      existing.innerHTML = '<p class="muted small">Waiting for a session created by the Super App.</p>';
      return;
    }
    root.innerHTML = '<h3>Child App</h3><p class="muted small">The Super App is signed in on this device. ' +
      'Continue without a code.</p><p style="margin-top:16px"><button id="exchange">Continue with this device</button></p>';
    existing.innerHTML = '<div class="kv"><span>device_secret</span><span>available (from super-app)</span>' +
      '<span>subject_token</span><span>the device secret itself</span>' +
      '<span>subject_token_type</span><span>urn:ietf:params:oauth:token-type:jwt</span></div>' +
      '<p class="note small">This is RFC 8693 token exchange; the server verifies ' +
      'sha256(device_secret) against the stored ds_hash and the sid in the id_token.</p>';

    document.getElementById('exchange').onclick = async function () {
      var button = this;
      button.disabled = true;
      var body = new URLSearchParams();
      body.set('grant_type', 'urn:ietf:params:oauth:grant-type:token-exchange');
      body.set('client_id', 'child-app');
      body.set('subject_token', superTokens.device_secret);
      body.set('subject_token_type', 'urn:ietf:params:oauth:token-type:jwt');
      body.set('requested_token_type', 'urn:ietf:params:oauth:token-type:access_token');
      body.set('scope', 'openid profile email');
      log('POST /oauth2/token  grant_type=token-exchange client_id=child-app subject_token=<device_secret>');
      var res = await fetch('/oauth2/token', { method: 'POST', body: body });
      var tokens = await res.json();
      log('  -> ' + res.status);
      if (!res.ok) {
        button.disabled = false;
        var hint = tokens.error === 'interaction_required'
          ? '<p class="muted small">The session behind the device secret is gone, so the app must show a login screen — that is the flow working correctly.</p>'
          : '';
        existing.innerHTML = '<div class="err">' + esc(tokens.error) + ': ' + esc(tokens.error_description) + '</div>' + hint;
        return;
      }
      store('sso:child-app', tokens);
      location.reload();
    };
  }

  function decodeJWTHeader(token) {
    try {
      var part = token.split('.')[0].replace(/-/g, '+').replace(/_/g, '/');
      return JSON.parse(atob(part));
    } catch (e) { return {}; }
  }

  function decodeJWT(token) {
    try {
      var part = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      return JSON.parse(decodeURIComponent(escape(atob(part))));
    } catch (e) { return {}; }
  }

  if (clientId === 'child-app') { renderChildApp(); } else { renderSuperApp(); }
})();
</script>`
}

// callbackScript exchanges the authorization code (returned from /oauth2/authorize) for tokens.
func callbackScript(clientID string) string {
	return `<script>
(function () {
  var clientId = ` + jsonString(clientID) + `;
  var params = new URLSearchParams(location.search);
  var logEl = document.getElementById('log');
  var msgEl = document.getElementById('msg');
  function log(line) { logEl.textContent += line + '\n'; }
  function store(key, value) { sessionStorage.setItem(key, JSON.stringify(value)); }
  function load(key) { try { return JSON.parse(sessionStorage.getItem(key) || 'null'); } catch (e) { return null; } }

  if (params.get('error')) {
    msgEl.innerHTML = '<b>' + params.get('error') + '</b>: ' + (params.get('error_description') || '');
    return;
  }
  var code = params.get('code');
  var verifier = load('pkce:' + clientId);
  var expectedState = load('state:' + clientId);
  if (!code) { msgEl.textContent = 'No authorization code in the URL.'; return; }
  if (expectedState && params.get('state') !== expectedState) {
    msgEl.textContent = 'The state parameter did not match — the response may have been tampered with.';
    return;
  }
  if (!verifier) { msgEl.textContent = 'Missing PKCE verifier — start again from the app.'; return; }

  var redirectURI = location.origin + '/app/callback?client=' + encodeURIComponent(clientId);
  var body = new URLSearchParams();
  body.set('grant_type', 'authorization_code');
  body.set('client_id', clientId);
  body.set('code', code);
  body.set('redirect_uri', redirectURI);
  body.set('code_verifier', verifier);

  log('POST /oauth2/token  grant_type=authorization_code client_id=' + clientId);
  fetch('/oauth2/token', { method: 'POST', body: body })
    .then(function (res) {
      log('  -> ' + res.status);
      return res.json().then(function (body) { return { res: res, body: body }; });
    })
    .then(function (result) {
      if (!result.res.ok) {
        msgEl.innerHTML = '<b>' + (result.body.error || 'error') + '</b>: ' + (result.body.error_description || '');
        log(JSON.stringify(result.body, null, 2));
        return;
      }
      sessionStorage.setItem('sso:' + clientId, JSON.stringify(result.body));
      log('stored tokens for ' + clientId);
      log('sid = ' + result.body.sid);
      if (result.body.device_secret) log('device_secret issued (' + result.body.device_secret.length + ' chars)');
      msgEl.textContent = 'Signed in. Returning to the app…';
      setTimeout(function () { location.replace('/app?client=' + encodeURIComponent(clientId)); }, 600);
    })
    .catch(function (error) {
      msgEl.textContent = 'Request failed: ' + error;
    });
})();
</script>`
}

// jsonString quotes a string as a JSON literal for embedding in a script.
func jsonString(v string) string {
	out := []byte{'"'}
	for _, r := range v {
		switch r {
		case '"', '\\':
			out = append(out, '\\', byte(r))
		case '\n':
			out = append(out, '\\', 'n')
		case '<', '>', '&':
			out = append(out, []byte("\\u00")...)
			out = append(out, []byte(fmt.Sprintf("%02x", r))...)
		default:
			out = append(out, []byte(string(r))...)
		}
	}
	return string(append(out, '"'))
}
