// Command native-sso-demo is a self-contained, runnable demonstration of the OpenID Connect
// Native SSO flow (device_sso scope, device_secret, ds_hash, sid and RFC 8693 token exchange).
//
// It plays two roles at once so that a single `go run` gives you a complete, clickable flow:
//
//  1. the authorization server / identity provider  (/oauth2/authorize, /oauth2/token, /userinfo)
//  2. two native "apps" that use it                 (/app?client=super-app, /app?client=child-app)
//
// Verification of the citizen is delegated to the platform service, so the one-time code really is
// mailed to the user's inbox — nothing is simulated.
//
// This is a teaching/reference implementation of the flow. The production authorization server is
// eSignet + thunderid-engine with the Native SSO patch (see ../../docs/native-sso.md).
package main

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ---------------------------------------------------------------------------
// configuration
// ---------------------------------------------------------------------------

type config struct {
	addr             string
	issuer           string
	platformURL      string
	platformKey      string
	clientSecret     string // shared secret for the two demo apps (confidential clients)
	secretValidity   time.Duration
	sessionValidity  time.Duration
	labOTP           string // lab-only: fixed code without contacting the platform (tests only)
	accessTokenTTL   time.Duration
	refreshTokenTTL  time.Duration
	maxRequestSize   int64
	shutdownGraceful time.Duration
}

func loadConfig() (config, error) {
	cfg := config{
		addr:             env("SSO_ADDR", ":8091"),
		issuer:           strings.TrimRight(env("SSO_ISSUER", "http://localhost:8091"), "/"),
		platformURL:      strings.TrimRight(env("SSO_PLATFORM_URL", "http://127.0.0.1:8090"), "/"),
		platformKey:      env("SSO_PLATFORM_API_KEY", ""),
		clientSecret:     env("SSO_CLIENT_SECRET", ""),
		secretValidity:   time.Hour,
		sessionValidity:  24 * time.Hour,
		labOTP:           env("SSO_LAB_OTP", ""),
		accessTokenTTL:   10 * time.Minute,
		refreshTokenTTL:  8 * time.Hour,
		maxRequestSize:   1 << 20,
		shutdownGraceful: 10 * time.Second,
	}
	if v := env("SSO_DEVICE_SECRET_VALIDITY", "1h"); v != "" {
		d, err := time.ParseDuration(v)
		if err != nil {
			return cfg, fmt.Errorf("SSO_DEVICE_SECRET_VALIDITY: %w", err)
		}
		cfg.secretValidity = d
	}
	if v := env("SSO_SESSION_VALIDITY", "24h"); v != "" {
		d, err := time.ParseDuration(v)
		if err != nil {
			return cfg, fmt.Errorf("SSO_SESSION_VALIDITY: %w", err)
		}
		cfg.sessionValidity = d
	}
	if cfg.platformKey == "" && cfg.labOTP == "" {
		return cfg, errors.New("SSO_PLATFORM_API_KEY is required (the key the platform service expects); " +
			"set SSO_LAB_OTP only for automated tests")
	}
	if cfg.clientSecret == "" {
		return cfg, errors.New("SSO_CLIENT_SECRET is required (it signs the demo tokens; use any long random string)")
	}
	return cfg, nil
}

func env(key, fallback string) string {
	if v, ok := os.LookupEnv(key); ok && v != "" {
		return v
	}
	return fallback
}

// ---------------------------------------------------------------------------
// domain types
// ---------------------------------------------------------------------------

// authRequest is an in-flight authorization request (between /oauth2/authorize and the redirect).
type authRequest struct {
	ID            string
	ClientID      string
	RedirectURI   string
	Scope         []string
	State         string
	CodeChallenge string
	CodeMethod    string
	CreatedAt     time.Time

	// filled in as the user authenticates
	TransactionID   string
	Identifier      string
	UIN             string
	AuthenticatedAt time.Time
	Consented       bool
}

// session is an authenticated eSignet session. In OIDC Native SSO the `sid` claim is the identifier
// of this session; a device_secret is bound to it.
type session struct {
	ID         string // this is the `sid` claim
	Subject    string // UIN
	Identifier string
	ClientID   string // the app that created the session
	Scopes     []string
	ACR        string
	CreatedAt  time.Time
	ExpiresAt  time.Time

	// Handle is the session_handle carried in a device secret's session_data. It is what the token
	// exchange resumes: the secret names sessions, it does not carry them.
	Handle string
	// FlowID is the flow_identifier of the same session_data entry.
	FlowID string
}

// refreshToken is an opaque, rotating refresh token bound to a session.
type refreshToken struct {
	Token     string
	SessionID string
	ClientID  string
	Scope     []string
	ExpiresAt time.Time
}

// codeEntry is a single-use authorization code.
type codeEntry struct {
	Code          string
	ClientID      string
	RedirectURI   string
	SessionID     string
	Scope         []string
	CodeChallenge string
	CodeMethod    string
	ExpiresAt     time.Time
}

// store is an in-memory, TTL-swept store. A demo only: production keeps sessions in
// esignet.device_sso_session (see the migration in db_upgrade_script).
type store struct {
	mu        sync.Mutex
	requests  map[string]*authRequest
	sessions  map[string]*session
	codes     map[string]*codeEntry
	bySubject map[string][]string // subject -> session ids
	byHandle  map[string]string   // session_handle -> session id
	refresh   map[string]*refreshToken
	now       func() time.Time
}

func newStore() *store {
	return &store{
		requests:  map[string]*authRequest{},
		sessions:  map[string]*session{},
		codes:     map[string]*codeEntry{},
		bySubject: map[string][]string{},
		byHandle:  map[string]string{},
		refresh:   map[string]*refreshToken{},
		now:       func() time.Time { return time.Now().UTC() },
	}
}

func (s *store) sweep(ctx context.Context) {
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			s.mu.Lock()
			now := s.now()
			for k, v := range s.requests {
				if now.Sub(v.CreatedAt) > 15*time.Minute {
					delete(s.requests, k)
				}
			}
			for k, v := range s.codes {
				if now.After(v.ExpiresAt) {
					delete(s.codes, k)
				}
			}
			for k, v := range s.sessions {
				if now.After(v.ExpiresAt) {
					delete(s.sessions, k)
					delete(s.byHandle, v.Handle)
					s.bySubject[v.Subject] = removeString(s.bySubject[v.Subject], k)
				}
			}
			for k, v := range s.refresh {
				if now.After(v.ExpiresAt) {
					delete(s.refresh, k)
				}
			}
			s.mu.Unlock()
		}
	}
}

func removeString(list []string, want string) []string {
	out := list[:0]
	for _, v := range list {
		if v != want {
			out = append(out, v)
		}
	}
	return out
}

// ---------------------------------------------------------------------------
// random identifiers and the JWT helper
// ---------------------------------------------------------------------------

func randomToken(n int) string {
	buf := make([]byte, n)
	if _, err := rand.Read(buf); err != nil {
		panic("crypto/rand unavailable: " + err.Error())
	}
	return base64.RawURLEncoding.EncodeToString(buf)
}

// hashSecret returns base64url(SHA-256(secret)), the value compared against the `ds_hash` claim.
func hashSecret(secret string) string {
	sum := sha256.Sum256([]byte(secret))
	return base64.RawURLEncoding.EncodeToString(sum[:])
}

func pkceChallenge(verifier string) string {
	sum := sha256.Sum256([]byte(verifier))
	return base64.RawURLEncoding.EncodeToString(sum[:])
}

// signJWT produces an HS256 JWT. The demo signs with HMAC so it has no dependencies; eSignet signs
// with RS256/PS512 through its key manager.
func signJWT(secret string, claims map[string]any) string {
	header := map[string]any{"alg": "HS256", "typ": "JWT", "kid": "native-sso-demo"}
	h, _ := json.Marshal(header)
	c, _ := json.Marshal(claims)
	signingInput := base64.RawURLEncoding.EncodeToString(h) + "." + base64.RawURLEncoding.EncodeToString(c)
	mac := hmacSHA256([]byte(secret), []byte(signingInput))
	return signingInput + "." + base64.RawURLEncoding.EncodeToString(mac)
}

// signJWTWithType signs a JWT with an explicit typ header, which is how a token announces what it is:
// the engine uses "sso-session+jwt" for device secrets.
func signJWTWithType(secret string, claims map[string]any, typ string) string {
	header := map[string]any{"alg": "HS256", "typ": typ, "kid": "native-sso-demo"}
	h, _ := json.Marshal(header)
	c, _ := json.Marshal(claims)
	signingInput := base64.RawURLEncoding.EncodeToString(h) + "." + base64.RawURLEncoding.EncodeToString(c)
	mac := hmacSHA256([]byte(secret), []byte(signingInput))
	return signingInput + "." + base64.RawURLEncoding.EncodeToString(mac)
}

// decodeJWTHeader returns the header of a JWT without verifying it, to read its typ.
func decodeJWTHeader(token string) (map[string]any, error) {
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return nil, errors.New("malformed token")
	}
	raw, err := base64.RawURLEncoding.DecodeString(parts[0])
	if err != nil {
		return nil, err
	}
	header := map[string]any{}
	if err := json.Unmarshal(raw, &header); err != nil {
		return nil, err
	}
	return header, nil
}

// parseJWT verifies the signature and expiry and returns the claims.
func parseJWT(secret, token string) (map[string]any, error) {
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return nil, errors.New("malformed token")
	}
	expected := base64.RawURLEncoding.EncodeToString(hmacSHA256([]byte(secret), []byte(parts[0]+"."+parts[1])))
	if subtleCompare(expected, parts[2]) != 1 {
		return nil, errors.New("bad signature")
	}
	raw, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return nil, err
	}
	claims := map[string]any{}
	if err := json.Unmarshal(raw, &claims); err != nil {
		return nil, err
	}
	if exp, ok := claims["exp"].(float64); ok && time.Now().Unix() >= int64(exp) {
		return nil, errors.New("token expired")
	}
	return claims, nil
}

// ---------------------------------------------------------------------------
// server
// ---------------------------------------------------------------------------

type server struct {
	cfg    config
	store  *store
	client *http.Client
	log    *slog.Logger
}

func main() {
	cfg, err := loadConfig()
	if err != nil {
		fmt.Fprintln(os.Stderr, "configuration error:", err)
		os.Exit(1)
	}
	log := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo}))
	srv := &server{
		cfg:    cfg,
		store:  newStore(),
		client: &http.Client{Timeout: 15 * time.Second},
		log:    log,
	}

	if len(os.Args) > 1 && os.Args[1] == "--check" {
		identifier := ""
		if len(os.Args) > 2 {
			identifier = os.Args[2]
		}
		os.Exit(runCheck(cfg, log, identifier))
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go srv.store.sweep(ctx)

	mux := srv.routes()

	httpServer := &http.Server{
		Addr:              cfg.addr,
		Handler:           srv.withHeaders(mux),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       20 * time.Second,
		WriteTimeout:      30 * time.Second,
		IdleTimeout:       60 * time.Second,
	}
	if cfg.labOTP != "" {
		log.Warn("LAB MODE: the login page accepts a fixed verification code and never contacts the platform",
			"code_length", strconv.Itoa(len(cfg.labOTP)))
	}
	log.Info("native sso demo listening", "address", cfg.addr, "issuer", cfg.issuer,
		"platform", cfg.platformURL, "device_secret_validity", cfg.secretValidity.String())
	if err := httpServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("server failed", "error", err.Error())
		os.Exit(1)
	}
}

func (s *server) handleHealth(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"status": "UP", "issuer": s.cfg.issuer, "labMode": s.cfg.labOTP != "",
		"sessions": len(s.store.sessions), "time": time.Now().UTC(),
	})
}

func (s *server) handleJWKS(w http.ResponseWriter, _ *http.Request) {
	// The demo signs with HMAC, so there is no public key to publish. The endpoint exists so that
	// clients written against eSignet (which serve RS256 keys here) find a well-known location.
	writeJSON(w, http.StatusOK, map[string]any{"keys": []any{}})
}

func (s *server) withHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "SAMEORIGIN")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Cache-Control", "no-store")
		next.ServeHTTP(w, r)
	})
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

func writeJSON(w http.ResponseWriter, status int, body any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(body)
}

func writeHTML(w http.ResponseWriter, status int, body string) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(status)
	_, _ = io.WriteString(w, body)
}

// writeOAuthError follows RFC 6749 §5.2 (error + error_description), plus the console-friendly message.
func writeOAuthError(w http.ResponseWriter, status int, code, description string) {
	writeJSON(w, status, map[string]any{
		"error":             code,
		"error_description": description,
	})
}

func (s *server) decodeForm(w http.ResponseWriter, r *http.Request) (map[string]string, bool) {
	r.Body = http.MaxBytesReader(w, r.Body, s.cfg.maxRequestSize)
	if err := r.ParseForm(); err != nil {
		writeOAuthError(w, http.StatusBadRequest, "invalid_request", "the request body could not be parsed")
		return nil, false
	}
	out := map[string]string{}
	for k := range r.Form {
		out[k] = strings.TrimSpace(r.Form.Get(k))
	}
	return out, true
}

func contains(list []string, want string) bool {
	for _, v := range list {
		if v == want {
			return true
		}
	}
	return false
}

func splitScopes(raw string) []string {
	out := []string{}
	for _, f := range strings.Fields(raw) {
		if f != "" {
			out = append(out, f)
		}
	}
	return out
}

func joinScopes(list []string) string { return strings.Join(list, " ") }

// subset reports whether every requested scope was granted.
func subset(requested, granted []string) bool {
	for _, v := range requested {
		if !contains(granted, v) {
			return false
		}
	}
	return true
}

func newID() string { return randomToken(16) }

// routes wires the endpoints. Kept separate from main so tests can drive the server directly.
func (s *server) routes() *http.ServeMux {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /", s.handleLanding)
	mux.HandleFunc("GET /app", s.handleApp)
	mux.HandleFunc("GET /app/callback", s.handleAppCallback)
	mux.HandleFunc("GET /oauth2/authorize", s.handleAuthorize)
	mux.HandleFunc("POST /oauth2/login", s.handleLogin)
	mux.HandleFunc("POST /oauth2/consent", s.handleConsent)
	mux.HandleFunc("POST /oauth2/token", s.handleToken)
	mux.HandleFunc("POST /oauth2/revoke", s.handleRevoke)
	mux.HandleFunc("GET /oauth2/userinfo", s.handleUserInfo)
	mux.HandleFunc("GET /health", s.handleHealth)
	mux.HandleFunc("GET /jwks", s.handleJWKS)
	return mux
}

// runCheck explains, step by step, whether the platform can actually deliver a code. It is the fastest
// way to answer "why is no email arriving?" without reading any logs.
func runCheck(cfg config, log *slog.Logger, identifier string) int {
	client := &http.Client{Timeout: 20 * time.Second}
	ok := true

	fmt.Println("1. configuration")
	fmt.Printf("   platform URL        : %s\n", cfg.platformURL)
	fmt.Printf("   internal API key    : %s\n", maskKey(cfg.platformKey))
	fmt.Printf("   signing secret      : %s\n", maskKey(cfg.clientSecret))
	if cfg.platformKey == "" {
		fmt.Println("   ✗ SSO_PLATFORM_API_KEY is empty — set it to PLATFORM_API_KEY from the platform")
		return 1
	}

	fmt.Println("2. platform health")
	resp, err := client.Get(cfg.platformURL + "/health")
	if err != nil {
		fmt.Printf("   ✗ cannot reach the platform: %v\n", err)
		fmt.Println("     is `go run ./cmd/platform` running on :8090?")
		return 1
	}
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
	resp.Body.Close()
	fmt.Printf("   %d %s\n", resp.StatusCode, strings.TrimSpace(string(body)))
	if resp.StatusCode != http.StatusOK {
		ok = false
	}

	if identifier == "" {
		fmt.Println("3. delivery test — skipped (no identifier given)")
		fmt.Println("   run: go run . --check you@example.com")
		if ok {
			return 0
		}
		return 1
	}

	fmt.Println("3. internal API authentication")
	payload := `{"identifier":"` + identifier + `","channel":"email","purpose":"native_sso_signin"}`
	req, _ := http.NewRequest(http.MethodPost, cfg.platformURL+"/internal/otp/send", strings.NewReader(payload))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Platform-Api-Key", cfg.platformKey)
	resp, err = client.Do(req)
	if err != nil {
		fmt.Printf("   ✗ request failed: %v\n", err)
		return 1
	}
	body, _ = io.ReadAll(io.LimitReader(resp.Body, 8192))
	resp.Body.Close()
	fmt.Printf("   %d %s\n", resp.StatusCode, strings.TrimSpace(string(body)))

	switch {
	case resp.StatusCode == http.StatusUnauthorized:
		fmt.Println("   ✗ the platform rejected the key: SSO_PLATFORM_API_KEY must equal PLATFORM_API_KEY")
		return 1
	case resp.StatusCode == http.StatusTooManyRequests:
		fmt.Println("   ⚠ rate limited — wait 30 seconds and run again")
		return 1
	case resp.StatusCode != http.StatusOK:
		fmt.Println("   ✗ the platform refused to send. Most common causes:")
		fmt.Printf("     • %s is not a registered citizen → register it:\n", identifier)
		fmt.Printf("       go run ./cmd/platform add-user --uin 1234567890 --name \"Your Name\" --email %s\n", identifier)
		fmt.Println("     • the SMTP provider rejected the message (check PLATFORM_SMTP_* in the platform .env)")
		fmt.Println("     • the mail did not fit the provider's rate limit")
		return 1
	}

	fmt.Println("   ✓ the platform accepted the message — it has been handed to the mail provider")
	fmt.Println("4. what to do next")
	fmt.Println("   check the inbox of " + identifier + " (and the spam folder), then sign in at http://localhost:8091")
	fmt.Println("   no email after a minute? run the platform's own probe:")
	fmt.Printf("     go run ./cmd/platform verify-delivery --email %s\n", identifier)
	return 0
}

// maskKey shows enough of a secret to compare two of them without printing it in full.
func maskKey(value string) string {
	switch {
	case value == "":
		return "MISSING"
	case len(value) <= 6:
		return strings.Repeat("*", len(value))
	default:
		return value[:4] + "…" + strings.Repeat("*", 4) + fmt.Sprintf(" (%d chars)", len(value))
	}
}
