package main

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/cookiejar"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"
)

// newTestServer starts the demo in lab mode (fixed code, no e-mail) so the whole flow can be driven
// head-lessly.
func newTestServer(t *testing.T) (*server, *httptest.Server) {
	t.Helper()
	cfg := config{
		issuer:          "http://demo.local",
		platformURL:     "http://127.0.0.1:1", // never contacted in lab mode
		platformKey:     "test-key",
		clientSecret:    "test-signing-key",
		secretValidity:  time.Hour,
		sessionValidity: 24 * time.Hour,
		labOTP:          "123456",
		accessTokenTTL:  10 * time.Minute,
		refreshTokenTTL: 8 * time.Hour,
		maxRequestSize:  1 << 20,
	}
	srv := &server{
		cfg:    cfg,
		store:  newStore(),
		client: &http.Client{Timeout: 2 * time.Second},
		log:    slog.New(slog.NewTextHandler(io.Discard, nil)),
	}
	ts := httptest.NewServer(srv.routes())
	t.Cleanup(ts.Close)
	srv.cfg.issuer = ts.URL // the registered redirect_uri derives from the issuer
	return srv, ts
}

func pkcePair() (verifier, challenge string) {
	verifier = randomToken(32)
	sum := sha256.Sum256([]byte(verifier))
	return verifier, base64.RawURLEncoding.EncodeToString(sum[:])
}

func postForm(t *testing.T, client *http.Client, endpoint string, form url.Values, followRedirect bool) (*http.Response, string) {
	t.Helper()
	if !followRedirect {
		client = &http.Client{
			Transport: client.Transport,
			CheckRedirect: func(*http.Request, []*http.Request) error {
				return http.ErrUseLastResponse
			},
		}
	}
	resp, err := client.PostForm(endpoint, form)
	if err != nil {
		t.Fatalf("POST %s: %v", endpoint, err)
	}
	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	return resp, string(body)
}

func mustJSON(t *testing.T, body string) map[string]any {
	t.Helper()
	out := map[string]any{}
	if err := json.Unmarshal([]byte(body), &out); err != nil {
		t.Fatalf("response is not JSON: %v (%s)", err, body)
	}
	return out
}

func postJSON(t *testing.T, client *http.Client, endpoint string, form url.Values) (int, map[string]any) {
	t.Helper()
	resp, body := postForm(t, client, endpoint, form, true)
	return resp.StatusCode, mustJSON(t, body)
}

// signIn drives authorize -> login -> OTP -> consent and returns the authorization code.
func signIn(t *testing.T, ts *httptest.Server, clientID string) (code string) {
	t.Helper()
	client := &http.Client{}
	verifier, challenge := pkcePair()
	redirect := ts.URL + "/app/callback?client=" + clientID

	q := url.Values{}
	q.Set("client_id", clientID)
	q.Set("response_type", "code")
	q.Set("redirect_uri", redirect)
	q.Set("scope", "openid profile email device_sso")
	q.Set("state", "state-123")
	q.Set("code_challenge", challenge)
	q.Set("code_challenge_method", "S256")

	resp, err := client.Get(ts.URL + "/oauth2/authorize?" + q.Encode())
	if err != nil {
		t.Fatalf("authorize: %v", err)
	}
	page, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("authorize: status %d", resp.StatusCode)
	}
	if !strings.Contains(string(page), "Sign in to continue") {
		t.Fatalf("authorize: login page not rendered")
	}

	sid := extractHidden(t, string(page), "sid")
	if _, body := postForm(t, client, ts.URL+"/oauth2/login", url.Values{
		"sid": {sid}, "step": {"send"}, "identifier": {"citizen@example.com"},
	}, true); !strings.Contains(body, "Enter your code") {
		t.Fatalf("login step 1: OTP page not rendered: %s", body)
	}
	if _, body := postForm(t, client, ts.URL+"/oauth2/login", url.Values{
		"sid": {sid}, "step": {"verify"}, "otp": {"123456"},
	}, true); !strings.Contains(body, "Share your details") {
		t.Fatalf("login step 2: consent page not rendered: %s", body)
	}

	resp, _ = postForm(t, client, ts.URL+"/oauth2/consent", url.Values{
		"sid": {sid}, "action": {"allow"},
	}, false)
	if resp.StatusCode != http.StatusFound {
		t.Fatalf("consent: expected 302, got %d", resp.StatusCode)
	}
	location, err := url.Parse(resp.Header.Get("Location"))
	if err != nil {
		t.Fatalf("consent: bad Location: %v", err)
	}
	if location.Query().Get("state") != "state-123" {
		t.Fatalf("consent: state not preserved")
	}
	code = location.Query().Get("code")
	if code == "" {
		t.Fatalf("consent: no code in redirect %s", location)
	}
	codeVerifiers[code] = verifier
	return code
}

var codeVerifiers = map[string]string{}

func extractHidden(t *testing.T, page, name string) string {
	t.Helper()
	marker := `name="` + name + `" value="`
	i := strings.Index(page, marker)
	if i < 0 {
		t.Fatalf("hidden input %q not found", name)
	}
	rest := page[i+len(marker):]
	return rest[:strings.Index(rest, `"`)]
}

// redeem exchanges an authorization code for tokens.
func redeem(t *testing.T, ts *httptest.Server, clientID, code string) (int, map[string]any) {
	t.Helper()
	return postJSON(t, &http.Client{}, ts.URL+"/oauth2/token", url.Values{
		"grant_type":    {"authorization_code"},
		"client_id":     {clientID},
		"code":          {code},
		"redirect_uri":  {ts.URL + "/app/callback?client=" + clientID},
		"code_verifier": {codeVerifiers[code]},
	})
}

// TestFullNativeSSOFlow is the whole story: a citizen signs in once, receives a device secret, and a
// second application redeems it without any login screen.
func TestFullNativeSSOFlow(t *testing.T) {
	_, ts := newTestServer(t)
	code := signIn(t, ts, "super-app")

	status, tokens := redeem(t, ts, "super-app", code)
	if status != http.StatusOK {
		t.Fatalf("token: status %d %v", status, tokens)
	}
	for _, key := range []string{"access_token", "id_token", "device_secret", "sid", "scope",
		"refresh_token", "session_data"} {
		if tokens[key] == nil || tokens[key] == "" {
			t.Fatalf("token response missing %q: %v", key, tokens)
		}
	}
	sid, _ := tokens["sid"].(string)
	idToken, _ := tokens["id_token"].(string)
	deviceSecret, _ := tokens["device_secret"].(string)

	// The device secret announces itself: typ=sso-session+jwt, and it carries session_data.
	header, err := decodeJWTHeader(deviceSecret)
	if err != nil {
		t.Fatalf("device_secret header: %v", err)
	}
	if header["typ"] != "sso-session+jwt" {
		t.Fatalf("device_secret typ = %v, want sso-session+jwt", header["typ"])
	}
	secretClaims, err := parseJWT("test-signing-key", deviceSecret)
	if err != nil {
		t.Fatalf("device_secret is not verifiable: %v", err)
	}
	entries, _ := secretClaims["session_data"].([]any)
	if len(entries) != 1 {
		t.Fatalf("device_secret must carry exactly one session_data entry, got %v", secretClaims)
	}
	entry, _ := entries[0].(map[string]any)
	handle, _ := entry["session_handle"].(string)
	if handle == "" || entry["flow_identifier"] != "super-app" {
		t.Fatalf("session_data entry malformed: %v", entry)
	}

	// The id token names the session the secret resumes.
	claims, err := parseJWT("test-signing-key", idToken)
	if err != nil {
		t.Fatalf("id_token is not verifiable: %v", err)
	}
	if claims["sid"] != sid {
		t.Fatalf("id_token sid %v != %v", claims["sid"], sid)
	}

	// A second application on the same device redeems the device secret — no code, no prompt.
	status, exchanged := postJSON(t, &http.Client{}, ts.URL+"/oauth2/token", url.Values{
		"grant_type":           {"urn:ietf:params:oauth:grant-type:token-exchange"},
		"client_id":            {"child-app"},
		"subject_token":        {deviceSecret},
		"subject_token_type":   {"urn:ietf:params:oauth:token-type:jwt"},
		"requested_token_type": {"urn:ietf:params:oauth:token-type:access_token"},
		"scope":                {"openid profile"},
	})
	if status != http.StatusOK {
		t.Fatalf("token exchange: status %d %v", status, exchanged)
	}
	if exchanged["sid"] != sid {
		t.Fatalf("the exchange must resume the same session")
	}
	if exchanged["issued_token_type"] != "urn:ietf:params:oauth:token-type:access_token" {
		t.Fatalf("missing issued_token_type")
	}
	if exchanged["refresh_token"] == nil {
		t.Fatalf("the exchange must issue a refresh token")
	}

	// Both tokens work at /userinfo, and both report the same session.
	for _, token := range []any{exchanged["access_token"], tokens["access_token"]} {
		req, _ := http.NewRequest(http.MethodGet, ts.URL+"/oauth2/userinfo", nil)
		req.Header.Set("Authorization", "Bearer "+token.(string))
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("userinfo: %v", err)
		}
		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("userinfo: status %d %s", resp.StatusCode, body)
		}
		if mustJSON(t, string(body))["sid"] != sid {
			t.Fatalf("userinfo must report the session id")
		}
	}

	// The refresh token rotates: the old one stops working.
	status, refreshed := postJSON(t, &http.Client{}, ts.URL+"/oauth2/token", url.Values{
		"grant_type":    {"refresh_token"},
		"client_id":     {"child-app"},
		"refresh_token": {exchanged["refresh_token"].(string)},
	})
	if status != http.StatusOK || refreshed["access_token"] == nil {
		t.Fatalf("refresh: status %d %v", status, refreshed)
	}
	status, reuse := postJSON(t, &http.Client{}, ts.URL+"/oauth2/token", url.Values{
		"grant_type":    {"refresh_token"},
		"client_id":     {"child-app"},
		"refresh_token": {exchanged["refresh_token"].(string)},
	})
	if status == http.StatusOK || reuse["error"] != "invalid_grant" {
		t.Fatalf("a rotated refresh token must not be reusable")
	}
}

// TestDeviceSecretRejections covers the ways a device secret exchange must fail.
func TestDeviceSecretRejections(t *testing.T) {
	srv, ts := newTestServer(t)
	code := signIn(t, ts, "super-app")
	_, tokens := redeem(t, ts, "super-app", code)
	deviceSecret := tokens["device_secret"].(string)

	exchange := func(over map[string]string) (int, map[string]any) {
		form := url.Values{
			"grant_type":         {"urn:ietf:params:oauth:grant-type:token-exchange"},
			"client_id":          {"child-app"},
			"subject_token":      {deviceSecret},
			"subject_token_type": {"urn:ietf:params:oauth:token-type:jwt"},
			"scope":              {"openid profile"},
		}
		for k, v := range over {
			form.Set(k, v)
		}
		return postJSON(t, &http.Client{}, ts.URL+"/oauth2/token", form)
	}

	cases := []struct {
		name     string
		override map[string]string
		want     string
	}{
		{"id_token is not a device secret", map[string]string{"subject_token": tokens["id_token"].(string)}, "invalid_request"},
		{"garbage subject token", map[string]string{"subject_token": "not-a-jwt"}, "invalid_request"},
		{"wrong subject_token_type", map[string]string{"subject_token_type": "urn:ietf:params:oauth:token-type:id_token"}, "invalid_request"},
		{"actor_token refused", map[string]string{"actor_token": tokens["access_token"].(string)}, "invalid_request"},
		{"only access tokens can be requested", map[string]string{"requested_token_type": "urn:ietf:params:oauth:token-type:refresh_token"}, "invalid_request"},
		{"device_sso cannot be exchanged", map[string]string{"scope": "openid device_sso"}, "invalid_scope"},
		{"scope widening", map[string]string{"scope": "openid admin"}, "invalid_scope"},
		{"unknown client", map[string]string{"client_id": "evil-app"}, "invalid_client"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			status, body := exchange(tc.override)
			if status == http.StatusOK {
				t.Fatalf("expected rejection, got 200 %v", body)
			}
			if body["error"] != tc.want {
				t.Fatalf("expected %q, got %v (%v)", tc.want, body["error"], body["error_description"])
			}
		})
	}

	// A tampered secret fails the signature check.
	tampered := deviceSecret[:len(deviceSecret)-4] + "AAAA"
	if status, body := exchange(map[string]string{"subject_token": tampered}); status == http.StatusOK {
		t.Fatalf("a tampered device secret must be refused: %v", body)
	}

	// Revoking the session turns the next exchange into interaction_required: the app must log in again.
	revokeResp, _ := postForm(t, &http.Client{}, ts.URL+"/oauth2/revoke", url.Values{
		"token": {tokens["refresh_token"].(string)},
	}, true)
	if revokeResp.StatusCode != http.StatusOK {
		t.Fatalf("revoke: status %d", revokeResp.StatusCode)
	}
	status, body := exchange(nil)
	if status == http.StatusOK || body["error"] != "interaction_required" {
		t.Fatalf("after revocation the exchange must answer interaction_required, got %d %v", status, body)
	}
	_ = srv
}

// TestAuthorizationCodeSingleUseAndPKCE keeps the code grant honest.
func TestAuthorizationCodeSingleUseAndPKCE(t *testing.T) {
	_, ts := newTestServer(t)
	code := signIn(t, ts, "super-app")

	if status, _ := redeem(t, ts, "super-app", code); status != http.StatusOK {
		t.Fatalf("first redemption must succeed")
	}
	status, body := redeem(t, ts, "super-app", code)
	if status == http.StatusOK || body["error"] != "invalid_grant" {
		t.Fatalf("code reuse must fail, got %d %v", status, body)
	}

	code2 := signIn(t, ts, "super-app")
	status, body = postJSON(t, &http.Client{}, ts.URL+"/oauth2/token", url.Values{
		"grant_type":    {"authorization_code"},
		"client_id":     {"super-app"},
		"code":          {code2},
		"redirect_uri":  {ts.URL + "/app/callback?client=super-app"},
		"code_verifier": {randomToken(32)},
	})
	if status == http.StatusOK || body["error"] != "invalid_grant" {
		t.Fatalf("PKCE mismatch must fail, got %d %v", status, body)
	}

	// The code is bound to its client and its redirect_uri.
	code3 := signIn(t, ts, "super-app")
	status, body = postJSON(t, &http.Client{}, ts.URL+"/oauth2/token", url.Values{
		"grant_type":    {"authorization_code"},
		"client_id":     {"child-app"},
		"code":          {code3},
		"redirect_uri":  {ts.URL + "/app/callback?client=super-app"},
		"code_verifier": {codeVerifiers[code3]},
	})
	if status == http.StatusOK || body["error"] != "invalid_grant" {
		t.Fatalf("a code redeemed by another client must fail, got %d %v", status, body)
	}
}

func TestAuthorizeValidation(t *testing.T) {
	_, ts := newTestServer(t)
	base := url.Values{
		"client_id": {"super-app"}, "response_type": {"code"},
		"redirect_uri":   {ts.URL + "/app/callback?client=super-app"},
		"scope":          {"openid device_sso"},
		"code_challenge": {pkceChallenge("v")}, "code_challenge_method": {"S256"},
		"state": {"x"},
	}
	cases := []struct{ name, key, value string }{
		{"unknown client", "client_id", "nope"},
		{"bad response type", "response_type", "token"},
		{"redirect uri mismatch", "redirect_uri", "http://evil.example/cb"},
		{"missing openid", "scope", "profile"},
		{"scope not allowed", "scope", "openid admin"},
		{"no pkce", "code_challenge", ""},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			q := url.Values{}
			for k, v := range base {
				q[k] = v
			}
			q.Set(tc.key, tc.value)
			client := &http.Client{CheckRedirect: func(*http.Request, []*http.Request) error {
				return http.ErrUseLastResponse
			}}
			resp, err := client.Get(ts.URL + "/oauth2/authorize?" + q.Encode())
			if err != nil {
				t.Fatalf("authorize: %v", err)
			}
			defer resp.Body.Close()
			redirectedWithError := resp.StatusCode == http.StatusFound &&
				strings.Contains(resp.Header.Get("Location"), "error=")
			if !(resp.StatusCode == http.StatusBadRequest || redirectedWithError) {
				t.Fatalf("expected rejection for %s, got %d", tc.name, resp.StatusCode)
			}
		})
	}

	resp, err := http.Get(ts.URL + "/oauth2/authorize?" + base.Encode())
	if err != nil {
		t.Fatalf("authorize: %v", err)
	}
	page, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != http.StatusOK || !strings.Contains(string(page), "Sign in to continue") {
		t.Fatalf("happy path: status %d", resp.StatusCode)
	}
}

func TestPagesRender(t *testing.T) {
	_, ts := newTestServer(t)
	for _, path := range []string{"/", "/app?client=super-app", "/app?client=child-app"} {
		resp, err := http.Get(ts.URL + path)
		if err != nil {
			t.Fatalf("GET %s: %v", path, err)
		}
		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("GET %s: status %d", path, resp.StatusCode)
		}
		if len(body) < 500 {
			t.Fatalf("GET %s: suspiciously short page", path)
		}
	}

	healthResp, err := http.Get(ts.URL + "/health")
	if err != nil || healthResp.StatusCode != http.StatusOK {
		t.Fatalf("GET /health failed")
	}
	healthBody, _ := io.ReadAll(healthResp.Body)
	healthResp.Body.Close()
	if mustJSON(t, string(healthBody))["status"] != "UP" {
		t.Fatalf("health must report UP")
	}

	jar, _ := cookiejar.New(nil)
	client := &http.Client{Jar: jar}
	resp, err := client.Get(ts.URL + "/app?client=child-app")
	if err != nil || resp.StatusCode != http.StatusOK {
		t.Fatalf("cookie-less GET failed")
	}
	resp.Body.Close()
}
