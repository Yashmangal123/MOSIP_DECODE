#!/usr/bin/env bash
# Builds and starts the Native SSO demo. The platform service must already be running on :8090.
set -euo pipefail
cd "$(dirname "$0")"

if [[ ! -f .env ]]; then
  echo "No .env found. Run: cp .env.example .env  and fill the CHANGE_ME values." >&2
  exit 1
fi
set -a; . ./.env; set +a

if ! curl -fsS "${SSO_PLATFORM_URL:-http://127.0.0.1:8090}/health" >/dev/null 2>&1; then
  echo "The platform service is not answering at ${SSO_PLATFORM_URL:-http://127.0.0.1:8090}." >&2
  echo "Start it first:  cd ../platform && set -a && . ./.env && set +a && go run ./cmd/platform" >&2
  exit 1
fi

echo "Building…"
go build -o bin/native-sso-demo .
echo "Native SSO demo listening on ${SSO_ADDR:-:8091} — open http://localhost${SSO_ADDR:-:8091}/"
exec ./bin/native-sso-demo
