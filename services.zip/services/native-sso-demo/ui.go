package main

import (
	"fmt"
	"html"
	"net/http"
	"net/url"
	"strings"
)

// ---------------------------------------------------------------------------
// shared layout
// ---------------------------------------------------------------------------

const baseCSS = `
:root{--bg:#0b1020;--card:#141b31;--card2:#1b2440;--ink:#eef2ff;--muted:#9aa7c7;--line:#26314f;
--brand:#4f7cff;--brand2:#22d3a6;--warn:#f6c177;--bad:#ff6b6b}
*{box-sizing:border-box}
body{margin:0;background:radial-gradient(1200px 600px at 20% -10%,#1a2e63 0%,var(--bg) 55%);
color:var(--ink);font:15px/1.6 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;min-height:100vh}
a{color:var(--brand2);text-decoration:none}a:hover{text-decoration:underline}
.wrap{max-width:1040px;margin:0 auto;padding:28px 20px 60px}
header.top{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:26px;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:12px;font-weight:700;font-size:18px;letter-spacing:.2px}
.logo{width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,var(--brand),var(--brand2));
display:grid;place-items:center;color:#04101f;font-weight:800}
h1{font-size:26px;margin:0 0 6px}h2{font-size:18px;margin:0 0 10px}
p.lead{color:var(--muted);margin:0 0 22px;max-width:70ch}
.card{background:linear-gradient(180deg,var(--card),var(--card2));border:1px solid var(--line);
border-radius:16px;padding:22px;box-shadow:0 20px 50px -30px #000}
.grid{display:grid;gap:18px;grid-template-columns:repeat(auto-fit,minmax(320px,1fr))}
.split{display:grid;gap:26px;grid-template-columns:minmax(320px,380px) 1fr;align-items:start}
@media(max-width:820px){.split{grid-template-columns:1fr}}
.between{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px}
details.card{padding:16px 20px}
details.card>summary{cursor:pointer;font-weight:600;color:var(--ink);list-style:none}
details.card>summary::-webkit-details-marker{display:none}
details.card>summary:before{content:"▸ ";color:var(--brand2)}
details.card[open]>summary:before{content:"▾ "}
h2{margin:0}
label{display:block;font-size:13px;color:var(--muted);margin:14px 0 6px}
input{width:100%;padding:12px 14px;border-radius:10px;border:1px solid var(--line);
background:#0e152a;color:var(--ink);font-size:15px}
input:focus{outline:2px solid var(--brand);outline-offset:1px}
button,a.btn{display:inline-block;padding:12px 18px;border-radius:10px;border:0;cursor:pointer;
background:linear-gradient(135deg,var(--brand),#6f5bff);color:#fff;font-weight:600;font-size:15px}
button.ghost,a.ghost{background:transparent;border:1px solid var(--line);color:var(--ink)}
button.green{background:linear-gradient(135deg,var(--brand2),#12b48a);color:#04211a}
button:disabled{opacity:.6;cursor:progress}
.row{display:flex;gap:12px;align-items:center;flex-wrap:wrap}
.muted{color:var(--muted)}.small{font-size:13px}
.pill{display:inline-block;padding:3px 10px;border-radius:999px;background:#0e152a;border:1px solid var(--line);
font-size:12px;color:var(--muted)}
.pill.ok{border-color:#1f6b52;color:var(--brand2)}.pill.warn{border-color:#6b5a1f;color:var(--warn)}
.err{background:#3a1520;border:1px solid #7a2b3c;color:#ffd7de;padding:10px 12px;border-radius:10px;
margin:12px 0;font-size:14px}
.note{background:#0e152a;border:1px dashed var(--line);border-radius:12px;padding:12px 14px;
color:var(--muted);font-size:13px}
code,pre{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
pre{background:#080d1b;border:1px solid var(--line);border-radius:10px;padding:12px;overflow:auto;
font-size:12px;color:#c8d4f5;max-height:260px}
ol.steps{counter-reset:s;list-style:none;padding:0;margin:0}
ol.steps li{counter-increment:s;position:relative;padding:0 0 14px 40px;color:var(--muted)}
ol.steps li:before{content:counter(s);position:absolute;left:0;top:0;width:26px;height:26px;border-radius:50%;
background:#16203a;border:1px solid var(--line);display:grid;place-items:center;color:var(--brand2);font-size:13px}
ol.steps li b{color:var(--ink)}
.phone{width:360px;max-width:100%;margin:0 auto;border:10px solid #0a0f1e;border-radius:34px;background:#0a1224;
box-shadow:0 40px 80px -40px #000;overflow:hidden}
.phone .bar{display:flex;justify-content:space-between;padding:8px 16px;font-size:11px;color:var(--muted);
background:#070c18}
.phone .app{padding:18px}
.phone h3{margin:0 0 2px;font-size:17px}
.kv{display:grid;grid-template-columns:120px 1fr;gap:6px 10px;font-size:13px;margin:10px 0}
.kv span:nth-child(odd){color:var(--muted)}
.badge{font-size:11px;padding:2px 8px;border-radius:999px;background:#12213c;color:var(--brand2);
border:1px solid #1f3a63}
footer{margin-top:34px;color:var(--muted);font-size:12px;text-align:center}
`

func (s *server) page(title, body string) string {
	return `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>` + html.EscapeString(title) + ` · Native SSO</title><style>` + baseCSS + `</style></head>
<body><div class="wrap">
<header class="top"><div class="brand"><div class="logo">eS</div>
<div>eSignet Native SSO <span class="pill">demo</span></div></div>
<div class="row small"><a href="/">Apps</a><a href="/health">Health</a></div></header>
` + body + `
<footer>OpenID Connect Native SSO · device_sso · device_secret / ds_hash / sid · RFC 8693 token exchange</footer>
</div></body></html>`
}

func esc(v string) string { return html.EscapeString(v) }

// ---------------------------------------------------------------------------
// landing page
// ---------------------------------------------------------------------------

func (s *server) handleLanding(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	mode := `<span class="pill ok">real e-mail delivery</span>`
	if s.cfg.labOTP != "" {
		mode = `<span class="pill warn">lab mode — fixed code, no e-mail</span>`
	}
	body := `
<h1>Two apps, one sign-in.</h1>
<p class="lead">Sign in once with a one-time code sent to your inbox, then open the second app — it never
asks for a code, because the phone holds a <code>device_secret</code> for that session. That is
<code>device_sso</code>. ` + mode + `</p>

<div class="grid">
  <div class="card">
    <div class="between"><h2>1 · Super App</h2><span class="badge">super-app</span></div>
    <p class="muted">Signs the citizen in with a real e-mail code, then receives the device secret.</p>
    <p style="margin:18px 0 0"><a class="btn" href="/app?client=super-app">Open Super App →</a></p>
  </div>
  <div class="card">
    <div class="between"><h2>2 · Child App</h2><span class="badge">child-app</span></div>
    <p class="muted">No login screen. Redeems the device secret and gets its own tokens.</p>
    <p style="margin:18px 0 0"><a class="btn ghost" href="/app?client=child-app">Open Child App →</a></p>
  </div>
</div>

<details class="card" style="margin-top:22px">
  <summary>How it works, step by step</summary>
  <ol class="steps" style="margin-top:14px">
    <li><b>Super App → /oauth2/authorize</b> with PKCE and <code>scope=… device_sso</code>.</li>
    <li><b>Login</b>: the platform mails the code; verifying it binds a session to the citizen's UIN.</li>
    <li><b>Consent</b> → redirect with a single-use <code>code</code>.</li>
    <li><b>POST /oauth2/token</b> (authorization_code) → access token, id token, refresh token and — because
        of <code>device_sso</code> — a <code>device_secret</code>: a JWT with <code>typ: sso-session+jwt</code>
        whose <code>session_data</code> names the sessions of this sign-in.</li>
    <li><b>Child App → POST /oauth2/token</b> (token exchange) with the device secret as the
        <code>subject_token</code> → its own tokens, no code, no user interaction.</li>
  </ol>
  <p class="note" style="margin-top:6px">The same protocol is implemented by the engine
  (<code>thunderid-engine</code>). This demo is the authorization server so that you can click through it
  without the full MOSIP stack.</p>
</details>

<details class="card" style="margin-top:14px">
  <summary>Troubleshooting: no e-mail arriving</summary>
  <p class="muted small" style="margin-top:12px">Run this in the demo's folder — it checks the platform key,
  the platform health and the delivery in one go, and prints the reason:</p>
  <pre>go run . --check you@example.com</pre>
  <p class="muted small">Most common causes: the address is not registered as a citizen
  (<code>go run ./cmd/platform add-user …</code>), <code>SSO_PLATFORM_API_KEY</code> does not equal
  <code>PLATFORM_API_KEY</code>, or the Gmail App Password in the platform's <code>.env</code> is wrong.</p>
</details>`
	writeHTML(w, http.StatusOK, s.page("Apps", body))
}

// ---------------------------------------------------------------------------
// the two demo apps
// ---------------------------------------------------------------------------

func (s *server) handleApp(w http.ResponseWriter, r *http.Request) {
	clientID := r.URL.Query().Get("client")
	client, ok := s.clients()[clientID]
	if !ok {
		s.renderError(w, http.StatusNotFound, "unknown_client", "Open /app?client=super-app or /app?client=child-app")
		return
	}
	authorizeURL := "/oauth2/authorize?client_id=" + url.QueryEscape(clientID) +
		"&response_type=code&redirect_uri=" + url.QueryEscape(s.redirectURI(clientID)) +
		"&scope=" + url.QueryEscape("openid profile email device_sso")
	other := "child-app"
	if clientID == "child-app" {
		other = "super-app"
	}

	body := `
<h1>` + esc(client.Name) + `</h1>
<p class="lead">` + esc(client.Description) + `</p>
<div class="split">
  <div class="phone">
    <div class="bar"><span>9:41</span><span>` + esc(client.Name) + `</span><span>▮▮▮</span></div>
    <div class="app" id="app" data-client="` + esc(clientID) + `" data-authorize="` + esc(authorizeURL) + `">
      <p class="muted small">Loading…</p>
    </div>
  </div>
  <div>
    <div class="card">
      <div class="between"><h2>Session</h2><a class="small" href="/app?client=` + esc(other) + `">other app →</a></div>
      <div id="state"><p class="muted small">Nothing yet.</p></div>
    </div>
    <details class="card" style="margin-top:14px">
      <summary>Tokens</summary>
      <div id="tokens" class="muted small" style="margin-top:12px">Sign in to see them.</div>
    </details>
    <details class="card" style="margin-top:14px">
      <summary>Requests made by this screen</summary>
      <pre id="log">(nothing yet)</pre>
    </details>
  </div>
</div>
` + appScript()
	writeHTML(w, http.StatusOK, s.page(client.Name, body))
}

// handleAppCallback receives the authorization code and swaps it for tokens in the browser.
func (s *server) handleAppCallback(w http.ResponseWriter, r *http.Request) {
	clientID := r.URL.Query().Get("client")
	body := `
<h1>Finishing sign-in…</h1>
<div class="card"><p class="muted" id="msg">Exchanging the authorization code for tokens…</p>
<pre id="log"></pre></div>
` + callbackScript(clientID)
	writeHTML(w, http.StatusOK, s.page("Callback", body))
}

// ---------------------------------------------------------------------------
// login, OTP, consent screens
// ---------------------------------------------------------------------------

func (s *server) renderLogin(w http.ResponseWriter, req *authRequest, identifier, errMsg, _ string) {
	if errMsg == "" && identifier != "" {
		errMsg = ""
	}
	errBlock := ""
	if errMsg != "" {
		hint := ""
		lower := strings.ToLower(errMsg)
		switch {
		case strings.Contains(lower, "could not be sent") || strings.Contains(lower, "not registered"):
			hint = `The platform refused to send. Either this address is not a registered citizen, or its
			mail provider rejected the message. Register it with:
			<pre>go run ./cmd/platform add-user --uin 1234567890 --name "Your Name" --email ` + esc(identifier) + `</pre>
			or run <code>go run . --check ` + esc(identifier) + `</code> from the demo folder to see the exact reason.`
		case strings.Contains(lower, "unauthorized") || strings.Contains(lower, "401"):
			hint = `<code>SSO_PLATFORM_API_KEY</code> does not match <code>PLATFORM_API_KEY</code> in the
			platform's <code>.env</code>.`
		case strings.Contains(lower, "rate") || strings.Contains(lower, "wait"):
			hint = `A code was requested moments ago. Wait 30 seconds and try again.`
		case strings.Contains(lower, "unreachable"):
			hint = `The platform service is not running. Start it with <code>go run ./cmd/platform</code> (port 8090).`
		}
		errBlock = `<div class="err">` + esc(errMsg) + `</div>`
		if hint != "" {
			errBlock += `<div class="note" style="margin-bottom:12px">` + hint + `</div>`
		}
	}
	client := s.clients()[req.ClientID]
	body := `
<h1>Sign in to continue</h1>
<p class="lead">` + esc(client.Name) + ` is asking eSignet to verify you. Your one-time code is sent to the
address registered against your identity — nothing is shown on this screen.</p>
<div class="card" style="max-width:520px">
  <div class="row" style="justify-content:space-between">
    <b>` + esc(client.Name) + `</b><span class="pill">client_id: ` + esc(req.ClientID) + `</span>
  </div>
  <p class="muted small" style="margin-top:10px">Requested access: ` + esc(joinScopes(req.Scope)) + `</p>
  ` + errBlock + `
  <form method="post" action="/oauth2/login">
    <input type="hidden" name="sid" value="` + esc(req.ID) + `">
    <input type="hidden" name="step" value="send">
    <label for="identifier">Email address or UIN registered with eSignet</label>
    <input id="identifier" name="identifier" autocomplete="username" autofocus
           placeholder="you@example.com" value="` + esc(identifier) + `">
    <p class="note" style="margin-top:12px">Use any citizen registered in the platform, e.g. the one you
    created with <code>platform add-user</code>. The code is delivered by the platform service.</p>
    <p style="margin-top:16px"><button type="submit">Send my code</button></p>
  </form>
</div>`
	writeHTML(w, http.StatusOK, s.page("Sign in", body))
}

func (s *server) renderOTP(w http.ResponseWriter, req *authRequest, masked, provider, errMsg string) {
	errBlock := ""
	if errMsg != "" {
		errBlock = `<div class="err">` + esc(errMsg) + `</div>`
	}
	labNote := ""
	if s.cfg.labOTP != "" {
		labNote = `<div class="err" style="background:#3a3015;border-color:#7a652b;color:#ffe9b8">
			Lab mode: the fixed verification code is <code>` + esc(s.cfg.labOTP) + `</code>. No e-mail was sent.</div>`
	}
	body := `
<h1>Enter your code</h1>
<p class="lead">Sent to <b>` + esc(masked) + `</b> via ` + esc(provider) + `. It expires in 5 minutes and can
be used once.</p>
<div class="card" style="max-width:520px">` + errBlock + labNote + `
  <form method="post" action="/oauth2/login">
    <input type="hidden" name="sid" value="` + esc(req.ID) + `">
    <input type="hidden" name="step" value="verify">
    <label for="otp">Verification code</label>
    <input id="otp" name="otp" inputmode="numeric" autocomplete="one-time-code" autofocus
           placeholder="6 digits" maxlength="8" style="letter-spacing:6px;font-size:20px">
    <div class="row" style="margin-top:16px">
      <button type="submit">Verify</button>
      <a class="btn ghost" href="/oauth2/authorize?client_id=` + url.QueryEscape(req.ClientID) +
		`&response_type=code&redirect_uri=` + url.QueryEscape(req.RedirectURI) +
		`&scope=` + url.QueryEscape(joinScopes(req.Scope)) + `&code_challenge=x&code_challenge_method=plain">Start over</a>
    </div>
  </form>
</div>`
	writeHTML(w, http.StatusOK, s.page("Verification code", body))
}

func (s *server) renderConsent(w http.ResponseWriter, req *authRequest) {
	client := s.clients()[req.ClientID]
	rows := ""
	for _, sc := range req.Scope {
		label := sc
		switch sc {
		case "openid":
			label = "Confirm who you are (openid)"
		case "profile":
			label = "Your name and date of birth (profile)"
		case "email":
			label = "Your email address (email)"
		case "phone":
			label = "Your mobile number (phone)"
		case "device_sso":
			label = "Keep me signed in on this device across apps (device_sso)"
		}
		rows += `<li><b>` + esc(label) + `</b></li>`
	}
	body := `
<h1>Share your details?</h1>
<p class="lead">You were verified as <b>` + esc(req.Identifier) + `</b>
(UIN <code>` + esc(req.UIN) + `</code>).</p>
<div class="card" style="max-width:560px">
  <p><b>` + esc(client.Name) + `</b> is requesting:</p>
  <ul>` + rows + `</ul>
  <p class="note">Granting <code>device_sso</code> lets this app receive a device secret so that other apps
  on the same phone can sign you in without another code. You can revoke it any time from the app.</p>
  <form method="post" action="/oauth2/consent">
    <input type="hidden" name="sid" value="` + esc(req.ID) + `">
    <div class="row" style="margin-top:16px">
      <button class="green" type="submit" name="action" value="allow">Allow</button>
      <button class="ghost" type="submit" name="action" value="deny">Deny</button>
    </div>
  </form>
</div>`
	writeHTML(w, http.StatusOK, s.page("Consent", body))
}

func (s *server) renderError(w http.ResponseWriter, status int, code, message string) {
	body := `<h1>` + esc(code) + `</h1><div class="card"><p class="muted">` + esc(message) + `</p>
	<p><a class="btn ghost" href="/">Back to the apps</a></p></div>`
	writeHTML(w, status, s.page("Error", body))
}

// redirectError returns an OAuth error to the client's redirect_uri (RFC 6749 §4.1.2.1).
func (s *server) redirectError(w http.ResponseWriter, r *http.Request, code, description string) {
	q := r.URL.Query()
	target := q.Get("redirect_uri")
	if target == "" || !strings.HasPrefix(target, s.cfg.issuer) {
		s.renderError(w, http.StatusBadRequest, code, description)
		return
	}
	sep := "?"
	if strings.Contains(target, "?") {
		sep = "&"
	}
	location := fmt.Sprintf("%s%serror=%s&error_description=%s", target, sep,
		url.QueryEscape(code), url.QueryEscape(description))
	if state := q.Get("state"); state != "" {
		location += "&state=" + url.QueryEscape(state)
	}
	http.Redirect(w, r, location, http.StatusFound)
}
