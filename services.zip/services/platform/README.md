# eSignet Platform Service

The platform service completes the Native SSO deployment that the eSignet authorization server and the
mobile applications form. It owns the pieces that are deliberately *not* part of the authorization
server: one-time-password issuance and delivery, the identity directory behind the demo identity
provider, notifications, the security event stream, and the administrator analytics console.

It is a separate Go module (`github.com/mosip/esignet-platform`) so it can be versioned, deployed and
scaled independently of eSignet, and it never touches eSignet's database: sessions, tokens and device
secrets stay in eSignet, which is the single authority for them.

```
                 ┌──────────────────────────┐        token introspection        ┌──────────────┐
  mobile apps ──▶│ platform service          │──────────────────────────────────▶│   eSignet    │
  (Super App,    │  · OTP send / verify      │        session read / revoke      │  (OIDC +     │
   Child App)    │  · identity directory     │◀──────────────────────────────────│   Native SSO)│
                 │  · notifications          │                                   └──────────────┘
                 │  · security events        │                                            │
  operators ────▶│  · admin console + SSE    │◀────── device_sso_session (read) ──────────┘
                 └───────┬──────────┬────────┘
                         │          │
                    SMTP/email   SMS provider (MSG91 / Twilio / AWS SNS)
                         │          │
                    PostgreSQL  platform schema
```

## What it provides

| Area | Capability |
| --- | --- |
| OTP | 6/8-digit CSPRNG codes, HMAC-SHA256 digests only, single-use challenges, attempt locking, resend cooldown, sliding-window and per-IP throttling, supersession of older codes |
| Delivery | Real SMTP email — implicit TLS (465), STARTTLS (587) or a local sink — with authentication and certificate verification that cannot be disabled; real SMS through MSG91, Twilio, AWS SNS (SigV4 signed in-process) **or any HTTP gateway via the templated `generic_http` transport**. Transient failures retried with backoff, permanent rejections not retried, every attempt persisted with the provider's own reference and latency. The development `console` transport reports `delivered: false` and is labelled as such everywhere. See [`docs/real-delivery.md`](docs/real-delivery.md) |
| Identity directory | The citizens the demo identity provider authenticates, exposed to eSignet over a key-protected internal API |
| Notifications | Per-user notification centre with unread counts |
| Security events | Append-only audit stream (`OTP_SENT`, `OTP_VERIFIED`, `OTP_FAILED`, `OTP_DELIVERY_FAILED`, `LOGIN_*`, `TOKEN_EXCHANGE_*`, `ADMIN_LOGIN*`, …) queried by the console and pushed live over SSE |
| Administrator console | Embedded single-page UI (`/console`): *operations overview* (active sessions, applications in use, OTP success rate, delivery health), *analytics* (daily authentication activity, OTP funnel, security severity), *sessions* (list and revoke), *audit trail*, effective configuration. Three roles: `ADMIN`, `AUDITOR`, `SUPPORT` |
| E2E demo platform | The Super App / Child App flows in the problem statement call this service for OTP sign-in, session visibility and cross-app sign-out |

## Running locally (no Docker)

Docker is not available in every environment, so the service also runs natively:

```bash
# 1. PostgreSQL 15+ with a database for the platform schema
createdb esignet_platform
psql -d esignet_platform -f db/schema.sql
psql -d esignet_platform -f db/seed.sql        # optional demo citizens

# 2. A REAL mail relay in .env (this project deliberately ships no local mailbox: codes must reach
#    the citizen). Gmail with an App Password, SES, SendGrid or your own relay:
#      PLATFORM_SMTP_HOST=smtp.gmail.com  PLATFORM_SMTP_PORT=587  PLATFORM_SMTP_TLS=starttls
#      PLATFORM_SMTP_USERNAME=you@gmail.com  PLATFORM_SMTP_PASSWORD=<app password, no spaces>

# 3. The service
cp .env.example .env && set -a && . ./.env && set +a
go run ./cmd/platform

# 4. Prove real delivery with your own mailbox / phone (uses the same transports as the service)
go run ./cmd/platform verify-delivery --email you@example.com --phone +919000000001

# 5. Optionally run the whole path end to end (reads the OTP out of the delivered email)
bash scripts/e2e_check.sh
```

Open <http://localhost:8090/console> and sign in with `PLATFORM_ADMIN_EMAIL` / `PLATFORM_ADMIN_PASSWORD`
(the first administrator is created on startup; the password is stored as a PBKDF2-HMAC-SHA256 digest).

### With Docker

```bash
docker compose -f deploy/docker-compose.yml up --build
```

The compose file starts PostgreSQL and the platform service (mail goes to the relay configured in your
`.env`), and mounts `db/schema.sql` and
`db/seed.sql` as first-run initialisation scripts.

## Configuration

Everything is environment-driven; `internal/config` documents each variable with its default, and
startup fails instead of running with an unsafe configuration (missing database URL, missing OTP pepper,
missing admin JWT secret, unknown provider).

| Variable | Default | Purpose |
| --- | --- | --- |
| `PLATFORM_PORT` | `8090` | HTTP port |
| `PLATFORM_ENV` | `development` | `development`, `test` or `production`; gates the development OTP echo |
| `PLATFORM_DATABASE_URL` | – (required) | PostgreSQL DSN |
| `PLATFORM_DB_SCHEMA` | `platform` | Schema holding the platform tables |
| `PLATFORM_API_KEY` | – | Shared key for the internal (service-to-service) API; the API is disabled when empty |
| `PLATFORM_OTP_PEPPER` | – (required) | Server-side secret mixed into the OTP digest |
| `PLATFORM_OTP_LENGTH` | `6` | OTP digits (6 or 8) |
| `PLATFORM_OTP_VALIDITY` | `5m` | Challenge lifetime |
| `PLATFORM_OTP_MAX_ATTEMPTS` | `5` | Wrong attempts before the challenge locks |
| `PLATFORM_OTP_RESEND_COOLDOWN` | `30s` | Minimum interval between sends |
| `PLATFORM_OTP_MAX_SENDS_PER_WINDOW` | `5` | Sends per user+IP per `PLATFORM_OTP_RATE_WINDOW` |
| `PLATFORM_OTP_RATE_WINDOW` | `15m` | Sliding window for the send limits |
| `PLATFORM_OTP_EXPOSE_IN_DEV` | `false` | Return the OTP in the send response **in development only** (for automated tests) |
| `PLATFORM_EMAIL_MODE` | `smtp` | `smtp` or `disabled` |
| `PLATFORM_SMTP_HOST` / `_PORT` | — (required) / `587` | real SMTP relay; a local test mailbox is refused |
| `PLATFORM_ALLOW_LAB_DELIVERY` | `false` | lab only: accept Mailpit/127.0.0.1 as the transport |
| `PLATFORM_SMTP_USERNAME` / `_PASSWORD` | – | SMTP AUTH, when required |
| `PLATFORM_SMTP_FROM` / `_FROM_NAME` | `no-reply@esignet.local` / `MOSIP eSignet` | Sender |
| `PLATFORM_SMTP_TLS` | `none` | `none` (local sink only), `starttls` (587) or `tls` (465). Credentials are refused with `none`, and `none` is refused in production. Certificates are always verified |
| `PLATFORM_SMTP_HELO` / `_REPLY_TO` | – | EHLO name (some relays require a resolvable one) and an optional Reply-To |
| `PLATFORM_EMAIL_MAX_ATTEMPTS` / `_RETRY_BACKOFF` | `3` / `400ms` | Retry policy for transient email failures |
| `PLATFORM_SMS_PROVIDER` | `console` | `msg91`, `twilio`, `aws_sns`, `generic_http` or `console` (development only) |
| `PLATFORM_SMS_MAX_ATTEMPTS` / `_RETRY_BACKOFF` | `3` / `400ms` | Retry policy for transient SMS failures |
| `PLATFORM_SMS_HTTP_*` | – | Generic HTTP gateway: `URL`, `METHOD`, `HEADERS`, `BODY`, `CONTENT_TYPE`, `SUCCESS_STATUS`, `SUCCESS_SUBSTRING`, `REFERENCE_FIELD`. Placeholders `{{to}}`, `{{to_plus}}`, `{{otp}}`, `{{message}}`, `{{sender}}` |
| `PLATFORM_SMS_SENDER_ID` | `ESIGNT` | Sender id / originator |
| `PLATFORM_MSG91_AUTH_KEY` / `_TEMPLATE_ID` / `_ROUTE` | – / – / `4` | MSG91 settings |
| `PLATFORM_TWILIO_ACCOUNT_SID` / `_AUTH_TOKEN` / `_FROM` | – | Twilio settings |
| `PLATFORM_AWS_ACCESS_KEY_ID` / `_SECRET_ACCESS_KEY` / `_REGION` | – | AWS SNS settings |
| `PLATFORM_ESIGNET_URL` | `http://localhost:8080` | eSignet base URL |
| `PLATFORM_ESIGNET_INTROSPECT_CLIENT_ID` / `_SECRET` | – | Client used to introspect mobile access tokens |
| `PLATFORM_ESIGNET_SESSION_API_KEY` | – | Bearer token for eSignet's device-SSO session API |
| `PLATFORM_ADMIN_JWT_SECRET` | – (required) | Signs administrator session tokens |
| `PLATFORM_ADMIN_TOKEN_TTL` | `8h` | Administrator token lifetime |
| `PLATFORM_ADMIN_EMAIL` / `_PASSWORD` | – | Bootstrap administrator, created when none exists |
| `PLATFORM_ADMIN_ALLOWED_ORIGINS` | `http://localhost:5173` | CORS origins for the login endpoints |

## Security properties

* **OTPs are never stored or logged in plaintext.** Only `HMAC-SHA256(pepper, uin || 0 || otp)` is
  persisted, so a database copy cannot be used to authenticate. The digest is bound to the user, which
  stops a digest from one account being replayed against another.
* **Challenges are single use.** `ACTIVE → VERIFIED → CONSUMED`; a replay returns `otp_already_used`.
  An undelivered OTP is cancelled rather than left usable, and a new OTP cancels the old one.
* **Enumeration resistance.** A send to an unknown identifier returns the same generic
  `otp_send_failed` as a delivery failure, and the response only ever contains a masked destination.
* **Throttling.** Resend cooldown plus a per-user/per-IP sliding window; throttled requests are recorded
  as `OTP_RATE_LIMITED` events.
* **Constant-time comparisons** for the internal API key, OTP digests, and administrator password
  digests.
* **Administrators** authenticate with PBKDF2-HMAC-SHA256 (600 000 iterations, per-password salt) and
  receive a short-lived, audience- and issuer-bound HS256 JWT. Roles are enforced per endpoint;
  administrative actions are written to `platform.admin_audit`.
* **Mobile tokens are validated by introspection** against eSignet, so revocation and expiry are
  enforced by the authorization server rather than trusted from the caller.
* **The console** is served with a strict Content-Security-Policy (no external scripts or styles, no
  framing) because it renders event data derived from untrusted client activity, and all rendering is
  escaped.
* **Secrets are read only from the environment**, never from the repository, and the
  `/v1/admin/config` endpoint reports the effective configuration with every credential masked.

## Operator commands

The binary carries its own tooling, so it always uses the same configuration and transports as the service:

```bash
platform verify-delivery --email you@example.com --phone +919000000001   # live delivery probe
bash scripts/live_otp.sh --email you@example.com                          # real OTP to a real inbox
platform add-user --uin 1990010112345678 --name "Asha Verma" \
                  --email asha@example.com --phone +919000000001          # identity directory
```

## API surface

See [`docs/api.md`](docs/api.md) for the request and response of every endpoint, including the internal
API that eSignet calls and the console API.

## Layout

```
cmd/platform/main.go        process wiring: config, store, transports, server, graceful shutdown
internal/config             environment configuration with validation and defaults
internal/store              PostgreSQL persistence (identity, OTP, delivery, notifications, events, admin)
internal/otp                OTP generation, hashing, delivery orchestration, verification state machine
internal/delivery           SMTP, MSG91, Twilio, AWS SNS transports; OTP message rendering
internal/api                HTTP API, auth middleware, SSE hub, recorder, embedded console
db/                         schema.sql, seed.sql
deploy/                     Dockerfile and docker-compose
scripts/                    e2e_check.sh (reads the code out of the real mailbox)
```

## Verified live

A real Gmail delivery was performed end to end in production configuration on 2026-11-02 — code generated
on the server, delivered by SMTP, read from the inbox, verified, then a replay rejected. The transcript is
in [`docs/live-otp-evidence.md`](../../docs/live-otp-evidence.md).

## Tests

```bash
go test ./...        # unit tests: OTP state machine, hashing, transports, auth, config
bash scripts/e2e_check.sh   # end-to-end against a running service and a real SMTP mailbox
```

The unit tests cover the OTP state machine (including replay, locking and expiry), the keyed digest,
masking, the SMTP adapter against an in-process SMTP server (real protocol exchange, rejection and
unreachable-server paths), SMS credential validation, password hashing, JWT issuance/verification,
role and API-key enforcement, CORS, and configuration validation.

`scripts/e2e_check.sh` reads the OTP **out of the delivered email** rather than from the response, which
is what makes it a check of real delivery rather than of a code path.
