// Command platform runs the eSignet platform service.
//
// The service provides the parts of the Native SSO deployment that are not part of the authorization
// server itself: OTP issuance and delivery over email and SMS, the identity directory used by the demo
// identity provider, notifications, the security event stream, and the administrator analytics console.
//
// It is wired from the environment only (see internal/config) and fails to start rather than starting
// with an unsafe configuration.
package main

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/mosip/esignet-platform/internal/api"
	"github.com/mosip/esignet-platform/internal/config"
	"github.com/mosip/esignet-platform/internal/delivery"
	"github.com/mosip/esignet-platform/internal/otp"
	"github.com/mosip/esignet-platform/internal/store"
)

func main() {
	logger := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo}))

	// Subcommands keep the operator tooling in the same binary (and therefore the same configuration
	// and transports as the running service).
	if len(os.Args) > 1 {
		switch os.Args[1] {
		case "verify-delivery":
			os.Exit(verifyDelivery(os.Args[2:], logger))
		case "add-user":
			os.Exit(addUser(os.Args[2:], logger))
		}
	}

	if err := run(logger); err != nil {
		logger.Error("platform service failed", "error", err)
		os.Exit(1)
	}
}

// run builds the service, serves it and shuts it down gracefully.
func run(logger *slog.Logger) error {
	cfg, err := config.Load()
	if err != nil {
		return fmt.Errorf("load configuration: %w", err)
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	st, err := store.New(ctx, cfg.DatabaseURL, cfg.Schema)
	if err != nil {
		return fmt.Errorf("open store: %w", err)
	}
	defer st.Close()

	hub := api.NewEventHub()

	emailSender := delivery.NewEmailSender(cfg.Email, logger.With("transport", "email"))
	smsSender := delivery.NewSMSSender(cfg.SMS, logger.With("transport", "sms"))
	logger.Info("delivery transports resolved",
		"email", emailSender.ProviderName(), "emailRealDelivery", emailSender.IsReal(),
		"sms", smsSender.ProviderName(), "smsRealDelivery", smsSender.IsReal())
	if !smsSender.IsReal() {
		logger.Warn("the SMS channel uses the development console transport; " +
			"set PLATFORM_SMS_PROVIDER to msg91, twilio or aws_sns for real delivery")
	}

	// The recorder persists every OTP event to the security_event table and mirrors it to the live stream.
	recorder := api.NewRecorder(st, hub, logger.With("component", "events"))
	otpService := otp.NewService(cfg, st, emailSender, smsSender, recorder, logger.With("component", "otp"))
	server := api.NewServer(cfg, st, otpService, hub, logger.With("component", "api"))

	if err := server.BootstrapAdministrator(ctx); err != nil {
		return fmt.Errorf("bootstrap administrator: %w", err)
	}

	httpServer := &http.Server{
		Addr:              fmt.Sprintf("0.0.0.0:%d", cfg.Port),
		Handler:           server.Routes(),
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       30 * time.Second,
		WriteTimeout:      0, // the SSE stream is long-lived
		IdleTimeout:       120 * time.Second,
		ErrorLog:          slog.NewLogLogger(logger.Handler(), slog.LevelError),
	}

	serverErrors := make(chan error, 1)
	go func() {
		logger.Info("platform service listening", "address", httpServer.Addr, "environment", cfg.Environment)
		if err := httpServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			serverErrors <- err
		}
	}()

	select {
	case err := <-serverErrors:
		return fmt.Errorf("serve: %w", err)
	case <-ctx.Done():
		logger.Info("shutdown signal received")
	}

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	if err := httpServer.Shutdown(shutdownCtx); err != nil {
		return fmt.Errorf("shutdown: %w", err)
	}
	logger.Info("platform service stopped")
	return nil
}
