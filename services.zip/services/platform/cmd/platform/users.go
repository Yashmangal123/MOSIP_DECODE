package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"os"
	"time"

	"github.com/mosip/esignet-platform/internal/config"
	"github.com/mosip/esignet-platform/internal/store"
)

// addUser inserts or updates a citizen in the platform identity directory.
//
// The directory is what the identity provider authenticates against, and it is also the only source of
// delivery destinations: the OTP service never accepts an address from the request, so a citizen must
// exist here before an OTP can be sent to them. This command is the operator path for that (the demo seed
// file is the bulk path).
//
//	platform add-user --uin 1990010112345678 --name "Asha Verma" --email asha@example.com --phone +919000000001
func addUser(args []string, logger *slog.Logger) int {
	flags := flag.NewFlagSet("add-user", flag.ExitOnError)
	uin := flags.String("uin", "", "UIN (national identifier), required")
	name := flags.String("name", "", "full name, required")
	given := flags.String("given-name", "", "given name (defaults to the first word of --name)")
	family := flags.String("family-name", "", "family name (defaults to the rest of --name)")
	email := flags.String("email", "", "email address that receives OTPs")
	phone := flags.String("phone", "", "phone number in E.164 form that receives OTPs")
	birthdate := flags.String("birthdate", "", "birthdate (YYYY-MM-DD)")
	gender := flags.String("gender", "", "gender")
	address := flags.String("address", "", "postal address")
	locale := flags.String("locale", "en", "preferred locale")
	_ = flags.Parse(args)

	if *uin == "" || *name == "" {
		fmt.Fprintln(os.Stderr, "add-user: --uin and --name are required")
		return 2
	}
	if *email == "" && *phone == "" {
		fmt.Fprintln(os.Stderr, "add-user: at least one of --email or --phone is required, "+
			"otherwise no OTP can ever be delivered to this citizen")
		return 2
	}

	cfg, err := config.Load()
	if err != nil {
		fmt.Fprintf(os.Stderr, "add-user: configuration error: %v\n", err)
		return 2
	}

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	db, err := store.New(ctx, cfg.DatabaseURL, cfg.Schema)
	if err != nil {
		fmt.Fprintf(os.Stderr, "add-user: database error: %v\n", err)
		return 1
	}
	defer db.Close()

	givenName, familyName := *given, *family
	if givenName == "" {
		givenName, familyName = splitName(*name)
	}

	// Email and phone are unique in the directory, so an existing citizen is updated in place rather than
	// duplicated: the identifier they already use is the one an OTP can be delivered to.
	resolvedUIN := *uin
	if existing, lookupErr := db.GetUserByIdentifier(ctx, firstNonEmpty(*email, *phone)); lookupErr == nil {
		if existing.UIN != *uin {
			logger.Warn("identifier already belongs to another citizen; updating that record instead",
				"requestedUin", *uin, "existingUin", existing.UIN)
		}
		resolvedUIN = existing.UIN
	} else if !errors.Is(lookupErr, store.ErrNotFound) {
		fmt.Fprintf(os.Stderr, "add-user: %v\n", lookupErr)
		return 1
	}

	user := store.IdentityUser{
		UIN: resolvedUIN, FullName: *name, GivenName: givenName, FamilyName: familyName,
		Email: *email, Phone: *phone, Birthdate: *birthdate, Gender: *gender,
		Address: *address, Locale: *locale,
		EmailVerified: *email != "", PhoneVerified: *phone != "",
	}
	if err := db.UpsertUser(ctx, user); err != nil {
		fmt.Fprintf(os.Stderr, "add-user: %v\n", err)
		return 1
	}

	logger.Info("identity directory updated", "uin", user.UIN, "email", user.Email, "phone", user.Phone)
	return 0
}

// firstNonEmpty returns the first non-empty value.
func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if value != "" {
			return value
		}
	}
	return ""
}

// splitName splits a full name into given and family parts.
func splitName(full string) (string, string) {
	for i, r := range full {
		if r == ' ' {
			return full[:i], full[i+1:]
		}
	}
	return full, ""
}
