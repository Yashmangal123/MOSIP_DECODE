package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"log/slog"
	"os"
	"time"

	"github.com/mosip/esignet-platform/internal/config"
	"github.com/mosip/esignet-platform/internal/delivery"
	"github.com/mosip/esignet-platform/internal/otp"
)

// verifyReport is one line of the verify-delivery output.
type verifyReport struct {
	Channel   string `json:"channel"`
	To        string `json:"to"`
	Provider  string `json:"provider"`
	Delivered bool   `json:"delivered"`
	Reference string `json:"reference,omitempty"`
	ErrorCode string `json:"errorCode,omitempty"`
	Attempts  int    `json:"attempts"`
	LatencyMS int64  `json:"latencyMs"`
	Error     string `json:"error,omitempty"`
	Note      string `json:"note,omitempty"`
}

// verifyDelivery sends a real OTP over the configured transports and reports what the provider did.
//
// This is the tool an operator runs after plugging in credentials: it uses the same transports, the same
// templates and the same retry policy as the running service, so a green result here means the service
// will deliver. It does not touch the database and does not create a challenge.
//
//	platform verify-delivery --email you@example.com --phone +919000000001
func verifyDelivery(args []string, logger *slog.Logger) int {
	flags := flag.NewFlagSet("verify-delivery", flag.ExitOnError)
	email := flags.String("email", "", "destination email address")
	phone := flags.String("phone", "", "destination phone number in E.164 form, e.g. +919000000001")
	ttl := flags.Int("ttl", 5, "OTP validity in minutes, rendered in the message")
	_ = flags.Parse(args)

	if *email == "" && *phone == "" {
		fmt.Fprintln(os.Stderr, "verify-delivery: at least one of --email or --phone is required")
		return 2
	}

	cfg, err := config.Load()
	if err != nil {
		fmt.Fprintf(os.Stderr, "verify-delivery: configuration error: %v\n", err)
		return 2
	}

	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()

	reports := make([]verifyReport, 0, 2)
	failed := 0

	if *email != "" {
		sender := delivery.NewEmailSender(cfg.Email, logger.With("transport", "email"))
		report := attemptSend(ctx, sender, delivery.Message{
			To: *email, Channel: "email", OTP: freshOTP(), Recipient: "", Purpose: "sign in",
			TTLMinutes: *ttl,
		})
		if !report.Delivered {
			failed++
		}
		reports = append(reports, report)
	}

	if *phone != "" {
		sender := delivery.NewSMSSender(cfg.SMS, logger.With("transport", "sms"))
		report := attemptSend(ctx, sender, delivery.Message{
			To: *phone, Channel: "sms", OTP: freshOTP(), Purpose: "sign in", TTLMinutes: *ttl,
		})
		if !report.Delivered {
			failed++
		}
		reports = append(reports, report)
	}

	encoder := json.NewEncoder(os.Stdout)
	encoder.SetIndent("", "  ")
	_ = encoder.Encode(map[string]any{
		"environment": cfg.Environment,
		"checkedAt":   time.Now().UTC(),
		"results":     reports,
	})

	if failed > 0 {
		fmt.Fprintf(os.Stderr, "\n%d destination(s) did not receive a message; see errorCode above.\n", failed)
		return 1
	}
	fmt.Fprintln(os.Stderr, "\nEvery destination accepted the message. Check the mailbox or phone to confirm.")
	return 0
}

// attemptSend sends one message and converts the result into a report row.
func attemptSend(ctx context.Context, sender delivery.Sender, message delivery.Message) verifyReport {
	started := time.Now()
	result, err := sender.Send(ctx, message)
	report := verifyReport{
		Channel:   message.Channel,
		To:        message.To,
		Provider:  result.Provider,
		Delivered: result.Delivered,
		Reference: result.Reference,
		ErrorCode: result.ErrorCode,
		Attempts:  result.Attempts,
		LatencyMS: time.Since(started).Milliseconds(),
	}
	if report.Provider == "" {
		report.Provider = sender.ProviderName()
	}
	if err != nil {
		report.Error = err.Error()
	}
	if !sender.IsReal() {
		report.Note = "this transport does not perform real delivery; configure credentials to test delivery"
	}
	if result.Attempts == 0 {
		report.Attempts = 1
	}
	return report
}

// freshOTP generates a real OTP of the configured length for the probe message.
func freshOTP() string {
	value, err := otp.GenerateOTP(6)
	if err != nil {
		return fmt.Sprintf("%06d", time.Now().UnixNano()%1_000_000)
	}
	return value
}
