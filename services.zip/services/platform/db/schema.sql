-- Platform service schema (PostgreSQL 15+).
--
-- Applied by the compose entrypoint / `make db` on first start; the service itself never runs DDL.
-- Every table carries cr_dtimes so retention jobs can be written as plain time-range deletes.

CREATE SCHEMA IF NOT EXISTS platform;
SET search_path TO platform;

-- ---------------------------------------------------------------------------------------------------
-- Identity directory
--
-- The demo citizens that the identity provider authenticates. A production deployment replaces this
-- table with the national identity system: the platform only requires the columns the identity provider
-- reads (uin, email, phone and the released claims).
-- ---------------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS identity_user (
    uin             VARCHAR(64)  PRIMARY KEY,
    full_name       VARCHAR(255) NOT NULL,
    given_name      VARCHAR(128) NOT NULL DEFAULT '',
    family_name     VARCHAR(128) NOT NULL DEFAULT '',
    email           VARCHAR(255) NOT NULL DEFAULT '',
    phone           VARCHAR(32)  NOT NULL DEFAULT '',
    birthdate       VARCHAR(16)  NOT NULL DEFAULT '',
    gender          VARCHAR(16)  NOT NULL DEFAULT '',
    address         TEXT         NOT NULL DEFAULT '',
    locale          VARCHAR(16)  NOT NULL DEFAULT 'en',
    picture         TEXT         NOT NULL DEFAULT '',
    email_verified  BOOLEAN      NOT NULL DEFAULT TRUE,
    phone_verified  BOOLEAN      NOT NULL DEFAULT TRUE,
    cr_dtimes       TIMESTAMPTZ  NOT NULL DEFAULT now(),
    upd_dtimes      TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_identity_user_email
    ON identity_user (lower(email)) WHERE email <> '';
CREATE UNIQUE INDEX IF NOT EXISTS idx_identity_user_phone
    ON identity_user (phone) WHERE phone <> '';

-- ---------------------------------------------------------------------------------------------------
-- OTP challenges
--
-- Only a keyed digest of the OTP is stored (otp_hash); the plaintext value exists only in memory and in
-- the delivered message. A challenge is single use: ACTIVE -> VERIFIED -> CONSUMED.
-- ---------------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS otp_challenge (
    id                 UUID         PRIMARY KEY,
    user_uin           VARCHAR(64)  NOT NULL REFERENCES identity_user (uin) ON DELETE CASCADE,
    channel            VARCHAR(16)  NOT NULL,
    destination        VARCHAR(255) NOT NULL,
    destination_hash   VARCHAR(64)  NOT NULL DEFAULT '',
    otp_hash           VARCHAR(128) NOT NULL,
    challenge_status   VARCHAR(16)  NOT NULL DEFAULT 'ACTIVE',
    attempts           INTEGER      NOT NULL DEFAULT 0,
    max_attempts       INTEGER      NOT NULL DEFAULT 5,
    send_count         INTEGER      NOT NULL DEFAULT 1,
    request_ip         VARCHAR(64)  NOT NULL DEFAULT '',
    purpose            VARCHAR(64)  NOT NULL DEFAULT '',
    verified_dtimes    TIMESTAMPTZ,
    cr_dtimes          TIMESTAMPTZ  NOT NULL DEFAULT now(),
    expiry_dtimes      TIMESTAMPTZ  NOT NULL,
    last_sent_dtimes   TIMESTAMPTZ  NOT NULL DEFAULT now(),
    CONSTRAINT otp_challenge_channel_chk CHECK (channel IN ('email', 'sms')),
    CONSTRAINT otp_challenge_status_chk
        CHECK (challenge_status IN ('ACTIVE', 'VERIFIED', 'CONSUMED', 'EXPIRED', 'LOCKED', 'CANCELLED'))
);

CREATE INDEX IF NOT EXISTS idx_otp_challenge_user_channel
    ON otp_challenge (user_uin, channel, challenge_status, cr_dtimes DESC);
CREATE INDEX IF NOT EXISTS idx_otp_challenge_expiry
    ON otp_challenge (expiry_dtimes) WHERE challenge_status = 'ACTIVE';
CREATE INDEX IF NOT EXISTS idx_otp_challenge_ip
    ON otp_challenge (request_ip, cr_dtimes DESC);

-- ---------------------------------------------------------------------------------------------------
-- Delivery records: one row per attempt to hand a message to a provider.
-- ---------------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS otp_delivery (
    id                    UUID        PRIMARY KEY,
    challenge_id          UUID        REFERENCES otp_challenge (id) ON DELETE CASCADE,
    channel               VARCHAR(16) NOT NULL,
    provider              VARCHAR(32) NOT NULL,
    provider_message_ref  VARCHAR(255) NOT NULL DEFAULT '',
    delivery_status       VARCHAR(16) NOT NULL,
    error_code            VARCHAR(64) NOT NULL DEFAULT '',
    latency_ms            INTEGER     NOT NULL DEFAULT 0,
    cr_dtimes             TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT otp_delivery_status_chk CHECK (delivery_status IN ('SENT', 'FAILED', 'SKIPPED'))
);

CREATE INDEX IF NOT EXISTS idx_otp_delivery_created ON otp_delivery (cr_dtimes DESC);
CREATE INDEX IF NOT EXISTS idx_otp_delivery_challenge ON otp_delivery (challenge_id);

-- ---------------------------------------------------------------------------------------------------
-- Notifications shown in the mobile application notification centre.
-- ---------------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notification (
    id           UUID         PRIMARY KEY,
    subject_uin  VARCHAR(64)  NOT NULL,
    category     VARCHAR(48)  NOT NULL DEFAULT 'GENERAL',
    title        VARCHAR(255) NOT NULL,
    body         TEXT         NOT NULL DEFAULT '',
    severity     VARCHAR(16)  NOT NULL DEFAULT 'INFO',
    metadata     JSONB        NOT NULL DEFAULT '{}'::jsonb,
    read_dtimes  TIMESTAMPTZ,
    cr_dtimes    TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_notification_subject
    ON notification (subject_uin, cr_dtimes DESC);

-- ---------------------------------------------------------------------------------------------------
-- Security events: the append-only audit stream behind the administrator console.
-- ---------------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS security_event (
    id           UUID        PRIMARY KEY,
    event_type   VARCHAR(64) NOT NULL,
    severity     VARCHAR(16) NOT NULL DEFAULT 'INFO',
    subject_uin  VARCHAR(64),
    client_id    VARCHAR(255),
    session_id   VARCHAR(255),
    event_status VARCHAR(32) NOT NULL DEFAULT '',
    request_ip   VARCHAR(64),
    user_agent   VARCHAR(512),
    metadata     JSONB       NOT NULL DEFAULT '{}'::jsonb,
    cr_dtimes    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT security_event_severity_chk
        CHECK (severity IN ('INFO', 'WARNING', 'ERROR', 'CRITICAL'))
);

CREATE INDEX IF NOT EXISTS idx_security_event_type_time ON security_event (event_type, cr_dtimes DESC);
CREATE INDEX IF NOT EXISTS idx_security_event_severity_time ON security_event (severity, cr_dtimes DESC);
CREATE INDEX IF NOT EXISTS idx_security_event_subject ON security_event (subject_uin, cr_dtimes DESC);
CREATE INDEX IF NOT EXISTS idx_security_event_client ON security_event (client_id, cr_dtimes DESC);

-- ---------------------------------------------------------------------------------------------------
-- Administrator accounts and their audit trail.
-- ---------------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_user (
    id                UUID         PRIMARY KEY,
    email             VARCHAR(255) NOT NULL,
    password_hash     VARCHAR(255) NOT NULL,
    role              VARCHAR(24)  NOT NULL DEFAULT 'ADMIN',
    cr_dtimes         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    last_login_dtimes TIMESTAMPTZ,
    CONSTRAINT admin_user_role_chk CHECK (role IN ('ADMIN', 'AUDITOR', 'SUPPORT'))
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_admin_user_email ON admin_user (lower(email));

CREATE TABLE IF NOT EXISTS admin_audit (
    id         UUID         PRIMARY KEY,
    actor      VARCHAR(255) NOT NULL,
    action     VARCHAR(64)  NOT NULL,
    target     VARCHAR(255) NOT NULL DEFAULT '',
    details    JSONB        NOT NULL DEFAULT '{}'::jsonb,
    cr_dtimes  TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_admin_audit_time ON admin_audit (cr_dtimes DESC);

-- ---------------------------------------------------------------------------------------------------
-- Housekeeping: ACTIVE challenges past their expiry are dead weight; the service expires them lazily,
-- and this index keeps the sweep cheap.
-- ---------------------------------------------------------------------------------------------------
COMMENT ON TABLE otp_challenge IS
    'One-time password challenges. Only a keyed digest of the OTP is stored. Sweep EXPIRED rows older than the retention period (default 30 days).';
COMMENT ON TABLE security_event IS
    'Append-only security audit stream consumed by the administrator console. Retain per deployment policy (default 1 year).';
COMMENT ON TABLE otp_delivery IS
    'Per-attempt delivery outcome. provider=console means the development transport handled the message and nothing was delivered.';
