-- Demo identity directory for local development.
--
-- These are synthetic citizens: the UINs are placeholders, the addresses use the reserved example.com
-- domain, and the phone numbers use the +91 90000 000xx range reserved for testing. Never load this file
-- into a production database.
INSERT INTO platform.identity_user
    (uin, full_name, given_name, family_name, email, phone, birthdate, gender, address, locale)
VALUES
    ('1990010112345678', 'Asha Verma', 'Asha', 'Verma', 'asha.verma@example.com', '+919000000001',
     '1990-01-01', 'Female', '14 Nehru Road, Bengaluru, Karnataka 560001', 'en'),
    ('1992020223456789', 'Rohit Nair', 'Rohit', 'Nair', 'rohit.nair@example.com', '+919000000002',
     '1992-02-02', 'Male', '8 Marine Drive, Kochi, Kerala 682031', 'en'),
    ('1988030334567890', 'Meera Iyer', 'Meera', 'Iyer', 'meera.iyer@example.com', '+919000000003',
     '1988-03-03', 'Female', '22 Anna Salai, Chennai, Tamil Nadu 600002', 'ta')
ON CONFLICT (uin) DO NOTHING;
