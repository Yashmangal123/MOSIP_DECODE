# Platform service API

Base URL: `http://localhost:8090` (`PLATFORM_PORT`).

Three authentication schemes are used, and they are not interchangeable:

| Area | Credential | Enforced by |
| --- | --- | --- |
| Identity / OTP (`/v1/identity/**`) | none (public, throttled) | rate limiter, CSP/CORS, generic errors |
| Internal (`/internal/**`) | `X-Platform-Api-Key: <PLATFORM_API_KEY>` | constant-time comparison; the API is disabled when no key is configured |
| End user (`/v1/me/**`) | `Authorization: Bearer <eSignet access token>` | eSignet introspection (active + scope), so revocation and expiry are authoritative |
| Administrator (`/v1/admin/**`) | `Authorization: Bearer <admin JWT>` | HS256 signature, issuer `esignet-platform`, audience `esignet-admin`, role |

Errors are always `{"error": {"code": "...", "message": "..."}}` with `Cache-Control: no-store`.

---

## Identity / OTP

### `POST /v1/identity/otp/send`

```json
{"identifier": "asha.verma@example.com", "channel": "email", "purpose": "sign-in"}
```

`identifier` accepts a UIN, an email address or a phone number. `channel` is `email` (default) or `sms`;
the destination is always resolved from the identity directory, never taken from the request.

`200 OK`

```json
{
  "transactionId": "9f0dce44-7022-4517-8dfa-6788d6ecdf39",
  "channel": "email",
  "maskedDestination": "a*********@example.com",
  "expiresIn": 299,
  "resendAfter": 30,
  "deliveryStatus": "SENT",
  "provider": "smtp",
  "developmentOtp": "482913"
}
```

`developmentOtp` is present **only** when `PLATFORM_ENV=development` *and*
`PLATFORM_OTP_EXPOSE_IN_DEV=true`; it exists so automated end-to-end tests need no mailbox and is
suppressed in every other environment.

| Status | Code | Meaning |
| --- | --- | --- |
| 400 | `otp_send_failed` | unknown identifier, unusable destination, or the provider rejected the message (deliberately indistinguishable) |
| 429 | `rate_limited` | resend cooldown or the per-user/per-IP window was hit |
| 500 | `internal_error` | unexpected failure |

### `POST /v1/identity/otp/verify`

```json
{"transactionId": "9f0dce44-...", "otp": "482913"}
```

`transactionId` may be replaced by `identifier` to verify against the newest active challenge.

`200 OK` → `{"verified": true, "uin": "1990010112345678"}`

| Status | Code | Meaning |
| --- | --- | --- |
| 400 | `incorrect_otp` | wrong code (the attempt is counted) |
| 400 | `otp_expired` | past the validity window |
| 400 | `otp_already_used` | replay of a consumed challenge |
| 400 | `no_active_otp` | no active challenge (e.g. superseded or cancelled) |
| 423 | `too_many_attempts` | locked after `PLATFORM_OTP_MAX_ATTEMPTS`; request a new code |

---

## Internal API (called by eSignet)

All endpoints require `X-Platform-Api-Key`.

| Method | Path | Purpose |
| --- | --- | --- |
| `POST` | `/internal/otp/send` | same body as the public send (no development echo) |
| `POST` | `/internal/otp/verify` | same body as the public verify |
| `GET` | `/internal/identity/users/{uin}` | identity claims for the identity provider (`uin`, `name`, `given_name`, `family_name`, `email`, `phone_number`, `birthdate`, `gender`, `address`, `locale`, `picture`, `email_verified`, `phone_verified`) |
| `POST` | `/internal/events` | record a security event: `{eventType, severity, subject, clientId, sessionId, status, ip, userAgent, metadata}` |
| `POST` | `/internal/notifications` | create a user notification: `{subject, category, title, body, severity, metadata}` |

---

## End-user API (mobile applications)

Requires an eSignet access token with scope `openid`.

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/v1/me/profile` | the authenticated user's profile |
| `GET` | `/v1/me/sessions` | Native SSO sessions of the user (read from eSignet's session API) |
| `POST` | `/v1/me/sessions/{sessionId}/revoke` | revoke one of the user's sessions |
| `GET` | `/v1/me/notifications?limit=50` | notifications plus `unreadCount` |
| `POST` | `/v1/me/notifications/{id}/read` | mark a notification read |
| `GET` | `/v1/me/activity` | the user's recent security events |

A user can only ever act on their own data: the subject comes from the introspected token and is
forwarded to eSignet as `X-ESignet-Subject-Id`.

---

## Administrator API

### `POST /v1/admin/login`

```json
{"email": "admin@esignet.local", "password": "…"}
```

`200 OK` → `{"token": "…", "expiresAt": "…", "admin": {"id": "…", "email": "…", "role": "ADMIN"}}`
`401 invalid_credentials` otherwise (identical for unknown accounts and wrong passwords).

### Console endpoints

| Method | Path | Roles | Purpose |
| --- | --- | --- | --- |
| `GET` | `/v1/admin/me` | any | the authenticated administrator |
| `GET` | `/v1/admin/overview` | all | 24-hour operations overview: applications in use, active sessions, OTP funnel, delivery health, security severity, recent events |
| `GET` | `/v1/admin/applications` | all | per-application session summary |
| `GET` | `/v1/admin/analytics/auth?days=7` | `ADMIN`, `AUDITOR` | daily authentication activity series + OTP totals |
| `GET` | `/v1/admin/otp/stats?hours=24` | `ADMIN`, `AUDITOR` | OTP verification and delivery statistics |
| `GET` | `/v1/admin/sessions?subject=` | all | Native SSO sessions (all users or one) |
| `POST` | `/v1/admin/sessions/{sessionId}/revoke` | `ADMIN`, `SUPPORT` | revoke one session |
| `POST` | `/v1/admin/sessions/revoke` | `ADMIN` | revoke every session of `{"subject": "…"}` |
| `GET` | `/v1/admin/security/events?eventType=&severity=&clientId=&subject=&limit=` | `ADMIN`, `AUDITOR` | security event query |
| `GET` | `/v1/admin/audit` | `ADMIN`, `AUDITOR` | administrative audit trail |
| `GET` | `/v1/admin/config` | `ADMIN` | effective configuration, secrets masked |
| `GET` | `/v1/admin/events/stream` | all | Server-Sent Events: `stream.ready`, `security.event`, `notification.created` |

Session endpoints proxy eSignet's session API (`PLATFORM_ESIGNET_SESSION_API_KEY`) and return
`502 upstream_error` when eSignet is not configured — the platform never fabricates session state.

Because `EventSource` cannot set headers, the stream accepts the administrator token in the `token`
query parameter; every other endpoint accepts it only in the `Authorization` header.

```
event: security.event
data: {"type":"security.event","at":"2026-11-02T14:27:24Z","data":{"event_type":"OTP_VERIFIED", …}}
```

---

## Operational

`GET /health` → `{"status": "UP", "environment": "development", "time": "…"}`; `503 unhealthy` when the
database is unreachable.

`GET /console` → the embedded administrator console (single page, strict CSP, no external assets).
