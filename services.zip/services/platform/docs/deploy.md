# Deployment guide

Three ways to run the platform service, from "on my laptop" to "on a government cluster".
The service is a single static binary (distroless image), talks to PostgreSQL, and holds no state of its
own — so it scales horizontally with no coordination.

| Target | Section |
| --- | --- |
| Laptop demo (Docker) | [1](#1-laptop--docker-compose-fastest) |
| Laptop demo (no Docker) | [2](#2-laptop--without-docker) |
| A VPS / single server (systemd) | [3](#3-single-server--systemd) |
| Kubernetes | [4](#4-kubernetes) |
| Production checklist | [5](#5-production-checklist) |

---

## 1. Laptop — Docker compose (fastest)

```bash
cd mosip-decode/services/platform
docker compose -f deploy/docker-compose.yml up --build
```

Brings up PostgreSQL 17 (schema + demo citizens auto-loaded) and the service at
<http://localhost:8090>, sending mail through the relay in your `.env`.
Console: <http://localhost:8090/console> → the administrator you set in `.env`.

There is no local mailbox in this stack, by design: a one-time code must reach the citizen's real
inbox. `PLATFORM_SMTP_HOST=127.0.0.1` / `mailpit` is refused at start-up unless you set
`PLATFORM_ALLOW_LAB_DELIVERY=true`.

Send a real OTP:

```bash
curl -X POST localhost:8090/v1/identity/otp/send -H 'Content-Type: application/json' \
     -d '{"identifier":"asha.verma@example.com","channel":"email"}'
```

Read the code in the citizen's inbox, then verify.

---

## 2. Laptop — without Docker

Prerequisites: Go 1.24+ and PostgreSQL 15+.

```bash
# database
sudo -u postgres psql -c "CREATE ROLE platform LOGIN PASSWORD 'platform'"
sudo -u postgres createdb -O platform esignet_platform

cd mosip-decode/services/platform
psql "postgres://platform:platform@127.0.0.1:5432/esignet_platform?sslmode=disable" -f db/schema.sql
psql "postgres://platform:platform@127.0.0.1:5432/esignet_platform?sslmode=disable" -f db/seed.sql

cp .env.example .env      # edit: SMTP credentials, secrets
set -a && . ./.env && set +a
go run ./cmd/platform
```

Prove delivery with a real mailbox:

```bash
go run ./cmd/platform verify-delivery --email you@example.com
```

---

## 3. Single server — systemd

Build once, ship the binary, run it as an unprivileged user.

```bash
# build (on the server or in CI)
CGO_ENABLED=0 go build -trimpath -ldflags="-s -w" -o /usr/local/bin/esignet-platform ./cmd/platform

# service account + config
sudo useradd --system --no-create-home --shell /usr/sbin/nologin esignet
sudo install -d -o esignet -g esignet -m 0750 /etc/esignet
sudo install -m 0640 -o esignet -g esignet .env /etc/esignet/platform.env
sudo install -m 0644 deploy/platform.service /etc/systemd/system/esignet-platform.service

sudo systemctl daemon-reload
sudo systemctl enable --now esignet-platform
journalctl -u esignet-platform -f
```

Put PostgreSQL and the service on the same host or a private network; terminate TLS at nginx/Caddy in
front of `:8090` (the service speaks plain HTTP and is not meant to face the internet directly).

```bash
curl -fsS localhost:8090/health   # {"status":"UP", …}
```

---

## 4. Kubernetes

`deploy/k8s.yaml` contains everything (namespace, config, secret template, deployment, service, HPA, PDB).

```bash
# 1. edit the Secret and ConfigMap at the top of the file
kubectl apply -f deploy/k8s.yaml

# 2. confirm
kubectl -n esignet-platform rollout status deploy/platform
kubectl -n esignet-platform port-forward svc/platform 8090:8090
curl -fsS localhost:8090/health
```

Notes baked into the manifest:

* the container runs as non-root on a read-only filesystem with all capabilities dropped;
* readiness and liveness probe `/health` (which checks the database);
* resources requests/limits are set, and an HPA scales on CPU (the service is stateless);
* `terminationGracePeriodSeconds: 30` matches the service's 15-second graceful shutdown plus margin;
* the secret holds the SMTP password, the OTP pepper, the admin JWT secret and the internal API key —
  supply them from your secret manager (`kubectl create secret`, External Secrets, Vault, SOPS).

Ingress: expose only `/v1/**`, `/internal/**` (internal only), and `/console`. If `/internal/**` must be
reachable from eSignet, use a NetworkPolicy rather than an Ingress — it is authenticated by a shared key,
not by user identity.

---

## 5. Production checklist

**Before going live**

- [ ] `PLATFORM_ENV=production` (this also refuses plaintext SMTP).
- [ ] `PLATFORM_SMTP_TLS=starttls` (587) or `tls` (465) with a real provider and a verified From domain
      (SPF + DKIM + DMARC, otherwise OTP mail lands in spam).
- [ ] `PLATFORM_SMS_PROVIDER` set to a real adapter **with DLT registration** for Indian numbers
      (sender ID + template); `console` must not be used.
- [ ] Secrets from a secret manager, never in `deployment.yaml` or the image.
- [ ] `PLATFORM_OTP_EXPOSE_IN_DEV=false` (and it is ignored outside development anyway).
- [ ] HTTPS termination with HSTS in front of `:8090`; `/console` restricted to the operator network.
- [ ] Database backups: `pg_dump` nightly + PITR; the OTP tables are small (retention: purge
      `otp_challenge` older than 30 days, keep `security_event` per policy).
- [ ] Alerting: `smtp_permanent_failure` / `provider_rejected` delivery codes, OTP success rate drop,
      `OTP_RATE_LIMITED` spikes, `/health` failing.
- [ ] Scale: the service is stateless — run ≥2 replicas; the SSE stream is per-pod, so the console shows
      events from the pod it connected to (durable history comes from the database).

**Data protection**

- OTPs exist only in memory and in the delivered message; the database holds a keyed digest.
- Only the SHA-256 digest of a device secret is stored (see `esignet.device_sso_session`).
- Rotate `PLATFORM_OTP_PEPPER` only with a maintenance window: existing challenges become unverifiable
  (they simply expire).
- Rotate `PLATFORM_ADMIN_JWT_SECRET` to invalidate every administrator session at once.

**Capacity**

One replica handles several hundred OTP requests per second; the real limits are the mail provider's rate
limits (Gmail ≈ 500/day, SES 14/s default, MSG91 per-plan) and the database. Widen
`PLATFORM_OTP_MAX_SENDS_PER_WINDOW` / `_PER_IP` only after the provider quota is raised.

---

## Where the rest of the system goes

| Component | Runs where | Notes |
| --- | --- | --- |
| eSignet (OIDC + Native SSO) | its own deployment | needs the 2.0.0 → 2.1.0 migration (`db_upgrade_script/`), a signing key, and `device_sso` enabled in `data/deployment.yaml` |
| Platform service | this guide | OTP, notifications, security events, console |
| Mobile apps (Super App / Child App) | app stores | use the OIDC code flow with `scope=… device_sso`, then RFC 8693 token exchange |
| PostgreSQL | managed or self-hosted | one database per component (eSignet and platform schemas are separate) |
