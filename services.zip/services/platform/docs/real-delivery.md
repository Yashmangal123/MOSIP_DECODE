# Turning on real email and SMS delivery

The service already generates real OTPs (crypto/rand, hashed at rest) and already speaks real delivery
protocols. What it cannot invent is a provider account. This page is the exact checklist to plug one in;
it takes about five minutes and one command proves it works.

Nothing about a provider is hardcoded. Email is standard SMTP (implicit TLS, STARTTLS or plaintext), and
SMS is either one of the built-in adapters (MSG91, Twilio, AWS SNS) or the generic HTTP gateway, which is
configured entirely from the environment.

## 1. Email

### Option A — Gmail (fastest way to see a real OTP in your inbox)

1. Enable 2-step verification on the Google account, then create an **App password**
   (Google Account → Security → App passwords). You get a 16-character password.
2. Configure:

   ```bash
   PLATFORM_EMAIL_MODE=smtp
   PLATFORM_SMTP_HOST=smtp.gmail.com
   PLATFORM_SMTP_PORT=587
   PLATFORM_SMTP_TLS=starttls
   PLATFORM_SMTP_USERNAME=your.address@gmail.com
   PLATFORM_SMTP_PASSWORD=abcdwxyzabcdwxyz      # the app password, not the account password
   PLATFORM_SMTP_FROM=your.address@gmail.com    # Gmail rewrites a different From
   PLATFORM_SMTP_FROM_NAME=MOSIP eSignet
   ```

   Gmail's limit is ~500 recipients/day, which is fine for a demo and not for production.

### Option B — Amazon SES (what a production deployment usually uses)

Verify the sending domain (or a single recipient address in the sandbox), then request production access.

```bash
PLATFORM_SMTP_HOST=email-smtp.ap-south-1.amazonaws.com
PLATFORM_SMTP_PORT=587
PLATFORM_SMTP_TLS=starttls
PLATFORM_SMTP_USERNAME=<SMTP username from the SES console>
PLATFORM_SMTP_PASSWORD=<SMTP password from the SES console>
PLATFORM_SMTP_FROM=no-reply@yourdomain.gov.in
```

### Option C — any other relay

SendGrid, Postmark, Mailgun, Zoho, an internal Postfix: same three fields (host, port, TLS mode) plus
credentials. Port 587 → `starttls`, port 465 → `tls`, port 25 → usually refused by cloud providers.

The transport refuses to authenticate over a plaintext connection, and in `PLATFORM_ENV=production` it
refuses `PLATFORM_SMTP_TLS=none` outright, so an OTP can never be mailed in the clear by accident.

## 2. SMS

Pick one. Every adapter is selected by `PLATFORM_SMS_PROVIDER`.

### MSG91 (India, DLT compliant)

```bash
PLATFORM_SMS_PROVIDER=msg91
PLATFORM_MSG91_AUTH_KEY=<authkey>
PLATFORM_MSG91_TEMPLATE_ID=<DLT template id>      # optional; sent as DLT_TE_ID
PLATFORM_MSG91_ROUTE=4
PLATFORM_SMS_SENDER_ID=ESIGNT                     # 6 characters, DLT registered
```

### Twilio (international, trial accounts can verify a single number)

```bash
PLATFORM_SMS_PROVIDER=twilio
PLATFORM_TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
PLATFORM_TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
PLATFORM_TWILIO_FROM=+1xxxxxxxxxx                 # or a Messaging Service SID
```

### AWS SNS (SigV4 signed in-process, no SDK)

```bash
PLATFORM_SMS_PROVIDER=aws_sns
PLATFORM_AWS_ACCESS_KEY_ID=AKIA...
PLATFORM_AWS_SECRET_ACCESS_KEY=...
PLATFORM_AWS_REGION=ap-south-1
PLATFORM_SMS_SENDER_ID=ESIGNT
```

### Any other gateway (no code change)

```bash
PLATFORM_SMS_PROVIDER=generic_http
PLATFORM_SMS_HTTP_URL=https://www.fast2sms.com/dev/bulkV2
PLATFORM_SMS_HTTP_METHOD=POST
PLATFORM_SMS_HTTP_CONTENT_TYPE=application/x-www-form-urlencoded
PLATFORM_SMS_HTTP_HEADERS=authorization:<your key>
PLATFORM_SMS_HTTP_BODY=route=q&sender_id={{sender}}&message={{message}}&numbers={{to}}
PLATFORM_SMS_HTTP_SUCCESS_SUBSTRING=request_id     # optional: proves the gateway queued it
PLATFORM_SMS_HTTP_SUCCESS_STATUS=200               # optional: default any 2xx
PLATFORM_SMS_HTTP_REFERENCE_FIELD=data.request_id  # optional: where the message id lives
```

Placeholders usable in the URL, the headers and the body: `{{to}}` (E.164, no `+`), `{{to_plus}}`,
`{{otp}}`, `{{message}}` (full rendered text), `{{sender}}`.

If the gateway answers `200` with an error document, set `PLATFORM_SMS_HTTP_SUCCESS_SUBSTRING` — a `200`
without the marker is recorded as `provider_rejected`, not as a delivery.

## 3. Prove it

One command, using exactly the transports, templates and retry policy of the running service:

```bash
# email + SMS at once; prints the provider's own result for each channel
go run ./cmd/platform verify-delivery \
    --email you@example.com \
    --phone +919000000001
```

Example of a failure it reports honestly (the development console transport):

```json
{"channel":"sms","to":"+919000000004","provider":"console","delivered":false,
 "note":"this transport does not perform real delivery; configure credentials to test delivery"}
```

and of a success:

```json
{"channel":"email","to":"you@example.com","provider":"smtp","delivered":true,
 "reference":"smtp:you@example.com","attempts":1,"latencyMs":812}
```

## 4. Then send a real login OTP (one script)

```bash
bash scripts/live_otp.sh --email you@example.com --phone +919000000001
```

It builds the service, registers the citizen in the identity directory (the OTP destination always comes
from there, never from the request), probes the transports, starts the service if it is not running, and
requests a real code — then tells you the one command that verifies it:

```bash
bash scripts/live_otp.sh --transaction <id> --code <code from the message>
```

The API response carries a masked destination, the transaction id, the provider and the delivery status —
never the code, unless `PLATFORM_OTP_EXPOSE_IN_DEV=true` in a development environment.

### Manually

A citizen must exist in the identity directory first — the OTP destination is always read from the
directory, never taken from the request:

```bash
go run ./cmd/platform add-user \
    --uin 1985050512345678 --name "Priya Sharma" \
    --email you@example.com --phone +919000000001

# start the service, then request a code
curl -s -X POST http://localhost:8090/v1/identity/otp/send \
     -H 'Content-Type: application/json' \
     -d '{"identifier":"you@example.com","channel":"email"}'
```

The response contains a masked destination, a transaction id, `provider` and `deliveryStatus`; the OTP
itself arrives in your inbox (or on your phone), because `PLATFORM_OTP_EXPOSE_IN_DEV` stays `false` in
production. Verify it with:

```bash
curl -s -X POST http://localhost:8090/v1/identity/otp/verify \
     -H 'Content-Type: application/json' \
     -d '{"transactionId":"<transaction id>","otp":"<code from the message>"}'
```

## 5. What the service does around the provider

| Behaviour | Why it matters in production |
| --- | --- |
| Retries: 3 attempts, 400 ms × 2 backoff | Transient network faults and provider throttling recover without the user re-entering an identifier |
| 429/5xx and SMTP 4xx retried; 401/400 and SMTP 5xx not | A rejected credential or a bad number never loops; repeated failures can suspend provider accounts |
| No redirect following | An OTP request cannot be bounced to another host |
| Signed SNS requests, TLS ≥ 1.2, verified certificates | OTP mail is never sent over a downgraded channel; no "insecure" switch exists |
| Delivery outcome persisted per attempt (provider, reference, latency, error code) | The console's *Email / SMS delivery* panel and `/v1/admin/otp/stats` show the provider's real behaviour |
| OTP never logged, never in an error string, never in a subject line | Provider dashboards and log aggregators cannot leak a live code |
| `console` transport reports `delivered: false` | A demo can never be mistaken for a working integration |

## 6. Credentials handling

Keep them in the environment (or your secret manager), never in `deployment.yaml` or the repository.
`PLATFORM_SMS_HTTP_HEADERS` supports `${VAR}` because the process environment expands it before the
template is used, so a gateway key can live in a Kubernetes Secret and be referenced indirectly.

Rotate with a restart: the transports are built once at startup and every request uses the same verified
connection settings.
