package api

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/mosip/esignet-platform/internal/store"
)

func TestHashAndVerifyPassword(t *testing.T) {
	digest, err := hashPassword("correct-horse-battery")
	require.NoError(t, err)

	t.Run("digest is self describing", func(t *testing.T) {
		assert.Regexp(t, `^pbkdf2-sha256\$\d+\$[^$]+\$[^$]+$`, digest)
	})

	t.Run("accepts the correct password", func(t *testing.T) {
		assert.True(t, verifyPassword(digest, "correct-horse-battery"))
	})

	t.Run("rejects a wrong password", func(t *testing.T) {
		assert.False(t, verifyPassword(digest, "correct-horse-batterY"))
	})

	t.Run("uses a fresh salt per digest", func(t *testing.T) {
		other, err := hashPassword("correct-horse-battery")
		require.NoError(t, err)
		assert.NotEqual(t, digest, other)
		assert.True(t, verifyPassword(other, "correct-horse-battery"))
	})

	t.Run("rejects short passwords", func(t *testing.T) {
		_, err := hashPassword("short")
		assert.Error(t, err)
	})

	t.Run("rejects malformed stored digests", func(t *testing.T) {
		for _, stored := range []string{
			"", "bcrypt$1$a$b", "pbkdf2-sha256$notanumber$a$b", "pbkdf2-sha256$600000$!!!$b",
			"pbkdf2-sha256$600000$a$", "pbkdf2-sha256$10$YWJj$YWJj",
		} {
			assert.False(t, verifyPassword(stored, "correct-horse-battery"), "stored=%q", stored)
		}
	})
}

func TestAdminTokenRoundTrip(t *testing.T) {
	server := &Server{cfg: testAPIConfig()}

	admin := adminUser("Admin@Example.com", "digest")
	assert.Equal(t, "admin@example.com", admin.Email, "emails are normalised to lower case")
	assert.Equal(t, RoleAdmin, admin.Role)

	token, expiresAt, err := server.issueAdminToken(&admin)
	require.NoError(t, err)
	assert.True(t, expiresAt.After(expiresAt.Add(-1)))
	assert.NotEmpty(t, token)

	claims, err := server.parseAdminToken(token)
	require.NoError(t, err)
	assert.Equal(t, admin.ID, claims.Subject)
	assert.Equal(t, "admin@example.com", claims.Email)
	assert.Equal(t, RoleAdmin, claims.Role)
}

func TestAdminTokenRejected(t *testing.T) {
	server := &Server{cfg: testAPIConfig()}
	admin := adminUser("admin@example.com", "digest")
	token, _, err := server.issueAdminToken(&admin)
	require.NoError(t, err)

	t.Run("tampered signature", func(t *testing.T) {
		tampered := token[:len(token)-2] + "aa"
		_, err := server.parseAdminToken(tampered)
		assert.Error(t, err)
	})

	t.Run("foreign secret", func(t *testing.T) {
		other := &Server{cfg: testAPIConfig()}
		other.cfg.Admin.JWTSecret = "a-completely-different-secret"
		_, err := other.parseAdminToken(token)
		assert.Error(t, err)
	})

	t.Run("empty token", func(t *testing.T) {
		_, err := server.parseAdminToken("")
		assert.Error(t, err)
	})
}

func TestRequireAdminMiddleware(t *testing.T) {
	server := &Server{cfg: testAPIConfig()}
	admin := adminUser("admin@example.com", "digest")
	token, _, err := server.issueAdminToken(&admin)
	require.NoError(t, err)

	handler := server.requireAdmin(RoleAdmin)(func(w http.ResponseWriter, r *http.Request) {
		claims := adminFrom(r.Context())
		require.NotNil(t, claims)
		writeJSON(w, http.StatusOK, map[string]string{"email": claims.Email})
	})

	t.Run("accepts a bearer token", func(t *testing.T) {
		request := httptest.NewRequest(http.MethodGet, "/v1/admin/me", nil)
		request.Header.Set("Authorization", "Bearer "+token)
		recorder := httptest.NewRecorder()
		handler(recorder, request)
		assert.Equal(t, http.StatusOK, recorder.Code)
	})

	t.Run("accepts a query parameter token for the event stream", func(t *testing.T) {
		request := httptest.NewRequest(http.MethodGet, "/v1/admin/events/stream?token="+token, nil)
		recorder := httptest.NewRecorder()
		handler(recorder, request)
		assert.Equal(t, http.StatusOK, recorder.Code)
	})

	t.Run("rejects a missing token", func(t *testing.T) {
		request := httptest.NewRequest(http.MethodGet, "/v1/admin/me", nil)
		recorder := httptest.NewRecorder()
		handler(recorder, request)
		assert.Equal(t, http.StatusUnauthorized, recorder.Code)
	})

	t.Run("rejects a token with the wrong scheme", func(t *testing.T) {
		request := httptest.NewRequest(http.MethodGet, "/v1/admin/me", nil)
		request.Header.Set("Authorization", "Basic "+token)
		recorder := httptest.NewRecorder()
		handler(recorder, request)
		assert.Equal(t, http.StatusUnauthorized, recorder.Code)
	})
}

func TestRequireAdminRole(t *testing.T) {
	server := &Server{cfg: testAPIConfig()}
	auditor := adminUser("auditor@example.com", "digest")
	auditor.Role = RoleAuditor
	token, _, err := server.issueAdminToken(&auditor)
	require.NoError(t, err)

	adminOnly := server.requireAdmin(RoleAdmin)(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})
	request := httptest.NewRequest(http.MethodGet, "/v1/admin/config", nil)
	request.Header.Set("Authorization", "Bearer "+token)
	recorder := httptest.NewRecorder()
	adminOnly(recorder, request)
	assert.Equal(t, http.StatusForbidden, recorder.Code, "an auditor may not read the configuration")
}

func TestRequireInternalAPIKey(t *testing.T) {
	server := &Server{cfg: testAPIConfig()}
	server.cfg.APIKey = "internal-key"
	handler := server.requireInternalAPIKey(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusAccepted)
	})

	t.Run("accepts the configured key", func(t *testing.T) {
		request := httptest.NewRequest(http.MethodPost, "/internal/otp/send", nil)
		request.Header.Set("X-Platform-Api-Key", "internal-key")
		recorder := httptest.NewRecorder()
		handler(recorder, request)
		assert.Equal(t, http.StatusAccepted, recorder.Code)
	})

	t.Run("rejects a wrong key", func(t *testing.T) {
		request := httptest.NewRequest(http.MethodPost, "/internal/otp/send", nil)
		request.Header.Set("X-Platform-Api-Key", "internal-kez")
		recorder := httptest.NewRecorder()
		handler(recorder, request)
		assert.Equal(t, http.StatusUnauthorized, recorder.Code)
	})

	t.Run("is unavailable when no key is configured", func(t *testing.T) {
		unconfigured := &Server{cfg: testAPIConfig()}
		inner := unconfigured.requireInternalAPIKey(func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusAccepted)
		})
		request := httptest.NewRequest(http.MethodPost, "/internal/otp/send", nil)
		recorder := httptest.NewRecorder()
		inner(recorder, request)
		assert.Equal(t, http.StatusServiceUnavailable, recorder.Code,
			"the internal API fails closed instead of accepting every caller")
	})
}

func TestHasScope(t *testing.T) {
	assert.True(t, hasScope("openid profile email", "profile"))
	assert.True(t, hasScope("openid", "openid"))
	assert.False(t, hasScope("openid", "device_sso"))
	assert.False(t, hasScope("", "openid"))
}

func TestBearerToken(t *testing.T) {
	cases := map[string]string{
		"Bearer abc":   "abc",
		"bearer abc":   "abc",
		"Basic abc":    "",
		"":             "",
		"Bearer":       "",
		"Bearer a b c": "a b c",
	}
	for header, expected := range cases {
		request := httptest.NewRequest(http.MethodGet, "/", nil)
		if header != "" {
			request.Header.Set("Authorization", header)
		}
		assert.Equal(t, expected, bearerToken(request), "header=%q", header)
	}
}

func TestClientIP(t *testing.T) {
	request := httptest.NewRequest(http.MethodPost, "/v1/identity/otp/send", nil)
	request.RemoteAddr = "10.1.2.3:5555"
	assert.Equal(t, "10.1.2.3", clientIP(request))

	request.Header.Set("X-Forwarded-For", "203.0.113.9, 10.1.2.3")
	assert.Equal(t, "203.0.113.9", clientIP(request), "only the first forwarded hop is used")

	request.Header.Del("X-Forwarded-For")
	request.RemoteAddr = "[::1]:5555"
	assert.Equal(t, "::1", clientIP(request), "IPv6 addresses are parsed, not truncated")
}

func TestErrorAndJSONWriters(t *testing.T) {
	recorder := httptest.NewRecorder()
	writeError(recorder, http.StatusLocked, "too_many_attempts", "Too many incorrect attempts")

	assert.Equal(t, http.StatusLocked, recorder.Code)
	assert.Equal(t, "no-store", recorder.Header().Get("Cache-Control"))

	var body struct {
		Error struct {
			Code    string `json:"code"`
			Message string `json:"message"`
		} `json:"error"`
	}
	require.NoError(t, json.Unmarshal(recorder.Body.Bytes(), &body))
	assert.Equal(t, "too_many_attempts", body.Error.Code)
	assert.Equal(t, "Too many incorrect attempts", body.Error.Message)
}

func TestSecurityHeaders(t *testing.T) {
	server := &Server{cfg: testAPIConfig()}
	handler := server.withSecurityHeaders(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	}))
	recorder := httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/health", nil))

	assert.Equal(t, "nosniff", recorder.Header().Get("X-Content-Type-Options"))
	assert.Equal(t, "DENY", recorder.Header().Get("X-Frame-Options"))
	assert.Equal(t, "no-referrer", recorder.Header().Get("Referrer-Policy"))
}

func TestCORS(t *testing.T) {
	server := &Server{cfg: testAPIConfig()}
	server.cfg.Admin.AllowedOrigins = []string{"https://app.example.com"}
	handler := server.withCORS(func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusOK) })

	t.Run("allowed origin", func(t *testing.T) {
		request := httptest.NewRequest(http.MethodPost, "/v1/identity/otp/send", nil)
		request.Header.Set("Origin", "https://app.example.com")
		recorder := httptest.NewRecorder()
		handler(recorder, request)
		assert.Equal(t, "https://app.example.com", recorder.Header().Get("Access-Control-Allow-Origin"))
	})

	t.Run("unknown origin gets no CORS grant", func(t *testing.T) {
		request := httptest.NewRequest(http.MethodPost, "/v1/identity/otp/send", nil)
		request.Header.Set("Origin", "https://evil.example.com")
		recorder := httptest.NewRecorder()
		handler(recorder, request)
		assert.Empty(t, recorder.Header().Get("Access-Control-Allow-Origin"))
	})
}

func TestEventHub(t *testing.T) {
	hub := NewEventHub()
	id, events, unsubscribe := hub.Subscribe()
	assert.NotEmpty(t, id)
	assert.Equal(t, 1, hub.SubscriberCount())

	hub.Publish(StreamEvent{Type: "otp.sent", Data: map[string]string{"channel": "email"}})
	select {
	case event := <-events:
		assert.Equal(t, "otp.sent", event.Type)
	default:
		t.Fatal("expected a published event")
	}

	unsubscribe()
	assert.Equal(t, 0, hub.SubscriberCount())

	// Publishing after every subscriber left must not panic.
	hub.Publish(StreamEvent{Type: "orphan"})
}

func TestEventHubDropsEventsForSlowSubscribers(t *testing.T) {
	hub := NewEventHub()
	_, _, unsubscribe := hub.Subscribe()
	defer unsubscribe()

	// The subscriber buffer is 64; publishing more must not block the publisher.
	done := make(chan struct{})
	go func() {
		for i := 0; i < 500; i++ {
			hub.Publish(StreamEvent{Type: "flood"})
		}
		close(done)
	}()
	select {
	case <-done:
	case <-timeAfterSecond():
		t.Fatal("Publish blocked on a slow subscriber")
	}
}

func TestStreamEventRequiresAdmin(t *testing.T) {
	server := &Server{cfg: testAPIConfig(), hub: NewEventHub()}
	handler := server.requireAdmin()(server.handleEventStream)

	request := httptest.NewRequest(http.MethodGet, "/v1/admin/events/stream", nil)
	recorder := httptest.NewRecorder()
	handler(recorder, request)
	assert.Equal(t, http.StatusUnauthorized, recorder.Code)
}

func TestRecorderPersistsAndPublishes(t *testing.T) {
	// The recorder is exercised end to end against PostgreSQL by scripts/e2e_check.sh; here the
	// publication half is asserted without a database by inspecting the hub after a publish.
	hub := NewEventHub()
	_, events, unsubscribe := hub.Subscribe()
	defer unsubscribe()

	hub.RecordSecurityEvent(context.Background(), store.SecurityEvent{
		EventType: "OTP_SENT", Severity: "INFO", Status: "SENT",
	})
	select {
	case event := <-events:
		assert.Equal(t, "security.event", event.Type)
	default:
		t.Fatal("the hub did not publish the security event")
	}

	hub.Notify(context.Background(), store.Notification{Category: "SECURITY", Title: "Signed in"})
	select {
	case event := <-events:
		assert.Equal(t, "notification.created", event.Type)
	default:
		t.Fatal("the hub did not publish the notification")
	}
}
