package api

import (
	"context"
	"crypto/subtle"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"github.com/mosip/esignet-platform/internal/store"
)

// Roles understood by the administrator console.
const (
	RoleAdmin   = "ADMIN"
	RoleAuditor = "AUDITOR"
	RoleSupport = "SUPPORT"
)

// AdminClaims is the payload of an administrator session token.
type AdminClaims struct {
	Subject string   `json:"sub"`
	Email   string   `json:"email"`
	Role    string   `json:"role"`
	Roles   []string `json:"roles,omitempty"`
	jwt.RegisteredClaims
}

// contextKey is the type of the context keys used by this package.
type contextKey string

const (
	// subjectContextKey holds the authenticated end-user subject extracted from an eSignet token.
	subjectContextKey contextKey = "subject"
	// adminContextKey holds the authenticated administrator claims.
	adminContextKey contextKey = "admin"
)

// issueAdminToken signs an administrator token.
func (s *Server) issueAdminToken(admin *store.AdminUser) (string, time.Time, error) {
	expiresAt := time.Now().Add(s.cfg.Admin.TokenTTL)
	claims := AdminClaims{
		Subject: admin.ID,
		Email:   admin.Email,
		Role:    admin.Role,
		Roles:   []string{admin.Role},
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    "esignet-platform",
			Subject:   admin.ID,
			Audience:  jwt.ClaimStrings{"esignet-admin"},
			IssuedAt:  jwt.NewNumericDate(time.Now()),
			NotBefore: jwt.NewNumericDate(time.Now()),
			ExpiresAt: jwt.NewNumericDate(expiresAt),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	signed, err := token.SignedString([]byte(s.cfg.Admin.JWTSecret))
	if err != nil {
		return "", time.Time{}, fmt.Errorf("sign admin token: %w", err)
	}
	return signed, expiresAt, nil
}

// parseAdminToken verifies an administrator token.
func (s *Server) parseAdminToken(raw string) (*AdminClaims, error) {
	claims := &AdminClaims{}
	parsed, err := jwt.ParseWithClaims(raw, claims, func(token *jwt.Token) (any, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method %v", token.Header["alg"])
		}
		return []byte(s.cfg.Admin.JWTSecret), nil
	}, jwt.WithAudience("esignet-admin"), jwt.WithIssuer("esignet-platform"), jwt.WithExpirationRequired())
	if err != nil || !parsed.Valid {
		return nil, errors.New("invalid administrator token")
	}
	return claims, nil
}

// requireAdmin is the middleware for administrator endpoints. It accepts the token in the
// Authorization header, and additionally in a `token` query parameter so the Server-Sent Events stream
// (which cannot set headers through EventSource) can authenticate.
func (s *Server) requireAdmin(allowedRoles ...string) func(http.HandlerFunc) http.HandlerFunc {
	return func(next http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			raw := bearerToken(r)
			if raw == "" {
				raw = r.URL.Query().Get("token")
			}
			if raw == "" {
				writeError(w, http.StatusUnauthorized, "unauthorized", "An administrator token is required")
				return
			}
			claims, err := s.parseAdminToken(raw)
			if err != nil {
				writeError(w, http.StatusUnauthorized, "unauthorized", "Invalid or expired administrator token")
				return
			}
			if len(allowedRoles) > 0 && !containsRole(claims, allowedRoles) {
				writeError(w, http.StatusForbidden, "forbidden", "This role may not access this resource")
				return
			}
			next(w, r.WithContext(context.WithValue(r.Context(), adminContextKey, claims)))
		}
	}
}

// containsRole reports whether the claims carry one of the allowed roles.
func containsRole(claims *AdminClaims, allowed []string) bool {
	for _, role := range allowed {
		if strings.EqualFold(claims.Role, role) || strings.EqualFold(role, RoleAdmin) && strings.EqualFold(claims.Role, RoleAdmin) {
			return true
		}
	}
	return false
}

// adminFrom returns the authenticated administrator of a request.
func adminFrom(ctx context.Context) *AdminClaims {
	claims, _ := ctx.Value(adminContextKey).(*AdminClaims)
	return claims
}

// requireInternalAPIKey guards the service-to-service endpoints. The key is compared in constant time.
func (s *Server) requireInternalAPIKey(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if s.cfg.APIKey == "" {
			writeError(w, http.StatusServiceUnavailable, "internal_api_disabled",
				"The internal API is disabled; set PLATFORM_API_KEY")
			return
		}
		presented := r.Header.Get("X-Platform-Api-Key")
		if subtle.ConstantTimeCompare([]byte(presented), []byte(s.cfg.APIKey)) != 1 {
			writeError(w, http.StatusUnauthorized, "unauthorized", "Invalid internal API key")
			return
		}
		next(w, r)
	}
}

// requireUserToken guards end-user endpoints. The eSignet access token is validated by introspection, so
// revocation, expiry and scopes are enforced by the authorization server rather than trusted from the
// client.
func (s *Server) requireUserToken(requiredScope string) func(http.HandlerFunc) http.HandlerFunc {
	return func(next http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			token := bearerToken(r)
			if token == "" {
				writeError(w, http.StatusUnauthorized, "unauthorized", "An access token is required")
				return
			}
			introspection, err := s.introspect(r.Context(), token)
			if err != nil {
				s.logger.ErrorContext(r.Context(), "token introspection failed", "error", err)
				writeError(w, http.StatusBadGateway, "upstream_error", "Could not validate the access token")
				return
			}
			if !introspection.Active {
				writeError(w, http.StatusUnauthorized, "invalid_token", "The access token is not active")
				return
			}
			if requiredScope != "" && !hasScope(introspection.Scope, requiredScope) {
				writeError(w, http.StatusForbidden, "insufficient_scope",
					"The access token does not carry the required scope")
				return
			}
			ctx := context.WithValue(r.Context(), subjectContextKey, introspection.Subject)
			next(w, r.WithContext(ctx))
		}
	}
}

// subjectFrom returns the authenticated end-user subject of a request.
func subjectFrom(ctx context.Context) string {
	subject, _ := ctx.Value(subjectContextKey).(string)
	return subject
}

// bearerToken extracts a bearer token from the Authorization header.
func bearerToken(r *http.Request) string {
	header := r.Header.Get("Authorization")
	if header == "" {
		return ""
	}
	parts := strings.SplitN(header, " ", 2)
	if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
		return ""
	}
	return strings.TrimSpace(parts[1])
}

// hasScope reports whether a space-delimited scope string contains a scope.
func hasScope(scopes, required string) bool {
	for _, scope := range strings.Fields(scopes) {
		if scope == required {
			return true
		}
	}
	return false
}

// introspectionResponse is the RFC 7662 response of eSignet.
type introspectionResponse struct {
	Active   bool   `json:"active"`
	Subject  string `json:"sub"`
	ClientID string `json:"client_id"`
	Scope    string `json:"scope"`
	Expires  int64  `json:"exp"`
	Audience any    `json:"aud"`
}

// introspect validates an access token against eSignet's introspection endpoint.
func (s *Server) introspect(ctx context.Context, token string) (*introspectionResponse, error) {
	if s.cfg.ESignet.IntrospectionClientID == "" {
		// Without client credentials the service cannot safely validate tokens; fail closed.
		return nil, errors.New("introspection client is not configured")
	}
	form := "token=" + token
	request, err := http.NewRequestWithContext(ctx, http.MethodPost,
		s.cfg.ESignet.BaseURL+"/oauth2/introspect", strings.NewReader(form))
	if err != nil {
		return nil, err
	}
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	request.SetBasicAuth(s.cfg.ESignet.IntrospectionClientID, s.cfg.ESignet.IntrospectionClientSecret)

	response, err := s.eSignetClient().Do(request)
	if err != nil {
		return nil, err
	}
	defer func() { _ = response.Body.Close() }()
	if response.StatusCode != http.StatusOK {
		return &introspectionResponse{Active: false}, nil
	}
	var result introspectionResponse
	if err := json.NewDecoder(response.Body).Decode(&result); err != nil {
		return nil, err
	}
	return &result, nil
}

// eSignetClient returns the HTTP client used for eSignet calls.
func (s *Server) eSignetClient() *http.Client {
	if s.httpClient != nil {
		return s.httpClient
	}
	return http.DefaultClient
}
