package api

import (
	_ "embed"
	"net/http"
)

// consoleHTML is the administrator console, embedded so the service ships as a single binary with no
// static asset directory to deploy or to keep in sync.
//
//go:embed console.html
var consoleHTML []byte

// handleConsole serves the administrator console page.
//
// The page is public HTML but useless without credentials: every endpoint it calls requires an
// administrator token. It is served with a strict Content Security Policy that forbids any external
// script, style or frame, because the console renders security-event data that originates from
// untrusted client activity.
func (s *Server) handleConsole(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Security-Policy",
		"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "+
			"connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'; "+
			"frame-ancestors 'none'")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(consoleHTML)
}
