package api

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/google/uuid"

	"github.com/mosip/esignet-platform/internal/store"
)

// Session is a Native SSO session as reported by eSignet's session API.
//
// The platform never stores session secrets: it reads the session view from eSignet, which owns the
// device_sso_session table. The platform is therefore a presentation and revocation layer over
// eSignet's session authority, not a second source of truth.
type Session struct {
	SessionID      string   `json:"sessionId"`
	ClientID       string   `json:"clientId"`
	Subject        string   `json:"subject"`
	ACR            string   `json:"acr,omitempty"`
	Scopes         []string `json:"scopes,omitempty"`
	Status         string   `json:"status"`
	DPoPThumbprint string   `json:"dpopThumbprint,omitempty"`
	CreatedAt      string   `json:"createdAt"`
	ExpiresAt      string   `json:"expiresAt"`
	RevokedAt      string   `json:"revokedAt,omitempty"`
}

// eSignetEnvelope is the MOSIP response envelope used by the eSignet administrative APIs.
type eSignetEnvelope struct {
	Response     json.RawMessage `json:"response"`
	Errors       []eSignetError  `json:"errors"`
	ResponseTime string          `json:"responsetime"`
}

// eSignetError is one entry of the eSignet error list.
type eSignetError struct {
	ErrorCode string `json:"errorCode"`
	Message   string `json:"message"`
}

// errSessionAPIUnavailable is returned when the session API is not configured.
var errSessionAPIUnavailable = errors.New("eSignet session API is not configured")

// eSignetSessions returns the sessions matching an optional subject filter.
func (s *Server) eSignetSessions(ctx context.Context, subject string) ([]Session, error) {
	if s.cfg.ESignet.SessionAPIKey == "" {
		return nil, errSessionAPIUnavailable
	}
	endpoint := s.cfg.ESignet.BaseURL + "/v1/esignet/device-sso/sessions?limit=200"
	if subject != "" {
		endpoint += "&subject=" + url.QueryEscape(subject)
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint, nil)
	if err != nil {
		return nil, err
	}
	request.Header.Set("Authorization", "Bearer "+s.cfg.ESignet.SessionAPIKey)

	sessions, err := s.doSessionRequest(request)
	if err != nil {
		return nil, err
	}
	return sessions, nil
}

// doSessionRequest performs a session API call and unwraps the envelope.
func (s *Server) doSessionRequest(request *http.Request) ([]Session, error) {
	response, err := s.eSignetClient().Do(request)
	if err != nil {
		return nil, fmt.Errorf("call eSignet: %w", err)
	}
	defer func() { _ = response.Body.Close() }()
	body, err := io.ReadAll(io.LimitReader(response.Body, 1<<20))
	if err != nil {
		return nil, fmt.Errorf("read eSignet response: %w", err)
	}

	var envelope eSignetEnvelope
	if err := json.Unmarshal(body, &envelope); err != nil {
		return nil, fmt.Errorf("decode eSignet response: %w", err)
	}
	if len(envelope.Errors) > 0 {
		return nil, fmt.Errorf("eSignet error %s: %s", envelope.Errors[0].ErrorCode,
			envelope.Errors[0].Message)
	}
	if response.StatusCode >= 300 {
		return nil, fmt.Errorf("eSignet returned status %d", response.StatusCode)
	}
	if len(envelope.Response) == 0 || string(envelope.Response) == "null" {
		return []Session{}, nil
	}

	// The list endpoint answers with {totalResults, sessions}; a single-session call answers with the
	// session object. Both shapes are accepted.
	var list struct {
		TotalResults int       `json:"totalResults"`
		Sessions     []Session `json:"sessions"`
	}
	if err := json.Unmarshal(envelope.Response, &list); err == nil && list.Sessions != nil {
		return list.Sessions, nil
	}
	var single Session
	if err := json.Unmarshal(envelope.Response, &single); err == nil && single.SessionID != "" {
		return []Session{single}, nil
	}
	return []Session{}, nil
}

// eSignetRevokeSession revokes one session. When subject is non-empty the request is scoped to that
// subject, so an end user cannot revoke somebody else's session.
func (s *Server) eSignetRevokeSession(ctx context.Context, sessionID, subject string) error {
	if s.cfg.ESignet.SessionAPIKey == "" {
		return errSessionAPIUnavailable
	}
	endpoint := s.cfg.ESignet.BaseURL + "/v1/esignet/device-sso/sessions/" +
		url.PathEscape(sessionID) + "/revoke"
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, nil)
	if err != nil {
		return err
	}
	request.Header.Set("Authorization", "Bearer "+s.cfg.ESignet.SessionAPIKey)
	if subject != "" {
		request.Header.Set("X-ESignet-Subject-Id", subject)
	}

	response, err := s.eSignetClient().Do(request)
	if err != nil {
		return fmt.Errorf("call eSignet: %w", err)
	}
	defer func() { _ = response.Body.Close() }()
	body, _ := io.ReadAll(io.LimitReader(response.Body, 1<<20))

	var envelope eSignetEnvelope
	_ = json.Unmarshal(body, &envelope)
	if len(envelope.Errors) > 0 {
		return fmt.Errorf("eSignet error %s: %s", envelope.Errors[0].ErrorCode,
			envelope.Errors[0].Message)
	}
	if response.StatusCode >= 300 {
		return fmt.Errorf("eSignet returned status %d", response.StatusCode)
	}
	return nil
}

// eSignetRevokeSubject revokes every active session of a subject and returns how many were revoked.
func (s *Server) eSignetRevokeSubject(ctx context.Context, subject string) (int, error) {
	if s.cfg.ESignet.SessionAPIKey == "" {
		return 0, errSessionAPIUnavailable
	}
	endpoint := s.cfg.ESignet.BaseURL + "/v1/esignet/device-sso/sessions/revoke?subject=" +
		url.QueryEscape(subject)
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, nil)
	if err != nil {
		return 0, err
	}
	request.Header.Set("Authorization", "Bearer "+s.cfg.ESignet.SessionAPIKey)

	response, err := s.eSignetClient().Do(request)
	if err != nil {
		return 0, fmt.Errorf("call eSignet: %w", err)
	}
	defer func() { _ = response.Body.Close() }()
	body, _ := io.ReadAll(io.LimitReader(response.Body, 1<<20))

	var envelope eSignetEnvelope
	if err := json.Unmarshal(body, &envelope); err != nil {
		return 0, fmt.Errorf("decode eSignet response: %w", err)
	}
	if len(envelope.Errors) > 0 {
		return 0, fmt.Errorf("eSignet error %s: %s", envelope.Errors[0].ErrorCode,
			envelope.Errors[0].Message)
	}
	var payload struct {
		RevokedCount int `json:"revokedCount"`
	}
	_ = json.Unmarshal(envelope.Response, &payload)
	return payload.RevokedCount, nil
}

// adminUser builds an administrator account record.
func adminUser(email, passwordHash string) store.AdminUser {
	return store.AdminUser{
		ID:           uuid.NewString(),
		Email:        strings.ToLower(strings.TrimSpace(email)),
		PasswordHash: passwordHash,
		Role:         RoleAdmin,
		CreatedAt:    time.Now().UTC(),
	}
}
