package api

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sync"
	"time"

	"github.com/google/uuid"

	"github.com/mosip/esignet-platform/internal/store"
)

// StreamEvent is one event pushed to administrator console subscribers.
type StreamEvent struct {
	Type string    `json:"type"`
	At   time.Time `json:"at"`
	Data any       `json:"data"`
}

// EventHub fans events out to the console's Server-Sent Events subscribers.
//
// Delivery is best effort and non-blocking: a subscriber that cannot keep up loses events rather than
// stalling the request that produced them. The hub is intentionally in-memory; the durable record of
// every event is the security_event table, which the console re-reads on reconnect.
type EventHub struct {
	mu          sync.RWMutex
	subscribers map[string]chan StreamEvent
	// keepAlive is the interval of SSE comment frames that keep idle connections open.
	keepAlive time.Duration
}

// NewEventHub builds an empty hub.
func NewEventHub() *EventHub {
	return &EventHub{subscribers: map[string]chan StreamEvent{}, keepAlive: 25 * time.Second}
}

// Subscribe registers a subscriber and returns its channel plus an unsubscribe function.
func (h *EventHub) Subscribe() (string, <-chan StreamEvent, func()) {
	id := uuid.NewString()
	channel := make(chan StreamEvent, 64)
	h.mu.Lock()
	h.subscribers[id] = channel
	h.mu.Unlock()

	unsubscribe := func() {
		h.mu.Lock()
		if existing, ok := h.subscribers[id]; ok {
			delete(h.subscribers, id)
			close(existing)
		}
		h.mu.Unlock()
	}
	return id, channel, unsubscribe
}

// Publish delivers an event to every subscriber without blocking.
func (h *EventHub) Publish(event StreamEvent) {
	h.mu.RLock()
	defer h.mu.RUnlock()
	for _, channel := range h.subscribers {
		select {
		case channel <- event:
		default:
			// Slow subscriber: drop the event for this subscriber only.
		}
	}
}

// SubscriberCount reports how many consoles are connected.
func (h *EventHub) SubscriberCount() int {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return len(h.subscribers)
}

// RecordSecurityEvent implements otp.EventRecorder.
func (h *EventHub) RecordSecurityEvent(_ context.Context, event store.SecurityEvent) {
	h.Publish(StreamEvent{Type: "security.event", At: event.CreatedAt, Data: event})
}

// Notify implements otp.EventRecorder.
func (h *EventHub) Notify(_ context.Context, notification store.Notification) {
	h.Publish(StreamEvent{Type: "notification.created", At: notification.CreatedAt,
		Data: map[string]any{"category": notification.Category, "title": notification.Title}})
}

// handleEventStream streams events to a connected console over Server-Sent Events.
func (s *Server) handleEventStream(w http.ResponseWriter, r *http.Request) {
	flusher, ok := w.(http.Flusher)
	if !ok {
		writeError(w, http.StatusInternalServerError, "streaming_unsupported",
			"This server cannot stream events")
		return
	}

	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache, no-transform")
	w.Header().Set("Connection", "keep-alive")
	w.Header().Set("X-Accel-Buffering", "no")
	w.WriteHeader(http.StatusOK)
	fmt.Fprint(w, ": connected\n\n")
	flusher.Flush()

	id, events, unsubscribe := s.hub.Subscribe()
	defer unsubscribe()

	// Announce the subscription so the console can show the stream is live.
	initial, _ := json.Marshal(StreamEvent{Type: "stream.ready", At: time.Now().UTC(),
		Data: map[string]any{"subscriberId": id}})
	fmt.Fprintf(w, "event: stream.ready\ndata: %s\n\n", initial)
	flusher.Flush()

	ctx := r.Context()
	for {
		select {
		case <-ctx.Done():
			return
		case event, open := <-events:
			if !open {
				return
			}
			payload, err := json.Marshal(event)
			if err != nil {
				continue
			}
			fmt.Fprintf(w, "event: %s\ndata: %s\n\n", event.Type, payload)
			flusher.Flush()
		case <-time.After(s.hub.keepAlive):
			// Comment frame: keeps proxies from closing an idle stream.
			fmt.Fprint(w, ": keep-alive\n\n")
			flusher.Flush()
		}
	}
}
