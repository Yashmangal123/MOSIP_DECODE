package api

import (
	"time"

	"github.com/mosip/esignet-platform/internal/config"
)

// testAPIConfig returns a configuration usable by the api package tests. Only the fields the tested
// functions read are populated.
func testAPIConfig() *config.Config {
	return &config.Config{
		Environment: "test",
		APIKey:      "",
		Admin: config.AdminConfig{
			JWTSecret:      "test-admin-secret",
			TokenTTL:       time.Hour,
			AllowedOrigins: []string{"http://localhost:5173"},
		},
		ESignet: config.ESignetConfig{BaseURL: "http://localhost:8080", Timeout: time.Second},
	}
}

// timeAfterSecond returns a channel that fires after one second, used as a test timeout guard.
func timeAfterSecond() <-chan time.Time {
	return time.After(time.Second)
}
