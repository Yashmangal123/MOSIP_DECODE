package api

import (
	"context"
	"crypto/pbkdf2"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"fmt"
	"strconv"
	"strings"
)

// Password hashing.
//
// Administrator passwords are stored as PBKDF2-HMAC-SHA256 digests in a self-describing string so the
// work factor can be raised later without a schema change:
//
//	pbkdf2-sha256$<iterations>$<base64 salt>$<base64 digest>
//
// Verification is constant time and rejects malformed stored values instead of panicking.
const (
	// passwordIterations is the PBKDF2 work factor. It is deliberately high because administrator
	// logins are rare; raise it as hardware improves (existing digests keep working).
	passwordIterations = 600_000
	// passwordSaltBytes is the salt length.
	passwordSaltBytes = 16
	// passwordKeyBytes is the derived key length.
	passwordKeyBytes = 32
	// passwordScheme is the prefix of stored digests.
	passwordScheme = "pbkdf2-sha256"
	// minPasswordLength is the minimum accepted administrator password length.
	minPasswordLength = 8
)

// hashPassword derives a storable digest from a password.
func hashPassword(password string) (string, error) {
	if len(password) < minPasswordLength {
		return "", fmt.Errorf("password must be at least %d characters", minPasswordLength)
	}
	salt := make([]byte, passwordSaltBytes)
	if _, err := rand.Read(salt); err != nil {
		return "", fmt.Errorf("read salt: %w", err)
	}
	digest, err := pbkdf2.Key(sha256.New, password, salt, passwordIterations, passwordKeyBytes)
	if err != nil {
		return "", fmt.Errorf("derive password digest: %w", err)
	}
	return fmt.Sprintf("%s$%d$%s$%s", passwordScheme, passwordIterations,
		base64.RawStdEncoding.EncodeToString(salt),
		base64.RawStdEncoding.EncodeToString(digest)), nil
}

// verifyPassword reports whether a password matches a stored digest in constant time.
func verifyPassword(stored, password string) bool {
	parts := strings.Split(stored, "$")
	if len(parts) != 4 || parts[0] != passwordScheme {
		return false
	}
	iterations, err := strconv.Atoi(parts[1])
	if err != nil || iterations < 1000 {
		return false
	}
	salt, err := base64.RawStdEncoding.DecodeString(parts[2])
	if err != nil {
		return false
	}
	expected, err := base64.RawStdEncoding.DecodeString(parts[3])
	if err != nil || len(expected) == 0 {
		return false
	}
	actual, err := pbkdf2.Key(sha256.New, password, salt, iterations, len(expected))
	if err != nil {
		return false
	}
	return subtle.ConstantTimeCompare(actual, expected) == 1
}

// ensureBootstrapAdmin creates the first administrator when the store has none.
func (s *Server) ensureBootstrapAdmin(ctx context.Context) error {
	count, err := s.store.CountAdmins(ctx)
	if err != nil {
		return err
	}
	if count > 0 {
		return nil
	}
	if s.cfg.Admin.BootstrapEmail == "" || s.cfg.Admin.BootstrapPassword == "" {
		s.logger.Warn("no administrator account exists and no bootstrap credentials are configured; " +
			"the administrator console cannot be used until PLATFORM_ADMIN_EMAIL and PLATFORM_ADMIN_PASSWORD are set")
		return nil
	}
	digest, err := hashPassword(s.cfg.Admin.BootstrapPassword)
	if err != nil {
		return fmt.Errorf("hash bootstrap administrator password: %w", err)
	}
	admin := adminUser(s.cfg.Admin.BootstrapEmail, digest)
	if err := s.store.CreateAdmin(ctx, admin); err != nil {
		return fmt.Errorf("create bootstrap administrator: %w", err)
	}
	s.logger.Info("created the bootstrap administrator account", "email", admin.Email)
	return nil
}

// BootstrapAdministrator creates the first administrator account when configured and none exists.
func (s *Server) BootstrapAdministrator(ctx context.Context) error {
	return s.ensureBootstrapAdmin(ctx)
}
