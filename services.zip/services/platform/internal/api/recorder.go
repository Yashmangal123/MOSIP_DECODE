package api

import (
	"context"
	"log/slog"

	"github.com/mosip/esignet-platform/internal/store"
)

// Recorder is the durable implementation of the OTP service's event recorder.
//
// Every security event is written to the security_event table (the source of truth the console queries)
// and then published to the live stream. Persistence failures are logged but never propagated: an audit
// write must not make a sign-in fail, and the OTP service logs the same condition from its side.
type Recorder struct {
	store  *store.Store
	hub    *EventHub
	logger *slog.Logger
}

// NewRecorder builds a recorder.
func NewRecorder(st *store.Store, hub *EventHub, logger *slog.Logger) *Recorder {
	return &Recorder{store: st, hub: hub, logger: logger}
}

// RecordSecurityEvent persists and publishes a security event.
func (r *Recorder) RecordSecurityEvent(ctx context.Context, event store.SecurityEvent) {
	if event.EventType == "" {
		return
	}
	if err := r.store.CreateSecurityEvent(ctx, event); err != nil {
		r.logger.ErrorContext(ctx, "failed to persist security event", "eventType", event.EventType,
			"error", err)
	}
	r.hub.Publish(StreamEvent{Type: "security.event", At: event.CreatedAt, Data: event})
}

// Notify persists and publishes a user notification.
func (r *Recorder) Notify(ctx context.Context, notification store.Notification) {
	if err := r.store.CreateNotification(ctx, notification); err != nil {
		r.logger.ErrorContext(ctx, "failed to persist notification", "category", notification.Category,
			"error", err)
	}
	r.hub.Publish(StreamEvent{Type: "notification.created", At: notification.CreatedAt,
		Data: map[string]any{"category": notification.Category, "title": notification.Title}})
}
