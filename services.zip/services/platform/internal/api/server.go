// Package api exposes the platform HTTP API: the OTP endpoints used by the login UI and the identity
// provider, the end-user endpoints consumed by the Super App and Child App dashboards, and the
// administrator console API.
package api

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"

	"github.com/mosip/esignet-platform/internal/config"
	"github.com/mosip/esignet-platform/internal/otp"
	"github.com/mosip/esignet-platform/internal/store"
)

// Server holds the dependencies of the HTTP API.
type Server struct {
	cfg        *config.Config
	store      *store.Store
	otp        *otp.Service
	hub        *EventHub
	logger     *slog.Logger
	httpClient *http.Client
}

// NewServer builds the API server.
func NewServer(cfg *config.Config, st *store.Store, otpSvc *otp.Service, hub *EventHub,
	logger *slog.Logger) *Server {
	return &Server{
		cfg: cfg, store: st, otp: otpSvc, hub: hub, logger: logger,
		httpClient: &http.Client{Timeout: cfg.ESignet.Timeout},
	}
}

// Routes builds the HTTP handler of the service.
func (s *Server) Routes() http.Handler {
	mux := http.NewServeMux()

	// Administrator console (static page; every endpoint it calls requires a token).
	mux.HandleFunc("GET /console", s.handleConsole)
	mux.HandleFunc("GET /", s.handleConsole)

	// Operational endpoints.
	mux.HandleFunc("GET /health", s.handleHealth)
	mux.HandleFunc("GET /v1/health", s.handleHealth)

	// Identity / OTP (called by the login UI).
	mux.HandleFunc("POST /v1/identity/otp/send", s.withCORS(s.handleSendOTP))
	mux.HandleFunc("POST /v1/identity/otp/verify", s.withCORS(s.handleVerifyOTP))
	mux.HandleFunc("OPTIONS /v1/identity/otp/send", s.handlePreflight)
	mux.HandleFunc("OPTIONS /v1/identity/otp/verify", s.handlePreflight)

	// Internal service-to-service API (eSignet identity provider).
	mux.HandleFunc("POST /internal/otp/send", s.requireInternalAPIKey(s.handleInternalSendOTP))
	mux.HandleFunc("POST /internal/otp/verify", s.requireInternalAPIKey(s.handleInternalVerifyOTP))
	mux.HandleFunc("GET /internal/identity/users/{uin}", s.requireInternalAPIKey(s.handleInternalUser))
	mux.HandleFunc("POST /internal/events", s.requireInternalAPIKey(s.handleInternalEvent))
	mux.HandleFunc("POST /internal/notifications", s.requireInternalAPIKey(s.handleInternalNotification))

	// End-user API (mobile applications, authenticated with an eSignet access token).
	mux.HandleFunc("GET /v1/me/profile", s.requireUserToken("openid")(s.handleMeProfile))
	mux.HandleFunc("GET /v1/me/sessions", s.requireUserToken("openid")(s.handleMeSessions))
	mux.HandleFunc("POST /v1/me/sessions/{sessionId}/revoke", s.requireUserToken("openid")(s.handleMeRevokeSession))
	mux.HandleFunc("GET /v1/me/notifications", s.requireUserToken("openid")(s.handleMeNotifications))
	mux.HandleFunc("POST /v1/me/notifications/{id}/read", s.requireUserToken("openid")(s.handleMeReadNotification))
	mux.HandleFunc("GET /v1/me/activity", s.requireUserToken("openid")(s.handleMeActivity))

	// Administrator console API.
	mux.HandleFunc("POST /v1/admin/login", s.withCORS(s.handleAdminLogin))
	mux.HandleFunc("OPTIONS /v1/admin/login", s.handlePreflight)
	mux.HandleFunc("GET /v1/admin/me", s.requireAdmin()(s.handleAdminMe))
	mux.HandleFunc("GET /v1/admin/overview", s.requireAdmin(RoleAdmin, RoleAuditor, RoleSupport)(s.handleAdminOverview))
	mux.HandleFunc("GET /v1/admin/applications", s.requireAdmin(RoleAdmin, RoleAuditor, RoleSupport)(s.handleAdminApplications))
	mux.HandleFunc("GET /v1/admin/analytics/auth", s.requireAdmin(RoleAdmin, RoleAuditor)(s.handleAdminAnalytics))
	mux.HandleFunc("GET /v1/admin/otp/stats", s.requireAdmin(RoleAdmin, RoleAuditor)(s.handleAdminOTPStats))
	mux.HandleFunc("GET /v1/admin/sessions", s.requireAdmin(RoleAdmin, RoleAuditor, RoleSupport)(s.handleAdminSessions))
	mux.HandleFunc("POST /v1/admin/sessions/{sessionId}/revoke",
		s.requireAdmin(RoleAdmin, RoleSupport)(s.handleAdminRevokeSession))
	mux.HandleFunc("POST /v1/admin/sessions/revoke", s.requireAdmin(RoleAdmin)(s.handleAdminRevokeSubject))
	mux.HandleFunc("GET /v1/admin/security/events", s.requireAdmin(RoleAdmin, RoleAuditor)(s.handleAdminSecurityEvents))
	mux.HandleFunc("GET /v1/admin/audit", s.requireAdmin(RoleAdmin, RoleAuditor)(s.handleAdminAudit))
	mux.HandleFunc("GET /v1/admin/config", s.requireAdmin(RoleAdmin)(s.handleAdminConfig))
	mux.HandleFunc("GET /v1/admin/events/stream", s.requireAdmin(RoleAdmin, RoleAuditor, RoleSupport)(s.handleEventStream))

	return s.withSecurityHeaders(mux)
}

// handleHealth reports service health, including database reachability.
func (s *Server) handleHealth(w http.ResponseWriter, r *http.Request) {
	if err := s.store.HealthCheck(r.Context()); err != nil {
		writeError(w, http.StatusServiceUnavailable, "unhealthy", "Database is unreachable")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"status":      "UP",
		"environment": s.cfg.Environment,
		"time":        time.Now().UTC(),
	})
}

// ---------- request/response helpers ----------

// apiError is the error shape returned by every endpoint.
type apiError struct {
	Code    string `json:"code"`
	Message string `json:"message"`
	Details any    `json:"details,omitempty"`
}

// errorEnvelope wraps an error.
type errorEnvelope struct {
	Error apiError `json:"error"`
}

// writeJSON writes a JSON response.
func writeJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	if payload != nil {
		_ = json.NewEncoder(w).Encode(payload)
	}
}

// writeError writes a structured error response.
func writeError(w http.ResponseWriter, status int, code, message string) {
	writeJSON(w, status, errorEnvelope{Error: apiError{Code: code, Message: message}})
}

// decodeJSON reads a JSON body of at most 64 KiB.
func decodeJSON(r *http.Request, target any) error {
	decoder := json.NewDecoder(http.MaxBytesReader(nil, r.Body, 64*1024))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		return fmt.Errorf("invalid request body: %w", err)
	}
	return nil
}

// clientIP resolves the caller's address, honouring a single forwarding hop.
func clientIP(r *http.Request) string {
	if forwarded := r.Header.Get("X-Forwarded-For"); forwarded != "" {
		if first := strings.TrimSpace(strings.Split(forwarded, ",")[0]); first != "" {
			return first
		}
	}
	// net.SplitHostPort handles both IPv4 and bracketed IPv6; a naive "cut at the last colon" would
	// mangle an IPv6 address into something that cannot be correlated in an audit trail.
	if host, _, err := net.SplitHostPort(r.RemoteAddr); err == nil {
		return host
	}
	return r.RemoteAddr
}

// withCORS adds CORS headers for the configured origins.
func (s *Server) withCORS(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		origin := r.Header.Get("Origin")
		for _, allowed := range s.cfg.Admin.AllowedOrigins {
			if allowed == "*" || strings.EqualFold(allowed, origin) {
				w.Header().Set("Access-Control-Allow-Origin", origin)
				w.Header().Set("Vary", "Origin")
				w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
				w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
				w.Header().Set("Access-Control-Allow-Credentials", "true")
				break
			}
		}
		next(w, r)
	}
}

// handlePreflight answers a CORS preflight request.
func (s *Server) handlePreflight(w http.ResponseWriter, r *http.Request) {
	s.withCORS(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusNoContent)
	})(w, r)
}

// withSecurityHeaders adds defensive response headers to every API response.
func (s *Server) withSecurityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		next.ServeHTTP(w, r)
	})
}

// ---------- OTP endpoints ----------

// sendOTPRequest is the body of both OTP send endpoints.
type sendOTPRequest struct {
	Identifier string `json:"identifier"`
	Channel    string `json:"channel"`
	Purpose    string `json:"purpose,omitempty"`
}

// sendOTPResponse is the body of both OTP send endpoints.
type sendOTPResponse struct {
	ChallengeID       string `json:"transactionId"`
	Channel           string `json:"channel"`
	DestinationMasked string `json:"maskedDestination"`
	ExpiresIn         int    `json:"expiresIn"`
	ResendAfter       int    `json:"resendAfter"`
	DeliveryStatus    string `json:"deliveryStatus"`
	Provider          string `json:"provider"`
	DevelopmentOTP    string `json:"developmentOtp,omitempty"`
}

// handleSendOTP issues an OTP for the login UI.
func (s *Server) handleSendOTP(w http.ResponseWriter, r *http.Request) { s.sendOTP(w, r) }

// handleInternalSendOTP issues an OTP on behalf of the eSignet identity provider.
func (s *Server) handleInternalSendOTP(w http.ResponseWriter, r *http.Request) { s.sendOTP(w, r) }

func (s *Server) sendOTP(w http.ResponseWriter, r *http.Request) {
	var body sendOTPRequest
	if err := decodeJSON(r, &body); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	if strings.TrimSpace(body.Identifier) == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "identifier is required")
		return
	}
	if body.Channel == "" {
		body.Channel = otp.ChannelEmail
	}

	result, err := s.otp.Send(r.Context(), body.Identifier, body.Channel, body.Purpose, clientIP(r))
	if err != nil {
		s.writeOTPError(w, r, err)
		return
	}
	s.hub.Publish(StreamEvent{
		Type: "otp.sent", At: time.Now().UTC(),
		Data: map[string]any{"channel": result.Channel, "provider": result.Provider},
	})
	writeJSON(w, http.StatusOK, sendOTPResponse{
		ChallengeID:       result.ChallengeID,
		Channel:           result.Channel,
		DestinationMasked: result.DestinationMasked,
		ExpiresIn:         result.ExpiresIn,
		ResendAfter:       result.ResendAfter,
		DeliveryStatus:    result.DeliveryStatus,
		Provider:          result.Provider,
		DevelopmentOTP:    result.DevelopmentOTP,
	})
}

// verifyOTPRequest is the body of both OTP verify endpoints.
type verifyOTPRequest struct {
	ChallengeID string `json:"transactionId,omitempty"`
	Identifier  string `json:"identifier,omitempty"`
	OTP         string `json:"otp"`
}

// verifyOTPResponse is the body of both OTP verify endpoints.
type verifyOTPResponse struct {
	Verified bool   `json:"verified"`
	UIN      string `json:"uin,omitempty"`
}

// handleVerifyOTP verifies an OTP for the login UI.
func (s *Server) handleVerifyOTP(w http.ResponseWriter, r *http.Request) { s.verifyOTP(w, r) }

// handleInternalVerifyOTP verifies an OTP on behalf of the eSignet identity provider.
func (s *Server) handleInternalVerifyOTP(w http.ResponseWriter, r *http.Request) { s.verifyOTP(w, r) }

func (s *Server) verifyOTP(w http.ResponseWriter, r *http.Request) {
	var body verifyOTPRequest
	if err := decodeJSON(r, &body); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	if body.ChallengeID == "" && body.Identifier == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "transactionId or identifier is required")
		return
	}

	result, err := s.otp.Verify(r.Context(), body.ChallengeID, body.Identifier, body.OTP, clientIP(r))
	if err != nil {
		s.writeOTPError(w, r, err)
		return
	}
	s.hub.Publish(StreamEvent{
		Type: "otp.verified", At: time.Now().UTC(),
		Data: map[string]any{"channel": "otp"},
	})
	writeJSON(w, http.StatusOK, verifyOTPResponse{Verified: true, UIN: result.UIN})
}

// writeOTPError maps OTP service errors onto HTTP responses. The messages are deliberately generic so
// they cannot be used to probe whether an identifier exists or which factor failed.
func (s *Server) writeOTPError(w http.ResponseWriter, _ *http.Request, err error) {
	switch {
	case errors.Is(err, otp.ErrUnknownIdentifier), errors.Is(err, otp.ErrDeliveryFailed),
		errors.Is(err, otp.ErrInvalidChannel):
		writeError(w, http.StatusBadRequest, "otp_send_failed",
			"The verification code could not be sent")
	case errors.Is(err, otp.ErrRateLimited):
		writeError(w, http.StatusTooManyRequests, "rate_limited",
			"Too many requests. Please wait before trying again")
	case errors.Is(err, otp.ErrIncorrectOTP):
		writeError(w, http.StatusBadRequest, "incorrect_otp", "The verification code is incorrect")
	case errors.Is(err, otp.ErrExpired):
		writeError(w, http.StatusBadRequest, "otp_expired", "The verification code has expired")
	case errors.Is(err, otp.ErrTooManyAttempts):
		writeError(w, http.StatusLocked, "too_many_attempts",
			"Too many incorrect attempts. Request a new code")
	case errors.Is(err, otp.ErrAlreadyUsed):
		writeError(w, http.StatusBadRequest, "otp_already_used", "This code was already used")
	case errors.Is(err, otp.ErrNoActiveChallenge):
		writeError(w, http.StatusBadRequest, "no_active_otp", "Request a new verification code")
	default:
		s.logger.Error("OTP operation failed", "error", err)
		writeError(w, http.StatusInternalServerError, "internal_error", "An unexpected error occurred")
	}
}

// ---------- internal identity endpoints ----------

// handleInternalUser returns an identity directory user for the identity provider.
func (s *Server) handleInternalUser(w http.ResponseWriter, r *http.Request) {
	uin := r.PathValue("uin")
	user, err := s.store.GetUserByUIN(r.Context(), uin)
	if errors.Is(err, store.ErrNotFound) {
		writeError(w, http.StatusNotFound, "not_found", "No such user")
		return
	}
	if err != nil {
		s.logger.Error("identity lookup failed", "error", err)
		writeError(w, http.StatusInternalServerError, "internal_error", "Lookup failed")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"uin":            user.UIN,
		"name":           user.FullName,
		"given_name":     user.GivenName,
		"family_name":    user.FamilyName,
		"email":          user.Email,
		"phone_number":   user.Phone,
		"birthdate":      user.Birthdate,
		"gender":         user.Gender,
		"address":        user.Address,
		"locale":         user.Locale,
		"picture":        user.Picture,
		"email_verified": user.EmailVerified,
		"phone_verified": user.PhoneVerified,
	})
}

// internalEventRequest is the body of the internal event endpoint.
type internalEventRequest struct {
	EventType string         `json:"eventType"`
	Severity  string         `json:"severity"`
	Subject   string         `json:"subject,omitempty"`
	ClientID  string         `json:"clientId,omitempty"`
	SessionID string         `json:"sessionId,omitempty"`
	Status    string         `json:"status,omitempty"`
	IP        string         `json:"ip,omitempty"`
	UserAgent string         `json:"userAgent,omitempty"`
	Metadata  map[string]any `json:"metadata,omitempty"`
}

// handleInternalEvent records a security event reported by a trusted service.
func (s *Server) handleInternalEvent(w http.ResponseWriter, r *http.Request) {
	var body internalEventRequest
	if err := decodeJSON(r, &body); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	if body.EventType == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "eventType is required")
		return
	}
	if body.Severity == "" {
		body.Severity = "INFO"
	}
	event := store.SecurityEvent{
		ID:         uuid.NewString(),
		EventType:  body.EventType,
		Severity:   body.Severity,
		SubjectUIN: body.Subject,
		ClientID:   body.ClientID,
		SessionID:  body.SessionID,
		Status:     body.Status,
		IP:         body.IP,
		UserAgent:  body.UserAgent,
		Metadata:   body.Metadata,
		CreatedAt:  time.Now().UTC(),
	}
	if err := s.store.CreateSecurityEvent(r.Context(), event); err != nil {
		s.logger.Error("failed to store security event", "error", err)
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not store the event")
		return
	}
	s.hub.Publish(StreamEvent{Type: "security.event", At: event.CreatedAt, Data: event})
	writeJSON(w, http.StatusAccepted, map[string]string{"id": event.ID})
}

// internalNotificationRequest is the body of the internal notification endpoint.
type internalNotificationRequest struct {
	Subject  string         `json:"subject"`
	Category string         `json:"category"`
	Title    string         `json:"title"`
	Body     string         `json:"body"`
	Severity string         `json:"severity,omitempty"`
	Metadata map[string]any `json:"metadata,omitempty"`
}

// handleInternalNotification creates a notification for a user.
func (s *Server) handleInternalNotification(w http.ResponseWriter, r *http.Request) {
	var body internalNotificationRequest
	if err := decodeJSON(r, &body); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	if body.Subject == "" || body.Title == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "subject and title are required")
		return
	}
	if body.Severity == "" {
		body.Severity = "INFO"
	}
	notification := store.Notification{
		ID:         uuid.NewString(),
		SubjectUIN: body.Subject,
		Category:   body.Category,
		Title:      body.Title,
		Body:       body.Body,
		Severity:   body.Severity,
		CreatedAt:  time.Now().UTC(),
		Metadata:   body.Metadata,
	}
	if err := s.store.CreateNotification(r.Context(), notification); err != nil {
		s.logger.Error("failed to store notification", "error", err)
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not store the notification")
		return
	}
	s.hub.Publish(StreamEvent{Type: "notification.created", At: notification.CreatedAt,
		Data: map[string]any{"category": notification.Category, "title": notification.Title}})
	writeJSON(w, http.StatusAccepted, map[string]string{"id": notification.ID})
}

// ---------- end-user endpoints ----------

// handleMeProfile returns the profile of the authenticated user.
func (s *Server) handleMeProfile(w http.ResponseWriter, r *http.Request) {
	subject := subjectFrom(r.Context())
	user, err := s.store.GetUserByUIN(r.Context(), subject)
	if errors.Is(err, store.ErrNotFound) {
		writeJSON(w, http.StatusOK, map[string]any{"subject": subject})
		return
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Lookup failed")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"subject":       user.UIN,
		"name":          user.FullName,
		"given_name":    user.GivenName,
		"family_name":   user.FamilyName,
		"email":         user.Email,
		"phone":         user.Phone,
		"emailVerified": user.EmailVerified,
		"phoneVerified": user.PhoneVerified,
		"locale":        user.Locale,
		"picture":       user.Picture,
	})
}

// handleMeSessions lists the Native SSO sessions of the authenticated user.
func (s *Server) handleMeSessions(w http.ResponseWriter, r *http.Request) {
	subject := subjectFrom(r.Context())
	sessions, err := s.eSignetSessions(r.Context(), subject)
	if err != nil {
		s.logger.Error("session listing failed", "error", err)
		writeError(w, http.StatusBadGateway, "upstream_error", "Could not read sessions")
		return
	}
	writeJSON(w, http.StatusOK, sessions)
}

// handleMeRevokeSession revokes one of the authenticated user's sessions.
func (s *Server) handleMeRevokeSession(w http.ResponseWriter, r *http.Request) {
	subject := subjectFrom(r.Context())
	sessionID := r.PathValue("sessionId")
	if sessionID == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "sessionId is required")
		return
	}
	if err := s.eSignetRevokeSession(r.Context(), sessionID, subject); err != nil {
		s.logger.Error("session revocation failed", "error", err)
		writeError(w, http.StatusBadGateway, "upstream_error", "Could not revoke the session")
		return
	}
	s.recordAudit(r.Context(), subject, "SESSION_REVOKED", sessionID, map[string]any{"by": "user"})
	writeJSON(w, http.StatusOK, map[string]string{"status": "REVOKED", "sessionId": sessionID})
}

// handleMeNotifications lists the authenticated user's notifications.
func (s *Server) handleMeNotifications(w http.ResponseWriter, r *http.Request) {
	subject := subjectFrom(r.Context())
	limit := 50
	if raw := r.URL.Query().Get("limit"); raw != "" {
		if parsed, err := strconv.Atoi(raw); err == nil && parsed > 0 && parsed <= 200 {
			limit = parsed
		}
	}
	notifications, err := s.store.ListNotifications(r.Context(), subject, limit)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read notifications")
		return
	}
	unread, _ := s.store.UnreadNotificationCount(r.Context(), subject)
	writeJSON(w, http.StatusOK, map[string]any{
		"notifications": notifications,
		"unreadCount":   unread,
	})
}

// handleMeReadNotification marks a notification read.
func (s *Server) handleMeReadNotification(w http.ResponseWriter, r *http.Request) {
	subject := subjectFrom(r.Context())
	if err := s.store.MarkNotificationRead(r.Context(), r.PathValue("id"), subject); err != nil {
		if errors.Is(err, store.ErrNotFound) {
			writeError(w, http.StatusNotFound, "not_found", "Notification not found")
			return
		}
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not update the notification")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "READ"})
}

// handleMeActivity returns the authenticated user's recent security activity.
func (s *Server) handleMeActivity(w http.ResponseWriter, r *http.Request) {
	subject := subjectFrom(r.Context())
	events, err := s.store.ListSecurityEvents(r.Context(), store.SecurityEventFilter{
		Subject: subject, Limit: 50,
	})
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read activity")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"events": events})
}

// ---------- administrator endpoints ----------

// adminLoginRequest is the administrator login body.
type adminLoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

// handleAdminLogin authenticates an administrator and issues a session token.
func (s *Server) handleAdminLogin(w http.ResponseWriter, r *http.Request) {
	var body adminLoginRequest
	if err := decodeJSON(r, &body); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	admin, err := s.store.GetAdminByEmail(r.Context(), body.Email)
	if err != nil {
		// Constant-ish response shape regardless of whether the account exists.
		s.recordAdminLoginEvent(r, body.Email, false)
		writeError(w, http.StatusUnauthorized, "invalid_credentials", "Invalid email or password")
		return
	}
	if !verifyPassword(admin.PasswordHash, body.Password) {
		s.recordAdminLoginEvent(r, body.Email, false)
		writeError(w, http.StatusUnauthorized, "invalid_credentials", "Invalid email or password")
		return
	}
	token, expiresAt, err := s.issueAdminToken(admin)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not issue a token")
		return
	}
	_ = s.store.TouchAdminLogin(r.Context(), admin.ID)
	s.recordAdminLoginEvent(r, body.Email, true)
	s.recordAudit(r.Context(), admin.Email, "ADMIN_LOGIN", admin.ID, map[string]any{"ip": clientIP(r)})
	writeJSON(w, http.StatusOK, map[string]any{
		"token":     token,
		"expiresAt": expiresAt,
		"admin":     map[string]any{"id": admin.ID, "email": admin.Email, "role": admin.Role},
	})
}

// handleAdminMe returns the authenticated administrator.
func (s *Server) handleAdminMe(w http.ResponseWriter, r *http.Request) {
	claims := adminFrom(r.Context())
	writeJSON(w, http.StatusOK, map[string]any{
		"sub": claims.Subject, "email": claims.Email, "role": claims.Role,
		"expiresAt": claims.ExpiresAt,
	})
}

// handleAdminOverview returns the console dashboard aggregates.
func (s *Server) handleAdminOverview(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	since := time.Now().Add(-24 * time.Hour)

	events, err := s.store.ListSecurityEvents(ctx, store.SecurityEventFilter{Since: time.Now().Add(-24 * time.Hour), Limit: 10})
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read security events")
		return
	}
	severity, err := s.store.GetSecurityEventSummary(ctx, since)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read the event summary")
		return
	}
	otpStats, err := s.store.GetOTPVerificationStats(ctx, since)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read OTP statistics")
		return
	}
	deliveryStats, err := s.store.GetDeliveryStats(ctx, since)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read delivery statistics")
		return
	}

	sessions, sessionErr := s.eSignetSessions(ctx, "")
	activeSessions := 0
	applications := map[string]bool{}
	if sessionErr == nil {
		for _, session := range sessions {
			if strings.EqualFold(session.Status, "ACTIVE") {
				activeSessions++
			}
			if session.ClientID != "" {
				applications[session.ClientID] = true
			}
		}
	}

	writeJSON(w, http.StatusOK, map[string]any{
		"generatedAt":       time.Now().UTC(),
		"windowHours":       24,
		"applications":      len(applications),
		"activeSessions":    activeSessions,
		"otp":               otpStats,
		"delivery":          deliveryStats,
		"securitySeverity":  severity,
		"recentEvents":      events,
		"sessionsAvailable": sessionErr == nil,
	})
}

// handleAdminApplications summarises the applications seen in the session table.
func (s *Server) handleAdminApplications(w http.ResponseWriter, r *http.Request) {
	sessions, err := s.eSignetSessions(r.Context(), "")
	if err != nil {
		writeError(w, http.StatusBadGateway, "upstream_error", "Could not read application sessions")
		return
	}
	type appSummary struct {
		ClientID       string `json:"clientId"`
		Sessions       int    `json:"sessions"`
		ActiveSessions int    `json:"activeSessions"`
		LastActivity   string `json:"lastActivity,omitempty"`
	}
	summaries := map[string]*appSummary{}
	for _, session := range sessions {
		summary, ok := summaries[session.ClientID]
		if !ok {
			summary = &appSummary{ClientID: session.ClientID}
			summaries[session.ClientID] = summary
		}
		summary.Sessions++
		if strings.EqualFold(session.Status, "ACTIVE") {
			summary.ActiveSessions++
		}
		if session.CreatedAt > summary.LastActivity {
			summary.LastActivity = session.CreatedAt
		}
	}
	out := make([]*appSummary, 0, len(summaries))
	for _, summary := range summaries {
		out = append(out, summary)
	}
	writeJSON(w, http.StatusOK, map[string]any{"applications": out})
}

// handleAdminAnalytics returns the authentication activity series.
func (s *Server) handleAdminAnalytics(w http.ResponseWriter, r *http.Request) {
	days := 7
	if raw := r.URL.Query().Get("days"); raw != "" {
		if parsed, err := strconv.Atoi(raw); err == nil && parsed > 0 && parsed <= 90 {
			days = parsed
		}
	}
	since := time.Now().AddDate(0, 0, -days)
	activity, err := s.store.GetAuthActivity(r.Context(), since)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read analytics")
		return
	}
	otpStats, err := s.store.GetOTPVerificationStats(r.Context(), since)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read OTP statistics")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"days": days, "activity": activity, "otp": otpStats,
	})
}

// handleAdminOTPStats returns OTP delivery and verification statistics.
func (s *Server) handleAdminOTPStats(w http.ResponseWriter, r *http.Request) {
	since := time.Now().Add(-24 * time.Hour)
	if raw := r.URL.Query().Get("hours"); raw != "" {
		if parsed, err := strconv.Atoi(raw); err == nil && parsed > 0 && parsed <= 720 {
			since = time.Now().Add(time.Duration(-parsed) * time.Hour)
		}
	}
	verification, err := s.store.GetOTPVerificationStats(r.Context(), since)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read OTP statistics")
		return
	}
	delivery, err := s.store.GetDeliveryStats(r.Context(), since)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read delivery statistics")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"verification": verification, "delivery": delivery})
}

// handleAdminSessions lists Native SSO sessions (all users, or one subject).
func (s *Server) handleAdminSessions(w http.ResponseWriter, r *http.Request) {
	sessions, err := s.eSignetSessions(r.Context(), r.URL.Query().Get("subject"))
	if err != nil {
		writeError(w, http.StatusBadGateway, "upstream_error", "Could not read sessions")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"sessions": sessions})
}

// handleAdminRevokeSession revokes one session.
func (s *Server) handleAdminRevokeSession(w http.ResponseWriter, r *http.Request) {
	sessionID := r.PathValue("sessionId")
	claims := adminFrom(r.Context())
	if err := s.eSignetRevokeSession(r.Context(), sessionID, ""); err != nil {
		writeError(w, http.StatusBadGateway, "upstream_error", "Could not revoke the session")
		return
	}
	s.recordAudit(r.Context(), claims.Email, "SESSION_REVOKED", sessionID, map[string]any{"by": "admin"})
	writeJSON(w, http.StatusOK, map[string]string{"status": "REVOKED", "sessionId": sessionID})
}

// handleAdminRevokeSubject revokes every session of a subject.
func (s *Server) handleAdminRevokeSubject(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Subject string `json:"subject"`
	}
	if err := decodeJSON(r, &body); err != nil || body.Subject == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "subject is required")
		return
	}
	count, err := s.eSignetRevokeSubject(r.Context(), body.Subject)
	if err != nil {
		writeError(w, http.StatusBadGateway, "upstream_error", "Could not revoke the sessions")
		return
	}
	claims := adminFrom(r.Context())
	s.recordAudit(r.Context(), claims.Email, "SESSIONS_REVOKED", body.Subject,
		map[string]any{"revokedCount": count})
	writeJSON(w, http.StatusOK, map[string]any{"revokedCount": count})
}

// handleAdminSecurityEvents lists security events.
func (s *Server) handleAdminSecurityEvents(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	limit := 100
	if raw := query.Get("limit"); raw != "" {
		if parsed, err := strconv.Atoi(raw); err == nil && parsed > 0 && parsed <= 500 {
			limit = parsed
		}
	}
	events, err := s.store.ListSecurityEvents(r.Context(), store.SecurityEventFilter{
		EventType: query.Get("eventType"),
		Severity:  query.Get("severity"),
		ClientID:  query.Get("clientId"),
		Subject:   query.Get("subject"),
		Limit:     limit,
	})
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read security events")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"events": events})
}

// handleAdminAudit lists administrative activity.
func (s *Server) handleAdminAudit(w http.ResponseWriter, r *http.Request) {
	records, err := s.store.ListAudit(r.Context(), 200)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "internal_error", "Could not read the audit trail")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"audit": records})
}

// handleAdminConfig returns the effective configuration with secrets masked.
func (s *Server) handleAdminConfig(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"environment": s.cfg.Environment,
		"otp": map[string]any{
			"length":            s.cfg.OTP.Length,
			"validitySeconds":   int(s.cfg.OTP.Validity.Seconds()),
			"maxAttempts":       s.cfg.OTP.MaxAttempts,
			"resendCooldown":    int(s.cfg.OTP.ResendCooldown.Seconds()),
			"maxSendsPerWindow": s.cfg.OTP.MaxSendsPerWindow,
			"rateWindow":        s.cfg.OTP.RateWindow.String(),
		},
		"email": map[string]any{
			"mode": s.cfg.Email.Mode, "host": s.cfg.Email.Host, "port": s.cfg.Email.Port,
			"from": s.cfg.Email.From, "tls": s.cfg.Email.TLSMode,
			"credentialsConfigured": s.cfg.Email.Username != "",
		},
		"sms": map[string]any{
			"provider": s.cfg.SMS.Provider, "senderId": s.cfg.SMS.SenderID,
			"credentialsConfigured": s.smsCredentialsConfigured(),
			"realDelivery":          s.cfg.SMS.Provider != "console",
		},
		"esignet": map[string]any{
			"baseUrl":                 s.cfg.ESignet.BaseURL,
			"introspectionConfigured": s.cfg.ESignet.IntrospectionClientID != "",
			"sessionApiConfigured":    s.cfg.ESignet.SessionAPIKey != "",
		},
		"admin": map[string]any{
			"tokenTtl":       s.cfg.Admin.TokenTTL.String(),
			"allowedOrigins": s.cfg.Admin.AllowedOrigins,
		},
	})
}

// smsCredentialsConfigured reports whether the configured SMS provider has credentials.
func (s *Server) smsCredentialsConfigured() bool {
	switch s.cfg.SMS.Provider {
	case "msg91":
		return s.cfg.SMS.MSG91AuthKey != ""
	case "twilio":
		return s.cfg.SMS.TwilioAccountSID != "" && s.cfg.SMS.TwilioAuthToken != ""
	case "aws_sns":
		return s.cfg.SMS.AWSAccessKeyID != "" && s.cfg.SMS.AWSSecretAccessKey != ""
	default:
		return false
	}
}

// recordAudit appends an administrative audit record (best effort).
func (s *Server) recordAudit(ctx context.Context, actor, action, target string, details map[string]any) {
	record := store.AuditRecord{
		ID: uuid.NewString(), Actor: actor, Action: action, Target: target, Details: details,
		CreatedAt: time.Now().UTC(),
	}
	if err := s.store.CreateAudit(ctx, record); err != nil {
		s.logger.ErrorContext(ctx, "failed to write audit record", "error", err)
	}
}

// recordAdminLoginEvent records an administrator login attempt as a security event.
func (s *Server) recordAdminLoginEvent(r *http.Request, email string, success bool) {
	eventType := "ADMIN_LOGIN_FAILED"
	status := "FAILED"
	severity := "WARNING"
	if success {
		eventType, status, severity = "ADMIN_LOGIN", "SUCCESS", "INFO"
	}
	event := store.SecurityEvent{
		ID: uuid.NewString(), EventType: eventType, Severity: severity, Status: status,
		IP: clientIP(r), UserAgent: r.UserAgent(),
		Metadata:  map[string]any{"email": email},
		CreatedAt: time.Now().UTC(),
	}
	if err := s.store.CreateSecurityEvent(r.Context(), event); err != nil {
		s.logger.ErrorContext(r.Context(), "failed to record admin login event", "error", err)
		return
	}
	s.hub.Publish(StreamEvent{Type: "security.event", At: event.CreatedAt, Data: event})
}
