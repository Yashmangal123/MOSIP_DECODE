// Package config loads the platform service configuration from the environment.
//
// Every setting has an environment variable and a documented default, so the service runs with a
// minimal local setup (`docker compose up`) and is fully configurable in production. Secrets (SMTP
// password, SMS provider credentials, JWT signing key, OTP pepper) are only ever read from the
// environment - never from the repository.
package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

// Config is the fully resolved configuration of the platform service.
type Config struct {
	// Port is the HTTP listen port.
	Port int
	// AllowLabDelivery permits a local test mailbox (Mailpit and friends) for the e-mail channel. Off by
	// default: a one-time code must reach the citizen's real inbox.
	AllowLabDelivery bool
	// Environment is one of development, test, production. It gates development-only behaviour such as
	// returning the OTP in the send-OTP response for automated end-to-end tests.
	Environment string
	// DatabaseURL is the PostgreSQL DSN.
	DatabaseURL string
	// Schema is the PostgreSQL schema that holds the platform tables.
	Schema string

	// APIKey is the shared secret that eSignet (and other trusted services) present on the internal
	// endpoints. Internal endpoints are unavailable when it is empty.
	APIKey string

	// OTP settings.
	OTP OTPConfig
	// Email delivery settings.
	Email EmailConfig
	// SMS delivery settings.
	SMS SMSConfig

	// eSignet settings used for token introspection and session management.
	ESignet ESignetConfig

	// Admin settings for the administrator console.
	Admin AdminConfig
}

// OTPConfig holds the one-time-password policy.
type OTPConfig struct {
	// Length is the number of digits of generated OTPs. Six by default.
	Length int
	// Validity is how long a challenge stays usable.
	Validity time.Duration
	// MaxAttempts is how many wrong verifications lock a challenge.
	MaxAttempts int
	// ResendCooldown is the minimum interval between two sends for the same user/channel.
	ResendCooldown time.Duration
	// MaxSendsPerWindow caps how many OTPs a user may request within RateWindow.
	MaxSendsPerWindow int
	// RateWindow is the sliding window used for MaxSendsPerWindow and for per-IP throttling.
	RateWindow time.Duration
	// MaxSendsPerIP caps how many OTPs a single source address may request within RateWindow.
	MaxSendsPerIP int
	// Pepper is the server-side secret mixed into the OTP hash. Required: an empty pepper disables
	// the service's ability to hash OTPs safely, so startup fails instead.
	Pepper string
	// ExposeInResponseInDev, when true and Environment is development, returns the generated OTP in the
	// send response. It exists so automated end-to-end tests can complete without reading a mailbox, and
	// it refuses to activate outside development.
	ExposeInResponseInDev bool
}

// EmailConfig holds SMTP delivery settings.
type EmailConfig struct {
	// Mode is "smtp" (real delivery) or "disabled".
	Mode string
	// Host and Port of the SMTP server (Mailpit in local development, a real provider in production).
	Host string
	Port int
	// Username/Password for SMTP AUTH. Both may be empty for an unauthenticated local server.
	Username string
	Password string
	// From is the envelope/header sender.
	From string
	// FromName is the display name of the sender.
	FromName string
	// TLSMode is "starttls" (port 587), "tls" (implicit TLS, port 465) or "none" (local sink only;
	// authentication is refused in this mode).
	TLSMode string
	// HeloName overrides the EHLO name sent to the server. Some relays require a resolvable name.
	HeloName string
	// ReplyTo is an optional Reply-To header.
	ReplyTo string
	// Timeout bounds a single SMTP transaction.
	Timeout time.Duration
	// MaxAttempts and RetryBackoff control retries of transient failures.
	MaxAttempts  int
	RetryBackoff time.Duration
}

// SMSConfig holds the SMS provider settings.
type SMSConfig struct {
	// Provider is one of msg91, twilio, aws_sns, console. "console" logs the message and is a
	// development-only transport: it is never reported as real delivery.
	Provider string
	// SenderID is the alphanumeric sender / originator.
	SenderID string
	// Timeout bounds a single provider call.
	Timeout time.Duration

	// MaxAttempts and RetryBackoff control retries of transient failures (network, 429, 5xx).
	MaxAttempts  int
	RetryBackoff time.Duration

	// Generic HTTP gateway settings (PLATFORM_SMS_PROVIDER=generic_http). The URL, headers and body are
	// templates: see internal/delivery/generic_http.go for the placeholders.
	HTTPURL              string
	HTTPMethod           string
	HTTPHeaders          string
	HTTPBody             string
	HTTPContentType      string
	HTTPSuccessStatus    string
	HTTPSuccessSubstring string
	HTTPReferenceField   string

	// MSG91 settings.
	MSG91AuthKey  string
	MSG91Template string
	MSG91Route    string

	// Twilio settings.
	TwilioAccountSID string
	TwilioAuthToken  string
	TwilioFrom       string

	// AWS SNS settings.
	AWSAccessKeyID     string
	AWSSecretAccessKey string
	AWSRegion          string
}

// ESignetConfig points the platform at eSignet for introspection and session management.
type ESignetConfig struct {
	// BaseURL is the eSignet issuer/root URL (e.g. http://localhost:8080).
	BaseURL string
	// IntrospectionClientID/Secret are the client credentials the platform uses to introspect access
	// tokens presented by the mobile applications.
	IntrospectionClientID     string
	IntrospectionClientSecret string
	// SessionAPIKey is the bearer token used for eSignet's administrative session API.
	SessionAPIKey string
	// Timeout bounds calls to eSignet.
	Timeout time.Duration
}

// AdminConfig configures the administrator console security.
type AdminConfig struct {
	// JWTSecret signs administrator session tokens. Required (startup fails when empty).
	JWTSecret string
	// TokenTTL is the lifetime of an administrator token.
	TokenTTL time.Duration
	// BootstrapEmail/BootstrapPassword create the first administrator on startup when no administrator
	// exists. The password is only read from the environment and is stored as a bcrypt hash.
	BootstrapEmail    string
	BootstrapPassword string
	// AllowedOrigins is a comma-separated list of origins allowed to call the admin API.
	AllowedOrigins []string
}

// Load resolves the configuration from the environment.
func Load() (*Config, error) {
	cfg := &Config{
		Port:             envInt("PLATFORM_PORT", 8090),
		Environment:      env("PLATFORM_ENV", "development"),
		AllowLabDelivery: strings.EqualFold(env("PLATFORM_ALLOW_LAB_DELIVERY", "false"), "true"),
		DatabaseURL:      env("PLATFORM_DATABASE_URL", ""),
		Schema:           env("PLATFORM_DB_SCHEMA", "platform"),
		APIKey:           env("PLATFORM_API_KEY", ""),
		OTP: OTPConfig{
			Length:                envInt("PLATFORM_OTP_LENGTH", 6),
			Validity:              envDuration("PLATFORM_OTP_VALIDITY", 5*time.Minute),
			MaxAttempts:           envInt("PLATFORM_OTP_MAX_ATTEMPTS", 5),
			ResendCooldown:        envDuration("PLATFORM_OTP_RESEND_COOLDOWN", 30*time.Second),
			MaxSendsPerWindow:     envInt("PLATFORM_OTP_MAX_SENDS_PER_WINDOW", 5),
			RateWindow:            envDuration("PLATFORM_OTP_RATE_WINDOW", 15*time.Minute),
			MaxSendsPerIP:         envInt("PLATFORM_OTP_MAX_SENDS_PER_IP", 20),
			Pepper:                env("PLATFORM_OTP_PEPPER", ""),
			ExposeInResponseInDev: envBool("PLATFORM_OTP_EXPOSE_IN_DEV", false),
		},
		Email: EmailConfig{
			Mode:         env("PLATFORM_EMAIL_MODE", "smtp"),
			Host:         env("PLATFORM_SMTP_HOST", ""),
			Port:         envInt("PLATFORM_SMTP_PORT", 587),
			Username:     env("PLATFORM_SMTP_USERNAME", ""),
			Password:     env("PLATFORM_SMTP_PASSWORD", ""),
			From:         env("PLATFORM_SMTP_FROM", "no-reply@esignet.local"),
			FromName:     env("PLATFORM_SMTP_FROM_NAME", "MOSIP eSignet"),
			TLSMode:      env("PLATFORM_SMTP_TLS", "starttls"),
			HeloName:     env("PLATFORM_SMTP_HELO", ""),
			ReplyTo:      env("PLATFORM_SMTP_REPLY_TO", ""),
			Timeout:      envDuration("PLATFORM_SMTP_TIMEOUT", 15*time.Second),
			MaxAttempts:  envInt("PLATFORM_EMAIL_MAX_ATTEMPTS", 3),
			RetryBackoff: envDuration("PLATFORM_EMAIL_RETRY_BACKOFF", 400*time.Millisecond),
		},
		SMS: SMSConfig{
			Provider:             env("PLATFORM_SMS_PROVIDER", "console"),
			SenderID:             env("PLATFORM_SMS_SENDER_ID", "ESIGNT"),
			Timeout:              envDuration("PLATFORM_SMS_TIMEOUT", 15*time.Second),
			MaxAttempts:          envInt("PLATFORM_SMS_MAX_ATTEMPTS", 3),
			RetryBackoff:         envDuration("PLATFORM_SMS_RETRY_BACKOFF", 400*time.Millisecond),
			HTTPURL:              env("PLATFORM_SMS_HTTP_URL", ""),
			HTTPMethod:           env("PLATFORM_SMS_HTTP_METHOD", "POST"),
			HTTPHeaders:          env("PLATFORM_SMS_HTTP_HEADERS", ""),
			HTTPBody:             env("PLATFORM_SMS_HTTP_BODY", ""),
			HTTPContentType:      env("PLATFORM_SMS_HTTP_CONTENT_TYPE", "application/json"),
			HTTPSuccessStatus:    env("PLATFORM_SMS_HTTP_SUCCESS_STATUS", ""),
			HTTPSuccessSubstring: env("PLATFORM_SMS_HTTP_SUCCESS_SUBSTRING", ""),
			HTTPReferenceField:   env("PLATFORM_SMS_HTTP_REFERENCE_FIELD", ""),
			MSG91AuthKey:         env("PLATFORM_MSG91_AUTH_KEY", ""),
			MSG91Template:        env("PLATFORM_MSG91_TEMPLATE_ID", ""),
			MSG91Route:           env("PLATFORM_MSG91_ROUTE", "4"),
			TwilioAccountSID:     env("PLATFORM_TWILIO_ACCOUNT_SID", ""),
			TwilioAuthToken:      env("PLATFORM_TWILIO_AUTH_TOKEN", ""),
			TwilioFrom:           env("PLATFORM_TWILIO_FROM", ""),
			AWSAccessKeyID:       env("PLATFORM_AWS_ACCESS_KEY_ID", ""),
			AWSSecretAccessKey:   env("PLATFORM_AWS_SECRET_ACCESS_KEY", ""),
			AWSRegion:            env("PLATFORM_AWS_REGION", ""),
		},
		ESignet: ESignetConfig{
			BaseURL:                   trimSlash(env("PLATFORM_ESIGNET_URL", "http://localhost:8080")),
			IntrospectionClientID:     env("PLATFORM_ESIGNET_INTROSPECT_CLIENT_ID", ""),
			IntrospectionClientSecret: env("PLATFORM_ESIGNET_INTROSPECT_CLIENT_SECRET", ""),
			SessionAPIKey:             env("PLATFORM_ESIGNET_SESSION_API_KEY", ""),
			Timeout:                   envDuration("PLATFORM_ESIGNET_TIMEOUT", 10*time.Second),
		},
		Admin: AdminConfig{
			JWTSecret:         env("PLATFORM_ADMIN_JWT_SECRET", ""),
			TokenTTL:          envDuration("PLATFORM_ADMIN_TOKEN_TTL", 8*time.Hour),
			BootstrapEmail:    env("PLATFORM_ADMIN_EMAIL", ""),
			BootstrapPassword: env("PLATFORM_ADMIN_PASSWORD", ""),
			AllowedOrigins:    splitCSV(env("PLATFORM_ADMIN_ALLOWED_ORIGINS", "http://localhost:5173")),
		},
	}

	if err := cfg.validate(); err != nil {
		return nil, err
	}
	return cfg, nil
}

// validate rejects configurations the service cannot run safely with.
func (c *Config) validate() error {
	if c.DatabaseURL == "" {
		return fmt.Errorf("PLATFORM_DATABASE_URL is required")
	}
	if c.OTP.Pepper == "" {
		return fmt.Errorf("PLATFORM_OTP_PEPPER is required: OTPs are hashed with this server-side secret")
	}
	if c.OTP.Length != 6 && c.OTP.Length != 8 {
		return fmt.Errorf("PLATFORM_OTP_LENGTH must be 6 or 8")
	}
	if c.Admin.JWTSecret == "" {
		return fmt.Errorf("PLATFORM_ADMIN_JWT_SECRET is required")
	}
	if c.Admin.BootstrapPassword != "" && len(c.Admin.BootstrapPassword) < 8 {
		return fmt.Errorf("PLATFORM_ADMIN_PASSWORD must be at least 8 characters")
	}
	switch c.Email.Mode {
	case "smtp", "disabled":
	default:
		return fmt.Errorf("PLATFORM_EMAIL_MODE must be smtp or disabled, got %q", c.Email.Mode)
	}
	switch c.SMS.Provider {
	case "msg91", "twilio", "aws_sns", "generic_http", "console":
	default:
		return fmt.Errorf("PLATFORM_SMS_PROVIDER must be msg91, twilio, aws_sns, generic_http or console, got %q",
			c.SMS.Provider)
	}
	if c.SMS.Provider == "generic_http" && c.SMS.HTTPURL == "" {
		return fmt.Errorf("PLATFORM_SMS_HTTP_URL is required when PLATFORM_SMS_PROVIDER=generic_http")
	}
	switch strings.ToLower(c.Email.TLSMode) {
	case "none", "starttls", "tls":
	default:
		return fmt.Errorf("PLATFORM_SMTP_TLS must be none, starttls or tls, got %q", c.Email.TLSMode)
	}
	if c.Email.Username != "" && strings.EqualFold(c.Email.TLSMode, "none") {
		return fmt.Errorf("PLATFORM_SMTP_USERNAME requires PLATFORM_SMTP_TLS=starttls or tls: " +
			"credentials are never sent over a plaintext connection")
	}
	if strings.EqualFold(c.Email.Mode, "smtp") && strings.EqualFold(c.Email.TLSMode, "none") &&
		c.Environment == "production" {
		// Plaintext SMTP is a development convenience; in production it would put OTP mail on the wire.
		return fmt.Errorf("PLATFORM_SMTP_TLS=none is refused in production: use starttls (587) or tls (465)")
	}
	// A citizen's one-time code must reach their real mailbox. A local catcher (Mailpit, mailhog, the
	// bundled test SMTP server) or a loopback relay silently swallows it, so it is refused unless the
	// deployment says, explicitly, that this is a lab.
	if strings.EqualFold(c.Email.Mode, "smtp") && strings.TrimSpace(c.Email.Host) == "" {
		return fmt.Errorf("PLATFORM_SMTP_HOST is required: set it to your real SMTP relay " +
			"(for example smtp.gmail.com, email-smtp.<region>.amazonaws.com or smtp.sendgrid.net)")
	}
	if strings.EqualFold(c.Email.Mode, "smtp") && !c.AllowLabDelivery {
		if host := strings.ToLower(strings.TrimSpace(c.Email.Host)); isLabRelay(host) {
			return fmt.Errorf("PLATFORM_SMTP_HOST=%q is a local test mailbox: codes would never reach the "+
				"citizen. Point it at a real SMTP relay, or set PLATFORM_ALLOW_LAB_DELIVERY=true for a lab", c.Email.Host)
		}
	}
	return nil
}

// isLabRelay reports whether host is a local test mailbox rather than a real SMTP relay.
func isLabRelay(host string) bool {
	switch host {
	case "", "localhost", "127.0.0.1", "::1", "0.0.0.0", "mailpit", "mailhog", "smtp4dev", "mailcatcher", "mail":
		return true
	}
	return strings.HasSuffix(host, ".local") || strings.HasSuffix(host, ".localhost")
}

// IsDevelopment reports whether development-only helpers are permitted.
func (c *Config) IsDevelopment() bool { return strings.EqualFold(c.Environment, "development") }

// env returns the environment value or a default.
func env(key, fallback string) string {
	if value, ok := os.LookupEnv(key); ok && value != "" {
		return value
	}
	return fallback
}

// envInt returns an integer environment value or a default.
func envInt(key string, fallback int) int {
	if value, ok := os.LookupEnv(key); ok && value != "" {
		if parsed, err := strconv.Atoi(value); err == nil {
			return parsed
		}
	}
	return fallback
}

// envBool returns a boolean environment value or a default.
func envBool(key string, fallback bool) bool {
	if value, ok := os.LookupEnv(key); ok && value != "" {
		if parsed, err := strconv.ParseBool(value); err == nil {
			return parsed
		}
	}
	return fallback
}

// envDuration returns a duration environment value (Go syntax, e.g. 30s, 5m) or a default.
func envDuration(key string, fallback time.Duration) time.Duration {
	if value, ok := os.LookupEnv(key); ok && value != "" {
		if parsed, err := time.ParseDuration(value); err == nil {
			return parsed
		}
	}
	return fallback
}

// splitCSV splits a comma-separated list, trimming whitespace and dropping empties.
func splitCSV(value string) []string {
	if value == "" {
		return nil
	}
	parts := strings.Split(value, ",")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		if trimmed := strings.TrimSpace(part); trimmed != "" {
			out = append(out, trimmed)
		}
	}
	return out
}

// trimSlash removes a trailing slash from a base URL.
func trimSlash(value string) string {
	return strings.TrimSuffix(value, "/")
}
