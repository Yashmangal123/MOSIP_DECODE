package config_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/mosip/esignet-platform/internal/config"
)

// setEnv sets an environment variable for the duration of a test.
func setEnv(t *testing.T, key, value string) {
	t.Helper()
	t.Setenv(key, value)
}

// minimalEnv sets the variables a valid configuration requires.
func minimalEnv(t *testing.T) {
	t.Helper()
	setEnv(t, "PLATFORM_DATABASE_URL", "postgres://platform:platform@localhost:5432/esignet_platform")
	setEnv(t, "PLATFORM_OTP_PEPPER", "pepper")
	setEnv(t, "PLATFORM_ADMIN_JWT_SECRET", "secret")
	setEnv(t, "PLATFORM_EMAIL_MODE", "")
	// A real relay: the local test mailbox is refused unless PLATFORM_ALLOW_LAB_DELIVERY is set.
	setEnv(t, "PLATFORM_SMTP_HOST", "smtp.example.com")
	setEnv(t, "PLATFORM_SMS_PROVIDER", "")
}

func TestLoadDefaults(t *testing.T) {
	minimalEnv(t)

	cfg, err := config.Load()
	require.NoError(t, err)

	assert.Equal(t, 8090, cfg.Port)
	assert.Equal(t, "development", cfg.Environment)
	assert.Equal(t, "platform", cfg.Schema)
	assert.Equal(t, 6, cfg.OTP.Length)
	assert.Equal(t, 5*time.Minute, cfg.OTP.Validity)
	assert.Equal(t, 5, cfg.OTP.MaxAttempts)
	assert.Equal(t, 30*time.Second, cfg.OTP.ResendCooldown)
	assert.Equal(t, "smtp", cfg.Email.Mode)
	assert.Equal(t, 587, cfg.Email.Port, "the default submission port is a real relay's, not a catcher's")
	assert.Equal(t, "starttls", cfg.Email.TLSMode)
	assert.Equal(t, "console", cfg.SMS.Provider, "the default SMS transport performs no real delivery")
	assert.Equal(t, "http://localhost:8080", cfg.ESignet.BaseURL)
	assert.Equal(t, 8*time.Hour, cfg.Admin.TokenTTL)
	assert.False(t, cfg.OTP.ExposeInResponseInDev, "the development OTP echo is off by default")
	assert.True(t, cfg.IsDevelopment())
}

func TestLoadOverrides(t *testing.T) {
	minimalEnv(t)
	setEnv(t, "PLATFORM_PORT", "9443")
	setEnv(t, "PLATFORM_ENV", "production")
	setEnv(t, "PLATFORM_OTP_LENGTH", "8")
	setEnv(t, "PLATFORM_OTP_VALIDITY", "90s")
	setEnv(t, "PLATFORM_OTP_MAX_ATTEMPTS", "3")
	setEnv(t, "PLATFORM_SMS_PROVIDER", "twilio")
	setEnv(t, "PLATFORM_SMTP_TLS", "starttls")
	setEnv(t, "PLATFORM_ADMIN_ALLOWED_ORIGINS", "https://a.example.com, https://b.example.com")
	setEnv(t, "PLATFORM_ESIGNET_URL", "https://esignet.example.com/")

	cfg, err := config.Load()
	require.NoError(t, err)

	assert.Equal(t, 9443, cfg.Port)
	assert.Equal(t, "production", cfg.Environment)
	assert.Equal(t, 8, cfg.OTP.Length)
	assert.Equal(t, 90*time.Second, cfg.OTP.Validity)
	assert.Equal(t, 3, cfg.OTP.MaxAttempts)
	assert.Equal(t, "twilio", cfg.SMS.Provider)
	assert.Equal(t, []string{"https://a.example.com", "https://b.example.com"}, cfg.Admin.AllowedOrigins)
	assert.Equal(t, "https://esignet.example.com", cfg.ESignet.BaseURL, "a trailing slash is trimmed")
	assert.False(t, cfg.IsDevelopment())
}

func TestLoadValidation(t *testing.T) {
	tests := []struct {
		name    string
		mutate  func(t *testing.T)
		message string
	}{
		{
			name:    "database url is required",
			mutate:  func(t *testing.T) { setEnv(t, "PLATFORM_DATABASE_URL", "") },
			message: "PLATFORM_DATABASE_URL",
		},
		{
			name:    "otp pepper is required",
			mutate:  func(t *testing.T) { setEnv(t, "PLATFORM_OTP_PEPPER", "") },
			message: "PLATFORM_OTP_PEPPER",
		},
		{
			name:    "admin jwt secret is required",
			mutate:  func(t *testing.T) { setEnv(t, "PLATFORM_ADMIN_JWT_SECRET", "") },
			message: "PLATFORM_ADMIN_JWT_SECRET",
		},
		{
			name:    "otp length must be six or eight",
			mutate:  func(t *testing.T) { setEnv(t, "PLATFORM_OTP_LENGTH", "4") },
			message: "PLATFORM_OTP_LENGTH",
		},
		{
			name:    "email mode is validated",
			mutate:  func(t *testing.T) { setEnv(t, "PLATFORM_EMAIL_MODE", "carrier-pigeon") },
			message: "PLATFORM_EMAIL_MODE",
		},
		{
			name:    "sms provider is validated",
			mutate:  func(t *testing.T) { setEnv(t, "PLATFORM_SMS_PROVIDER", "carrier-pigeon") },
			message: "PLATFORM_SMS_PROVIDER",
		},
		{
			name:    "smtp tls mode is validated",
			mutate:  func(t *testing.T) { setEnv(t, "PLATFORM_SMTP_TLS", "sometimes") },
			message: "PLATFORM_SMTP_TLS",
		},
		{
			name: "credentials are refused without tls",
			mutate: func(t *testing.T) {
				setEnv(t, "PLATFORM_SMTP_TLS", "none")
				setEnv(t, "PLATFORM_SMTP_USERNAME", "user")
				setEnv(t, "PLATFORM_SMTP_PASSWORD", "secret")
			},
			message: "PLATFORM_SMTP_USERNAME",
		},
		{
			name: "generic http provider requires a url",
			mutate: func(t *testing.T) {
				setEnv(t, "PLATFORM_SMS_PROVIDER", "generic_http")
				setEnv(t, "PLATFORM_SMS_HTTP_URL", "")
			},
			message: "PLATFORM_SMS_HTTP_URL",
		},
		{
			name:    "bootstrap password length is enforced",
			mutate:  func(t *testing.T) { setEnv(t, "PLATFORM_ADMIN_PASSWORD", "short") },
			message: "PLATFORM_ADMIN_PASSWORD",
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			minimalEnv(t)
			test.mutate(t)
			_, err := config.Load()
			require.Error(t, err)
			assert.Contains(t, err.Error(), test.message)
		})
	}
}

func TestLocalMailboxIsRefusedUnlessLab(t *testing.T) {
	base := map[string]string{
		"PLATFORM_DATABASE_URL":       "postgres://x/y",
		"PLATFORM_EMAIL_MODE":         "smtp",
		"PLATFORM_SMTP_HOST":          "mailpit",
		"PLATFORM_SMTP_PORT":          "1025",
		"PLATFORM_SMTP_TLS":           "none",
		"PLATFORM_SMTP_FROM":          "no-reply@example.com",
		"PLATFORM_OTP_PEPPER":         "pepper",
		"PLATFORM_ADMIN_JWT_SECRET":   "secret",
		"PLATFORM_API_KEY":            "key",
		"PLATFORM_ALLOW_LAB_DELIVERY": "false",
	}
	apply := func(over map[string]string) {
		for k, v := range base {
			t.Setenv(k, v)
		}
		for k, v := range over {
			t.Setenv(k, v)
		}
	}

	// A local catcher is a hard error, even in development: the code would never reach the citizen.
	apply(map[string]string{"PLATFORM_ENV": "development"})
	if _, err := config.Load(); err == nil {
		t.Fatalf("a local test mailbox must be refused")
	}
	// Opting into a lab is the only way to use one.
	apply(map[string]string{"PLATFORM_ENV": "development", "PLATFORM_ALLOW_LAB_DELIVERY": "true"})
	if _, err := config.Load(); err != nil {
		t.Fatalf("lab delivery must be allowed when asked for explicitly: %v", err)
	}
	// A real relay is accepted.
	for _, host := range []string{"smtp.gmail.com", "email-smtp.ap-south-1.amazonaws.com", "smtp.sendgrid.net"} {
		apply(map[string]string{"PLATFORM_ENV": "production", "PLATFORM_SMTP_HOST": host,
			"PLATFORM_SMTP_TLS": "starttls", "PLATFORM_SMTP_USERNAME": "user", "PLATFORM_SMTP_PASSWORD": "pass"})
		if _, err := config.Load(); err != nil {
			t.Fatalf("host %q must be accepted: %v", host, err)
		}
	}
	// An empty host is refused rather than defaulting to something local.
	apply(map[string]string{"PLATFORM_ENV": "production", "PLATFORM_SMTP_HOST": ""})
	if _, err := config.Load(); err == nil {
		t.Fatalf("an empty SMTP host must be refused")
	}
}
