package delivery

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"time"

	"github.com/mosip/esignet-platform/internal/config"
)

// snsPublish publishes an SMS message through the AWS SNS Publish API using Signature Version 4.
//
// The request is signed in-process with the operator-supplied access key so the service has no AWS SDK
// dependency; the algorithm is the standard SigV4 header-signing procedure for the sns service.
func snsPublish(ctx context.Context, client *http.Client, cfg config.SMSConfig, phone, message string) (
	string, error) {
	const (
		service    = "sns"
		apiVersion = "2010-03-31"
	)
	endpoint := fmt.Sprintf("https://sns.%s.amazonaws.com/", cfg.AWSRegion)
	now := time.Now().UTC()
	amzDate := now.Format("20060102T150405Z")
	dateStamp := now.Format("20060102")

	payload := url.Values{}
	payload.Set("Action", "Publish")
	payload.Set("Version", apiVersion)
	payload.Set("PhoneNumber", phone)
	payload.Set("Message", message)
	if cfg.SenderID != "" {
		// An SMS sender id is passed as a message attribute.
		payload.Set("MessageAttributes.entry.1.Name", "AWS.SNS.SMS.SenderID")
		payload.Set("MessageAttributes.entry.1.Value.DataType", "String")
		payload.Set("MessageAttributes.entry.1.Value.StringValue", cfg.SenderID)
	}
	body := payload.Encode()

	payloadHash := sha256.Sum256([]byte(body))
	canonicalHeaders := "content-type:application/x-www-form-urlencoded\n" +
		"host:" + strings.TrimPrefix(endpoint, "https://") + "\n" +
		"x-amz-date:" + amzDate + "\n"
	signedHeaders := "content-type;host;x-amz-date"

	canonicalRequest := strings.Join([]string{
		http.MethodPost,
		"/",
		"",
		canonicalHeaders,
		signedHeaders,
		hex.EncodeToString(payloadHash[:]),
	}, "\n")

	credentialScope := strings.Join([]string{dateStamp, cfg.AWSRegion, service, "aws4_request"}, "/")
	canonicalRequestHash := sha256.Sum256([]byte(canonicalRequest))
	stringToSign := strings.Join([]string{
		"AWS4-HMAC-SHA256",
		amzDate,
		credentialScope,
		hex.EncodeToString(canonicalRequestHash[:]),
	}, "\n")

	signingKey := hmacSHA256([]byte("AWS4"+cfg.AWSSecretAccessKey), dateStamp)
	signingKey = hmacSHA256(signingKey, cfg.AWSRegion)
	signingKey = hmacSHA256(signingKey, service)
	signingKey = hmacSHA256(signingKey, "aws4_request")
	signature := hex.EncodeToString(hmacSHA256(signingKey, stringToSign))

	authorization := fmt.Sprintf("AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s",
		cfg.AWSAccessKeyID, credentialScope, signedHeaders, signature)

	request, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, strings.NewReader(body))
	if err != nil {
		return "", fmt.Errorf("build SNS request: %w", err)
	}
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	request.Header.Set("X-Amz-Date", amzDate)
	request.Header.Set("Authorization", authorization)

	response, err := client.Do(request)
	if err != nil {
		return "", fmt.Errorf("SNS request: %w", err)
	}
	defer func() { _ = response.Body.Close() }()
	responseBody, _ := io.ReadAll(io.LimitReader(response.Body, 16384))

	if response.StatusCode >= 300 {
		return "", fmt.Errorf("SNS returned status %d", response.StatusCode)
	}

	// The Publish response is XML; the MessageId element is the useful reference.
	text := string(responseBody)
	const open, close = "<MessageId>", "</MessageId>"
	if start := strings.Index(text, open); start >= 0 {
		start += len(open)
		if end := strings.Index(text[start:], close); end >= 0 {
			return text[start : start+end], nil
		}
	}
	return "sns", nil
}

// hmacSHA256 returns HMAC-SHA256(key, data).
func hmacSHA256(key []byte, data string) []byte {
	mac := hmac.New(sha256.New, key)
	mac.Write([]byte(data))
	return mac.Sum(nil)
}

// sortedKeys returns the sorted keys of a map (used by canonical request builders in tests).
func sortedKeys(values map[string]string) []string {
	keys := make([]string, 0, len(values))
	for key := range values {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	return keys
}

// jsonBody is a tiny helper for provider adapters that post JSON.
func jsonBody(payload any) (io.Reader, error) {
	encoded, err := json.Marshal(payload)
	if err != nil {
		return nil, err
	}
	return strings.NewReader(string(encoded)), nil
}
