// Package delivery implements the outbound email and SMS transports.
//
// Design rules, in order of importance:
//
//  1. A transport never claims a delivery it did not make. Result.Delivered is true only when a real
//     provider accepted the message; the development console transport always reports false.
//  2. Every failure is classified. Transient conditions (network errors, HTTP 429/5xx, SMTP 4xx) are
//     retried with exponential backoff; permanent rejections (bad credentials, invalid destination,
//     HTTP 4xx, SMTP 5xx) are not retried, because retrying them only burns provider quota.
//  3. Nothing about a specific vendor is hardcoded beyond its public protocol. Any other gateway is
//     supported without writing code through the generic HTTP transport (see generic_http.go).
//  4. The OTP is the only secret in a message: it is never logged, never included in an error string and
//     never returned in a provider error code.
package delivery

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"time"

	"github.com/mosip/esignet-platform/internal/config"
)

// Message is one outbound OTP-bearing message.
type Message struct {
	// To is the email address or E.164 phone number.
	To string
	// Channel is "email" or "sms".
	Channel string
	// OTP is the one-time password. It must never be logged or put in an error.
	OTP string
	// Recipient is the display name of the recipient, when known.
	Recipient string
	// Purpose describes why the message was sent ("sign-in").
	Purpose string
	// TTLMinutes is the validity of the OTP, rendered in the message.
	TTLMinutes int
}

// Result reports how a message was handled.
type Result struct {
	// Provider is the transport that handled the message: "smtp", "smtp_tls", "ses", "msg91", "twilio",
	// "aws_sns", "generic_http", "console", "disabled".
	Provider string
	// Reference is the provider message id, when the provider returns one.
	Reference string
	// Delivered reports whether a real provider accepted the message for delivery. False for the
	// development console transport, which delivers nothing.
	Delivered bool
	// ErrorCode is a stable, loggable code describing a failure. It never contains message content.
	ErrorCode string
	// Retryable reports whether the failure was transient and the message may be sent again.
	Retryable bool
	// Attempts is how many times the transport was tried (set by the retrying wrapper).
	Attempts int
	// Latency is the wall-clock time of the final attempt.
	Latency time.Duration
}

// Sender sends messages of one channel.
type Sender interface {
	// Send delivers a message.
	Send(ctx context.Context, message Message) (Result, error)
	// ProviderName identifies the transport for status reporting.
	ProviderName() string
	// IsReal reports whether this transport performs real delivery.
	IsReal() bool
}

// NewEmailSender builds the email transport from configuration.
//
// "smtp" selects the SMTP client (which supports implicit TLS on 465, STARTTLS on 587 and plaintext on a
// trusted private network such as Mailpit on 1025).
func NewEmailSender(cfg config.EmailConfig, logger *slog.Logger) Sender {
	if cfg.Mode != "smtp" {
		return &disabledSender{provider: "disabled", logger: logger}
	}
	var sender Sender = &smtpSender{cfg: cfg, logger: logger}
	return withRetry(sender, cfg.MaxAttempts, cfg.RetryBackoff, logger)
}

// NewSMSSender builds the SMS transport from configuration.
//
// Every adapter is selected by configuration only; adding a provider means adding an adapter, and any
// provider that speaks plain HTTP can be used today through "generic_http".
func NewSMSSender(cfg config.SMSConfig, logger *slog.Logger) Sender {
	var sender Sender
	switch cfg.Provider {
	case "msg91":
		sender = &msg91Sender{cfg: cfg, client: newHTTPClient(cfg.Timeout)}
	case "twilio":
		sender = &twilioSender{cfg: cfg, client: newHTTPClient(cfg.Timeout)}
	case "aws_sns":
		sender = &snsSender{cfg: cfg, client: newHTTPClient(cfg.Timeout)}
	case "generic_http":
		sender = &genericHTTPSender{cfg: cfg, client: newHTTPClient(cfg.Timeout)}
	default:
		return &consoleSender{logger: logger}
	}
	return withRetry(sender, cfg.MaxAttempts, cfg.RetryBackoff, logger)
}

// disabledSender is used when a channel is switched off in configuration.
type disabledSender struct {
	provider string
	logger   *slog.Logger
}

func (d *disabledSender) Send(_ context.Context, _ Message) (Result, error) {
	return Result{Provider: d.provider, ErrorCode: "channel_disabled"},
		errors.New("channel is disabled by configuration")
}
func (d *disabledSender) ProviderName() string { return d.provider }
func (d *disabledSender) IsReal() bool         { return false }

// consoleSender is a development-only transport: it writes the message to the service log so a developer
// can complete the flow locally, and reports that nothing was delivered.
type consoleSender struct {
	logger *slog.Logger
}

func (c *consoleSender) Send(_ context.Context, message Message) (Result, error) {
	c.logger.Warn("message delivered through the development console transport (not a real delivery)",
		"to", message.To, "channel", message.Channel, "otp", message.OTP)
	return Result{Provider: "console", Reference: "console", Delivered: false}, nil
}
func (c *consoleSender) ProviderName() string { return "console" }
func (c *consoleSender) IsReal() bool         { return false }

// newHTTPClient builds an HTTP client with the provider timeout. Redirects are not followed: an OTP
// request must go to the configured endpoint, not wherever it redirects.
func newHTTPClient(timeout time.Duration) *http.Client {
	if timeout <= 0 {
		timeout = 15 * time.Second
	}
	return &http.Client{
		Timeout: timeout,
		CheckRedirect: func(*http.Request, []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
}
