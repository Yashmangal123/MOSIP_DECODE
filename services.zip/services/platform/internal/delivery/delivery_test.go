package delivery_test

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"log/slog"
	"net"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/mosip/esignet-platform/internal/config"
	"github.com/mosip/esignet-platform/internal/delivery"
)

// fakeSMTP is a minimal in-process SMTP server. It accepts a single transaction and records the message
// body, which proves the SMTP adapter performs a real protocol exchange rather than just formatting a
// string.
type fakeSMTP struct {
	listener  net.Listener
	mu        sync.Mutex
	messages  []string
	envelopes []string
	failData  bool
}

// startFakeSMTP starts the server on a random loopback port.
func startFakeSMTP(t *testing.T) *fakeSMTP {
	t.Helper()
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	server := &fakeSMTP{listener: listener}
	go server.serve()
	t.Cleanup(func() { _ = listener.Close() })
	return server
}

// port returns the listening port.
func (f *fakeSMTP) port() int { return f.listener.Addr().(*net.TCPAddr).Port }

// messagesSnapshot returns the recorded message bodies.
func (f *fakeSMTP) messagesSnapshot() []string {
	f.mu.Lock()
	defer f.mu.Unlock()
	return append([]string(nil), f.messages...)
}

// envelopesSnapshot returns the recorded MAIL FROM / RCPT TO pairs.
func (f *fakeSMTP) envelopesSnapshot() []string {
	f.mu.Lock()
	defer f.mu.Unlock()
	return append([]string(nil), f.envelopes...)
}

// serve accepts connections until the listener closes.
func (f *fakeSMTP) serve() {
	for {
		connection, err := f.listener.Accept()
		if err != nil {
			return
		}
		go f.handle(connection)
	}
}

// handle runs the SMTP dialogue for one connection.
func (f *fakeSMTP) handle(connection net.Conn) {
	defer func() { _ = connection.Close() }()
	reader := bufio.NewReader(connection)
	writer := bufio.NewWriter(connection)
	reply := func(line string) {
		_, _ = writer.WriteString(line + "\r\n")
		_ = writer.Flush()
	}

	reply("220 fake-smtp ESMTP")
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			return
		}
		command := strings.ToUpper(strings.TrimSpace(line))
		switch {
		case strings.HasPrefix(command, "EHLO"), strings.HasPrefix(command, "HELO"):
			_, _ = writer.WriteString("250-fake-smtp\r\n250-8BITMIME\r\n250 OK\r\n")
			_ = writer.Flush()
		case strings.HasPrefix(command, "MAIL FROM"):
			f.mu.Lock()
			f.envelopes = append(f.envelopes, command)
			f.mu.Unlock()
			reply("250 OK")
		case strings.HasPrefix(command, "RCPT TO"):
			f.mu.Lock()
			f.envelopes = append(f.envelopes, command)
			f.mu.Unlock()
			reply("250 OK")
		case command == "DATA":
			if f.failData {
				reply("554 5.6.0 message rejected")
				continue
			}
			reply("354 End data with <CR><LF>.<CR><LF>")
			var body strings.Builder
			for {
				dataLine, err := reader.ReadString('\n')
				if err != nil {
					return
				}
				if strings.TrimRight(dataLine, "\r\n") == "." {
					break
				}
				body.WriteString(dataLine)
			}
			f.mu.Lock()
			f.messages = append(f.messages, body.String())
			f.mu.Unlock()
			reply("250 OK queued")
		case command == "QUIT":
			reply("221 Bye")
			return
		case command == "RSET", command == "NOOP":
			reply("250 OK")
		default:
			reply("250 OK")
		}
	}
}

// testLogger returns a silent logger.
func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func TestSMTPSenderDelivers(t *testing.T) {
	server := startFakeSMTP(t)
	cfg := config.EmailConfig{
		Mode: "smtp", Host: "127.0.0.1", Port: server.port(),
		From: "no-reply@esignet.local", FromName: "MOSIP eSignet",
		TLSMode: "none", Timeout: 5 * time.Second,
	}
	sender := delivery.NewEmailSender(cfg, testLogger())
	assert.True(t, sender.IsReal())
	assert.Equal(t, "smtp", sender.ProviderName())

	result, err := sender.Send(context.Background(), delivery.Message{
		To: "asha.verma@example.com", Channel: "email", OTP: "482913",
		Recipient: "Asha", Purpose: "sign-in", TTLMinutes: 5,
	})
	require.NoError(t, err)
	assert.True(t, result.Delivered, "SMTP transport must report real delivery")
	assert.Equal(t, "smtp", result.Provider)

	messages := server.messagesSnapshot()
	require.Len(t, messages, 1)
	assert.Contains(t, messages[0], "482913")
	assert.Contains(t, messages[0], "To: asha.verma@example.com")
	assert.Contains(t, messages[0], "Subject: Your MOSIP eSignet verification code")
	assert.Contains(t, messages[0], "Hello Asha")
	assert.Contains(t, messages[0], "Content-Type: text/html")

	envelopes := server.envelopesSnapshot()
	require.GreaterOrEqual(t, len(envelopes), 2)
	// The fake server uppercases the command verb; the addresses are compared case-insensitively.
	assert.Contains(t, strings.ToLower(envelopes[0]), "mail from:<no-reply@esignet.local>")
	assert.Contains(t, strings.ToLower(envelopes[1]), "rcpt to:<asha.verma@example.com>")
}

func TestSMTPSenderRejectedMessage(t *testing.T) {
	server := startFakeSMTP(t)
	server.failData = true
	cfg := config.EmailConfig{
		Mode: "smtp", Host: "127.0.0.1", Port: server.port(),
		From: "no-reply@esignet.local", TLSMode: "none", Timeout: 5 * time.Second,
	}
	sender := delivery.NewEmailSender(cfg, testLogger())

	result, err := sender.Send(context.Background(), delivery.Message{
		To: "asha.verma@example.com", OTP: "482913", TTLMinutes: 5,
	})
	require.Error(t, err)
	assert.False(t, result.Delivered, "a rejected message must not be reported as delivered")
	// 554 is a permanent rejection: it must be classified as such and not retried.
	assert.Equal(t, "smtp_permanent_failure", result.ErrorCode)
	assert.False(t, result.Retryable, "a 5xx rejection must not be retried")
	assert.Equal(t, 1, result.Attempts, "a permanent rejection is attempted exactly once")
}

func TestSMTPSenderUnreachableServer(t *testing.T) {
	// Reserve a port and close it so the connection is refused.
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	port := listener.Addr().(*net.TCPAddr).Port
	_ = listener.Close()

	sender := delivery.NewEmailSender(config.EmailConfig{
		Mode: "smtp", Host: "127.0.0.1", Port: port, From: "no-reply@esignet.local",
		TLSMode: "none", Timeout: time.Second, MaxAttempts: 3, RetryBackoff: time.Millisecond,
	}, testLogger())

	result, err := sender.Send(context.Background(), delivery.Message{To: "a@example.com", OTP: "1"})
	require.Error(t, err)
	assert.False(t, result.Delivered)
	assert.Equal(t, "dial_failed", result.ErrorCode)
	assert.True(t, result.Retryable, "a refused connection is transient and may be retried")
	assert.Equal(t, 3, result.Attempts, "transient failures are retried up to the configured attempts")
}

func TestDisabledEmailSender(t *testing.T) {
	sender := delivery.NewEmailSender(config.EmailConfig{Mode: "disabled"}, testLogger())
	assert.False(t, sender.IsReal())
	_, err := sender.Send(context.Background(), delivery.Message{To: "a@example.com", OTP: "1"})
	require.Error(t, err)
}

func TestConsoleSMSSenderDoesNotClaimDelivery(t *testing.T) {
	sender := delivery.NewSMSSender(config.SMSConfig{Provider: "console"}, testLogger())
	assert.Equal(t, "console", sender.ProviderName())
	assert.False(t, sender.IsReal(), "the console transport is not a real delivery path")

	result, err := sender.Send(context.Background(), delivery.Message{
		To: "+919000000001", Channel: "sms", OTP: "482913", TTLMinutes: 5,
	})
	require.NoError(t, err)
	assert.False(t, result.Delivered)
}

func TestSMSProvidersRequireCredentials(t *testing.T) {
	cases := []struct {
		name     string
		cfg      config.SMSConfig
		errorMsg string
	}{
		{name: "msg91", cfg: config.SMSConfig{Provider: "msg91"}, errorMsg: "MSG91"},
		{name: "twilio", cfg: config.SMSConfig{Provider: "twilio"}, errorMsg: "Twilio"},
		{name: "aws sns", cfg: config.SMSConfig{Provider: "aws_sns"}, errorMsg: "AWS"},
	}
	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			sender := delivery.NewSMSSender(test.cfg, testLogger())
			assert.True(t, sender.IsReal())
			result, err := sender.Send(context.Background(), delivery.Message{To: "+919000000001", OTP: "1"})
			require.Error(t, err)
			assert.False(t, result.Delivered)
			assert.Contains(t, result.ErrorCode, "missing")
			assert.Contains(t, err.Error(), test.errorMsg)
		})
	}
}

func TestSMSProviderRejectsInvalidPhone(t *testing.T) {
	sender := delivery.NewSMSSender(config.SMSConfig{
		Provider: "twilio", TwilioAccountSID: "AC", TwilioAuthToken: "token", TwilioFrom: "+919000000000",
	}, testLogger())
	result, err := sender.Send(context.Background(), delivery.Message{To: "not-a-number", OTP: "1"})
	require.Error(t, err)
	assert.Equal(t, "invalid_phone", result.ErrorCode)
	assert.False(t, result.Delivered)
}

func TestMessageRenderingNeverLeaksIntoProviderName(t *testing.T) {
	// Guard rail: the rendered SMS body carries the OTP exactly once and the provider name never does.
	sender := delivery.NewSMSSender(config.SMSConfig{Provider: "console"}, testLogger())
	assert.False(t, strings.Contains(sender.ProviderName(), "4"))
	assert.Equal(t, fmt.Sprintf("%T", sender), "*delivery.consoleSender")
}
