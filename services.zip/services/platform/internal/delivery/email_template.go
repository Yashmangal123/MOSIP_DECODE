package delivery

import (
	"fmt"
	"mime"
	"strings"
	"time"

	"github.com/mosip/esignet-platform/internal/config"
)

// SubjectOTP is the subject line of an OTP email. It is a constant so mail filters and tests can rely on
// it, and it never contains the OTP (a subject line is logged by relays).
const SubjectOTP = "Your MOSIP eSignet verification code"

// buildEmail renders the RFC 5322 message of an OTP email.
func buildEmail(cfg config.EmailConfig, message Message) []byte {
	headers := []string{
		"From: " + formatFrom(cfg.FromName, cfg.From),
		"To: " + message.To,
		"Subject: " + mime.QEncoding.Encode("utf-8", SubjectOTP),
		"Date: " + time.Now().Format(time.RFC1123Z),
		"MIME-Version: 1.0",
		"Content-Type: text/html; charset=UTF-8",
		"Content-Transfer-Encoding: 8bit",
		// Transactional mail: ask relays not to auto-reply and mark it as automated.
		"Auto-Submitted: auto-generated",
		"X-Auto-Response-Suppress: All",
	}
	if cfg.ReplyTo != "" {
		headers = append(headers, "Reply-To: "+cfg.ReplyTo)
	}
	return []byte(strings.Join(headers, "\r\n") + "\r\n\r\n" + renderOTPEmailBody(message))
}

// renderOTPEmailBody builds the HTML body. The OTP appears in the body only, in a plain element, so it
// survives text-only clients and any provider that renders HTML.
func renderOTPEmailBody(message Message) string {
	greeting := "Hello"
	if strings.TrimSpace(message.Recipient) != "" {
		greeting = "Hello " + message.Recipient
	}
	purpose := "sign in"
	if message.Purpose != "" {
		purpose = message.Purpose
	}
	return fmt.Sprintf(`<!DOCTYPE html>
<html><body style="margin:0;padding:24px;background:#f5f7fb;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#101828">
  <table role="presentation" width="100%%" cellpadding="0" cellspacing="0" style="max-width:520px;margin:0 auto;background:#ffffff;border-radius:16px;padding:32px">
    <tr><td>
      <p style="margin:0 0 8px;font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#6941c6;font-weight:600">MOSIP eSignet</p>
      <h1 style="margin:0 0 16px;font-size:22px">Your verification code</h1>
      <p style="margin:0 0 24px;font-size:15px;line-height:22px;color:#475467">%s, use the code below to %s. It expires in %d minutes.</p>
      <div style="font-size:34px;font-weight:700;letter-spacing:10px;background:#f4f3ff;color:#3e1c96;padding:18px 0;text-align:center;border-radius:12px">%s</div>
      <p style="margin:24px 0 0;font-size:13px;line-height:20px;color:#667085">If you did not try to sign in, ignore this email and consider changing your password. Never share this code with anyone.</p>
    </td></tr>
  </table>
</body></html>`, greeting, purpose, message.TTLMinutes, message.OTP)
}

// formatFrom renders the RFC 5322 From header.
func formatFrom(name, address string) string {
	if name == "" {
		return address
	}
	return mime.QEncoding.Encode("utf-8", name) + " <" + address + ">"
}
