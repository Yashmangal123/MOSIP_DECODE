package delivery

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/mosip/esignet-platform/internal/config"
)

// genericHTTPSender delivers SMS through any HTTP gateway, configured entirely from the environment.
//
// This is the answer to "our provider is not in your list": every Indian SMS gateway (Kaleyra, Gupshup,
// Fast2SMS, Textlocal, ValueFirst, Karix, an internal aggregator, or a DLT-compliant middleware) exposes
// an HTTP endpoint with a destination, a message and a credential. Nothing about the vendor needs to be
// compiled in: the URL, method, headers and body are templates.
//
// Template placeholders, substituted in the URL, the headers and the body:
//
//	{{to}}       E.164 destination without the leading '+' (as most gateways expect)
//	{{to_plus}}  E.164 destination with the leading '+'
//	{{otp}}      the one-time password
//	{{message}}  the full rendered message text
//	{{sender}}   the configured sender id
//
// Example (Fast2SMS style, form encoded):
//
//	PLATFORM_SMS_PROVIDER=generic_http
//	PLATFORM_SMS_HTTP_URL=https://www.fast2sms.com/dev/bulkV2
//	PLATFORM_SMS_HTTP_METHOD=POST
//	PLATFORM_SMS_HTTP_CONTENT_TYPE=application/x-www-form-urlencoded
//	PLATFORM_SMS_HTTP_HEADERS=authorization:${FAST2SMS_KEY}
//	PLATFORM_SMS_HTTP_BODY=route=q&sender_id={{sender}}&message={{message}}&numbers={{to}}
//
// Example (JSON gateway):
//
//	PLATFORM_SMS_HTTP_URL=https://api.gateway.example.com/v1/messages
//	PLATFORM_SMS_HTTP_HEADERS=Authorization:Bearer ${SMS_TOKEN}
//	PLATFORM_SMS_HTTP_BODY={"to":"{{to}}","sender":"{{sender}}","text":"{{message}}"}
type genericHTTPSender struct {
	cfg    config.SMSConfig
	client *http.Client
}

// ProviderName identifies the transport in delivery records.
func (g *genericHTTPSender) ProviderName() string { return "generic_http" }

// IsReal reports that this transport performs real delivery.
func (g *genericHTTPSender) IsReal() bool { return true }

// Send posts the templated request to the configured gateway.
func (g *genericHTTPSender) Send(ctx context.Context, message Message) (Result, error) {
	fail := func(code string, retryable bool, err error) (Result, error) {
		return Result{Provider: "generic_http", ErrorCode: code, Retryable: retryable}, err
	}

	if g.cfg.HTTPURL == "" {
		return fail("missing_gateway_url", false,
			fmt.Errorf("PLATFORM_SMS_HTTP_URL is required for the generic_http provider"))
	}
	destination := normalizeMSISDN(message.To)
	if destination == "" {
		return fail("invalid_phone", false, fmt.Errorf("invalid phone number"))
	}
	if message.OTP == "" {
		return fail("empty_message", false, fmt.Errorf("refusing to send an SMS without an OTP"))
	}

	values := templateValues{
		to:      destination,
		toPlus:  "+" + destination,
		otp:     message.OTP,
		message: renderSMS(message),
		sender:  g.cfg.SenderID,
	}

	method := strings.ToUpper(strings.TrimSpace(g.cfg.HTTPMethod))
	if method == "" {
		method = http.MethodPost
	}
	endpoint := values.expand(g.cfg.HTTPURL)
	body := values.expand(g.cfg.HTTPBody)
	if body == "" {
		body = values.expand(`{"to":"{{to}}","sender":"{{sender}}","text":"{{message}}"}`)
	}

	request, err := http.NewRequestWithContext(ctx, method, endpoint, strings.NewReader(body))
	if err != nil {
		return fail("request_build_failed", false, fmt.Errorf("build gateway request: %w", err))
	}
	contentType := g.cfg.HTTPContentType
	if contentType == "" {
		contentType = "application/json"
	}
	request.Header.Set("Content-Type", contentType)
	request.Header.Set("Accept", "application/json")
	for key, value := range parseHeaderList(g.cfg.HTTPHeaders) {
		request.Header.Set(key, values.expand(value))
	}

	started := time.Now()
	response, err := g.client.Do(request)
	elapsed := time.Since(started)
	if err != nil {
		return fail("network_error", true, fmt.Errorf("gateway request failed: %w", err))
	}
	defer func() { _ = response.Body.Close() }()
	responseBody, _ := io.ReadAll(io.LimitReader(response.Body, 16*1024))

	result := Result{Provider: "generic_http", Latency: elapsed}
	if !statusAllowed(response.StatusCode, g.cfg.HTTPSuccessStatus) {
		result.ErrorCode = fmt.Sprintf("http_%d", response.StatusCode)
		result.Retryable = isRetryableStatus(response.StatusCode)
		return result, fmt.Errorf("gateway returned status %d", response.StatusCode)
	}
	if g.cfg.HTTPSuccessSubstring != "" &&
		!strings.Contains(string(responseBody), g.cfg.HTTPSuccessSubstring) {
		// Some gateways answer 200 with an error document; the substring is the contract that a message
		// actually went out.
		result.ErrorCode = "provider_rejected"
		result.Retryable = false
		return result, fmt.Errorf("gateway response did not contain the configured success marker")
	}

	result.Delivered = true
	result.Reference = extractReference(responseBody, g.cfg.HTTPReferenceField)
	return result, nil
}

// templateValues holds the substitution map for the request templates.
type templateValues struct {
	to, toPlus, otp, message, sender string
}

// expand replaces every placeholder in a template.
func (v templateValues) expand(template string) string {
	replacer := strings.NewReplacer(
		"{{to_plus}}", v.toPlus,
		"{{to}}", v.to,
		"{{otp}}", v.otp,
		"{{message}}", v.message,
		"{{sender}}", v.sender,
	)
	return replacer.Replace(template)
}

// parseHeaderList parses "Key: value;Key2: value2" into a map. Values may reference the placeholders and
// are expanded by the caller, so a credential can be supplied as ${VAR} by the environment.
func parseHeaderList(raw string) map[string]string {
	headers := map[string]string{}
	for _, entry := range strings.Split(raw, ";") {
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		parts := strings.SplitN(entry, ":", 2)
		if len(parts) != 2 {
			continue
		}
		headers[strings.TrimSpace(parts[0])] = strings.TrimSpace(parts[1])
	}
	return headers
}

// statusAllowed reports whether a status code satisfies the configured success specification, which is
// either a list ("200,201,202") or a range ("200-299"). Empty means "any 2xx".
func statusAllowed(status int, specification string) bool {
	specification = strings.TrimSpace(specification)
	if specification == "" {
		return status >= 200 && status < 300
	}
	for _, part := range strings.Split(specification, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		if strings.Contains(part, "-") {
			bounds := strings.SplitN(part, "-", 2)
			var low, high int
			if _, err := fmt.Sscanf(bounds[0], "%d", &low); err != nil {
				continue
			}
			if _, err := fmt.Sscanf(bounds[1], "%d", &high); err != nil {
				continue
			}
			if status >= low && status <= high {
				return true
			}
			continue
		}
		var exact int
		if _, err := fmt.Sscanf(part, "%d", &exact); err == nil && exact == status {
			return true
		}
	}
	return false
}

// extractReference pulls a provider message id out of a JSON response. When no field is configured, a
// shallow search for a conventional identifier key is used.
func extractReference(body []byte, field string) string {
	if len(body) == 0 {
		return ""
	}
	var payload map[string]any
	if err := json.Unmarshal(body, &payload); err != nil {
		return ""
	}
	if field != "" {
		if value, ok := lookupField(payload, field); ok {
			return fmt.Sprint(value)
		}
		return ""
	}
	for _, key := range []string{"message_id", "messageId", "id", "request_id", "requestId",
		"reference", "sid", "job_id"} {
		if value, ok := payload[key]; ok {
			if text := fmt.Sprint(value); text != "" && text != "<nil>" {
				return text
			}
		}
	}
	return ""
}

// lookupField resolves a dotted path ("data.id") in a decoded JSON object.
func lookupField(payload map[string]any, path string) (any, bool) {
	current := any(payload)
	for _, segment := range strings.Split(path, ".") {
		object, ok := current.(map[string]any)
		if !ok {
			return nil, false
		}
		current, ok = object[segment]
		if !ok {
			return nil, false
		}
	}
	return current, true
}
