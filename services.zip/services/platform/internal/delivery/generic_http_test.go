package delivery

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/mosip/esignet-platform/internal/config"
)

// newGenericSender builds a generic_http transport pointed at a test server.
func newGenericSender(url string, customize func(*config.SMSConfig)) Sender {
	cfg := config.SMSConfig{
		Provider: "generic_http", SenderID: "ESIGNT", Timeout: 5 * time.Second,
		MaxAttempts: 1, HTTPURL: url,
	}
	if customize != nil {
		customize(&cfg)
	}
	return NewSMSSender(cfg, testLogger())
}

func TestGenericHTTPDelivers(t *testing.T) {
	var (
		receivedBody   string
		receivedHeader http.Header
	)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body := make([]byte, r.ContentLength)
		_, _ = r.Body.Read(body)
		receivedBody = string(body)
		receivedHeader = r.Header.Clone()
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"message_id":"msg-9182","status":"queued"}`))
	}))
	defer server.Close()

	sender := newGenericSender(server.URL+"/v1/send", func(cfg *config.SMSConfig) {
		cfg.HTTPHeaders = "Authorization: Bearer ${SMS_TOKEN};X-Client: esignet"
		cfg.HTTPBody = `{"to":"{{to}}","sender":"{{sender}}","text":"{{message}}"}`

		receivedHeader = nil
	})
	result, err := sender.Send(context.Background(), Message{
		To: "+919000000001", Channel: "sms", OTP: "482913", TTLMinutes: 5,
	})
	require.NoError(t, err)
	assert.True(t, result.Delivered)
	assert.Equal(t, "generic_http", result.Provider)
	assert.Equal(t, "msg-9182", result.Reference, "the provider message id is captured")

	assert.Contains(t, receivedBody, `"to":"919000000001"`, "the leading + is stripped for the gateway")
	assert.Contains(t, receivedBody, `"sender":"ESIGNT"`)
	assert.Contains(t, receivedBody, "482913", "the OTP reaches the message body")
	assert.Equal(t, "application/json", receivedHeader.Get("Content-Type"))
	assert.Equal(t, "esignet", receivedHeader.Get("X-Client"))
}

func TestGenericHTTPFormEncoded(t *testing.T) {
	var contentType, body string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		contentType = r.Header.Get("Content-Type")
		raw := make([]byte, r.ContentLength)
		_, _ = r.Body.Read(raw)
		body = string(raw)
		_, _ = w.Write([]byte("ok"))
	}))
	defer server.Close()

	sender := newGenericSender(server.URL, func(cfg *config.SMSConfig) {
		cfg.HTTPContentType = "application/x-www-form-urlencoded"
		cfg.HTTPBody = "numbers={{to}}&sender_id={{sender}}&message={{message}}"
		cfg.HTTPSuccessSubstring = "ok"
	})
	result, err := sender.Send(context.Background(), Message{
		To: "+919000000001", OTP: "482913", TTLMinutes: 5,
	})
	require.NoError(t, err)
	assert.True(t, result.Delivered)
	assert.Equal(t, "application/x-www-form-urlencoded", contentType)
	assert.Contains(t, body, "numbers=919000000001")
	assert.Contains(t, body, "482913")
}

func TestGenericHTTPRetriesTransientFailures(t *testing.T) {
	var attempts int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if atomic.AddInt32(&attempts, 1) < 3 {
			w.WriteHeader(http.StatusTooManyRequests) // 429: retryable
			return
		}
		_, _ = w.Write([]byte(`{"id":"msg-1"}`))
	}))
	defer server.Close()

	sender := newGenericSender(server.URL, func(cfg *config.SMSConfig) {
		cfg.MaxAttempts = 3
		cfg.RetryBackoff = time.Millisecond
	})
	result, err := sender.Send(context.Background(), Message{
		To: "+919000000001", OTP: "482913", TTLMinutes: 5,
	})
	require.NoError(t, err)
	assert.True(t, result.Delivered)
	assert.Equal(t, 3, result.Attempts, "the transport retried until the gateway accepted the message")
	assert.EqualValues(t, 3, atomic.LoadInt32(&attempts))
}

func TestGenericHTTPDoesNotRetryRejections(t *testing.T) {
	var attempts int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		atomic.AddInt32(&attempts, 1)
		w.WriteHeader(http.StatusUnauthorized) // bad credentials: permanent
	}))
	defer server.Close()

	sender := newGenericSender(server.URL, func(cfg *config.SMSConfig) {
		cfg.MaxAttempts = 3
		cfg.RetryBackoff = time.Millisecond
	})
	result, err := sender.Send(context.Background(), Message{
		To: "+919000000001", OTP: "482913", TTLMinutes: 5,
	})
	require.Error(t, err)
	assert.False(t, result.Delivered)
	assert.Equal(t, "http_401", result.ErrorCode)
	assert.Equal(t, 1, result.Attempts, "a rejected credential is not retried")
	assert.EqualValues(t, 1, atomic.LoadInt32(&attempts))
}

func TestGenericHTTPRejectsUnmarkedSuccessResponse(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"error":"insufficient_balance"}`))
	}))
	defer server.Close()

	sender := newGenericSender(server.URL, func(cfg *config.SMSConfig) {
		cfg.HTTPSuccessSubstring = `"status":"queued"`
	})
	result, err := sender.Send(context.Background(), Message{To: "+919000000001", OTP: "482913"})
	require.Error(t, err)
	assert.False(t, result.Delivered, "a 200 without the success marker is not a delivery")
	assert.Equal(t, "provider_rejected", result.ErrorCode)
}

func TestGenericHTTPRequiresURL(t *testing.T) {
	cfg := config.SMSConfig{Provider: "generic_http", MaxAttempts: 1}
	sender := NewSMSSender(cfg, testLogger())
	_, err := sender.Send(context.Background(), Message{To: "+919000000001", OTP: "1"})
	require.Error(t, err)
}

func TestGenericHTTPRejectsInvalidPhone(t *testing.T) {
	sender := newGenericSender("http://127.0.0.1:1/never", nil)
	result, err := sender.Send(context.Background(), Message{To: "not-a-phone", OTP: "1"})
	require.Error(t, err)
	assert.Equal(t, "invalid_phone", result.ErrorCode)
}

func TestStatusAllowed(t *testing.T) {
	assert.True(t, statusAllowed(200, ""))
	assert.True(t, statusAllowed(204, ""))
	assert.False(t, statusAllowed(302, ""))
	assert.True(t, statusAllowed(202, "200,202"))
	assert.False(t, statusAllowed(201, "200,202"))
	assert.True(t, statusAllowed(250, "200-299"))
	assert.False(t, statusAllowed(300, "200-299"))
	assert.False(t, statusAllowed(200, "not-a-number"))
}

func TestTemplateExpansion(t *testing.T) {
	values := templateValues{to: "919000000001", toPlus: "+919000000001", otp: "482913",
		message: "code 482913", sender: "ESIGNT"}

	// Placeholders are substituted verbatim: a gateway that needs a URL-encoded '+' gets {{to}} and adds
	// its own prefix, and one that wants the '+' gets {{to_plus}}.
	assert.Equal(t, "https://gw/send?n=919000000001&plus=+919000000001",
		values.expand("https://gw/send?n={{to}}&plus={{to_plus}}"))
	assert.Equal(t, "code 482913|482913|ESIGNT", values.expand("{{message}}|{{otp}}|{{sender}}"))
	// An unknown placeholder is left intact so a typo is visible in the request rather than silently lost.
	assert.Equal(t, "{{unknown}}", values.expand("{{unknown}}"))
}

func TestParseHeaderList(t *testing.T) {
	headers := parseHeaderList("Authorization: Bearer abc; X-Client: esignet ;;malformed")
	assert.Equal(t, "Bearer abc", headers["Authorization"])
	assert.Equal(t, "esignet", headers["X-Client"])
	assert.Len(t, headers, 2)
}

func TestExtractReference(t *testing.T) {
	body := []byte(`{"data":{"id":"nested-1"},"message_id":"msg-2"}`)
	assert.Equal(t, "msg-2", extractReference(body, ""))
	assert.Equal(t, "nested-1", extractReference(body, "data.id"))
	assert.Equal(t, "", extractReference(body, "missing.field"))
	assert.Equal(t, "", extractReference([]byte("plain text"), ""))
}

func TestRenderSMSCarriesTheCodeEarly(t *testing.T) {
	text := renderSMS(Message{OTP: "482913", TTLMinutes: 5})
	assert.True(t, strings.HasPrefix(text, "482913"), "the code leads the message so truncation keeps it")
	assert.Contains(t, text, "5 minutes")
	assert.Contains(t, text, "Do not share")
}

func TestProviderNamesAreStable(t *testing.T) {
	// Delivery records and the console group by these names, so they must not drift.
	assert.Equal(t, "smtp", NewEmailSender(config.EmailConfig{Mode: "smtp", TLSMode: "none"},
		testLogger()).ProviderName())
	assert.Equal(t, "smtp_tls", NewEmailSender(config.EmailConfig{Mode: "smtp", TLSMode: "tls"},
		testLogger()).ProviderName())
	assert.Equal(t, "msg91", NewSMSSender(config.SMSConfig{Provider: "msg91"}, testLogger()).ProviderName())
	assert.Equal(t, "generic_http", NewSMSSender(config.SMSConfig{Provider: "generic_http",
		HTTPURL: "http://x"}, testLogger()).ProviderName())
	assert.Equal(t, "console", NewSMSSender(config.SMSConfig{Provider: "console"}, testLogger()).ProviderName())
}

func TestRetryWrapperHonoursMaxAttempts(t *testing.T) {
	var attempts int32
	inner := &countingSender{fail: true, retryable: true, attempts: &attempts}
	sender := withRetry(inner, 3, time.Millisecond, testLogger())
	result, err := sender.Send(context.Background(), Message{OTP: "1"})
	require.Error(t, err)
	assert.Equal(t, 3, result.Attempts)
	assert.EqualValues(t, 3, atomic.LoadInt32(&attempts))
}

func TestRetryWrapperStopsOnPermanentFailure(t *testing.T) {
	var attempts int32
	inner := &countingSender{fail: true, retryable: false, attempts: &attempts}
	sender := withRetry(inner, 4, time.Millisecond, testLogger())
	result, err := sender.Send(context.Background(), Message{OTP: "1"})
	require.Error(t, err)
	assert.Equal(t, 1, result.Attempts)
	assert.EqualValues(t, 1, atomic.LoadInt32(&attempts))
}

func TestRetryWrapperCapsAttempts(t *testing.T) {
	var attempts int32
	inner := &countingSender{fail: true, retryable: true, attempts: &attempts}
	sender := withRetry(inner, 50, time.Millisecond, testLogger())
	_, _ = sender.Send(context.Background(), Message{OTP: "1"})
	assert.EqualValues(t, 5, atomic.LoadInt32(&attempts), "attempts are capped at five")
}

func TestRetryWrapperStopsWhenContextIsCancelled(t *testing.T) {
	var attempts int32
	inner := &countingSender{fail: true, retryable: true, attempts: &attempts}
	sender := withRetry(inner, 5, 50*time.Millisecond, testLogger())

	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	started := time.Now()
	_, err := sender.Send(ctx, Message{OTP: "1"})
	require.Error(t, err)
	assert.Less(t, time.Since(started), time.Second)
}

// countingSender is a Sender double for the retry wrapper tests.
type countingSender struct {
	fail      bool
	retryable bool
	attempts  *int32
}

func (c *countingSender) Send(context.Context, Message) (Result, error) {
	atomic.AddInt32(c.attempts, 1)
	if c.fail {
		return Result{Provider: "double", ErrorCode: "boom", Retryable: c.retryable},
			&stubError{}
	}
	return Result{Provider: "double", Delivered: true}, nil
}
func (c *countingSender) ProviderName() string { return "double" }
func (c *countingSender) IsReal() bool         { return false }

// stubError is a plain error for the doubles.
type stubError struct{}

func (s *stubError) Error() string { return "stub failure" }

