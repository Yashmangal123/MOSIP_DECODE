package delivery

import (
	"io"
	"log/slog"
)

// testLogger returns a silent logger for the white-box tests in this package.
func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}
