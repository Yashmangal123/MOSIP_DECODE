package delivery

import (
	"context"
	"log/slog"
	"time"
)

// retrySender wraps a Sender with bounded exponential backoff for transient failures.
//
// Only failures the transport classified as retryable are retried: network errors, provider throttling
// (HTTP 429) and provider-side faults (HTTP/SMTP 5xx, SMTP 4xx greylisting). A rejected credential or an
// invalid destination fails immediately, because retrying cannot help and repeated failed attempts can
// get an account suspended by the provider.
type retrySender struct {
	inner       Sender
	maxAttempts int
	baseBackoff time.Duration
	logger      *slog.Logger
}

// withRetry wraps a transport. A non-positive attempt count means a single attempt.
func withRetry(inner Sender, maxAttempts int, baseBackoff time.Duration, logger *slog.Logger) Sender {
	if maxAttempts <= 0 {
		maxAttempts = 1
	}
	if maxAttempts > 5 {
		// More than five attempts against a provider is abuse, not resilience.
		maxAttempts = 5
	}
	if baseBackoff <= 0 {
		baseBackoff = 200 * time.Millisecond
	}
	return &retrySender{inner: inner, maxAttempts: maxAttempts, baseBackoff: baseBackoff, logger: logger}
}

// Send attempts the wrapped transport, backing off between retryable failures.
func (r *retrySender) Send(ctx context.Context, message Message) (Result, error) {
	backoff := r.baseBackoff
	var (
		result Result
		err    error
	)
	for attempt := 1; attempt <= r.maxAttempts; attempt++ {
		started := time.Now()
		result, err = r.inner.Send(ctx, message)
		result.Attempts = attempt
		result.Latency = time.Since(started)

		if err == nil || !result.Retryable || attempt == r.maxAttempts {
			return result, err
		}

		r.logger.WarnContext(ctx, "delivery attempt failed, retrying",
			"provider", r.inner.ProviderName(), "attempt", attempt, "maxAttempts", r.maxAttempts,
			"errorCode", result.ErrorCode, "backoff", backoff.String())

		select {
		case <-ctx.Done():
			return Result{Provider: r.inner.ProviderName(), ErrorCode: "context_cancelled",
				Retryable: false, Attempts: attempt}, ctx.Err()
		case <-time.After(backoff):
		}
		backoff *= 2
	}
	return result, err
}

func (r *retrySender) ProviderName() string { return r.inner.ProviderName() }
func (r *retrySender) IsReal() bool         { return r.inner.IsReal() }

// isRetryableStatus classifies an HTTP status code.
func isRetryableStatus(status int) bool {
	switch {
	case status == 429:
		return true
	case status >= 500:
		return true
	default:
		return false
	}
}
