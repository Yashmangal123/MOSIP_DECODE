package delivery

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"

	"github.com/mosip/esignet-platform/internal/config"
)

// renderSMS builds the SMS body.
func renderSMS(message Message) string {
	return fmt.Sprintf("%s is your MOSIP eSignet verification code. It expires in %d minutes. "+
		"Do not share it with anyone.", message.OTP, message.TTLMinutes)
}

// msg91Sender delivers OTP SMS through MSG91 (https://docs.msg91.com/).
type msg91Sender struct {
	cfg    config.SMSConfig
	client *http.Client
}

func (m *msg91Sender) ProviderName() string { return "msg91" }
func (m *msg91Sender) IsReal() bool         { return true }

func (m *msg91Sender) Send(ctx context.Context, message Message) (Result, error) {
	if m.cfg.MSG91AuthKey == "" {
		return Result{Provider: "msg91", ErrorCode: "missing_credentials"},
			errors.New("MSG91 auth key is not configured")
	}
	mobile := normalizeMSISDN(message.To)
	if mobile == "" {
		return Result{Provider: "msg91", ErrorCode: "invalid_phone"}, errors.New("invalid phone number")
	}

	form := url.Values{}
	form.Set("authkey", m.cfg.MSG91AuthKey)
	form.Set("mobiles", mobile)
	form.Set("sender", m.cfg.SenderID)
	form.Set("route", m.cfg.MSG91Route)
	form.Set("country", "91")
	if m.cfg.MSG91Template != "" {
		// The DL T template carries the OTP as its single variable.
		form.Set("DLT_TE_ID", m.cfg.MSG91Template)
		form.Set("message", renderSMS(message))
	} else {
		form.Set("message", renderSMS(message))
	}

	request, err := http.NewRequestWithContext(ctx, http.MethodPost,
		"https://control.msg91.com/api/sendhttp.php", strings.NewReader(form.Encode()))
	if err != nil {
		return Result{Provider: "msg91", ErrorCode: "request_build_failed"}, err
	}
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	response, err := m.client.Do(request)
	if err != nil {
		return Result{Provider: "msg91", ErrorCode: "network_error", Retryable: true},
			fmt.Errorf("msg91 request: %w", err)
	}
	defer func() { _ = response.Body.Close() }()
	body, _ := io.ReadAll(io.LimitReader(response.Body, 4096))

	if response.StatusCode >= 300 {
		return Result{Provider: "msg91", ErrorCode: fmt.Sprintf("http_%d", response.StatusCode),
				Retryable: isRetryableStatus(response.StatusCode)},
			fmt.Errorf("msg91 returned status %d", response.StatusCode)
	}
	// MSG91 answers with a request id (or an error object) in the body.
	reference := strings.TrimSpace(string(body))
	if strings.Contains(strings.ToLower(reference), "error") {
		return Result{Provider: "msg91", ErrorCode: "provider_error"},
			fmt.Errorf("msg91 rejected the message")
	}
	return Result{Provider: "msg91", Reference: reference, Delivered: true}, nil
}

// twilioSender delivers OTP SMS through Twilio's REST API.
type twilioSender struct {
	cfg    config.SMSConfig
	client *http.Client
}

func (t *twilioSender) ProviderName() string { return "twilio" }
func (t *twilioSender) IsReal() bool         { return true }

func (t *twilioSender) Send(ctx context.Context, message Message) (Result, error) {
	if t.cfg.TwilioAccountSID == "" || t.cfg.TwilioAuthToken == "" {
		return Result{Provider: "twilio", ErrorCode: "missing_credentials"},
			errors.New("Twilio credentials are not configured")
	}
	if t.cfg.TwilioFrom == "" {
		return Result{Provider: "twilio", ErrorCode: "missing_sender"}, errors.New("Twilio sender is not configured")
	}
	if normalizeMSISDN(message.To) == "" {
		return Result{Provider: "twilio", ErrorCode: "invalid_phone"}, errors.New("invalid phone number")
	}

	endpoint := fmt.Sprintf("https://api.twilio.com/2010-04-01/Accounts/%s/Messages.json", t.cfg.TwilioAccountSID)
	form := url.Values{}
	form.Set("To", message.To)
	form.Set("From", t.cfg.TwilioFrom)
	form.Set("Body", renderSMS(message))

	request, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, strings.NewReader(form.Encode()))
	if err != nil {
		return Result{Provider: "twilio", ErrorCode: "request_build_failed"}, err
	}
	request.SetBasicAuth(t.cfg.TwilioAccountSID, t.cfg.TwilioAuthToken)
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	response, err := t.client.Do(request)
	if err != nil {
		return Result{Provider: "twilio", ErrorCode: "network_error", Retryable: true},
			fmt.Errorf("twilio request: %w", err)
	}
	defer func() { _ = response.Body.Close() }()
	body, _ := io.ReadAll(io.LimitReader(response.Body, 8192))

	if response.StatusCode >= 300 {
		var apiError struct {
			Code    int    `json:"code"`
			Message string `json:"message"`
		}
		_ = json.Unmarshal(body, &apiError)
		return Result{Provider: "twilio", ErrorCode: fmt.Sprintf("twilio_%d", apiError.Code),
				Retryable: isRetryableStatus(response.StatusCode)},
			fmt.Errorf("twilio returned status %d", response.StatusCode)
	}

	var payload struct {
		SID    string `json:"sid"`
		Status string `json:"status"`
	}
	_ = json.Unmarshal(body, &payload)
	return Result{Provider: "twilio", Reference: payload.SID, Delivered: true}, nil
}

// snsSender publishes an OTP SMS through AWS SNS. The request is signed with Signature Version 4.
type snsSender struct {
	cfg    config.SMSConfig
	client *http.Client
}

func (s *snsSender) ProviderName() string { return "aws_sns" }
func (s *snsSender) IsReal() bool         { return true }

func (s *snsSender) Send(ctx context.Context, message Message) (Result, error) {
	if s.cfg.AWSAccessKeyID == "" || s.cfg.AWSSecretAccessKey == "" || s.cfg.AWSRegion == "" {
		return Result{Provider: "aws_sns", ErrorCode: "missing_credentials"},
			errors.New("AWS SNS credentials or region are not configured")
	}
	if normalizeMSISDN(message.To) == "" {
		return Result{Provider: "aws_sns", ErrorCode: "invalid_phone"}, errors.New("invalid phone number")
	}
	reference, err := snsPublish(ctx, s.client, s.cfg, message.To, renderSMS(message))
	if err != nil {
		return Result{Provider: "aws_sns", ErrorCode: "provider_error", Retryable: true}, err
	}
	return Result{Provider: "aws_sns", Reference: reference, Delivered: true}, nil
}

// normalizeMSISDN validates a phone number and returns it in E.164 form without a leading '+' when
// possible. It accepts an optional '+', 8-15 digits, and rejects anything else.
func normalizeMSISDN(phone string) string {
	trimmed := strings.TrimSpace(phone)
	trimmed = strings.ReplaceAll(trimmed, " ", "")
	trimmed = strings.ReplaceAll(trimmed, "-", "")
	trimmed = strings.TrimPrefix(trimmed, "+")
	if len(trimmed) < 8 || len(trimmed) > 15 {
		return ""
	}
	for _, r := range trimmed {
		if r < '0' || r > '9' {
			return ""
		}
	}
	return trimmed
}
