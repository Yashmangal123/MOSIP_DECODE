package delivery

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"log/slog"
	"net"
	"net/smtp"
	"net/textproto"
	"strconv"
	"strings"
	"time"

	"github.com/mosip/esignet-platform/internal/config"
)

// TLS modes for the SMTP transport.
const (
	// TLSModeNone speaks plaintext SMTP. Only acceptable for a local sink (Mailpit, smtp_catcher) or a
	// trusted private network; credentials are refused in this mode.
	TLSModeNone = "none"
	// TLSModeStartTLS upgrades a plaintext connection (submission port 587, the common case for Gmail,
	// Amazon SES, SendGrid, Postmark, Mailgun and an internal relay).
	TLSModeStartTLS = "starttls"
	// TLSModeTLS dials TLS first (smtps, port 465).
	TLSModeTLS = "tls"
)

// smtpSender delivers email over SMTP.
//
// It implements the three real-world submission modes (implicit TLS, STARTTLS, plaintext), authenticates
// with PLAIN when credentials are configured, uses the configured EHLO name, and classifies the reply
// codes so a transient 4xx is retried while a permanent 5xx is not.
type smtpSender struct {
	cfg    config.EmailConfig
	logger *slog.Logger
}

// ProviderName reports the transport and its security mode, so an operator can see from a delivery record
// whether the message was sent over TLS.
func (s *smtpSender) ProviderName() string {
	if strings.EqualFold(s.cfg.TLSMode, TLSModeTLS) {
		return "smtp_tls"
	}
	return "smtp"
}

// IsReal reports that this transport performs real delivery.
func (s *smtpSender) IsReal() bool { return true }

// Send delivers one email.
func (s *smtpSender) Send(ctx context.Context, message Message) (Result, error) {
	provider := s.ProviderName()
	fail := func(code string, retryable bool, err error) (Result, error) {
		return Result{Provider: provider, ErrorCode: code, Retryable: retryable}, err
	}

	if strings.TrimSpace(message.OTP) == "" {
		return fail("empty_message", false, errors.New("refusing to send an email without an OTP"))
	}
	if !strings.Contains(message.To, "@") {
		return fail("invalid_recipient", false, errors.New("invalid email address"))
	}

	tlsMode := strings.ToLower(strings.TrimSpace(s.cfg.TLSMode))
	if tlsMode == "" {
		tlsMode = TLSModeNone
	}
	if tlsMode == TLSModeNone && s.cfg.Username != "" {
		// Credentials over an unencrypted connection would leak the provider password.
		return fail("insecure_credentials", false,
			errors.New("SMTP credentials require STARTTLS or TLS: refusing to authenticate in plaintext"))
	}
	if tlsMode != TLSModeNone && tlsMode != TLSModeStartTLS && tlsMode != TLSModeTLS {
		return fail("invalid_tls_mode", false, fmt.Errorf("unknown SMTP TLS mode %q", s.cfg.TLSMode))
	}

	address := net.JoinHostPort(s.cfg.Host, strconv.Itoa(s.cfg.Port))
	timeout := s.cfg.Timeout
	if timeout <= 0 {
		timeout = 15 * time.Second
	}

	var connection net.Conn
	var err error
	dialer := &net.Dialer{Timeout: timeout}
	if tlsMode == TLSModeTLS {
		// Implicit TLS: the handshake happens before any SMTP command is sent.
		tlsDialer := &tls.Dialer{NetDialer: dialer, Config: tlsConfig(s.cfg.Host)}
		connection, err = tlsDialer.DialContext(ctx, "tcp", address)
		if err != nil {
			return fail("tls_dial_failed", true, fmt.Errorf("smtp TLS dial: %w", err))
		}
	} else {
		connection, err = dialer.DialContext(ctx, "tcp", address)
		if err != nil {
			return fail("dial_failed", true, fmt.Errorf("smtp dial: %w", err))
		}
	}
	_ = connection.SetDeadline(time.Now().Add(timeout))
	defer func() { _ = connection.Close() }()

	client, err := smtp.NewClient(connection, s.cfg.Host)
	if err != nil {
		return fail("handshake_failed", true, fmt.Errorf("smtp handshake: %w", err))
	}
	defer func() { _ = client.Close() }()

	if s.cfg.HeloName != "" {
		if err := client.Hello(s.cfg.HeloName); err != nil {
			return fail("helo_failed", true, fmt.Errorf("smtp HELO: %w", err))
		}
	}

	if tlsMode == TLSModeStartTLS {
		if ok, _ := client.Extension("STARTTLS"); !ok {
			return fail("starttls_unsupported", false,
				errors.New("SMTP server does not advertise STARTTLS; use TLS mode for port 465"))
		}
		if err := client.StartTLS(tlsConfig(s.cfg.Host)); err != nil {
			return fail("starttls_failed", true, fmt.Errorf("smtp STARTTLS: %w", err))
		}
	}

	if s.cfg.Username != "" {
		auth := smtp.PlainAuth("", s.cfg.Username, s.cfg.Password, s.cfg.Host)
		if err := client.Auth(auth); err != nil {
			// A rejected credential is permanent: never retried, so an account cannot be locked out.
			return fail("auth_failed", false, fmt.Errorf("smtp authentication failed: %w", err))
		}
	}

	from := s.cfg.From
	if from == "" {
		return fail("missing_sender", false, errors.New("SMTP From address is not configured"))
	}
	if err := client.Mail(from); err != nil {
		code, retry := classifySMTPError(err)
		return fail(code, retry, fmt.Errorf("smtp MAIL FROM: %w", err))
	}
	if err := client.Rcpt(message.To); err != nil {
		code, retry := classifySMTPError(err)
		return fail(code, retry, fmt.Errorf("smtp RCPT TO: %w", err))
	}

	writer, err := client.Data()
	if err != nil {
		code, retry := classifySMTPError(err)
		return fail(code, retry, fmt.Errorf("smtp DATA: %w", err))
	}
	payload := buildEmail(s.cfg, message)
	if _, err := writer.Write(payload); err != nil {
		_ = writer.Close()
		return fail("write_failed", true, fmt.Errorf("smtp write: %w", err))
	}
	if err := writer.Close(); err != nil {
		code, retry := classifySMTPError(err)
		return fail(code, retry, fmt.Errorf("smtp closing DATA: %w", err))
	}
	if err := client.Quit(); err != nil {
		// QUIT failing after the message was accepted does not mean the message was rejected.
		s.logger.Debug("smtp QUIT failed after acceptance", "error", err)
	}

	return Result{Provider: provider, Reference: "smtp:" + message.To, Delivered: true}, nil
}

// classifySMTPError maps an SMTP error onto a stable code and a retry decision. 4xx replies are transient
// (greylisting, mailbox busy, rate limiting); 5xx replies are permanent (unknown user, policy rejection).
func classifySMTPError(err error) (code string, retryable bool) {
	var protocolError *textproto.Error
	if errors.As(err, &protocolError) {
		switch {
		case protocolError.Code >= 400 && protocolError.Code < 500:
			return "smtp_temporary_failure", true
		case protocolError.Code >= 500:
			return "smtp_permanent_failure", false
		}
	}
	return "smtp_error", true
}

// tlsConfig returns the TLS configuration used for SMTP. Certificates are always verified against the
// system trust store and TLS 1.2 is the floor: the service offers no option to skip verification.
func tlsConfig(serverName string) *tls.Config {
	return &tls.Config{ServerName: serverName, MinVersion: tls.VersionTLS12}
}
