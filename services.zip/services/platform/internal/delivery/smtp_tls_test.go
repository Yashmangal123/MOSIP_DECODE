package delivery_test

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"math/big"
	"net"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/mosip/esignet-platform/internal/config"
	"github.com/mosip/esignet-platform/internal/delivery"
)

// selfSignedTLSListener starts a TLS listener with a self-signed certificate, i.e. one that no system
// trust store contains.
func selfSignedTLSListener(t *testing.T) net.Listener {
	t.Helper()
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	require.NoError(t, err)

	template := &x509.Certificate{
		SerialNumber: big.NewInt(1),
		Subject:      pkix.Name{CommonName: "localhost"},
		NotBefore:    time.Now().Add(-time.Hour),
		NotAfter:     time.Now().Add(time.Hour),
		DNSNames:     []string{"localhost"},
		IPAddresses:  []net.IP{net.ParseIP("127.0.0.1")},
		KeyUsage:     x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign,
		ExtKeyUsage:  []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		IsCA:         true,
		BasicConstraintsValid: true,
	}
	der, err := x509.CreateCertificate(rand.Reader, template, template, &key.PublicKey, key)
	require.NoError(t, err)
	certificate := tls.Certificate{Certificate: [][]byte{der}, PrivateKey: key}

	listener, err := tls.Listen("tcp", "127.0.0.1:0", &tls.Config{
		Certificates: []tls.Certificate{certificate},
		MinVersion:   tls.VersionTLS12,
	})
	require.NoError(t, err)
	t.Cleanup(func() { _ = listener.Close() })
	return listener
}

func TestSMTPSenderImplicitTLS(t *testing.T) {
	// The listener presents a self-signed certificate. The transport must refuse it: certificate
	// verification is never disabled, so the failure proves TLS is actually negotiated and checked.
	listener := selfSignedTLSListener(t)
	port := listener.Addr().(*net.TCPAddr).Port

	sender := delivery.NewEmailSender(config.EmailConfig{
		Mode: "smtp", Host: "127.0.0.1", Port: port, From: "no-reply@esignet.local",
		TLSMode: "tls", Timeout: 3 * time.Second, MaxAttempts: 1,
	}, testLogger())

	result, err := sender.Send(context.Background(), delivery.Message{
		To: "asha.verma@example.com", OTP: "482913", TTLMinutes: 5,
	})
	require.Error(t, err)
	assert.False(t, result.Delivered)
	assert.Equal(t, "tls_dial_failed", result.ErrorCode)
}

func TestSMTPSenderImplicitTLSAgainstPlaintextServer(t *testing.T) {
	// Speaking TLS to a plaintext SMTP sink must fail fast rather than hang or downgrade.
	server := startFakeSMTP(t)
	sender := delivery.NewEmailSender(config.EmailConfig{
		Mode: "smtp", Host: "127.0.0.1", Port: server.port(), From: "no-reply@esignet.local",
		TLSMode: "tls", Timeout: 2 * time.Second, MaxAttempts: 1,
	}, testLogger())

	result, err := sender.Send(context.Background(), delivery.Message{To: "a@example.com", OTP: "1"})
	require.Error(t, err)
	assert.False(t, result.Delivered)
	assert.Contains(t, []string{"tls_dial_failed", "handshake_failed"}, result.ErrorCode)
}

func TestSMTPSenderRefusesCredentialsInPlaintext(t *testing.T) {
	server := startFakeSMTP(t)
	sender := delivery.NewEmailSender(config.EmailConfig{
		Mode: "smtp", Host: "127.0.0.1", Port: server.port(), From: "no-reply@esignet.local",
		Username: "user", Password: "secret", TLSMode: "none", Timeout: 2 * time.Second,
	}, testLogger())

	result, err := sender.Send(context.Background(), delivery.Message{To: "a@example.com", OTP: "1"})
	require.Error(t, err)
	assert.Equal(t, "insecure_credentials", result.ErrorCode)
	assert.False(t, result.Retryable)
	assert.Empty(t, server.messagesSnapshot(), "nothing may be sent when credentials would be exposed")
}

func TestSMTPSenderRequiresRecipient(t *testing.T) {
	sender := delivery.NewEmailSender(config.EmailConfig{
		Mode: "smtp", Host: "127.0.0.1", Port: 25, From: "no-reply@esignet.local", MaxAttempts: 1,
	}, testLogger())
	result, err := sender.Send(context.Background(), delivery.Message{To: "not-an-email", OTP: "1"})
	require.Error(t, err)
	assert.Equal(t, "invalid_recipient", result.ErrorCode)
}

func TestSMTPSenderRefusesEmptyOTP(t *testing.T) {
	sender := delivery.NewEmailSender(config.EmailConfig{
		Mode: "smtp", Host: "127.0.0.1", Port: 25, From: "no-reply@esignet.local", MaxAttempts: 1,
	}, testLogger())
	result, err := sender.Send(context.Background(), delivery.Message{To: "a@example.com"})
	require.Error(t, err)
	assert.Equal(t, "empty_message", result.ErrorCode)
}
