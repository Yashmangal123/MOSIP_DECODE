// Package otp implements one-time-password generation, hashing, delivery orchestration and
// verification.
//
// Security properties implemented here:
//   - OTPs are generated with crypto/rand from a digits-only alphabet of the configured length.
//   - Only an HMAC-SHA256 digest (keyed by the server-side pepper) of the OTP is persisted; the value
//     is never written to the database, a log line or an event.
//   - A challenge is single use: verification transitions ACTIVE -> VERIFIED -> CONSUMED, and a
//     consumed challenge can never be verified again (replay protection).
//   - Wrong attempts are counted and lock the challenge at the configured maximum.
//   - Resends are rate limited by a per-user cooldown and a per-user/per-IP sliding window.
//   - Verification compares digests in constant time.
package otp

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"log/slog"
	"math/big"
	"strings"
	"time"

	"github.com/google/uuid"

	"github.com/mosip/esignet-platform/internal/config"
	"github.com/mosip/esignet-platform/internal/delivery"
	"github.com/mosip/esignet-platform/internal/store"
)

// Channels supported by the OTP service.
const (
	ChannelEmail = "email"
	ChannelSMS   = "sms"
)

// Sentinel errors mapped to HTTP error codes by the API layer.
var (
	// ErrUnknownIdentifier means no user matches the presented identifier.
	ErrUnknownIdentifier = errors.New("unknown_identifier")
	// ErrInvalidChannel means the requested channel is not email or sms.
	ErrInvalidChannel = errors.New("invalid_channel")
	// ErrRateLimited means the resend cooldown or a sliding window limit was hit.
	ErrRateLimited = errors.New("rate_limited")
	// ErrTooManyAttempts means the challenge was locked after too many wrong OTPs.
	ErrTooManyAttempts = errors.New("too_many_attempts")
	// ErrExpired means the challenge is past its validity window.
	ErrExpired = errors.New("expired")
	// ErrIncorrectOTP means the presented OTP does not match.
	ErrIncorrectOTP = errors.New("incorrect_otp")
	// ErrAlreadyUsed means the challenge was already verified or consumed.
	ErrAlreadyUsed = errors.New("already_used")
	// ErrNoActiveChallenge means there is no active challenge to verify.
	ErrNoActiveChallenge = errors.New("no_active_challenge")
	// ErrDeliveryFailed means the provider rejected the message; the challenge is cancelled.
	ErrDeliveryFailed = errors.New("delivery_failed")
)

// SendResult is the outcome of an OTP send request.
type SendResult struct {
	ChallengeID       string
	Channel           string
	DestinationMasked string
	ExpiresIn         int
	ResendAfter       int
	Provider          string
	DeliveryStatus    string
	// DevelopmentOTP is populated only in development mode when the operator explicitly enables it, so
	// automated end-to-end tests can complete without mailbox access. It is empty in every other mode.
	DevelopmentOTP string
}

// VerifyResult is the outcome of a successful verification.
type VerifyResult struct {
	UIN   string
	Email string
	Phone string
}

// EventRecorder records security events and notifications produced by OTP activity.
type EventRecorder interface {
	RecordSecurityEvent(ctx context.Context, event store.SecurityEvent)
	Notify(ctx context.Context, notification store.Notification)
}

// Repository is the persistence contract the OTP service needs. *store.Store is the production
// implementation; tests supply an in-memory double so the OTP state machine is exercised without a
// database.
type Repository interface {
	// GetUserByIdentifier resolves a user from a UIN, email address or phone number.
	GetUserByIdentifier(ctx context.Context, identifier string) (*store.IdentityUser, error)
	// GetUserByUIN loads a user by UIN.
	GetUserByUIN(ctx context.Context, uin string) (*store.IdentityUser, error)
	// CountSendsSince counts challenges created since a point in time (rate limiting).
	CountSendsSince(ctx context.Context, uin, requestIP string, since time.Time) (int, error)
	// ActiveChallengeFor returns the newest ACTIVE challenge of a user on a channel.
	ActiveChallengeFor(ctx context.Context, uin, channel string) (*store.OTPChallenge, error)
	// GetChallenge loads a challenge by id.
	GetChallenge(ctx context.Context, id string) (*store.OTPChallenge, error)
	// CreateChallenge persists a new challenge.
	CreateChallenge(ctx context.Context, challenge store.OTPChallenge) error
	// UpdateChallengeStatus transitions a challenge.
	UpdateChallengeStatus(ctx context.Context, id, status string) error
	// IncrementAttempts records a failed verification and returns the new count.
	IncrementAttempts(ctx context.Context, id string) (int, error)
	// RecordDelivery stores a delivery outcome.
	RecordDelivery(ctx context.Context, record store.DeliveryRecord) error
}

// Service orchestrates OTP issuance, delivery and verification.
type Service struct {
	cfg      *config.Config
	store    Repository
	email    delivery.Sender
	sms      delivery.Sender
	recorder EventRecorder
	logger   *slog.Logger
}

// NewService builds the OTP service.
func NewService(cfg *config.Config, st Repository, email, sms delivery.Sender, recorder EventRecorder,
	logger *slog.Logger) *Service {
	return &Service{cfg: cfg, store: st, email: email, sms: sms, recorder: recorder, logger: logger}
}

// GenerateOTP returns a cryptographically secure numeric OTP of the configured length.
func GenerateOTP(length int) (string, error) {
	if length <= 0 {
		return "", fmt.Errorf("invalid OTP length %d", length)
	}
	var builder strings.Builder
	builder.Grow(length)
	max := big.NewInt(10)
	for i := 0; i < length; i++ {
		n, err := rand.Int(rand.Reader, max)
		if err != nil {
			return "", fmt.Errorf("generate OTP: %w", err)
		}
		builder.WriteByte(byte('0' + n.Int64()))
	}
	return builder.String(), nil
}

// HashOTP returns the hex HMAC-SHA256 digest of an OTP keyed by the server-side pepper. The OTP itself
// is deliberately not part of any log line produced by this function.
func (s *Service) HashOTP(uin, otp string) string {
	mac := hmac.New(sha256.New, []byte(s.cfg.OTP.Pepper))
	// Bind the digest to the user so a digest from one account cannot be replayed on another.
	mac.Write([]byte(uin))
	mac.Write([]byte{0})
	mac.Write([]byte(otp))
	return hex.EncodeToString(mac.Sum(nil))
}

// hashDestination returns a stable digest of the delivery destination so delivery records can be
// correlated without storing the address again.
func hashDestination(destination string) string {
	sum := sha256.Sum256([]byte(strings.ToLower(strings.TrimSpace(destination))))
	return base64.RawURLEncoding.EncodeToString(sum[:])
}

// MaskEmail masks an email address for display: j***@example.com.
func MaskEmail(email string) string {
	at := strings.LastIndex(email, "@")
	if at <= 0 {
		return "***"
	}
	local, domain := email[:at], email[at:]
	if len(local) <= 1 {
		return "*" + domain
	}
	return local[:1] + strings.Repeat("*", max(1, len(local)-1)) + domain
}

// MaskPhone masks a phone number for display, keeping the last four digits.
func MaskPhone(phone string) string {
	if len(phone) <= 4 {
		return strings.Repeat("*", len(phone))
	}
	return strings.Repeat("*", len(phone)-4) + phone[len(phone)-4:]
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

// Send issues an OTP for an identifier on a channel and delivers it.
//
// The identifier may be a UIN, an email address or a phone number; the delivery destination is always
// taken from the identity directory, never from the request, so a caller cannot redirect an OTP.
func (s *Service) Send(ctx context.Context, identifier, channel, purpose, requestIP string) (*SendResult, error) {
	channel = strings.ToLower(strings.TrimSpace(channel))
	if channel != ChannelEmail && channel != ChannelSMS {
		return nil, ErrInvalidChannel
	}

	user, err := s.store.GetUserByIdentifier(ctx, identifier)
	if err != nil {
		if errors.Is(err, store.ErrNotFound) {
			// Do not disclose whether the identifier exists: the caller receives the same error shape
			// as a delivery failure.
			return nil, ErrUnknownIdentifier
		}
		return nil, err
	}

	destination := user.Email
	if channel == ChannelSMS {
		destination = user.Phone
	}
	if destination == "" {
		return nil, ErrUnknownIdentifier
	}

	now := time.Now().UTC()

	// Rate limiting: per-user/per-IP sliding window.
	windowStart := now.Add(-s.cfg.OTP.RateWindow)
	sends, err := s.store.CountSendsSince(ctx, user.UIN, requestIP, windowStart)
	if err != nil {
		return nil, err
	}
	if sends >= s.cfg.OTP.MaxSendsPerWindow+1 {
		s.recordRateLimited(ctx, user.UIN, channel, requestIP)
		return nil, ErrRateLimited
	}

	// Resend cooldown against the current active challenge.
	if existing, err := s.store.ActiveChallengeFor(ctx, user.UIN, channel); err == nil {
		if now.Sub(existing.LastSentAt) < s.cfg.OTP.ResendCooldown {
			return nil, ErrRateLimited
		}
		// A new OTP supersedes the previous one: the older challenge is cancelled so only one value is
		// ever valid at a time.
		if err := s.store.UpdateChallengeStatus(ctx, existing.ID, store.ChallengeCancelled); err != nil {
			return nil, err
		}
	} else if !errors.Is(err, store.ErrNotFound) {
		return nil, err
	}

	otpValue, err := GenerateOTP(s.cfg.OTP.Length)
	if err != nil {
		return nil, err
	}

	challenge := store.OTPChallenge{
		ID:              uuid.NewString(),
		UserUIN:         user.UIN,
		Channel:         channel,
		Destination:     destination,
		DestinationHash: hashDestination(destination),
		OTPHash:         s.HashOTP(user.UIN, otpValue),
		Status:          store.ChallengeActive,
		Attempts:        0,
		MaxAttempts:     s.cfg.OTP.MaxAttempts,
		SendCount:       1,
		CreatedAt:       now,
		ExpiresAt:       now.Add(s.cfg.OTP.Validity),
		LastSentAt:      now,
		RequestIP:       requestIP,
		Purpose:         purpose,
	}
	if err := s.store.CreateChallenge(ctx, challenge); err != nil {
		return nil, err
	}

	masked := MaskEmail(destination)
	if channel == ChannelSMS {
		masked = MaskPhone(destination)
	}

	// Deliver. The message body contains the OTP, so it is never logged; only the outcome is.
	started := time.Now()
	deliveryResult, derr := s.deliver(ctx, channel, destination, otpValue, user)
	latency := int(time.Since(started).Milliseconds())

	record := store.DeliveryRecord{
		ID:              uuid.NewString(),
		ChallengeID:     challenge.ID,
		Channel:         channel,
		Provider:        deliveryResult.Provider,
		ProviderMessage: deliveryResult.Reference,
		Status:          store.DeliverySent,
		LatencyMS:       latency,
		CreatedAt:       time.Now().UTC(),
	}
	if derr != nil {
		record.Status = store.DeliveryFailed
		record.ErrorCode = deliveryResult.ErrorCode
		if record.ErrorCode == "" {
			record.ErrorCode = "provider_error"
		}
	}
	if err := s.store.RecordDelivery(ctx, record); err != nil {
		s.logger.ErrorContext(ctx, "failed to record OTP delivery", "error", err)
	}

	if derr != nil {
		// The challenge is unusable if delivery failed: cancel it so it cannot be guessed later.
		_ = s.store.UpdateChallengeStatus(ctx, challenge.ID, store.ChallengeCancelled)
		s.recordEvent(ctx, store.SecurityEvent{
			EventType: "OTP_DELIVERY_FAILED", Severity: "WARNING", SubjectUIN: user.UIN,
			Status: "FAILED", IP: requestIP,
			Metadata: map[string]any{"channel": channel, "provider": deliveryResult.Provider,
				"errorCode": record.ErrorCode},
		})
		return nil, ErrDeliveryFailed
	}

	s.recordEvent(ctx, store.SecurityEvent{
		EventType: "OTP_SENT", Severity: "INFO", SubjectUIN: user.UIN, Status: "SENT", IP: requestIP,
		Metadata: map[string]any{"channel": channel, "provider": deliveryResult.Provider,
			"destination": masked},
	})

	result := &SendResult{
		ChallengeID:       challenge.ID,
		Channel:           channel,
		DestinationMasked: masked,
		ExpiresIn:         int(time.Until(challenge.ExpiresAt).Seconds()),
		ResendAfter:       int(s.cfg.OTP.ResendCooldown.Seconds()),
		Provider:          deliveryResult.Provider,
		DeliveryStatus:    store.DeliverySent,
	}
	if s.cfg.IsDevelopment() && s.cfg.OTP.ExposeInResponseInDev {
		// Development-only affordance for automated end-to-end tests. It cannot activate in any other
		// environment (validated in config.Load and re-checked here).
		result.DevelopmentOTP = otpValue
	}
	return result, nil
}

// deliver hands the message to the provider adapter for the channel.
func (s *Service) deliver(ctx context.Context, channel, destination, otpValue string,
	user *store.IdentityUser) (delivery.Result, error) {
	message := delivery.Message{
		To:         destination,
		Channel:    channel,
		OTP:        otpValue,
		Recipient:  user.GivenName,
		Purpose:    "sign-in",
		TTLMinutes: int(s.cfg.OTP.Validity.Minutes()),
	}
	if channel == ChannelEmail {
		return s.email.Send(ctx, message)
	}
	return s.sms.Send(ctx, message)
}

// Verify checks an OTP against a challenge (by id) or against the newest active challenge of an
// identifier. It returns the verified user on success.
func (s *Service) Verify(ctx context.Context, challengeID, identifier, otpValue, requestIP string) (*VerifyResult, error) {
	otpValue = strings.TrimSpace(otpValue)
	if otpValue == "" {
		return nil, ErrIncorrectOTP
	}

	var challenge *store.OTPChallenge
	var err error
	if challengeID != "" {
		challenge, err = s.store.GetChallenge(ctx, challengeID)
		if errors.Is(err, store.ErrNotFound) {
			return nil, ErrNoActiveChallenge
		}
	} else {
		user, userErr := s.store.GetUserByIdentifier(ctx, identifier)
		if userErr != nil {
			return nil, ErrUnknownIdentifier
		}
		challenge, err = s.store.ActiveChallengeFor(ctx, user.UIN, ChannelEmail)
		if errors.Is(err, store.ErrNotFound) {
			challenge, err = s.store.ActiveChallengeFor(ctx, user.UIN, ChannelSMS)
		}
		if errors.Is(err, store.ErrNotFound) {
			return nil, ErrNoActiveChallenge
		}
	}
	if err != nil {
		return nil, err
	}

	now := time.Now().UTC()
	switch challenge.Status {
	case store.ChallengeVerified, store.ChallengeConsumed:
		return nil, ErrAlreadyUsed
	case store.ChallengeLocked:
		return nil, ErrTooManyAttempts
	case store.ChallengeCancelled:
		return nil, ErrNoActiveChallenge
	case store.ChallengeExpired:
		return nil, ErrExpired
	}
	if now.After(challenge.ExpiresAt) {
		_ = s.store.UpdateChallengeStatus(ctx, challenge.ID, store.ChallengeExpired)
		s.recordEvent(ctx, store.SecurityEvent{
			EventType: "OTP_EXPIRED", Severity: "INFO", SubjectUIN: challenge.UserUIN,
			Status: "EXPIRED", IP: requestIP,
			Metadata: map[string]any{"channel": challenge.Channel},
		})
		return nil, ErrExpired
	}

	expected := s.HashOTP(challenge.UserUIN, otpValue)
	if !hmac.Equal([]byte(expected), []byte(challenge.OTPHash)) {
		attempts, incErr := s.store.IncrementAttempts(ctx, challenge.ID)
		if incErr != nil {
			return nil, incErr
		}
		s.recordEvent(ctx, store.SecurityEvent{
			EventType: "OTP_FAILED", Severity: "WARNING", SubjectUIN: challenge.UserUIN,
			Status: "FAILED", IP: requestIP,
			Metadata: map[string]any{"channel": challenge.Channel, "attempt": attempts,
				"maxAttempts": challenge.MaxAttempts},
		})
		if attempts >= challenge.MaxAttempts {
			_ = s.store.UpdateChallengeStatus(ctx, challenge.ID, store.ChallengeLocked)
			return nil, ErrTooManyAttempts
		}
		return nil, ErrIncorrectOTP
	}

	// Correct OTP: mark verified then consumed (single use).
	if err := s.store.UpdateChallengeStatus(ctx, challenge.ID, store.ChallengeVerified); err != nil {
		return nil, err
	}
	if err := s.store.UpdateChallengeStatus(ctx, challenge.ID, store.ChallengeConsumed); err != nil {
		return nil, err
	}

	user, err := s.store.GetUserByUIN(ctx, challenge.UserUIN)
	if err != nil {
		return nil, err
	}

	s.recordEvent(ctx, store.SecurityEvent{
		EventType: "OTP_VERIFIED", Severity: "INFO", SubjectUIN: user.UIN, Status: "SUCCESS", IP: requestIP,
		Metadata: map[string]any{"channel": challenge.Channel},
	})

	return &VerifyResult{UIN: user.UIN, Email: user.Email, Phone: user.Phone}, nil
}

// recordEvent stores a security event (best effort: a failure must never break the OTP flow) and
// mirrors user-visible events into the notification centre.
func (s *Service) recordEvent(ctx context.Context, event store.SecurityEvent) {
	if s.recorder == nil {
		return
	}
	event.ID = uuid.NewString()
	event.CreatedAt = time.Now().UTC()
	s.recorder.RecordSecurityEvent(ctx, event)
}

// recordRateLimited records a throttled OTP request as a suspicious repeated request.
func (s *Service) recordRateLimited(ctx context.Context, uin, channel, requestIP string) {
	s.recordEvent(ctx, store.SecurityEvent{
		EventType: "OTP_RATE_LIMITED", Severity: "WARNING", SubjectUIN: uin, Status: "BLOCKED",
		IP: requestIP, Metadata: map[string]any{"channel": channel},
	})
}
