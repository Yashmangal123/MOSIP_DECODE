package otp_test

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/mosip/esignet-platform/internal/config"
	"github.com/mosip/esignet-platform/internal/delivery"
	"github.com/mosip/esignet-platform/internal/otp"
	"github.com/mosip/esignet-platform/internal/store"
)

// memoryStore is an in-memory Repository double.
type memoryStore struct {
	mu         sync.Mutex
	users      map[string]store.IdentityUser
	challenges map[string]*store.OTPChallenge
	deliveries []store.DeliveryRecord
	seq        int
}

func newMemoryStore() *memoryStore {
	return &memoryStore{
		users: map[string]store.IdentityUser{
			"1990010112345678": {
				UIN: "1990010112345678", FullName: "Asha Verma", GivenName: "Asha",
				Email: "asha.verma@example.com", Phone: "+919000000001",
			},
			"nophone": {UIN: "nophone", FullName: "No Phone", Email: "nophone@example.com"},
		},
		challenges: map[string]*store.OTPChallenge{},
	}
}

func (m *memoryStore) GetUserByIdentifier(_ context.Context, identifier string) (*store.IdentityUser, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, user := range m.users {
		if user.UIN == identifier || strings.EqualFold(user.Email, identifier) || user.Phone == identifier {
			copied := user
			return &copied, nil
		}
	}
	return nil, store.ErrNotFound
}

func (m *memoryStore) GetUserByUIN(_ context.Context, uin string) (*store.IdentityUser, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	user, ok := m.users[uin]
	if !ok {
		return nil, store.ErrNotFound
	}
	copied := user
	return &copied, nil
}

func (m *memoryStore) CountSendsSince(_ context.Context, uin, requestIP string, since time.Time) (int, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	count := 0
	for _, challenge := range m.challenges {
		if challenge.CreatedAt.After(since) && (challenge.UserUIN == uin || challenge.RequestIP == requestIP) {
			count++
		}
	}
	return count, nil
}

func (m *memoryStore) ActiveChallengeFor(_ context.Context, uin, channel string) (*store.OTPChallenge, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	var newest *store.OTPChallenge
	for _, challenge := range m.challenges {
		if challenge.UserUIN != uin || challenge.Channel != channel ||
			challenge.Status != store.ChallengeActive {
			continue
		}
		if newest == nil || challenge.CreatedAt.After(newest.CreatedAt) {
			newest = challenge
		}
	}
	if newest == nil {
		return nil, store.ErrNotFound
	}
	copied := *newest
	return &copied, nil
}

func (m *memoryStore) GetChallenge(_ context.Context, id string) (*store.OTPChallenge, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	challenge, ok := m.challenges[id]
	if !ok {
		return nil, store.ErrNotFound
	}
	copied := *challenge
	return &copied, nil
}

func (m *memoryStore) CreateChallenge(_ context.Context, challenge store.OTPChallenge) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	copied := challenge
	m.challenges[challenge.ID] = &copied
	m.seq++
	return nil
}

func (m *memoryStore) UpdateChallengeStatus(_ context.Context, id, status string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	challenge, ok := m.challenges[id]
	if !ok {
		return store.ErrNotFound
	}
	challenge.Status = status
	if status == store.ChallengeVerified {
		now := time.Now().UTC()
		challenge.VerifiedAt = &now
	}
	return nil
}

func (m *memoryStore) IncrementAttempts(_ context.Context, id string) (int, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	challenge, ok := m.challenges[id]
	if !ok {
		return 0, store.ErrNotFound
	}
	challenge.Attempts++
	return challenge.Attempts, nil
}

func (m *memoryStore) RecordDelivery(_ context.Context, record store.DeliveryRecord) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.deliveries = append(m.deliveries, record)
	return nil
}

// captureSender is a delivery.Sender that records the messages it receives.
type captureSender struct {
	mu       sync.Mutex
	messages []delivery.Message
	failWith error
}

func (c *captureSender) Send(_ context.Context, message delivery.Message) (delivery.Result, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.messages = append(c.messages, message)
	if c.failWith != nil {
		return delivery.Result{Provider: "capture", ErrorCode: "provider_error"}, c.failWith
	}
	return delivery.Result{Provider: "capture", Reference: "ref-1", Delivered: true}, nil
}
func (c *captureSender) ProviderName() string { return "capture" }
func (c *captureSender) IsReal() bool         { return true }

// recorder captures security events.
type recorder struct {
	mu     sync.Mutex
	events []store.SecurityEvent
}

func (r *recorder) RecordSecurityEvent(_ context.Context, event store.SecurityEvent) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.events = append(r.events, event)
}

func (r *recorder) Notify(_ context.Context, _ store.Notification) {}

func (r *recorder) eventTypes() []string {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]string, 0, len(r.events))
	for _, event := range r.events {
		out = append(out, event.EventType)
	}
	return out
}

// testConfig returns a configuration suitable for the OTP service tests.
func testConfig() *config.Config {
	return &config.Config{
		// Development mode is used so the send response exposes the generated OTP and the tests do not
		// have to read it out of the delivery transport. The production behaviour is covered separately
		// by TestSendOTP/does_not_expose_the_OTP_outside_development.
		Environment: "development",
		OTP: config.OTPConfig{
			Length:                6,
			Validity:              5 * time.Minute,
			MaxAttempts:           3,
			ResendCooldown:        30 * time.Second,
			MaxSendsPerWindow:     5,
			RateWindow:            15 * time.Minute,
			Pepper:                "test-pepper",
			ExposeInResponseInDev: true,
		},
	}
}

// newService wires the OTP service with the given doubles.
func newService(t *testing.T) (*otp.Service, *memoryStore, *captureSender, *captureSender, *recorder) {
	t.Helper()
	st := newMemoryStore()
	emailSender := &captureSender{}
	smsSender := &captureSender{}
	events := &recorder{}
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	return otp.NewService(testConfig(), st, emailSender, smsSender, events, logger), st,
		emailSender, smsSender, events
}

func TestGenerateOTP(t *testing.T) {
	tests := []struct {
		name   string
		length int
	}{
		{name: "six digits", length: 6},
		{name: "eight digits", length: 8},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			value, err := otp.GenerateOTP(test.length)
			require.NoError(t, err)
			assert.Len(t, value, test.length)
			for _, r := range value {
				assert.GreaterOrEqual(t, r, '0')
				assert.LessOrEqual(t, r, '9')
			}
		})
	}

	t.Run("rejects a non-positive length", func(t *testing.T) {
		_, err := otp.GenerateOTP(0)
		assert.Error(t, err)
	})
}

func TestGenerateOTPIsNotConstant(t *testing.T) {
	seen := map[string]bool{}
	for i := 0; i < 50; i++ {
		value, err := otp.GenerateOTP(6)
		require.NoError(t, err)
		seen[value] = true
	}
	// 50 draws from a 10^6 space must not collide often; a constant generator would yield one value.
	assert.Greater(t, len(seen), 40)
}

func TestHashOTP(t *testing.T) {
	service, _, _, _, _ := newService(t)

	t.Run("is deterministic", func(t *testing.T) {
		first := service.HashOTP("uin-1", "123456")
		second := service.HashOTP("uin-1", "123456")
		assert.Equal(t, first, second)
	})

	t.Run("binds the digest to the user", func(t *testing.T) {
		assert.NotEqual(t, service.HashOTP("uin-1", "123456"), service.HashOTP("uin-2", "123456"))
	})

	t.Run("differs per OTP", func(t *testing.T) {
		assert.NotEqual(t, service.HashOTP("uin-1", "123456"), service.HashOTP("uin-1", "123457"))
	})

	t.Run("does not contain the OTP", func(t *testing.T) {
		assert.NotContains(t, service.HashOTP("uin-1", "123456"), "123456")
	})
}

func TestMasking(t *testing.T) {
	assert.Equal(t, "a***@example.com", otp.MaskEmail("asha@example.com"))
	assert.Equal(t, "***", otp.MaskEmail("invalid"))
	assert.Equal(t, "*********0001", otp.MaskPhone("+919000000001"))
	assert.Equal(t, "****", otp.MaskPhone("0001"), "a very short number is masked completely")
}

func TestSendOTP(t *testing.T) {
	t.Run("delivers over email by default", func(t *testing.T) {
		service, st, emailSender, smsSender, events := newService(t)

		result, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail,
			"sign-in", "10.0.0.1")
		require.NoError(t, err)

		assert.Equal(t, otp.ChannelEmail, result.Channel)
		assert.Equal(t, "a*********@example.com", result.DestinationMasked)
		assert.Equal(t, store.DeliverySent, result.DeliveryStatus)
		assert.Equal(t, 6, len(result.DevelopmentOTP), "development OTP is populated for tests")
		assert.Empty(t, smsSender.messages, "the SMS transport must not be used for the email channel")
		require.Len(t, emailSender.messages, 1)
		assert.Equal(t, "asha.verma@example.com", emailSender.messages[0].To)

		// The stored challenge must not contain the plaintext OTP.
		stored := st.challenges[result.ChallengeID]
		require.NotNil(t, stored)
		assert.NotEqual(t, result.DevelopmentOTP, stored.OTPHash)
		assert.Len(t, stored.OTPHash, 64)
		assert.NotContains(t, stored.OTPHash, result.DevelopmentOTP)

		assert.Contains(t, events.eventTypes(), "OTP_SENT")
	})

	t.Run("delivers over SMS when requested and validates the destination", func(t *testing.T) {
		service, _, emailSender, smsSender, _ := newService(t)

		result, err := service.Send(context.Background(), "1990010112345678", otp.ChannelSMS, "", "10.0.0.1")
		require.NoError(t, err)
		assert.Equal(t, otp.ChannelSMS, result.Channel)
		require.Len(t, smsSender.messages, 1)
		assert.Equal(t, "+919000000001", smsSender.messages[0].To)
		assert.Empty(t, emailSender.messages)
	})

	t.Run("rejects an unknown identifier", func(t *testing.T) {
		service, _, _, _, _ := newService(t)
		_, err := service.Send(context.Background(), "nobody@example.com", otp.ChannelEmail, "", "")
		assert.ErrorIs(t, err, otp.ErrUnknownIdentifier)
	})

	t.Run("rejects an unsupported channel", func(t *testing.T) {
		service, _, _, _, _ := newService(t)
		_, err := service.Send(context.Background(), "asha.verma@example.com", "whatsapp", "", "")
		assert.ErrorIs(t, err, otp.ErrInvalidChannel)
	})

	t.Run("fails when the user has no phone number", func(t *testing.T) {
		service, _, _, _, _ := newService(t)
		_, err := service.Send(context.Background(), "nophone@example.com", otp.ChannelSMS, "", "")
		assert.ErrorIs(t, err, otp.ErrUnknownIdentifier)
	})

	t.Run("cancels the challenge when delivery fails", func(t *testing.T) {
		service, st, emailSender, _, events := newService(t)
		emailSender.failWith = errors.New("smtp down")

		_, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		assert.ErrorIs(t, err, otp.ErrDeliveryFailed)
		require.Len(t, st.challenges, 1)
		for _, challenge := range st.challenges {
			assert.Equal(t, store.ChallengeCancelled, challenge.Status,
				"an undelivered OTP must not remain usable")
		}
		assert.Contains(t, events.eventTypes(), "OTP_DELIVERY_FAILED")
		require.Len(t, st.deliveries, 1)
		assert.Equal(t, store.DeliveryFailed, st.deliveries[0].Status)
	})

	t.Run("enforces the resend cooldown", func(t *testing.T) {
		service, _, _, _, _ := newService(t)
		_, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)

		_, err = service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		assert.ErrorIs(t, err, otp.ErrRateLimited)
	})

	t.Run("supersedes the previous OTP after the cooldown elapses", func(t *testing.T) {
		service, st, _, _, _ := newService(t)
		first, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)

		// Age the first challenge so the cooldown has passed.
		for _, challenge := range st.challenges {
			challenge.LastSentAt = time.Now().Add(-2 * time.Minute)
			challenge.CreatedAt = time.Now().Add(-2 * time.Minute)
		}

		second, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)
		assert.NotEqual(t, first.ChallengeID, second.ChallengeID)
		assert.Equal(t, store.ChallengeCancelled, st.challenges[first.ChallengeID].Status)
		assert.Equal(t, store.ChallengeActive, st.challenges[second.ChallengeID].Status)
	})

	t.Run("enforces the sliding send window", func(t *testing.T) {
		service, st, _, _, _ := newService(t)
		// Fill the window with older challenges that no longer block the cooldown.
		for i := 0; i < 6; i++ {
			created := time.Now().Add(-2 * time.Minute)
			id := "seed-" + string(rune('a'+i))
			st.challenges[id] = &store.OTPChallenge{
				ID: id, UserUIN: "1990010112345678", Channel: otp.ChannelEmail,
				Status: store.ChallengeCancelled, CreatedAt: created, LastSentAt: created,
			}
		}
		_, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		assert.ErrorIs(t, err, otp.ErrRateLimited)
	})

	t.Run("does not expose the OTP outside development", func(t *testing.T) {
		st := newMemoryStore()
		cfg := testConfig()
		cfg.Environment = "production"
		cfg.OTP.ExposeInResponseInDev = true // must still be ignored
		service := otp.NewService(cfg, st, &captureSender{}, &captureSender{}, nil,
			slog.New(slog.NewTextHandler(io.Discard, nil)))

		result, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)
		assert.Empty(t, result.DevelopmentOTP)
	})
}

func TestVerifyOTP(t *testing.T) {
	t.Run("verifies the correct OTP once", func(t *testing.T) {
		service, st, _, _, events := newService(t)
		sent, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)

		result, err := service.Verify(context.Background(), sent.ChallengeID, "", sent.DevelopmentOTP, "")
		require.NoError(t, err)
		assert.Equal(t, "1990010112345678", result.UIN)
		assert.Equal(t, store.ChallengeConsumed, st.challenges[sent.ChallengeID].Status)
		assert.Contains(t, events.eventTypes(), "OTP_VERIFIED")

		// Replay protection: the same OTP can never be verified again.
		_, err = service.Verify(context.Background(), sent.ChallengeID, "", sent.DevelopmentOTP, "")
		assert.ErrorIs(t, err, otp.ErrAlreadyUsed)
	})

	t.Run("rejects an incorrect OTP and counts the attempt", func(t *testing.T) {
		service, st, _, _, events := newService(t)
		sent, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)

		wrong := "000000"
		if sent.DevelopmentOTP == wrong {
			wrong = "111111"
		}
		_, err = service.Verify(context.Background(), sent.ChallengeID, "", wrong, "")
		assert.ErrorIs(t, err, otp.ErrIncorrectOTP)
		assert.Equal(t, 1, st.challenges[sent.ChallengeID].Attempts)
		assert.Contains(t, events.eventTypes(), "OTP_FAILED")
	})

	t.Run("locks the challenge after the maximum attempts", func(t *testing.T) {
		service, st, _, _, _ := newService(t)
		sent, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)

		wrong := "000000"
		if sent.DevelopmentOTP == wrong {
			wrong = "111111"
		}
		var lastErr error
		for i := 0; i < 3; i++ {
			_, lastErr = service.Verify(context.Background(), sent.ChallengeID, "", wrong, "")
		}
		assert.ErrorIs(t, lastErr, otp.ErrTooManyAttempts)
		assert.Equal(t, store.ChallengeLocked, st.challenges[sent.ChallengeID].Status)

		// Even the correct OTP no longer works.
		_, err = service.Verify(context.Background(), sent.ChallengeID, "", sent.DevelopmentOTP, "")
		assert.ErrorIs(t, err, otp.ErrTooManyAttempts)
	})

	t.Run("rejects an expired challenge", func(t *testing.T) {
		service, st, _, _, _ := newService(t)
		sent, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)
		st.challenges[sent.ChallengeID].ExpiresAt = time.Now().Add(-time.Minute)

		_, err = service.Verify(context.Background(), sent.ChallengeID, "", sent.DevelopmentOTP, "")
		assert.ErrorIs(t, err, otp.ErrExpired)
		assert.Equal(t, store.ChallengeExpired, st.challenges[sent.ChallengeID].Status)
	})

	t.Run("resolves the active challenge from an identifier", func(t *testing.T) {
		service, _, _, _, _ := newService(t)
		sent, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)

		result, err := service.Verify(context.Background(), "", "asha.verma@example.com",
			sent.DevelopmentOTP, "")
		require.NoError(t, err)
		assert.Equal(t, "1990010112345678", result.UIN)
	})

	t.Run("rejects verification without an active challenge", func(t *testing.T) {
		service, _, _, _, _ := newService(t)
		_, err := service.Verify(context.Background(), "", "asha.verma@example.com", "123456", "")
		assert.ErrorIs(t, err, otp.ErrNoActiveChallenge)
	})

	t.Run("rejects an empty OTP", func(t *testing.T) {
		service, _, _, _, _ := newService(t)
		sent, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)
		_, err = service.Verify(context.Background(), sent.ChallengeID, "", "   ", "")
		assert.ErrorIs(t, err, otp.ErrIncorrectOTP)
	})

	t.Run("rejects a cancelled challenge", func(t *testing.T) {
		service, st, _, _, _ := newService(t)
		sent, err := service.Send(context.Background(), "asha.verma@example.com", otp.ChannelEmail, "", "")
		require.NoError(t, err)
		require.NoError(t, st.UpdateChallengeStatus(context.Background(), sent.ChallengeID,
			store.ChallengeCancelled))

		_, err = service.Verify(context.Background(), sent.ChallengeID, "", sent.DevelopmentOTP, "")
		assert.ErrorIs(t, err, otp.ErrNoActiveChallenge)
	})
}
