// Package store is the PostgreSQL persistence layer of the platform service.
//
// It owns the identity directory used by the demo identity provider, OTP challenges and delivery
// records, notifications, security events, administrator accounts and the administrative audit trail.
// OTPs are never stored in plaintext: only an HMAC-SHA256 digest of the value is persisted, together
// with its policy window and attempt counter.
package store

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// ErrNotFound is returned when a requested row does not exist.
var ErrNotFound = errors.New("not found")

// IdentityUser is a person in the demo identity directory. It is the data source of the identity
// claims eSignet releases to relying parties after a successful OTP authentication.
type IdentityUser struct {
	UIN           string
	FullName      string
	GivenName     string
	FamilyName    string
	Email         string
	Phone         string
	Birthdate     string
	Gender        string
	Address       string
	Locale        string
	Picture       string
	EmailVerified bool
	PhoneVerified bool
}

// OTPChallenge is one OTP issuance.
type OTPChallenge struct {
	ID              string
	UserUIN         string
	Channel         string
	Destination     string
	DestinationHash string
	OTPHash         string
	Status          string
	Attempts        int
	MaxAttempts     int
	SendCount       int
	CreatedAt       time.Time
	ExpiresAt       time.Time
	LastSentAt      time.Time
	VerifiedAt      *time.Time
	RequestIP       string
	Purpose         string
}

// Challenge statuses.
const (
	ChallengeActive    = "ACTIVE"
	ChallengeVerified  = "VERIFIED"
	ChallengeConsumed  = "CONSUMED"
	ChallengeExpired   = "EXPIRED"
	ChallengeLocked    = "LOCKED"
	ChallengeCancelled = "CANCELLED"
)

// DeliveryRecord is the outcome of handing an OTP to a delivery provider.
type DeliveryRecord struct {
	ID              string
	ChallengeID     string
	Channel         string
	Provider        string
	ProviderMessage string
	Status          string
	ErrorCode       string
	LatencyMS       int
	CreatedAt       time.Time
}

// Delivery statuses.
const (
	DeliverySent    = "SENT"
	DeliveryFailed  = "FAILED"
	DeliverySkipped = "SKIPPED"
)

// Notification is a user-facing notification.
type Notification struct {
	ID         string         `json:"id"`
	SubjectUIN string         `json:"subjectUin"`
	Category   string         `json:"category"`
	Title      string         `json:"title"`
	Body       string         `json:"body"`
	Severity   string         `json:"severity"`
	ReadAt     *time.Time     `json:"readAt,omitempty"`
	CreatedAt  time.Time      `json:"createdAt"`
	Metadata   map[string]any `json:"metadata,omitempty"`
}

// SecurityEvent is one entry of the security event stream.
type SecurityEvent struct {
	ID         string         `json:"id"`
	EventType  string         `json:"eventType"`
	Severity   string         `json:"severity"`
	SubjectUIN string         `json:"subjectUin,omitempty"`
	ClientID   string         `json:"clientId,omitempty"`
	SessionID  string         `json:"sessionId,omitempty"`
	Status     string         `json:"status,omitempty"`
	IP         string         `json:"ip,omitempty"`
	UserAgent  string         `json:"userAgent,omitempty"`
	Metadata   map[string]any `json:"metadata,omitempty"`
	CreatedAt  time.Time      `json:"createdAt"`
}

// AdminUser is an administrator account.
type AdminUser struct {
	ID           string
	Email        string
	PasswordHash string
	Role         string
	CreatedAt    time.Time
	LastLoginAt  *time.Time
}

// Store is the platform persistence layer.
type Store struct {
	pool   *pgxpool.Pool
	schema string
}

// New opens the connection pool and validates the schema name.
func New(ctx context.Context, databaseURL, schema string) (*Store, error) {
	if !validIdentifier(schema) {
		return nil, fmt.Errorf("invalid schema name %q", schema)
	}
	pool, err := pgxpool.New(ctx, databaseURL)
	if err != nil {
		return nil, fmt.Errorf("connect postgres: %w", err)
	}
	if err := pool.Ping(ctx); err != nil {
		pool.Close()
		return nil, fmt.Errorf("ping postgres: %w", err)
	}
	return &Store{pool: pool, schema: schema}, nil
}

// Close releases the pool.
func (s *Store) Close() { s.pool.Close() }

// Pool exposes the underlying pool (used by health checks and tests).
func (s *Store) Pool() *pgxpool.Pool { return s.pool }

// table qualifies a table name with the configured schema.
func (s *Store) table(name string) string { return s.schema + "." + name }

// validIdentifier reports whether a string is a safe SQL identifier (letters, digits, underscore).
func validIdentifier(value string) bool {
	if value == "" {
		return false
	}
	for _, r := range value {
		if !(r == '_' || (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9')) {
			return false
		}
	}
	return true
}

// ---------- identity directory ----------

// GetUserByUIN loads a user by UIN.
func (s *Store) GetUserByUIN(ctx context.Context, uin string) (*IdentityUser, error) {
	query := `SELECT uin, full_name, given_name, family_name, email, phone, birthdate, gender, address,
	                 locale, picture, email_verified, phone_verified
	          FROM ` + s.table("identity_user") + ` WHERE uin = $1`
	return s.scanUser(ctx, query, uin)
}

// GetUserByEmail loads a user by email address (case-insensitive).
func (s *Store) GetUserByEmail(ctx context.Context, email string) (*IdentityUser, error) {
	query := `SELECT uin, full_name, given_name, family_name, email, phone, birthdate, gender, address,
	                 locale, picture, email_verified, phone_verified
	          FROM ` + s.table("identity_user") + ` WHERE lower(email) = lower($1)`
	return s.scanUser(ctx, query, email)
}

// GetUserByPhone loads a user by phone number.
func (s *Store) GetUserByPhone(ctx context.Context, phone string) (*IdentityUser, error) {
	query := `SELECT uin, full_name, given_name, family_name, email, phone, birthdate, gender, address,
	                 locale, picture, email_verified, phone_verified
	          FROM ` + s.table("identity_user") + ` WHERE phone = $1`
	return s.scanUser(ctx, query, phone)
}

// GetUserByIdentifier resolves a user from any supported identifier: UIN, email or phone.
func (s *Store) GetUserByIdentifier(ctx context.Context, identifier string) (*IdentityUser, error) {
	if user, err := s.GetUserByUIN(ctx, identifier); err == nil {
		return user, nil
	} else if !errors.Is(err, ErrNotFound) {
		return nil, err
	}
	if user, err := s.GetUserByEmail(ctx, identifier); err == nil {
		return user, nil
	} else if !errors.Is(err, ErrNotFound) {
		return nil, err
	}
	return s.GetUserByPhone(ctx, identifier)
}

func (s *Store) scanUser(ctx context.Context, query string, args ...any) (*IdentityUser, error) {
	var user IdentityUser
	err := s.pool.QueryRow(ctx, query, args...).Scan(
		&user.UIN, &user.FullName, &user.GivenName, &user.FamilyName, &user.Email, &user.Phone,
		&user.Birthdate, &user.Gender, &user.Address, &user.Locale, &user.Picture,
		&user.EmailVerified, &user.PhoneVerified)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("query identity user: %w", err)
	}
	return &user, nil
}

// UpsertUser inserts or updates a user of the identity directory.
func (s *Store) UpsertUser(ctx context.Context, user IdentityUser) error {
	query := `INSERT INTO ` + s.table("identity_user") + `
		(uin, full_name, given_name, family_name, email, phone, birthdate, gender, address, locale,
		 picture, email_verified, phone_verified, upd_dtimes)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13, now())
		ON CONFLICT (uin) DO UPDATE SET
			full_name = EXCLUDED.full_name, given_name = EXCLUDED.given_name,
			family_name = EXCLUDED.family_name, email = EXCLUDED.email, phone = EXCLUDED.phone,
			birthdate = EXCLUDED.birthdate, gender = EXCLUDED.gender, address = EXCLUDED.address,
			locale = EXCLUDED.locale, picture = EXCLUDED.picture,
			email_verified = EXCLUDED.email_verified, phone_verified = EXCLUDED.phone_verified,
			upd_dtimes = now()`
	_, err := s.pool.Exec(ctx, query, user.UIN, user.FullName, user.GivenName, user.FamilyName,
		user.Email, user.Phone, user.Birthdate, user.Gender, user.Address, user.Locale, user.Picture,
		user.EmailVerified, user.PhoneVerified)
	if err != nil {
		return fmt.Errorf("upsert identity user: %w", err)
	}
	return nil
}

// ---------- OTP challenges ----------

// CreateChallenge persists a new OTP challenge.
func (s *Store) CreateChallenge(ctx context.Context, challenge OTPChallenge) error {
	query := `INSERT INTO ` + s.table("otp_challenge") + `
		(id, user_uin, channel, destination, destination_hash, otp_hash, challenge_status, attempts,
		 max_attempts, send_count, cr_dtimes, expiry_dtimes, last_sent_dtimes, request_ip, purpose)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`
	_, err := s.pool.Exec(ctx, query, challenge.ID, challenge.UserUIN, challenge.Channel,
		challenge.Destination, challenge.DestinationHash, challenge.OTPHash, challenge.Status,
		challenge.Attempts, challenge.MaxAttempts, challenge.SendCount, challenge.CreatedAt,
		challenge.ExpiresAt, challenge.LastSentAt, challenge.RequestIP, challenge.Purpose)
	if err != nil {
		return fmt.Errorf("create otp challenge: %w", err)
	}
	return nil
}

// GetChallenge loads a challenge by id.
func (s *Store) GetChallenge(ctx context.Context, id string) (*OTPChallenge, error) {
	query := `SELECT id, user_uin, channel, destination, destination_hash, otp_hash, challenge_status,
	                 attempts, max_attempts, send_count, cr_dtimes, expiry_dtimes, last_sent_dtimes,
	                 verified_dtimes, request_ip, COALESCE(purpose, '')
	          FROM ` + s.table("otp_challenge") + ` WHERE id = $1`
	var challenge OTPChallenge
	err := s.pool.QueryRow(ctx, query, id).Scan(&challenge.ID, &challenge.UserUIN, &challenge.Channel,
		&challenge.Destination, &challenge.DestinationHash, &challenge.OTPHash, &challenge.Status,
		&challenge.Attempts, &challenge.MaxAttempts, &challenge.SendCount, &challenge.CreatedAt,
		&challenge.ExpiresAt, &challenge.LastSentAt, &challenge.VerifiedAt, &challenge.RequestIP,
		&challenge.Purpose)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("get otp challenge: %w", err)
	}
	return &challenge, nil
}

// ActiveChallengeFor returns the newest active challenge of a user on a channel, if any. It is used to
// enforce the resend cooldown and to invalidate a previous OTP when a new one is requested.
func (s *Store) ActiveChallengeFor(ctx context.Context, uin, channel string) (*OTPChallenge, error) {
	query := `SELECT id, user_uin, channel, destination, destination_hash, otp_hash, challenge_status,
	                 attempts, max_attempts, send_count, cr_dtimes, expiry_dtimes, last_sent_dtimes,
	                 verified_dtimes, request_ip, COALESCE(purpose, '')
	          FROM ` + s.table("otp_challenge") + `
	          WHERE user_uin = $1 AND channel = $2 AND challenge_status = $3
	          ORDER BY cr_dtimes DESC LIMIT 1`
	var challenge OTPChallenge
	err := s.pool.QueryRow(ctx, query, uin, channel, ChallengeActive).Scan(&challenge.ID,
		&challenge.UserUIN, &challenge.Channel, &challenge.Destination, &challenge.DestinationHash,
		&challenge.OTPHash, &challenge.Status, &challenge.Attempts, &challenge.MaxAttempts,
		&challenge.SendCount, &challenge.CreatedAt, &challenge.ExpiresAt, &challenge.LastSentAt,
		&challenge.VerifiedAt, &challenge.RequestIP, &challenge.Purpose)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("get active otp challenge: %w", err)
	}
	return &challenge, nil
}

// CountSendsSince counts challenges created for a user or IP since a point in time (rate limiting).
func (s *Store) CountSendsSince(ctx context.Context, uin, requestIP string, since time.Time) (int, error) {
	query := `SELECT count(*) FROM ` + s.table("otp_challenge") + `
	          WHERE cr_dtimes >= $1 AND (user_uin = $2 OR ($3 <> '' AND request_ip = $3))`
	var count int
	if err := s.pool.QueryRow(ctx, query, since, uin, requestIP).Scan(&count); err != nil {
		return 0, fmt.Errorf("count otp sends: %w", err)
	}
	return count, nil
}

// UpdateChallengeStatus transitions a challenge to a terminal status.
func (s *Store) UpdateChallengeStatus(ctx context.Context, id, status string) error {
	// The parameter is cast explicitly because it is referenced twice in the statement; without the cast
	// PostgreSQL cannot deduce a single type for it (SQLSTATE 42P08).
	query := `UPDATE ` + s.table("otp_challenge") + `
	          SET challenge_status = $1::varchar,
	              verified_dtimes = CASE WHEN $1::varchar = 'VERIFIED' THEN now() ELSE verified_dtimes END
	          WHERE id = $2::uuid`
	if _, err := s.pool.Exec(ctx, query, status, id); err != nil {
		return fmt.Errorf("update otp challenge status: %w", err)
	}
	return nil
}

// IncrementAttempts records a failed verification and returns the new attempt count.
func (s *Store) IncrementAttempts(ctx context.Context, id string) (int, error) {
	query := `UPDATE ` + s.table("otp_challenge") + ` SET attempts = attempts + 1
	          WHERE id = $1 RETURNING attempts`
	var attempts int
	if err := s.pool.QueryRow(ctx, query, id).Scan(&attempts); err != nil {
		return 0, fmt.Errorf("increment otp attempts: %w", err)
	}
	return attempts, nil
}

// RecordDelivery stores the delivery outcome of an OTP (or of any message).
func (s *Store) RecordDelivery(ctx context.Context, record DeliveryRecord) error {
	query := `INSERT INTO ` + s.table("otp_delivery") + `
		(id, challenge_id, channel, provider, provider_message_ref, delivery_status, error_code,
		 latency_ms, cr_dtimes)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`
	_, err := s.pool.Exec(ctx, query, record.ID, record.ChallengeID, record.Channel, record.Provider,
		record.ProviderMessage, record.Status, record.ErrorCode, record.LatencyMS, record.CreatedAt)
	if err != nil {
		return fmt.Errorf("record otp delivery: %w", err)
	}
	return nil
}

// DeliveryStats aggregates OTP delivery outcomes per channel for the admin console.
type DeliveryStats struct {
	Channel      string  `json:"channel"`
	Provider     string  `json:"provider"`
	Sent         int     `json:"sent"`
	Failed       int     `json:"failed"`
	SuccessRate  float64 `json:"successRate"`
	AvgLatencyMS float64 `json:"avgLatencyMs"`
}

// GetDeliveryStats returns delivery counts grouped by channel and provider since a point in time.
func (s *Store) GetDeliveryStats(ctx context.Context, since time.Time) ([]DeliveryStats, error) {
	query := `SELECT channel, provider,
	                 count(*) FILTER (WHERE delivery_status = 'SENT') AS sent,
	                 count(*) FILTER (WHERE delivery_status = 'FAILED') AS failed,
	                 COALESCE(avg(latency_ms) FILTER (WHERE latency_ms > 0), 0) AS avg_latency
	          FROM ` + s.table("otp_delivery") + `
	          WHERE cr_dtimes >= $1
	          GROUP BY channel, provider ORDER BY channel`
	rows, err := s.pool.Query(ctx, query, since)
	if err != nil {
		return nil, fmt.Errorf("delivery stats: %w", err)
	}
	defer rows.Close()

	stats := make([]DeliveryStats, 0)
	for rows.Next() {
		var row DeliveryStats
		if err := rows.Scan(&row.Channel, &row.Provider, &row.Sent, &row.Failed, &row.AvgLatencyMS); err != nil {
			return nil, fmt.Errorf("delivery stats: %w", err)
		}
		total := row.Sent + row.Failed
		if total > 0 {
			row.SuccessRate = float64(row.Sent) / float64(total) * 100
		}
		stats = append(stats, row)
	}
	return stats, rows.Err()
}

// OTPVerificationStats aggregates verification outcomes for the admin console.
type OTPVerificationStats struct {
	Requested   int     `json:"requested"`
	Verified    int     `json:"verified"`
	Failed      int     `json:"failed"`
	Expired     int     `json:"expired"`
	Locked      int     `json:"locked"`
	SuccessRate float64 `json:"successRate"`
}

// GetOTPVerificationStats returns challenge outcome counts since a point in time.
func (s *Store) GetOTPVerificationStats(ctx context.Context, since time.Time) (OTPVerificationStats, error) {
	query := `SELECT count(*) AS requested,
	                 count(*) FILTER (WHERE challenge_status IN ('VERIFIED','CONSUMED')) AS verified,
	                 count(*) FILTER (WHERE attempts > 0) AS failed,
	                 count(*) FILTER (WHERE challenge_status = 'EXPIRED') AS expired,
	                 count(*) FILTER (WHERE challenge_status = 'LOCKED') AS locked
	          FROM ` + s.table("otp_challenge") + ` WHERE cr_dtimes >= $1`
	var stats OTPVerificationStats
	if err := s.pool.QueryRow(ctx, query, since).Scan(&stats.Requested, &stats.Verified, &stats.Failed,
		&stats.Expired, &stats.Locked); err != nil {
		return stats, fmt.Errorf("otp verification stats: %w", err)
	}
	if stats.Requested > 0 {
		stats.SuccessRate = float64(stats.Verified) / float64(stats.Requested) * 100
	}
	return stats, nil
}

// ---------- notifications ----------

// CreateNotification stores a notification for a user.
func (s *Store) CreateNotification(ctx context.Context, notification Notification) error {
	query := `INSERT INTO ` + s.table("notification") + `
		(id, subject_uin, category, title, body, severity, cr_dtimes, metadata)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`
	_, err := s.pool.Exec(ctx, query, notification.ID, notification.SubjectUIN, notification.Category,
		notification.Title, notification.Body, notification.Severity, notification.CreatedAt,
		notification.Metadata)
	if err != nil {
		return fmt.Errorf("create notification: %w", err)
	}
	return nil
}

// ListNotifications returns a user's notifications, newest first.
func (s *Store) ListNotifications(ctx context.Context, subjectUIN string, limit int) ([]Notification, error) {
	query := `SELECT id, subject_uin, category, title, body, severity, read_dtimes, cr_dtimes, metadata
	          FROM ` + s.table("notification") + `
	          WHERE subject_uin = $1 ORDER BY cr_dtimes DESC LIMIT $2`
	rows, err := s.pool.Query(ctx, query, subjectUIN, limit)
	if err != nil {
		return nil, fmt.Errorf("list notifications: %w", err)
	}
	defer rows.Close()

	out := make([]Notification, 0)
	for rows.Next() {
		var n Notification
		if err := rows.Scan(&n.ID, &n.SubjectUIN, &n.Category, &n.Title, &n.Body, &n.Severity,
			&n.ReadAt, &n.CreatedAt, &n.Metadata); err != nil {
			return nil, fmt.Errorf("scan notification: %w", err)
		}
		out = append(out, n)
	}
	return out, rows.Err()
}

// MarkNotificationRead marks one notification read for its owner.
func (s *Store) MarkNotificationRead(ctx context.Context, id, subjectUIN string) error {
	query := `UPDATE ` + s.table("notification") + `
	          SET read_dtimes = now() WHERE id = $1 AND subject_uin = $2`
	result, err := s.pool.Exec(ctx, query, id, subjectUIN)
	if err != nil {
		return fmt.Errorf("mark notification read: %w", err)
	}
	if result.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// UnreadNotificationCount counts unread notifications of a user.
func (s *Store) UnreadNotificationCount(ctx context.Context, subjectUIN string) (int, error) {
	query := `SELECT count(*) FROM ` + s.table("notification") + `
	          WHERE subject_uin = $1 AND read_dtimes IS NULL`
	var count int
	if err := s.pool.QueryRow(ctx, query, subjectUIN).Scan(&count); err != nil {
		return 0, fmt.Errorf("unread notifications: %w", err)
	}
	return count, nil
}

// ---------- security events ----------

// CreateSecurityEvent appends a security event.
func (s *Store) CreateSecurityEvent(ctx context.Context, event SecurityEvent) error {
	query := `INSERT INTO ` + s.table("security_event") + `
		(id, event_type, severity, subject_uin, client_id, session_id, event_status, request_ip,
		 user_agent, metadata, cr_dtimes)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`
	_, err := s.pool.Exec(ctx, query, event.ID, event.EventType, event.Severity, event.SubjectUIN,
		event.ClientID, event.SessionID, event.Status, event.IP, event.UserAgent, event.Metadata,
		event.CreatedAt)
	if err != nil {
		return fmt.Errorf("create security event: %w", err)
	}
	return nil
}

// SecurityEventFilter narrows a security event query.
type SecurityEventFilter struct {
	EventType string
	Severity  string
	ClientID  string
	Subject   string
	Since     time.Time
	Limit     int
}

// ListSecurityEvents returns security events matching the filter, newest first.
func (s *Store) ListSecurityEvents(ctx context.Context, filter SecurityEventFilter) ([]SecurityEvent, error) {
	if filter.Limit <= 0 || filter.Limit > 500 {
		filter.Limit = 100
	}
	query := `SELECT id, event_type, severity, COALESCE(subject_uin,''), COALESCE(client_id,''),
	                 COALESCE(session_id,''), event_status, COALESCE(request_ip,''),
	                 COALESCE(user_agent,''), metadata, cr_dtimes
	          FROM ` + s.table("security_event") + `
	          WHERE ($1 = '' OR event_type = $1)
	            AND ($2 = '' OR severity = $2)
	            AND ($3 = '' OR client_id = $3)
	            AND ($4 = '' OR subject_uin = $4)
	            AND ($5::timestamptz IS NULL OR cr_dtimes >= $5)
	          ORDER BY cr_dtimes DESC LIMIT $6`
	var since *time.Time
	if !filter.Since.IsZero() {
		since = &filter.Since
	}
	rows, err := s.pool.Query(ctx, query, filter.EventType, filter.Severity, filter.ClientID,
		filter.Subject, since, filter.Limit)
	if err != nil {
		return nil, fmt.Errorf("list security events: %w", err)
	}
	defer rows.Close()

	events := make([]SecurityEvent, 0)
	for rows.Next() {
		var event SecurityEvent
		if err := rows.Scan(&event.ID, &event.EventType, &event.Severity, &event.SubjectUIN,
			&event.ClientID, &event.SessionID, &event.Status, &event.IP, &event.UserAgent,
			&event.Metadata, &event.CreatedAt); err != nil {
			return nil, fmt.Errorf("scan security event: %w", err)
		}
		events = append(events, event)
	}
	return events, rows.Err()
}

// SeverityCount is one bucket of the security event summary.
type SeverityCount struct {
	Severity string `json:"severity"`
	Count    int    `json:"count"`
}

// GetSecurityEventSummary counts events by severity since a point in time.
func (s *Store) GetSecurityEventSummary(ctx context.Context, since time.Time) ([]SeverityCount, error) {
	query := `SELECT severity, count(*) FROM ` + s.table("security_event") + `
	          WHERE cr_dtimes >= $1 GROUP BY severity`
	rows, err := s.pool.Query(ctx, query, since)
	if err != nil {
		return nil, fmt.Errorf("security event summary: %w", err)
	}
	defer rows.Close()

	out := make([]SeverityCount, 0)
	for rows.Next() {
		var bucket SeverityCount
		if err := rows.Scan(&bucket.Severity, &bucket.Count); err != nil {
			return nil, fmt.Errorf("security event summary: %w", err)
		}
		out = append(out, bucket)
	}
	return out, rows.Err()
}

// AuthActivityPoint is one day of authentication activity for the analytics charts.
type AuthActivityPoint struct {
	Day       string `json:"day"`
	EventType string `json:"eventType"`
	Count     int    `json:"count"`
}

// GetAuthActivity returns daily counts of authentication-related security events.
func (s *Store) GetAuthActivity(ctx context.Context, since time.Time) ([]AuthActivityPoint, error) {
	query := `SELECT to_char(date_trunc('day', cr_dtimes), 'YYYY-MM-DD') AS day, event_type, count(*)
	          FROM ` + s.table("security_event") + `
	          WHERE cr_dtimes >= $1
	            AND event_type IN ('LOGIN_SUCCESS','LOGIN_FAILED','TOKEN_EXCHANGE_SUCCESS',
	                               'TOKEN_EXCHANGE_FAILED','OTP_VERIFIED','OTP_FAILED')
	          GROUP BY day, event_type ORDER BY day`
	rows, err := s.pool.Query(ctx, query, since)
	if err != nil {
		return nil, fmt.Errorf("auth activity: %w", err)
	}
	defer rows.Close()

	out := make([]AuthActivityPoint, 0)
	for rows.Next() {
		var point AuthActivityPoint
		if err := rows.Scan(&point.Day, &point.EventType, &point.Count); err != nil {
			return nil, fmt.Errorf("auth activity: %w", err)
		}
		out = append(out, point)
	}
	return out, rows.Err()
}

// ---------- administrators ----------

// GetAdminByEmail loads an administrator by email.
func (s *Store) GetAdminByEmail(ctx context.Context, email string) (*AdminUser, error) {
	query := `SELECT id, email, password_hash, role, cr_dtimes, last_login_dtimes
	          FROM ` + s.table("admin_user") + ` WHERE lower(email) = lower($1)`
	var admin AdminUser
	err := s.pool.QueryRow(ctx, query, email).Scan(&admin.ID, &admin.Email, &admin.PasswordHash,
		&admin.Role, &admin.CreatedAt, &admin.LastLoginAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("get admin: %w", err)
	}
	return &admin, nil
}

// CountAdmins returns how many administrator accounts exist.
func (s *Store) CountAdmins(ctx context.Context) (int, error) {
	query := `SELECT count(*) FROM ` + s.table("admin_user")
	var count int
	if err := s.pool.QueryRow(ctx, query).Scan(&count); err != nil {
		return 0, fmt.Errorf("count admins: %w", err)
	}
	return count, nil
}

// CreateAdmin inserts an administrator account.
func (s *Store) CreateAdmin(ctx context.Context, admin AdminUser) error {
	query := `INSERT INTO ` + s.table("admin_user") + `
		(id, email, password_hash, role, cr_dtimes) VALUES ($1,$2,$3,$4,$5)`
	if _, err := s.pool.Exec(ctx, query, admin.ID, admin.Email, admin.PasswordHash, admin.Role,
		admin.CreatedAt); err != nil {
		return fmt.Errorf("create admin: %w", err)
	}
	return nil
}

// TouchAdminLogin records a successful administrator login.
func (s *Store) TouchAdminLogin(ctx context.Context, id string) error {
	query := `UPDATE ` + s.table("admin_user") + ` SET last_login_dtimes = now() WHERE id = $1`
	if _, err := s.pool.Exec(ctx, query, id); err != nil {
		return fmt.Errorf("touch admin login: %w", err)
	}
	return nil
}

// AuditRecord is one administrative action.
type AuditRecord struct {
	ID        string         `json:"id"`
	Actor     string         `json:"actor"`
	Action    string         `json:"action"`
	Target    string         `json:"target,omitempty"`
	Details   map[string]any `json:"details,omitempty"`
	CreatedAt time.Time      `json:"createdAt"`
}

// CreateAudit appends an administrative audit record.
func (s *Store) CreateAudit(ctx context.Context, record AuditRecord) error {
	query := `INSERT INTO ` + s.table("admin_audit") + `
		(id, actor, action, target, details, cr_dtimes) VALUES ($1,$2,$3,$4,$5,$6)`
	if _, err := s.pool.Exec(ctx, query, record.ID, record.Actor, record.Action, record.Target,
		record.Details, record.CreatedAt); err != nil {
		return fmt.Errorf("create audit record: %w", err)
	}
	return nil
}

// ListAudit returns administrative audit records, newest first.
func (s *Store) ListAudit(ctx context.Context, limit int) ([]AuditRecord, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	query := `SELECT id, actor, action, COALESCE(target,''), details, cr_dtimes
	          FROM ` + s.table("admin_audit") + ` ORDER BY cr_dtimes DESC LIMIT $1`
	rows, err := s.pool.Query(ctx, query, limit)
	if err != nil {
		return nil, fmt.Errorf("list audit: %w", err)
	}
	defer rows.Close()

	out := make([]AuditRecord, 0)
	for rows.Next() {
		var record AuditRecord
		if err := rows.Scan(&record.ID, &record.Actor, &record.Action, &record.Target, &record.Details,
			&record.CreatedAt); err != nil {
			return nil, fmt.Errorf("scan audit record: %w", err)
		}
		out = append(out, record)
	}
	return out, rows.Err()
}

// HealthCheck verifies the database is reachable.
func (s *Store) HealthCheck(ctx context.Context) error {
	if err := s.pool.Ping(ctx); err != nil {
		return fmt.Errorf("database unreachable: %w", err)
	}
	return nil
}
