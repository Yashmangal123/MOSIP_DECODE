#!/usr/bin/env bash
#
# End-to-end check of the platform service against a running instance and a real SMTP mailbox.
#
# It proves the delivery path is real: the OTP is read out of the delivered email in a REAL mailbox,
# never out of the service response. Requirements:
#   - the platform service is running (base URL in PLATFORM_URL, default http://localhost:8090)
#   - a real mailbox to read from (scripts/read_otp.py):
#       MAIL_IMAP_HOST=imap.gmail.com MAIL_IMAP_USER=you@gmail.com MAIL_IMAP_PASSWORD=<app password>
#     A local sink (.eml files in MAIL_DIR) is supported for a lab with --dir / MAIL_DIR
#   - PLATFORM_ADMIN_EMAIL / PLATFORM_ADMIN_PASSWORD match the configured administrator
#
# Exit code 0 means every assertion passed.

set -euo pipefail

PLATFORM_URL="${PLATFORM_URL:-http://localhost:8090}"
MAIL_DIR="${MAIL_DIR:-/tmp/esignet-mail}"
IDENTIFIER="${IDENTIFIER:-asha.verma@example.com}"
ADMIN_EMAIL="${PLATFORM_ADMIN_EMAIL:-admin@esignet.local}"
ADMIN_PASSWORD="${PLATFORM_ADMIN_PASSWORD:-Admin#12345}"
API_KEY="${PLATFORM_API_KEY:-local-internal-key}"

pass() { printf '  \033[32mPASS\033[0m %s\n' "$1"; }
fail() { printf '  \033[31mFAIL\033[0m %s\n' "$1"; exit 1; }
step() { printf '\n\033[1m%s\033[0m\n' "$1"; }

# jq is not assumed to be present: extract values with python3.
json() { python3 -c "import json,sys;d=json.load(sys.stdin);print(eval('d'+sys.argv[1]))" "$1"; }

step "1. Health"
status=$(curl -sf "$PLATFORM_URL/health" | json "['status']")
[ "$status" = "UP" ] && pass "service reports UP" || fail "unexpected status $status"

step "2. Send an OTP by email (real SMTP delivery)"
before=$(ls -1 "$MAIL_DIR"/*.eml 2>/dev/null | wc -l)
send_file=/tmp/otp-send.json
send_code=$(curl -s -o "$send_file" -w '%{http_code}' -X POST "$PLATFORM_URL/v1/identity/otp/send" \
  -H 'Content-Type: application/json' \
  -d "{\"identifier\":\"$IDENTIFIER\",\"channel\":\"email\"}")
if [ "$send_code" = "429" ]; then
  # The rate limiter is behaving correctly; this run simply cannot issue a new challenge yet.
  printf '  \033[33mSKIP\033[0m the OTP rate limiter is throttling %s\n' "$IDENTIFIER"
  printf '  Re-run after the window elapses, clear the otp_challenge table, or set IDENTIFIER=<another seeded user>.\n'
  exit 2
fi
[ "$send_code" = "200" ] || fail "send returned HTTP $send_code: $(cat "$send_file")"
send_body=$(cat "$send_file")
txn=$(printf '%s' "$send_body" | json "['transactionId']")
provider=$(printf '%s' "$send_body" | json "['provider']")
masked=$(printf '%s' "$send_body" | json "['maskedDestination']")
[ "$provider" = "smtp" ] && pass "delivered through the SMTP transport (provider=$provider)" \
  || fail "unexpected provider $provider"
pass "destination masked as $masked"
pass "challenge $txn created"

step "3. Read the OTP from the delivered email"
otp=""
if [ -n "${MAIL_IMAP_HOST:-}" ]; then
  where="IMAP $MAIL_IMAP_HOST"
else
  where="local sink $MAIL_DIR (lab)"
fi
for _ in $(seq 1 30); do
  otp=$(python3 "$(dirname "$0")/read_otp.py" $([ -z "${MAIL_IMAP_HOST:-}" ] && echo --dir) 2>/dev/null || true)
  [ -n "$otp" ] && break
  sleep 2
done
[ -n "$otp" ] || fail "no code found in $where — check the mailbox credentials and that the email arrived"
pass "OTP recovered from the mailbox ($where)"

step "4. The OTP reached the mailbox and matches the challenge"
# The development OTP echo is enabled for this stack; it exists so automated tests can cross-check the
# delivered message. In any other environment the field is empty, which internal/otp tests assert
# directly (TestSendOTP/does_not_expose_the_OTP_outside_development).
echoed=$(printf '%s' "$send_body" | json ".get('developmentOtp','')")
if [ -n "$echoed" ]; then
  [ "$echoed" = "$otp" ] && pass "the echoed development OTP matches the delivered email" \
    || fail "the echoed OTP ($echoed) does not match the delivered email ($otp)"
else
  pass "no OTP is echoed in the send response"
fi

step "5. Verify the OTP"
verify_body=$(curl -sf -X POST "$PLATFORM_URL/v1/identity/otp/verify" \
  -H 'Content-Type: application/json' \
  -d "{\"transactionId\":\"$txn\",\"otp\":\"$otp\"}")
verified=$(printf '%s' "$verify_body" | json "['verified']")
[ "$verified" = "True" ] && pass "OTP verified" || fail "verification failed: $verify_body"

step "6. Replay protection"
code=$(curl -s -o /tmp/otp-replay.json -w '%{http_code}' -X POST "$PLATFORM_URL/v1/identity/otp/verify" \
  -H 'Content-Type: application/json' \
  -d "{\"transactionId\":\"$txn\",\"otp\":\"$otp\"}")
[ "$code" = "400" ] && grep -q otp_already_used /tmp/otp-replay.json &&
  pass "the same OTP cannot be used twice (HTTP $code)" || fail "replay was not rejected: $code"

step "7. Wrong OTP is rejected and counted"
wrong=$([ "$otp" = "000000" ] && echo 111111 || echo 000000)
code=$(curl -s -o /tmp/otp-wrong.json -w '%{http_code}' -X POST "$PLATFORM_URL/v1/identity/otp/send" \
  -H 'Content-Type: application/json' -d "{\"identifier\":\"$IDENTIFIER\",\"channel\":\"email\"}")
code=$(curl -s -o /tmp/otp-wrong.json -w '%{http_code}' -X POST "$PLATFORM_URL/v1/identity/otp/verify" \
  -H 'Content-Type: application/json' -d "{\"identifier\":\"$IDENTIFIER\",\"otp\":\"$wrong\"}")
[ "$code" = "400" ] && grep -q incorrect_otp /tmp/otp-wrong.json &&
  pass "an incorrect OTP is rejected (HTTP $code)" || fail "unexpected response: $code"

step "8. Internal API key is enforced"
code=$(curl -s -o /dev/null -w '%{http_code}' -X POST "$PLATFORM_URL/internal/otp/verify" \
  -H 'Content-Type: application/json' -d '{"identifier":"x","otp":"y"}')
[ "$code" = "401" ] && pass "internal endpoints reject a missing API key (HTTP $code)" \
  || fail "internal endpoint answered $code without a key"
code=$(curl -s -o /dev/null -w '%{http_code}' -X POST "$PLATFORM_URL/internal/otp/verify" \
  -H "X-Platform-Api-Key: $API_KEY" -H 'Content-Type: application/json' \
  -d '{"identifier":"x","otp":"y"}')
[ "$code" = "400" ] && pass "internal endpoint accepts the configured key (HTTP $code)" \
  || fail "internal endpoint answered $code with a valid key"

step "9. Administrator login and console endpoints"
login=$(curl -sf -X POST "$PLATFORM_URL/v1/admin/login" -H 'Content-Type: application/json' \
  -d "{\"email\":\"$ADMIN_EMAIL\",\"password\":\"$ADMIN_PASSWORD\"}")
token=$(printf '%s' "$login" | json "['token']")
[ -n "$token" ] && pass "administrator token issued" || fail "no token: $login"

code=$(curl -s -o /dev/null -w '%{http_code}' "$PLATFORM_URL/v1/admin/overview")
[ "$code" = "401" ] && pass "console endpoints reject anonymous callers (HTTP $code)" \
  || fail "console endpoint answered $code anonymously"

overview=$(curl -sf "$PLATFORM_URL/v1/admin/overview" -H "Authorization: Bearer $token")
otp_requested=$(printf '%s' "$overview" | json "['otp']['requested']")
[ "$otp_requested" -ge 1 ] && pass "overview reports $otp_requested OTP challenges" \
  || fail "overview reports no OTP activity"
delivery_channel=$(printf '%s' "$overview" | json "['delivery'][0]['channel']")
pass "delivery statistics available for channel $delivery_channel"

stats=$(curl -sf "$PLATFORM_URL/v1/admin/otp/stats" -H "Authorization: Bearer $token")
sent=$(printf '%s' "$stats" | json "['delivery'][0]['sent']")
pass "OTP delivery statistics: $sent message(s) accepted by the provider"

events=$(curl -sf "$PLATFORM_URL/v1/admin/security/events?eventType=OTP_VERIFIED" -H "Authorization: Bearer $token")
event_count=$(printf '%s' "$events" | json "['events'].__len__()")
[ "$event_count" -ge 1 ] && pass "$event_count OTP_VERIFIED security event(s) recorded" \
  || fail "no OTP_VERIFIED event recorded"

audit=$(curl -sf "$PLATFORM_URL/v1/admin/audit" -H "Authorization: Bearer $token")
audit_count=$(printf '%s' "$audit" | json "['audit'].__len__()")
[ "$audit_count" -ge 1 ] && pass "$audit_count administrative audit record(s) written" \
  || fail "no audit records"

config=$(curl -sf "$PLATFORM_URL/v1/admin/config" -H "Authorization: Bearer $token")
smtp_mode=$(printf '%s' "$config" | json "['email']['mode']")
printf '%s' "$config" | grep -q 'PEPPER\|SECRET\|PASSWORD' && fail "the configuration leaks a secret" ||
  pass "effective configuration reported without secrets (email mode $smtp_mode)"

step "10. Server-Sent Events stream"
timeout 3 curl -sN "$PLATFORM_URL/v1/admin/events/stream?token=$token" > /tmp/sse.txt || true
grep -q 'event: stream.ready' /tmp/sse.txt && pass "the console stream subscribes" ||
  fail "no stream.ready frame"

printf '\n\033[32mAll platform end-to-end checks passed.\033[0m\n'
