#!/usr/bin/env bash
#
# Send a real OTP to a real mailbox (and optionally a real phone) through the platform service.
#
# Everything comes from the environment, so the same script works against Gmail, SES, MSG91, Twilio or a
# generic gateway:
#
#   export PLATFORM_SMTP_HOST=smtp.gmail.com PLATFORM_SMTP_PORT=587 PLATFORM_SMTP_TLS=starttls \
#          PLATFORM_SMTP_USERNAME=you@gmail.com PLATFORM_SMTP_PASSWORD=<app password> \
#          PLATFORM_SMTP_FROM=you@gmail.com \
#          PLATFORM_DATABASE_URL='postgres://platform:platform@127.0.0.1:5432/esignet_platform?sslmode=disable' \
#          PLATFORM_OTP_PEPPER=some-pepper PLATFORM_ADMIN_JWT_SECRET=some-secret PLATFORM_API_KEY=internal-key
#
#   bash scripts/live_otp.sh --email you@example.com [--phone +919000000001] [--code 123456]
#
# Step 1 proves the transport with verify-delivery; step 2 runs the real login OTP flow; step 3 verifies
# the code when --code is given.
set -euo pipefail

EMAIL=""; PHONE=""; CODE=""; TXN=""
while [ $# -gt 0 ]; do
  case "$1" in
    --email) EMAIL="$2"; shift 2 ;;
    --phone) PHONE="$2"; shift 2 ;;
    --code)  CODE="$2"; shift 2 ;;
    # Verify an already-issued challenge instead of sending a new OTP.
    --transaction=*) TXN="${1#*=}"; shift ;;
    --transaction) TXN="$2"; shift 2 ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done
[ -n "$EMAIL" ] || [ -n "$PHONE" ] || [ -n "$TXN" ] || { echo "provide --email/--phone, or --transaction with --code" >&2; exit 2; }
[ -z "$TXN" ] || [ -n "$CODE" ] || { echo "--transaction requires --code" >&2; exit 2; }

# Production behaviour by default: the code is never echoed in the API response, only delivered.
export PLATFORM_OTP_EXPOSE_IN_DEV="${PLATFORM_OTP_EXPOSE_IN_DEV:-false}"

BASE="${PLATFORM_URL:-http://localhost:8090}"
PORT="${PLATFORM_PORT:-8090}"
IDENTIFIER="${EMAIL:-$PHONE}"
# A deterministic UIN so re-running the script updates the same citizen instead of piling up rows.
UIN="$(printf '%s' "$IDENTIFIER" | sha256sum | cut -c1-16)"

if [ -n "$TXN" ]; then
  echo "==> verifying transaction $TXN"
  curl -s -X POST "${PLATFORM_URL:-http://localhost:8090}/v1/identity/otp/verify" \
    -H 'Content-Type: application/json' -d "{\"transactionId\":\"$TXN\",\"otp\":\"$CODE\"}"
  echo
  exit 0
fi

echo "==> building"
GO_BIN="${GO:-go}"
command -v "$GO_BIN" >/dev/null 2>&1 || GO_BIN=/usr/local/go/bin/go
"$GO_BIN" build -o bin/platform ./cmd/platform

echo "==> registering the citizen in the identity directory (uin=$UIN)"
UIN_ARG=(--uin "$UIN" --name "Live Test Citizen")
[ -n "$EMAIL" ] && UIN_ARG+=(--email "$EMAIL")
[ -n "$PHONE" ] && UIN_ARG+=(--phone "$PHONE")
./bin/platform add-user "${UIN_ARG[@]}"

echo "==> probing the transports"
PROBE=(./bin/platform verify-delivery)
[ -n "$EMAIL" ] && PROBE+=(--email "$EMAIL")
[ -n "$PHONE" ] && PROBE+=(--phone "$PHONE")
"${PROBE[@]}"

if ! curl -sf "$BASE/health" >/dev/null 2>&1; then
  echo "==> starting the service on port $PORT"
  PLATFORM_PORT="$PORT" setsid nohup ./bin/platform >> /tmp/platform-live.log 2>&1 < /dev/null &
  for _ in $(seq 1 40); do curl -sf "$BASE/health" >/dev/null 2>&1 && break; sleep 0.25; done
fi

CHANNEL=email; [ -n "$EMAIL" ] || CHANNEL=sms
echo "==> requesting a real OTP over $CHANNEL for $IDENTIFIER"
RESPONSE=$(curl -s -X POST "$BASE/v1/identity/otp/send" -H 'Content-Type: application/json' \
  -d "{\"identifier\":\"$IDENTIFIER\",\"channel\":\"$CHANNEL\"}")
echo "$RESPONSE"
TXN=$(printf '%s' "$RESPONSE" | python3 -c "import json,sys;print(json.load(sys.stdin).get('transactionId',''))")
[ -n "$TXN" ] || { echo "no transaction id: the OTP was not issued" >&2; exit 1; }

echo
echo "Check the message, then verify with:"
echo "  bash scripts/live_otp.sh --transaction $TXN --code <code from the message>"


