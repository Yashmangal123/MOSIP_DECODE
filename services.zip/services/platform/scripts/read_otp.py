#!/usr/bin/env python3
"""Read the one-time code out of the delivered email — from a real IMAP mailbox, or from a directory
of .eml files when a local sink is explicitly allowed.

The code is never read from the service response: this is what makes the end-to-end check meaningful.

Real mailbox (default):
    MAIL_IMAP_HOST=imap.gmail.com MAIL_IMAP_USER=you@gmail.com \
    MAIL_IMAP_PASSWORD=<app password> MAILBOX=INBOX python3 scripts/read_otp.py

Local sink (lab only, needs PLATFORM_ALLOW_LAB_DELIVERY=true on the service):
    MAIL_DIR=/tmp/esignet-mail python3 scripts/read_otp.py --dir
"""
import email
import imaplib
import os
import re
import sys
from email import policy

CODE = re.compile(r">\s*([0-9]{6})\s*<")


def extract(raw: bytes) -> str:
    message = email.message_from_bytes(raw, policy=policy.default)
    for part in message.walk():
        if part.get_content_type() not in ("text/html", "text/plain"):
            continue
        try:
            body = part.get_content()
        except Exception:  # noqa: BLE001 - a malformed part is skipped, not fatal
            continue
        match = CODE.search(body) or re.search(r"\b([0-9]{6})\b", body)
        if match:
            return match.group(1)
    return ""


def from_imap() -> str:
    host = os.environ["MAIL_IMAP_HOST"]
    user = os.environ["MAIL_IMAP_USER"]
    password = os.environ["MAIL_IMAP_PASSWORD"]
    mailbox = os.environ.get("MAILBOX", "INBOX")
    conn = imaplib.IMAP4_SSL(host, int(os.environ.get("MAIL_IMAP_PORT", "993")))
    try:
        conn.login(user, password)
        conn.select(mailbox)
        typ, data = conn.search(None, os.environ.get("MAIL_SEARCH", "ALL"))
        if typ != "OK" or not data or not data[0]:
            return ""
        for uid in reversed(data[0].split()[-5:]):  # newest five messages
            typ, fetched = conn.fetch(uid, "(RFC822)")
            if typ != "OK" or not fetched or not isinstance(fetched[0], tuple):
                continue
            code = extract(fetched[0][1])
            if code:
                return code
        return ""
    finally:
        try:
            conn.logout()
        except Exception:  # noqa: BLE001
            pass


def from_dir() -> str:
    directory = os.environ.get("MAIL_DIR", "/tmp/esignet-mail")
    files = sorted(
        (os.path.join(directory, name) for name in os.listdir(directory) if name.endswith(".eml")),
        key=os.path.getmtime,
        reverse=True,
    )
    for path in files[:5]:
        with open(path, "rb") as handle:
            code = extract(handle.read())
        if code:
            return code
    return ""


if __name__ == "__main__":
    try:
        print(from_dir() if "--dir" in sys.argv else from_imap())
    except KeyError as missing:
        print(f"missing environment variable {missing}", file=sys.stderr)
        print("", end="")
