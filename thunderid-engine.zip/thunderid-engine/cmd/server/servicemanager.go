// Copyright 2025-2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

// Package managers provides functionality for managing and registering system services.
package main

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"time"

	mcpsdk "github.com/modelcontextprotocol/go-sdk/mcp"

	"github.com/thunder-id/thunderid/internal/actorprovider"
	"github.com/thunder-id/thunderid/internal/agent"
	"github.com/thunder-id/thunderid/internal/agentmgtprovider"
	"github.com/thunder-id/thunderid/internal/application"
	"github.com/thunder-id/thunderid/internal/attestation"
	"github.com/thunder-id/thunderid/internal/attributecache"
	"github.com/thunder-id/thunderid/internal/authn"
	authnAssert "github.com/thunder-id/thunderid/internal/authn/assert"
	authncm "github.com/thunder-id/thunderid/internal/authn/common"
	authnconfig "github.com/thunder-id/thunderid/internal/authn/config"
	authnConsent "github.com/thunder-id/thunderid/internal/authn/consent"
	"github.com/thunder-id/thunderid/internal/authn/github"
	"github.com/thunder-id/thunderid/internal/authn/google"
	"github.com/thunder-id/thunderid/internal/authn/magiclink"
	authnOAuth "github.com/thunder-id/thunderid/internal/authn/oauth"
	authnOIDC "github.com/thunder-id/thunderid/internal/authn/oidc"
	"github.com/thunder-id/thunderid/internal/authn/openid4vp"
	"github.com/thunder-id/thunderid/internal/authn/otp"
	"github.com/thunder-id/thunderid/internal/authn/passkey"
	"github.com/thunder-id/thunderid/internal/authnprovider/defaultprovider"
	authnprovidermgr "github.com/thunder-id/thunderid/internal/authnprovider/manager"
	"github.com/thunder-id/thunderid/internal/authnprovider/restprovider"
	"github.com/thunder-id/thunderid/internal/authz"
	authzdetailexec "github.com/thunder-id/thunderid/internal/authzdetail/exec"
	authzdetailmgt "github.com/thunder-id/thunderid/internal/authzdetail/mgt"
	"github.com/thunder-id/thunderid/internal/authzen"
	"github.com/thunder-id/thunderid/internal/cert"
	"github.com/thunder-id/thunderid/internal/cimd"
	"github.com/thunder-id/thunderid/internal/connection"
	"github.com/thunder-id/thunderid/internal/connection/authzenpdp"
	"github.com/thunder-id/thunderid/internal/connection/httpconnection"
	"github.com/thunder-id/thunderid/internal/consent"
	layoutmgt "github.com/thunder-id/thunderid/internal/design/layout/mgt"
	"github.com/thunder-id/thunderid/internal/design/resolve"
	thememgt "github.com/thunder-id/thunderid/internal/design/theme/mgt"
	"github.com/thunder-id/thunderid/internal/entity"
	"github.com/thunder-id/thunderid/internal/entityprovider"
	"github.com/thunder-id/thunderid/internal/entitytype"
	flowconfig "github.com/thunder-id/thunderid/internal/flow/config"
	flowcore "github.com/thunder-id/thunderid/internal/flow/core"
	"github.com/thunder-id/thunderid/internal/flow/executor"
	"github.com/thunder-id/thunderid/internal/flow/flowexec"
	"github.com/thunder-id/thunderid/internal/flow/flowmeta"
	"github.com/thunder-id/thunderid/internal/flow/graphbuilder"
	"github.com/thunder-id/thunderid/internal/flow/interceptor"
	flowmgt "github.com/thunder-id/thunderid/internal/flow/mgt"
	flowsession "github.com/thunder-id/thunderid/internal/flow/session"
	"github.com/thunder-id/thunderid/internal/gateway"
	"github.com/thunder-id/thunderid/internal/group"
	"github.com/thunder-id/thunderid/internal/identitygovernance"
	"github.com/thunder-id/thunderid/internal/identitygovernanceprovider"
	"github.com/thunder-id/thunderid/internal/idp"
	"github.com/thunder-id/thunderid/internal/inboundclient"
	"github.com/thunder-id/thunderid/internal/notification"
	notificationconfig "github.com/thunder-id/thunderid/internal/notification/config"
	"github.com/thunder-id/thunderid/internal/notificationtemplate"
	"github.com/thunder-id/thunderid/internal/oauth"
	oauthconfig "github.com/thunder-id/thunderid/internal/oauth/config"
	"github.com/thunder-id/thunderid/internal/oauth/oauth2/dcr"
	"github.com/thunder-id/thunderid/internal/oauth/oauth2/dpop"
	"github.com/thunder-id/thunderid/internal/oauth/oauth2/jti"
	"github.com/thunder-id/thunderid/internal/oauth/oauth2/logout/backchannel"
	"github.com/thunder-id/thunderid/internal/oauth/oauth2/revocation"
	"github.com/thunder-id/thunderid/internal/oauth/oauth2/tokenservice"
	"github.com/thunder-id/thunderid/internal/openid4vci"
	"github.com/thunder-id/thunderid/internal/ou"
	"github.com/thunder-id/thunderid/internal/resource"
	"github.com/thunder-id/thunderid/internal/role"
	"github.com/thunder-id/thunderid/internal/runtimestore"
	"github.com/thunder-id/thunderid/internal/scim"
	scimconfig "github.com/thunder-id/thunderid/internal/scim/config"
	"github.com/thunder-id/thunderid/internal/serverconfig"
	"github.com/thunder-id/thunderid/internal/sharing"
	"github.com/thunder-id/thunderid/internal/system/cache"
	"github.com/thunder-id/thunderid/internal/system/cmodels"
	"github.com/thunder-id/thunderid/internal/system/config"
	"github.com/thunder-id/thunderid/internal/system/cors"
	"github.com/thunder-id/thunderid/internal/system/cryptolib"
	"github.com/thunder-id/thunderid/internal/system/csp"
	dbprovider "github.com/thunder-id/thunderid/internal/system/database/provider"
	declarativeresource "github.com/thunder-id/thunderid/internal/system/declarative_resource"
	"github.com/thunder-id/thunderid/internal/system/export"
	healthcheckservice "github.com/thunder-id/thunderid/internal/system/healthcheck/service"
	httpservice "github.com/thunder-id/thunderid/internal/system/http"
	i18nmgt "github.com/thunder-id/thunderid/internal/system/i18n/mgt"
	"github.com/thunder-id/thunderid/internal/system/importer"
	"github.com/thunder-id/thunderid/internal/system/jose"
	joseconfig "github.com/thunder-id/thunderid/internal/system/jose/config"
	"github.com/thunder-id/thunderid/internal/system/jose/jwt"
	"github.com/thunder-id/thunderid/internal/system/kmprovider"
	"github.com/thunder-id/thunderid/internal/system/kmprovider/defaultkm/pki"
	"github.com/thunder-id/thunderid/internal/system/log"

	"github.com/thunder-id/thunderid/internal/system/mcp"
	"github.com/thunder-id/thunderid/internal/system/observability"
	"github.com/thunder-id/thunderid/internal/system/resourcedependency"
	"github.com/thunder-id/thunderid/internal/system/secretresolver"
	"github.com/thunder-id/thunderid/internal/system/services"
	"github.com/thunder-id/thunderid/internal/system/sysauthz"
	"github.com/thunder-id/thunderid/internal/user"
	"github.com/thunder-id/thunderid/internal/usermgtprovider"
	"github.com/thunder-id/thunderid/internal/variablestore"
	"github.com/thunder-id/thunderid/internal/vc/credential"
	"github.com/thunder-id/thunderid/internal/vc/presentation"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"
)

// observabilitySvc is the observability service instance. This is used for graceful shutdown.
var observabilitySvc observability.ObservabilityServiceInterface

// registerServices registers all the services with the provided HTTP multiplexer.
// It also returns the import service so the bootstrap subcommand can create default
// resources in-process through the same service instances.
// nolint:gocyclo // This is the main service registration function, so its length is expected to be proportional
// to the number of services. Eventhough it has many branching statements, almost all are early exits so cognitive
// complexity is low.
func registerServices(mux *http.ServeMux, cacheManager cache.CacheManagerInterface) (
	jwt.JWTServiceInterface, kmprovider.RuntimeCryptoProvider, importer.ImportServiceInterface, *mcpsdk.Server,
	backchannel.DispatcherInterface, identitygovernance.LockNotifierInterface) {
	logger := log.GetLogger()

	// Service registration runs during application startup, outside any request.
	ctx := context.Background()

	// Load the server's private key for signing JWTs.
	pkiService, err := pki.Initialize()
	fatalOnError(ctx, logger, err, "Failed to initialize certificate service")

	runtimeCryptoSvc, configCryptoSvc, err := kmprovider.Initialize(pkiService)
	fatalOnError(ctx, logger, err, "Failed to initialize key manager provider")
	// Inject the ConfigCryptoProvider into cmodels. This breaks the import cycle that would
	// arise if cmodels were to directly import the kmprovider/defaultkm package.
	cmodels.SetConfigCryptoProvider(configCryptoSvc)

	runtime := config.GetServerRuntime()
	joseCfg := joseconfig.Config{
		Issuer:         runtime.Config.JWT.Issuer,
		ValidityPeriod: runtime.Config.JWT.ValidityPeriod,
		Audience:       runtime.Config.JWT.Audience,
		PreferredKeyID: runtime.Config.JWT.PreferredKeyID,
		Leeway:         runtime.Config.JWT.Leeway,
		JWKSCacheTTL:   time.Duration(runtime.Config.Server.SecurityConfig.JWKSCacheTTL) * time.Second,
	}
	jwtService, jweService, err := jose.Initialize(runtimeCryptoSvc, joseCfg)
	fatalOnError(ctx, logger, err, "Failed to initialize JOSE services")

	observabilitySvc = observability.Initialize(config.GetServerRuntime().Config.Observability)

	// Initialize MCP server early so packages initializing below can register tools.
	// Route mounting (mcp.Initialize) happens later in main(), once the token-revocation enforcer
	// exists — mcp.DefaultGuard needs it to reject revoked tokens the same way the REST gate does.
	mcpServer := mcp.NewServer()

	// List to collect exporters from each package
	var exporters []declarativeresource.ResourceExporter

	// Initialize i18n service for internationalization support.
	i18nService, i18nExporter, err := i18nmgt.Initialize(mux, config.GetServerRuntime().Config.Translation)
	fatalOnError(ctx, logger, err, "Failed to initialize i18n service")
	// Add to exporters list (must be done after initializing list)
	exporters = append(exporters, i18nExporter)

	// Initialize the variable store. It takes the config crypto provider directly, since that is
	// what seals a secret before it reaches the database.
	_, references := variablestore.Initialize(mux, configCryptoSvc, cacheManager)

	ouAuthzService, err := sysauthz.Initialize()
	fatalOnError(ctx, logger, err, "Failed to initialize system authorization service")

	ouService, ouHierarchyResolver, ouEnumerator, ouExporter, err := ou.Initialize(
		mux, mcpServer, cacheManager, ouAuthzService)
	fatalOnError(ctx, logger, err, "Failed to initialize OrganizationUnitService")
	exporters = append(exporters, ouExporter)

	// Complete the two-phase initialization: inject the OU hierarchy resolver into the
	// authz service now that the ou package is ready. This breaks the import-cycle that
	// would arise if sysauthz were to directly import the ou package.
	ouAuthzService.SetOUHierarchyResolver(ouHierarchyResolver)

	// Initialized ahead of the resource types it shares, because each registers itself on startup.
	sharingService, err := sharing.Initialize(cacheManager, ouHierarchyResolver, ouEnumerator,
		runtime.Config.ResourceSharing.AllowChildOUCrossTreeSharing)
	fatalOnError(ctx, logger, err, "Failed to initialize SharingService")

	hashCfg, err := buildHashConfig()
	fatalOnError(ctx, logger, err, "Failed to build HashService config")
	hashService, err := cryptolib.Initialize(hashCfg)
	fatalOnError(ctx, logger, err, "Failed to initialize HashService")

	// Initialize user type service
	entityTypeService, entityTypeExporter, agentTypeExporter, err := entitytype.Initialize(
		mux, mcpServer, cacheManager, ouService, ouAuthzService)
	fatalOnError(ctx, logger, err, "Failed to initialize EntityTypeService")
	exporters = append(exporters, entityTypeExporter)
	exporters = append(exporters, agentTypeExporter)

	// Initialize entity service
	entityService, err := entity.Initialize(cacheManager, hashService, entityTypeService, ouService,
		sharingService)
	fatalOnError(ctx, logger, err, "Failed to initialize EntityService")

	// Initialize entity provider
	entityProvider := entityprovider.InitializeEntityProvider(entityService)

	// The notification services are built before governance, which sends the lock email through them.
	notifSenderMgtSvc, notifOTPService, notifSenderSvc, notificationConfigHandler, err :=
		notification.Initialize(jwtService, notificationconfig.FromServerRuntime(), ouService)
	fatalOnError(ctx, logger, err, "Failed to initialize NotificationService")

	notifTemplateSvc, notifTemplateRenderer, notifTemplateExporter, err :=
		notificationtemplate.Initialize(mux, cacheManager, ouService, i18nService)
	fatalOnError(ctx, logger, err, "Failed to initialize NotificationTemplateService")
	exporters = append(exporters, notifTemplateExporter)

	// The accountAccess handler is built over the deployment policy, which must be valid on its own.
	governanceCfg := identitygovernance.FromServerRuntime()
	err = governanceCfg.Validate()
	fatalOnError(ctx, logger, err, "Invalid account_access configuration")

	authZENPDPService, err := authzenpdp.Initialize(runtime.Config.AuthZENPDP, entityTypeService, ouService)
	fatalOnError(ctx, logger, err, "Failed to initialize AuthZENPDPService")

	resourceService, resourceExporter, err := resource.Initialize(mux, ouService, authZENPDPService, nil)
	fatalOnError(ctx, logger, err, "Failed to initialize Resource Service")
	exporters = append(exporters, resourceExporter)

	// Create the flow server-config handler early so it can be registered before serverconfig is
	// initialized. The handle-existence validator is injected in a second phase after flowMgtService
	// is available.
	flowConfigHandler := flowmgt.NewFlowConfigHandler()

	// Initialize server-wide configuration after its handler dependencies and before the services that
	// read it.
	serverConfigHandlers := map[serverconfig.ConfigName]serverconfig.ServerConfigHandlerInterface{
		serverconfig.ConfigNameCORS:                  cors.OriginHandler{},
		serverconfig.ConfigNameDefaultResourceServer: resource.NewDefaultResourceServerConfigHandler(resourceService),
		serverconfig.ConfigNameSession:               flowsession.ConfigHandler{},
		serverconfig.ConfigNameFlow:                  flowConfigHandler,
		serverconfig.ConfigNameCSP:                   csp.PolicyHandler{},
		serverconfig.ConfigNameAccountAccess:         identitygovernance.NewAccountAccessHandler(governanceCfg),
		serverconfig.ConfigNameNotification:          notificationConfigHandler,
	}
	serverConfigService, serverConfigExporter, err := serverconfig.Initialize(mux, cacheManager, serverConfigHandlers,
		observabilitySvc)
	fatalOnError(ctx, logger, err, "Failed to initialize server config service")
	exporters = append(exporters, serverConfigExporter)

	// CORS origins come from the server-config cors section.
	cors.InitializeDynamicMatcher(serverConfigService)

	// Decorate the resource provider so an empty identifier resolves the configured default resource
	// server. Keeps the default-resource-server policy server-side: OAuth, CIBA, PAR, grant handlers,
	// and the flow executor depend only on providers.ResourceServerProvider, not on serverConfigService.
	// The base resourceService is still used for resource-management APIs and server-config validation.
	resourceServerProvider := resource.NewDefaultAwareResourceServerProvider(resourceService, serverConfigService)

	// Initialize authorization details type management and processing.
	authzDetailMgtService, authzDetailExporter, err := authzdetailmgt.Initialize(mux, mcpServer, nil)
	fatalOnError(ctx, logger, err, "Failed to initialize AuthorizationDetailMgtService")
	exporters = append(exporters, authzDetailExporter)
	authzDetailService := authzdetailexec.Initialize(authzDetailMgtService,
		runtime.Config.OAuth.AuthorizationDetails.ProcessorTimeoutOrDefault())

	// The security-headers middleware reads the deny-first CSP policy from the server-config csp section.
	csp.InitializeConfigReader(serverConfigService)

	// Identity governance reads the accountAccess section and the lock email's default sender through
	// the server-config service.
	governanceService, lockNotifier, err := identitygovernance.Initialize(
		entityService, serverConfigService, governanceCfg, &identitygovernance.NotificationDependencies{
			Templates:   notifTemplateRenderer,
			Senders:     notifSenderSvc,
			EntityTypes: entityTypeService,
		}, ouAuthzService, observabilitySvc)
	fatalOnError(ctx, logger, err, "Failed to initialize IdentityGovernanceService")
	governanceProvider := identitygovernanceprovider.Initialize(governanceService,
		runtime.Config.IdentityGovernanceProvider)

	userService, ouUserResolver, userExporter, err := user.Initialize(
		mux, entityService, ouService, entityTypeService, ouAuthzService, governanceService, sharingService, nil,
	)
	fatalOnError(ctx, logger, err, "Failed to initialize UserService")
	exporters = append(exporters, userExporter)

	// Initialize user management provider
	userMgtProvider := usermgtprovider.Initialize(userService)

	groupService, ouGroupResolver, groupExporter, err := group.Initialize(
		mux, dbprovider.GetDBProvider(), ouService, entityService, entityTypeService, ouAuthzService,
	)
	fatalOnError(ctx, logger, err, "Failed to initialize GroupService")
	exporters = append(exporters, groupExporter)

	httpConnectionService, err := httpconnection.Initialize(runtime.Config.HTTPConnection, ouService)
	fatalOnError(ctx, logger, err, "Failed to initialize HTTPConnectionService")

	// Initialize SCIM service.
	scim.Initialize(
		mux,
		userService,
		entityTypeService,
		groupService,
		scimconfig.FromServerRuntime(),
	)

	roleService, roleAssignmentService, ouRoleResolver, roleExporter, err := role.Initialize(
		mux, entityService, groupService, ouService, resourceService, entityTypeService, ouAuthzService,
		sharingService)
	fatalOnError(ctx, logger, err, "Failed to initialize RoleService")
	exporters = append(exporters, roleExporter)

	// Two-phase initialization: inject user/group/role resolvers into OU service.
	ouService.SetOUUserResolver(ouUserResolver)
	ouService.SetOUGroupResolver(ouGroupResolver)
	ouService.SetOURoleResolver(ouRoleResolver)

	// Adapt the OU service to the runtime provider contract. The OAuth and flow layers depend only
	// on providers.OrganizationUnitProvider and never see the management model.
	ouProvider := ou.NewOrganizationUnitProvider(ouService)

	// Complete the two-phase initialization of the privilege-escalation guard. The resolver spans
	// roles, groups, and entities, so it can only be built once all three are ready. Until it is
	// injected the guard fails closed, so this must not be skipped.
	ouAuthzService.SetPermissionResolver(
		role.NewEffectivePermissionResolver(roleService, groupService, entityService))

	authZService := authz.Initialize(
		roleService, resourceService, entityService, authZENPDPService)

	idpService, err := idp.Initialize(
		cacheManager, entityTypeService, roleService, groupService, resourceService, ouService)
	fatalOnError(ctx, logger, err, "Failed to initialize IDPService")

	// Register the /connections API as a thin layer over the identity-provider and
	// notification-sender services.
	connectionExporter, ouDependencyProvider, httpConnectionWriter, err := connection.Initialize(
		mux, mcpServer, idpService, notifSenderMgtSvc, resourceService, authZENPDPService, httpConnectionService,
		nil, sharingService)
	fatalOnError(ctx, logger, err, "Failed to initialize connection declarative resources")
	exporters = append(exporters, connectionExporter)

	// Initialize magic link service
	magicLinkService := magiclink.Initialize(jwtService)

	// Initialize otp core service
	otpCoreService := otp.Initialize(notifOTPService)

	// Initialize federated authentication services.
	oauthAuthnService := authnOAuth.Initialize(idpService)
	oidcAuthnService := authnOIDC.Initialize(oauthAuthnService, jwtService)
	googleAuthnService := google.Initialize(oidcAuthnService, jwtService)
	githubAuthnService := github.Initialize(oauthAuthnService)

	federatedAuths := map[providers.IDPType]authncm.FederatedAuthenticator{
		providers.IDPTypeOAuth:  oauthAuthnService,
		providers.IDPTypeOIDC:   oidcAuthnService,
		providers.IDPTypeGoogle: googleAuthnService,
		providers.IDPTypeGitHub: githubAuthnService,
	}

	runtimeStoreProvider, transactioner, err := runtimestore.Initialize(runtime.Config.Database.RuntimeTransient.Type,
		runtime.Config.Server.Identifier)
	fatalOnError(ctx, logger, err, "Failed to initialize runtime store")

	// Initialize passkey service
	passkeyService := passkey.Initialize(entityService, runtimeStoreProvider, governanceService)

	// Shared DPoP verifier (and its JTI replay cache) so OAuth and OpenID4VCI
	// share JTI replay protection.
	oauthCfg := oauthconfig.FromServerRuntime()
	dpopVerifier := dpop.Initialize(oauthCfg, jti.Initialize(runtimeStoreProvider), runtimeCryptoSvc)
	artifactLifetime := func(client *providers.OAuthClient) time.Duration {
		return tokenservice.ArtifactLifetime(oauthCfg, client)
	}

	openid4vpSvc, openid4vpDefSvc, openid4vciCredSvc, exporters :=
		initializeVCServices(ctx, logger, mux, runtimeCryptoSvc, configCryptoSvc, jwtService,
			ouService, runtimeStoreProvider, exporters)

	defaultProvider := defaultprovider.Initialize(entityService, passkeyService,
		otpCoreService, magicLinkService, openid4vpSvc, federatedAuths, governanceService)

	customProviders := map[string]providers.CustomAuthnProvider{}
	restCfg := runtime.Config.AuthnProvider.Rest
	if restCfg.Enabled {
		restProvider, err := restprovider.Initialize(restCfg)
		fatalOnError(ctx, logger, err, "Failed to initialize REST authn provider")
		customProviders[restprovider.Name] = providers.CustomAuthnProvider{
			Instance: restProvider,
			Creds:    restCfg.CredentialTypes,
		}
	}
	authnProvider, err := authnprovidermgr.Initialize(defaultProvider, customProviders)
	if err != nil {
		logger.Fatal(ctx, "Failed to initialize authn provider manager", log.Error(err))
	}

	// Initialize authentication services.
	authAssertGen := authnAssert.Initialize()
	consentEnforcer := authnConsent.Initialize(jwtService, authzDetailMgtService)

	_, directAuthGuard := authn.Initialize(mux, mcpServer, idpService, jwtService, authnProvider, authAssertGen,
		otpCoreService, notifSenderSvc, notifTemplateRenderer, magicLinkService, oauthAuthnService,
		oidcAuthnService, googleAuthnService, githubAuthnService, entityTypeService, governanceService,
		authnconfig.FromServerRuntime())

	// AuthZEN access-evaluation endpoints are Direct API endpoints, so they reuse the Direct Auth
	// guard created by the authn service.
	authzen.Initialize(mux, authZService, entityProvider, governanceService, resourceService, directAuthGuard)

	attributeCacheService := attributecache.Initialize(runtimeStoreProvider, runtimeCryptoSvc,
		runtime.Config.AttributeCache.Encryption.Enabled)

	flowConfig := flowconfig.FromServerRuntime()
	revocationEnforcer, revocationSvc, err := revocation.Initialize(oauthCfg, jwtService, observabilitySvc)
	fatalOnError(ctx, logger, err, "Failed to initialize revocation service")
	sessionRevoker := sessionCriteriaRevoker{revoker: revocationSvc}
	// The termination hook is kept for the back-channel logout dispatcher, which OAuth builds and which
	// is added to the hook once OAuth is initialized.
	sessionService, terminationHook, sessionCfg := initSessionService(ctx, serverConfigService,
		runtime.Config.Server.Identifier, sessionRevoker, logger)
	flowConfig.Session = sessionCfg
	flowFactory, execRegistry, interceptorRegistry, graphBuilder := initializeFlowCoreAndExecutor(ctx, logger,
		cacheManager, executor.ExecutorDependencies{
			OUService:              ouProvider,
			IDPService:             idpService,
			NotifSenderSvc:         notifSenderSvc,
			JWTService:             jwtService,
			AuthAssertGen:          authAssertGen,
			ConsentEnforcer:        consentEnforcer,
			AuthnProvider:          authnProvider,
			OTPService:             otpCoreService,
			MagicLinkService:       magicLinkService,
			AuthZService:           authZService,
			EntityTypeService:      entityTypeService,
			GroupService:           groupService,
			RoleService:            roleService,
			RoleAssignmentService:  roleAssignmentService,
			EntityProvider:         entityProvider,
			UserMgtProvider:        userMgtProvider,
			AttributeCacheSvc:      attributeCacheService,
			TemplateRenderer:       notifTemplateRenderer,
			OAuthSvc:               oauthAuthnService,
			OIDCSvc:                oidcAuthnService,
			GithubSvc:              githubAuthnService,
			GoogleSvc:              googleAuthnService,
			OpenID4VPVerifierSvc:   openid4vpSvc,
			SessionService:         sessionService,
			ResourceService:        resourceServerProvider,
			UserService:            userService,
			CriteriaRevoker:        revocationSvc,
			ResourceMgtService:     resourceService,
			HTTPConnectionProvider: httpConnectionService,
			// A redirect would resend the connection's credential to another host. Each call is bounded
			// by its connection's timeout, and private addresses are allowed since administrators set
			// the endpoint.
			ExtensionHTTPClient: httpservice.NewHTTPClientWithoutRedirects(0, false),
			ObservabilitySvc:    observabilitySvc,
			IdentityGovernance:  governanceProvider,
			ArtifactLifetime:    artifactLifetime,
			AuthzDetailProvider: authzDetailService,
		},
		interceptor.InterceptorDependencies{},
		flowConfig,
	)

	flowMgtService, flowMgtExporter, err := flowmgt.Initialize(
		mux, mcpServer, cacheManager, flowFactory, execRegistry, interceptorRegistry, graphBuilder,
		serverConfigService, ouService, notifTemplateSvc, httpConnectionService, flowConfigHandler, idpService,
		true, sharingService)
	fatalOnError(ctx, logger, err, "Failed to initialize FlowMgtService")

	// Two-phase initialization: inject the flow resolver into the OU service.
	ouService.SetOUFlowResolver(flowMgtService)

	exporters = append(exporters, flowMgtExporter)
	certservice, err := cert.Initialize(cacheManager, dbprovider.GetDBProvider())
	fatalOnError(ctx, logger, err, "Failed to initialize CertificateService")

	// Initialize theme and layout services
	themeMgtService, themeExporter, err := thememgt.Initialize(mux, mcpServer)
	fatalOnError(ctx, logger, err, "Failed to initialize ThemeMgtService")
	exporters = append(exporters, themeExporter)

	layoutMgtService, layoutExporter, err := layoutmgt.Initialize(mux)
	fatalOnError(ctx, logger, err, "Failed to initialize LayoutMgtService")
	exporters = append(exporters, layoutExporter)

	cimdService := cimd.Initialize(mux)
	inboundClientService, err := inboundclient.Initialize(
		cacheManager, certservice, entityProvider,
		themeMgtService, layoutMgtService, flowMgtService, entityTypeService, runtimeCryptoSvc, jweService,
		cimdService, sharingService, entityService)
	fatalOnError(ctx, logger, err, "Failed to initialize InboundClientService")

	// Inject the consent service into the consent enforcer. It is wired here rather than at enforcer
	// construction because it depends on the inbound client service, which is only available after the
	// flow services (which themselves depend on the enforcer) are initialized.
	consentEnforcer.SetConsentService(initConsentService(ctx, logger, inboundClientService))

	applicationService, applicationExporter, err := application.Initialize(
		mux, mcpServer, entityService, inboundClientService, ouService, i18nService,
		runtimeCryptoSvc, serverConfigService, artifactLifetime, sharingService, nil, governanceService, nil)
	fatalOnError(ctx, logger, err, "Failed to initialize ApplicationService")
	// Two-phase initialization: inject the application service into the executors that act on it.
	fatalOnError(ctx, logger, executor.SetApplicationProvider(execRegistry, applicationService),
		"Failed to inject the application provider into the flow executors")
	exporters = append(exporters, applicationExporter)

	agentService, agentExporter, err := agent.Initialize(mux, entityService, inboundClientService, ouService,
		roleService, ouAuthzService, governanceService, nil, entityTypeService,
		dbprovider.GetDBProvider(), observabilitySvc)
	fatalOnError(ctx, logger, err, "Failed to initialize AgentService")
	exporters = append(exporters, agentExporter)

	// Two-phase initialization: inject the agent provider into the executors that provision agents.
	fatalOnError(ctx, logger, executor.SetAgentMgtProvider(execRegistry, agentmgtprovider.Initialize(agentService)),
		"Failed to inject the agent provider into the flow executors")

	// Wire the dependency registry into the consuming services (two-phase init to avoid cyclic
	// imports). flowMgtService is both a consumer and a provider: it reports which flows reference an
	// identity provider, notification sender or HTTP connection.
	registerDependencyRegistry(dependencyConsumers{
		theme:          themeMgtService,
		layout:         layoutMgtService,
		flow:           flowMgtService,
		user:           userService,
		idp:            idpService,
		notifSender:    notifSenderMgtSvc,
		application:    applicationService,
		agent:          agentService,
		group:          groupService,
		ou:             ouService,
		resource:       resourceService,
		notifTemplate:  notifTemplateSvc,
		httpConnection: httpConnectionService,
	}, applicationService, agentService, flowMgtService, roleAssignmentService, roleService,
		groupService, ouService, ouUserResolver, ouGroupResolver, entityTypeService, resourceService,
		sharingService, notifTemplateSvc, ouDependencyProvider)

	// Initialize design resolve service for theme and layout resolution
	designResolveService := resolve.Initialize(mux, themeMgtService, layoutMgtService, applicationService)

	// Inject the design resolve service now that it exists (the translation resolver was passed at init).
	notifTemplateRenderer.SetDesignResolver(designResolveService)

	actorProvider := actorprovider.Initialize(
		inboundClientService, entityProvider, authnProvider, roleService, entityTypeService)
	// Two-phase initialization: inject the actor provider into the executors that resolve an actor's
	// OAuth client.
	fatalOnError(ctx, logger, executor.SetActorProvider(execRegistry, actorProvider),
		"Failed to inject the actor provider into the flow executors")

	// Initialize flow metadata service
	_ = flowmeta.Initialize(mux, actorProvider, ouProvider, designResolveService, i18nService)

	// Initialize export service with collected exporters
	exportService := export.Initialize(mux, exporters, export.TemplatePlaceholders)

	// The gateways this control plane administers. Registration is bounded by server.max_gateways,
	// which is one unless a deployment raises it.
	gatewayService, err := gateway.Initialize(mux, exportService, nil, exporters, nil)
	fatalOnError(ctx, logger, err, "Failed to initialize gateway service")

	// Initialize import service
	importService := importer.Initialize(
		mux,
		applicationService,
		idpService,
		notifSenderMgtSvc,
		flowMgtService,
		ouService,
		entityTypeService,
		roleService,
		roleAssignmentService,
		groupService,
		resourceService,
		themeMgtService,
		layoutMgtService,
		userService,
		i18nService,
		agentService,
		openid4vpDefSvc,
		openid4vciCredSvc,
		serverConfigService,
		gatewayService,
		notifTemplateSvc,
		authZENPDPService,
		sharingService,
		authzDetailMgtService,
		httpConnectionWriter,
		// Only the Control Plane serves projects, so a root organization unit is imported on its own.
		nil,
		// References in imported configuration are replaced with what this deployment's store holds. A
		// secret is put only where an export of the resource keeps one, which its exporter names.
		secretresolver.New(variablestore.Lookup(references)).
			WithSecretFields(declarativeresource.SecretFieldsOf(exporters)),
	)

	attestationProvider := initAttestationProvider(ctx, logger, runtimeCryptoSvc)
	// The flow endpoint and the authorize endpoint share one SSO handle transport. The SSO cookie is
	// marked Secure unless the deployment is configured to serve over plain HTTP.
	ssoTransport := flowsession.NewHandleTransport(flowsession.TransportConfig{SecureCookies: flowConfig.SecureCookies})
	flowExecService, err := flowexec.Initialize(mux, flowMgtService, actorProvider,
		execRegistry, interceptorRegistry, observabilitySvc, runtimeCryptoSvc, attestationProvider,
		graphBuilder, jwtService, runtimeStoreProvider, transactioner, serverConfigService, ssoTransport,
		governanceProvider, flowMgtService, flowConfig)
	fatalOnError(ctx, logger, err, "Failed to initialize flow execution service")

	// Initialize OAuth services.
	tokenValidator, dispatcher, err := oauth.Initialize(mux, actorProvider, authnProvider, jwtService, jweService,
		flowExecService, observabilitySvc, runtimeCryptoSvc, ouProvider, attributeCacheService, authZService,
		resourceServerProvider, i18nService, idpService, dpopVerifier,
		runtimeStoreProvider, transactioner, revocationEnforcer, revocationSvc,
		sessionService, ssoTransport, flowMgtService, governanceProvider, authzDetailService, authzDetailMgtService,
		oauthCfg)
	fatalOnError(ctx, logger, err, "Failed to initialize OAuth services")
	if dispatcher != nil {
		err = terminationHook.Add(dispatcher)
		fatalOnError(ctx, logger, err, "Failed to register the back-channel logout dispatcher")
	}

	// Initialized after the OAuth services because credential issuance validates the presented
	// access token with the OAuth token validator and resolves the wallet application behind it.
	_, err = openid4vci.Initialize(mux, runtimeCryptoSvc, tokenValidator, userService, dpopVerifier,
		openid4vciCredSvc, actorProvider, runtimeStoreProvider)
	fatalOnError(ctx, logger, err, "Failed to initialize OpenID4VCI issuer service")

	if oauthCfg.OAuth.DCR.IsEnabled() {
		// Register OAuth2 DCR service.
		err = dcr.Initialize(mux, applicationService, ouService, i18nService, authnProvider, oauthCfg)
		fatalOnError(ctx, logger, err, "Failed to initialize OAuth2 DCR service")
	}

	// Register the health service.
	healthSvc := healthcheckservice.Initialize(dbprovider.GetDBProvider(), dbprovider.GetRedisProvider())
	services.NewHealthCheckService(mux, healthSvc)

	return jwtService, runtimeCryptoSvc, importService, mcpServer, dispatcher, lockNotifier
}

// initAttestationProvider initializes the platform attestation provider, terminating server startup
// on failure rather than running with a non-functional verifier.
func initAttestationProvider(ctx context.Context, logger *log.Logger,
	cryptoSvc kmprovider.RuntimeCryptoProvider) providers.AttestationProvider {
	attestationProvider, err := attestation.Initialize(cryptoSvc)
	if err != nil {
		logger.Fatal(ctx, "Failed to initialize attestation provider", log.Error(err))
	}
	return attestationProvider
}

// dependencyConsumers groups the services that check the dependency registry before deleting their
// own resources.
type dependencyConsumers struct {
	theme          thememgt.ThemeMgtServiceInterface
	layout         layoutmgt.LayoutMgtServiceInterface
	flow           flowmgt.FlowMgtServiceInterface
	user           user.UserServiceInterface
	idp            idp.IDPServiceInterface
	notifSender    notification.NotificationSenderMgtSvcInterface
	application    application.ApplicationServiceInterface
	agent          agent.AgentServiceInterface
	group          group.GroupServiceInterface
	ou             ou.ConfigurableOUService
	resource       resource.ResourceServiceInterface
	notifTemplate  notificationtemplate.NotificationTemplateServiceInterface
	httpConnection httpconnection.HTTPConnectionServiceInterface
}

// registerDependencyRegistry builds the dependency registry from the given providers and wires it
// into the consuming services.
func registerDependencyRegistry(consumers dependencyConsumers, providers ...resourcedependency.Provider) {
	registry := resourcedependency.Initialize(providers...)
	consumers.theme.SetDependencyRegistry(registry)
	consumers.layout.SetDependencyRegistry(registry)
	consumers.flow.SetDependencyRegistry(registry)
	consumers.user.SetDependencyRegistry(registry)
	consumers.idp.SetDependencyRegistry(registry)
	consumers.notifSender.SetDependencyRegistry(registry)
	consumers.application.SetDependencyRegistry(registry)
	consumers.agent.SetDependencyRegistry(registry)
	consumers.group.SetDependencyRegistry(registry)
	consumers.ou.SetDependencyRegistry(registry)
	consumers.resource.SetDependencyRegistry(registry)
	consumers.notifTemplate.SetDependencyRegistry(registry)
	consumers.httpConnection.SetDependencyRegistry(registry)
}

// unregisterServices unregisters all services that require cleanup during shutdown.
func unregisterServices() {
	observabilitySvc.Shutdown()
}

// initSessionService reads the effective SSO session configuration from the server-config section and
// builds the session service, returning the service, its termination hook, and the config so the caller
// can thread the config into flowexec too.
func initSessionService(ctx context.Context, svc serverconfig.ServerConfigService, deploymentID string,
	criteriaRevoker flowsession.CriteriaRevoker, logger *log.Logger,
) (flowsession.Service, flowsession.TerminationHook, flowsession.Config) {
	cfg := readSessionConfig(ctx, svc, logger)
	sessionService, terminationHook, err := flowsession.Initialize(dbprovider.GetDBProvider(), deploymentID,
		flowsession.NewTimeouts(cfg.IdleTimeoutSeconds, cfg.AbsoluteTimeoutSeconds,
			cfg.ActivityRefreshIntervalSeconds), criteriaRevoker)
	fatalOnError(ctx, logger, err, "Failed to initialize SSO session service")
	return sessionService, terminationHook, cfg
}

// sessionCriteriaRevoker fixes the reason used when the session service revokes a token family.
type sessionCriteriaRevoker struct {
	revoker revocation.CriteriaRevokerInterface
}

// RevokeTokenFamily revokes the given token family with the session-logout reason.
func (a sessionCriteriaRevoker) RevokeTokenFamily(ctx context.Context, tokenFamilyID string) error {
	return a.revoker.RevokeTokenFamily(ctx, tokenFamilyID, revocation.RevocationReasonSessionLogout)
}

// readSessionConfig reads the effective SSO session lifetime configuration from the server-config
// "session" section. An unset section resolves to the zero Config, which NewTimeouts turns into the
// built-in defaults; a read error is non-fatal for the same reason, so it logs and falls back.
func readSessionConfig(ctx context.Context, svc serverconfig.ServerConfigService,
	logger *log.Logger) flowsession.Config {
	merged, svcErr := svc.GetMergedConfig(ctx, string(serverconfig.ConfigNameSession))
	if svcErr != nil {
		logger.Warn(ctx, "Failed to read session server config; using default timeouts",
			log.String("code", svcErr.Code))
		return flowsession.Config{}
	}
	cfg, _ := merged.(flowsession.Config)
	return cfg
}

// initConsentService initializes the consent service backed by the inbound client service, which
// satisfies consent.InboundClientProvider directly.
func initConsentService(ctx context.Context, logger *log.Logger,
	inboundClientService inboundclient.InboundClientServiceInterface) consent.ConsentServiceInterface {
	consentService, err := consent.Initialize(inboundClientService)
	fatalOnError(ctx, logger, err, "Failed to initialize consent service")
	return consentService
}

// fatalOnError logs msg and exits the process if err is non-nil.
func fatalOnError(ctx context.Context, logger *log.Logger, err error, msg string) {
	if err != nil {
		logger.Fatal(ctx, msg, log.Error(err))
	}
}

// initializeFlowCoreAndExecutor initializes the flow core and executor services.
func initializeFlowCoreAndExecutor(
	ctx context.Context,
	logger *log.Logger,
	cacheManager cache.CacheManagerInterface,
	execDeps executor.ExecutorDependencies,
	interceptorDeps interceptor.InterceptorDependencies,
	flowConfig flowconfig.Config,
) (flowcore.FlowFactoryInterface, executor.ExecutorRegistryInterface,
	interceptor.InterceptorRegistryInterface, graphbuilder.GraphBuilderInterface) {
	// Initialize flow core services.
	flowFactory, graphCache := flowcore.Initialize(cacheManager)
	execDeps.FlowFactory = flowFactory
	interceptorDeps.FlowFactory = flowFactory

	// Initialize flow executor registry
	execRegistry, err := executor.Initialize(execDeps, flowConfig)
	fatalOnError(ctx, logger, err, "Failed to register flow executors")
	interceptorRegistry, err := interceptor.Initialize(interceptorDeps, flowConfig.Flow)
	fatalOnError(ctx, logger, err, "Failed to initialize Interceptor registry")

	graphBuilder := graphbuilder.Initialize(flowFactory, execRegistry, interceptorRegistry, graphCache)

	return flowFactory, execRegistry, interceptorRegistry, graphBuilder
}

// initializeVCServices initializes the OpenID4VP verifier and the credential-configuration
// service, appending their declarative-resource exporters to exporters. The OpenID4VCI issuer
// itself is initialized later, once the application service it depends on exists.
func initializeVCServices(
	ctx context.Context, logger *log.Logger, mux *http.ServeMux,
	runtimeCrypto providers.RuntimeCryptoProvider, configCrypto kmprovider.ConfigCryptoProvider,
	jwtService jwt.JWTServiceInterface,
	ouService ou.OrganizationUnitServiceInterface,
	runtimeStoreProvider providers.RuntimeStoreProvider,
	exporters []declarativeresource.ResourceExporter,
) (openid4vp.OpenID4VPServiceInterface, presentation.PresentationDefinitionServiceInterface,
	credential.CredentialConfigurationServiceInterface, []declarativeresource.ResourceExporter) {
	openid4vpDefSvc, vpDefExp, err := presentation.Initialize(mux, ouService)
	fatalOnError(ctx, logger, err, "Failed to initialize presentation definition service")
	if vpDefExp != nil {
		exporters = append(exporters, vpDefExp)
	}

	openid4vpSvc, err := openid4vp.Initialize(mux, runtimeCrypto, configCrypto, jwtService, openid4vpDefSvc,
		runtimeStoreProvider)
	fatalOnError(ctx, logger, err, "Failed to initialize OpenID4VP verifier service")

	openid4vciCredSvc, vciCredExp, err := credential.Initialize(mux, ouService)
	fatalOnError(ctx, logger, err, "Failed to initialize credential configuration service")
	if vciCredExp != nil {
		exporters = append(exporters, vciCredExp)
	}

	return openid4vpSvc, openid4vpDefSvc, openid4vciCredSvc, exporters
}

// buildHashConfig constructs a cryptolib.HashConfig from the server configuration.
func buildHashConfig() (cryptolib.HashConfig, error) {
	cfg := config.GetServerRuntime().Config.Crypto.PasswordHashing
	alg := cryptolib.CredAlgorithm(strings.ToUpper(cfg.Algorithm))
	switch alg {
	case "", cryptolib.SHA256:
		return cryptolib.HashConfig{Algorithm: cryptolib.SHA256, SaltSize: cfg.SHA256.SaltSize}, nil
	case cryptolib.PBKDF2:
		return cryptolib.HashConfig{Algorithm: alg, SaltSize: cfg.PBKDF2.SaltSize,
			Iterations: cfg.PBKDF2.Iterations, KeySize: cfg.PBKDF2.KeySize}, nil
	case cryptolib.ARGON2ID:
		return cryptolib.HashConfig{Algorithm: alg, SaltSize: cfg.Argon2ID.SaltSize,
			Iterations: cfg.Argon2ID.Iterations, Memory: cfg.Argon2ID.Memory,
			Parallelism: cfg.Argon2ID.Parallelism, KeySize: cfg.Argon2ID.KeySize}, nil
	default:
		return cryptolib.HashConfig{}, fmt.Errorf("unrecognized password hashing algorithm %q", cfg.Algorithm)
	}
}
