// Copyright 2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package connection

import (
	"context"
	"net/http"
	"net/url"
	"strconv"
	"strings"

	"github.com/thunder-id/thunderid/internal/connection/authzenpdp"
	"github.com/thunder-id/thunderid/internal/connection/httpconnection"
	"github.com/thunder-id/thunderid/internal/idp"
	"github.com/thunder-id/thunderid/internal/notification"
	ncommon "github.com/thunder-id/thunderid/internal/notification/common"
	"github.com/thunder-id/thunderid/internal/sharing"
	serverconst "github.com/thunder-id/thunderid/internal/system/constants"
	"github.com/thunder-id/thunderid/internal/system/error/apierror"
	"github.com/thunder-id/thunderid/internal/system/filter"
	sysutils "github.com/thunder-id/thunderid/internal/system/utils"
	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"
)

// handler serves the connection HTTP endpoints. Each vendor file (google.go, ...) defines
// its own typed request/response structs, its toDTO/fromDTO mappers, and thin handler
// methods that delegate the request plumbing to the generic helpers below.
type handler struct {
	svc *service
}

// newHandler creates a new connection handler.
func newHandler(svc *service) *handler {
	return &handler{svc: svc}
}

// createConnection decodes a typed request, maps it to an IdP DTO via the vendor's mapper,
// delegates creation, and writes the encoded response.
func createConnection[Req any, Resp any](h *handler, w http.ResponseWriter, r *http.Request,
	toDTO func(Req) (*providers.IDPDTO, error), fromDTO func(providers.IDPDTO) (Resp, error)) {
	ctx := r.Context()
	req, err := sysutils.DecodeJSONBody[Req](r)
	if err != nil {
		writeInvalidBody(ctx, w)
		return
	}
	dto, err := toDTO(*req)
	if err != nil {
		writeServiceError(ctx, w, &tidcommon.InternalServerError)
		return
	}
	created, svcErr := h.svc.create(ctx, dto)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	resp, err := fromDTO(*created)
	if err != nil {
		writeServiceError(ctx, w, &tidcommon.InternalServerError)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusCreated, resp)
}

// getConnection fetches an instance of the given type and writes the encoded response.
func getConnection[Resp any](h *handler, w http.ResponseWriter, r *http.Request,
	idpType providers.IDPType, fromDTO func(providers.IDPDTO) (Resp, error)) {
	ctx := r.Context()
	id := r.PathValue("id")
	if strings.TrimSpace(id) == "" {
		writeServiceError(ctx, w, &idp.ErrorInvalidIDPID)
		return
	}
	dto, svcErr := h.svc.getByType(ctx, idpType, id)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	resp, err := fromDTO(*dto)
	if err != nil {
		writeServiceError(ctx, w, &tidcommon.InternalServerError)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, resp)
}

// updateConnection decodes a typed request, maps it, delegates the update (which preserves
// any secret the request omits), and writes the encoded response.
func updateConnection[Req any, Resp any](h *handler, w http.ResponseWriter, r *http.Request,
	idpType providers.IDPType, toDTO func(Req) (*providers.IDPDTO, error),
	fromDTO func(providers.IDPDTO) (Resp, error)) {
	ctx := r.Context()
	id := r.PathValue("id")
	if strings.TrimSpace(id) == "" {
		writeServiceError(ctx, w, &idp.ErrorInvalidIDPID)
		return
	}
	req, err := sysutils.DecodeJSONBody[Req](r)
	if err != nil {
		writeInvalidBody(ctx, w)
		return
	}
	dto, err := toDTO(*req)
	if err != nil {
		writeServiceError(ctx, w, &tidcommon.InternalServerError)
		return
	}
	updated, svcErr := h.svc.update(ctx, idpType, id, dto)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	resp, err := fromDTO(*updated)
	if err != nil {
		writeServiceError(ctx, w, &tidcommon.InternalServerError)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, resp)
}

// createHandler binds a vendor's mappers to createConnection, yielding a registerable handler.
func createHandler[Req any, Resp any](h *handler, toDTO func(Req) (*providers.IDPDTO, error),
	fromDTO func(providers.IDPDTO) (Resp, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		createConnection(h, w, r, toDTO, fromDTO)
	}
}

// getHandler binds a vendor's type and mapper to getConnection, yielding a registerable handler.
func getHandler[Resp any](h *handler, idpType providers.IDPType,
	fromDTO func(providers.IDPDTO) (Resp, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		getConnection(h, w, r, idpType, fromDTO)
	}
}

// updateHandler binds a vendor's type and mappers to updateConnection, yielding a registerable handler.
func updateHandler[Req any, Resp any](h *handler, idpType providers.IDPType,
	toDTO func(Req) (*providers.IDPDTO, error),
	fromDTO func(providers.IDPDTO) (Resp, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		updateConnection(h, w, r, idpType, toDTO, fromDTO)
	}
}

// listInstances returns a handler that lists the configured instances of a connection type.
func (h *handler) listInstances(idpType providers.IDPType) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		instances, svcErr := h.svc.listByType(ctx, idpType)
		if svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		summaries := make([]connectionInstanceSummary, 0, len(instances))
		for _, instance := range instances {
			summaries = append(summaries, connectionInstanceSummary{
				ID:          instance.ID,
				Name:        instance.Name,
				Description: instance.Description,
			})
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, summaries)
	}
}

// deleteInstance returns a handler that deletes an instance of a connection type.
func (h *handler) deleteInstance(idpType providers.IDPType) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		id := r.PathValue("id")
		if strings.TrimSpace(id) == "" {
			writeServiceError(ctx, w, &idp.ErrorInvalidIDPID)
			return
		}
		if svcErr := h.svc.deleteByType(ctx, idpType, id); svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusNoContent, nil)
	}
}

// usagesInstance returns a handler that lists the resources referencing an instance of a
// connection type. Drives the pre-delete confirmation dialog.
func (h *handler) usagesInstance(idpType providers.IDPType) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		id := r.PathValue("id")
		if strings.TrimSpace(id) == "" {
			writeServiceError(ctx, w, &idp.ErrorInvalidIDPID)
			return
		}
		usages, svcErr := h.svc.usagesByType(ctx, idpType, id)
		if svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, usages)
	}
}

// parsePaginationParams parses the limit and offset query parameters, applying the default
// page size when limit is omitted.
func parsePaginationParams(query url.Values) (int, int, *tidcommon.ServiceError) {
	limit := serverconst.DefaultPageSize
	offset := 0

	if limitStr := query.Get("limit"); limitStr != "" {
		parsedLimit, err := strconv.Atoi(limitStr)
		if err != nil {
			return 0, 0, &ErrorInvalidLimit
		}
		limit = parsedLimit
	}

	if offsetStr := query.Get("offset"); offsetStr != "" {
		parsedOffset, err := strconv.Atoi(offsetStr)
		if err != nil {
			return 0, 0, &ErrorInvalidOffset
		}
		offset = parsedOffset
	}

	return limit, offset, nil
}

// handleListConnections handles GET /connections, returning a paginated flat list of configured
// connection instances across both IdP- and sender-backed services, optionally filtered by
// the category query parameter. An ouId filter lists the connections that organization unit owns,
// followed by the ones shared into it.
func (h *handler) handleListConnections(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	category, ok := parseConnectionCategory(r.URL.Query().Get("category"))
	if !ok {
		writeServiceError(ctx, w, &ErrorInvalidConnectionCategory)
		return
	}
	filters, err := filter.ParseEqualityFilterParam(r.URL.Query())
	if err != nil {
		writeServiceError(ctx, w, &ErrorInvalidFilter)
		return
	}
	ouID, rest, err := filter.SplitOUIDFilter(filters)
	if err != nil || len(rest) > 0 {
		writeServiceError(ctx, w, &ErrorInvalidFilter)
		return
	}
	limit, offset, svcErr := parsePaginationParams(r.URL.Query())
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	resp, svcErr := h.svc.listInstances(ctx, category, ouID, limit, offset)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, resp)
}

// createAuthZENPDPConnection creates an AuthZEN PDP connection.
func (h *handler) createAuthZENPDPConnection(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	req, err := sysutils.DecodeJSONBody[authzenpdp.ConnectionRequest](r)
	if err != nil {
		writeServiceError(ctx, w, &ErrorInvalidRequestFormat)
		return
	}
	created, svcErr := h.svc.createAuthZENPDP(ctx, *req)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusCreated, authzenpdp.ToResponse(*created))
}

// listAuthZENPDPConnections lists configured AuthZEN PDP connections.
func (h *handler) listAuthZENPDPConnections(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	connections, svcErr := h.svc.listAuthZENPDP(ctx)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	summaries := make([]connectionInstanceSummary, 0, len(connections))
	for _, connection := range connections {
		summaries = append(summaries, connectionInstanceSummary{
			ID:          connection.ID,
			Name:        connection.Name,
			Description: connection.Description,
		})
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, summaries)
}

// getAuthZENPDPConnection returns an AuthZEN PDP connection by ID.
func (h *handler) getAuthZENPDPConnection(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	id := r.PathValue("id")
	if strings.TrimSpace(id) == "" {
		writeServiceError(ctx, w, &authzenpdp.ErrorNotFound)
		return
	}
	connection, svcErr := h.svc.getAuthZENPDP(ctx, id)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, authzenpdp.ToResponse(*connection))
}

// updateAuthZENPDPConnection updates an AuthZEN PDP connection by ID.
func (h *handler) updateAuthZENPDPConnection(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	id := r.PathValue("id")
	if strings.TrimSpace(id) == "" {
		writeServiceError(ctx, w, &authzenpdp.ErrorNotFound)
		return
	}
	req, err := sysutils.DecodeJSONBody[authzenpdp.ConnectionRequest](r)
	if err != nil {
		writeServiceError(ctx, w, &ErrorInvalidRequestFormat)
		return
	}
	updated, svcErr := h.svc.updateAuthZENPDP(ctx, id, *req)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, authzenpdp.ToResponse(*updated))
}

// deleteAuthZENPDPConnection deletes an AuthZEN PDP connection by ID.
func (h *handler) deleteAuthZENPDPConnection(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	id := r.PathValue("id")
	if strings.TrimSpace(id) == "" {
		writeServiceError(ctx, w, &authzenpdp.ErrorNotFound)
		return
	}
	if svcErr := h.svc.deleteAuthZENPDP(ctx, id); svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusNoContent, nil)
}

// usagesAuthZENPDPConnection lists resources that reference an AuthZEN PDP connection.
func (h *handler) usagesAuthZENPDPConnection(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	id := r.PathValue("id")
	if strings.TrimSpace(id) == "" {
		writeServiceError(ctx, w, &authzenpdp.ErrorNotFound)
		return
	}
	usages, svcErr := h.svc.usagesAuthZENPDP(ctx, id)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, usages)
}

// createHTTPConnection creates an HTTP connection.
func (h *handler) createHTTPConnection(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	req, err := sysutils.DecodeJSONBody[httpConnectionRequest](r)
	if err != nil {
		writeServiceError(ctx, w, &ErrorInvalidRequestFormat)
		return
	}
	dto, err := httpToDTO(*req)
	if err != nil {
		writeSenderMappingError(ctx, w, err)
		return
	}
	created, svcErr := h.svc.createHTTP(ctx, *dto)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	writeHTTPConnection(ctx, w, http.StatusCreated, created)
}

// listHTTPConnections lists configured HTTP connections.
func (h *handler) listHTTPConnections(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	connections, svcErr := h.svc.listHTTP(ctx)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	summaries := make([]connectionInstanceSummary, 0, len(connections))
	for _, connection := range connections {
		summaries = append(summaries, connectionInstanceSummary{
			ID:          connection.ID,
			Name:        connection.Name,
			Description: connection.Description,
		})
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, summaries)
}

// getHTTPConnection returns an HTTP connection by ID, with its secret masked.
func (h *handler) getHTTPConnection(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	connection, svcErr := h.svc.getHTTP(ctx, r.PathValue("id"))
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	writeHTTPConnection(ctx, w, http.StatusOK, connection)
}

// updateHTTPConnection updates an HTTP connection by ID.
func (h *handler) updateHTTPConnection(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	req, err := sysutils.DecodeJSONBody[httpConnectionRequest](r)
	if err != nil {
		writeServiceError(ctx, w, &ErrorInvalidRequestFormat)
		return
	}
	dto, err := httpUpdateToDTO(*req)
	if err != nil {
		writeSenderMappingError(ctx, w, err)
		return
	}
	updated, svcErr := h.svc.updateHTTP(ctx, r.PathValue("id"), *dto)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	writeHTTPConnection(ctx, w, http.StatusOK, updated)
}

// deleteHTTPConnection deletes an HTTP connection by ID.
func (h *handler) deleteHTTPConnection(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	if svcErr := h.svc.deleteHTTP(ctx, r.PathValue("id")); svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusNoContent, nil)
}

// usagesHTTPConnection lists the resources that use an HTTP connection.
func (h *handler) usagesHTTPConnection(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	usages, svcErr := h.svc.usagesHTTP(ctx, r.PathValue("id"))
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, usages)
}

// writeHTTPConnection writes an HTTP connection with its secret masked.
func writeHTTPConnection(ctx context.Context, w http.ResponseWriter, status int,
	connection *httpconnection.HTTPConnection) {
	resp, err := httpFromDTO(*connection)
	if err != nil {
		writeServiceError(ctx, w, &tidcommon.InternalServerError)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, status, resp)
}

// handleGetConnectionMeta handles GET /connections/meta, describing the configurable options of
// every registered vendor, or of the vendor named by the optional vendor query parameter. It lets
// the console render authentication methods it was never compiled against.
func (h *handler) handleGetConnectionMeta(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	resp, svcErr := h.svc.getConnectionMeta(r.URL.Query().Get("vendor"))
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, resp)
}

// createSenderConnection decodes a typed request, maps it to a notification-sender DTO via the
// vendor's mapper, delegates creation, and writes the encoded response.
func createSenderConnection[Req any, Resp any](h *handler, w http.ResponseWriter, r *http.Request,
	toDTO func(Req) (*ncommon.NotificationSenderDTO, error),
	fromDTO func(ncommon.NotificationSenderDTO) (Resp, error)) {
	ctx := r.Context()
	req, err := sysutils.DecodeJSONBody[Req](r)
	if err != nil {
		writeInvalidBody(ctx, w)
		return
	}
	dto, err := toDTO(*req)
	if err != nil {
		writeSenderMappingError(ctx, w, err)
		return
	}
	created, svcErr := h.svc.createSender(ctx, *dto)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	resp, err := fromDTO(*created)
	if err != nil {
		writeServiceError(ctx, w, &tidcommon.InternalServerError)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusCreated, resp)
}

// getSenderConnection fetches a sender of the given type and provider and writes the encoded
// response.
func getSenderConnection[Resp any](h *handler, w http.ResponseWriter, r *http.Request,
	senderType ncommon.NotificationSenderType, provider ncommon.NotificationProviderType,
	fromDTO func(ncommon.NotificationSenderDTO) (Resp, error)) {
	ctx := r.Context()
	id := r.PathValue("id")
	if strings.TrimSpace(id) == "" {
		writeServiceError(ctx, w, &notification.ErrorInvalidSenderID)
		return
	}
	dto, svcErr := h.svc.getSenderByProvider(ctx, senderType, provider, id)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	resp, err := fromDTO(*dto)
	if err != nil {
		writeServiceError(ctx, w, &tidcommon.InternalServerError)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, resp)
}

// updateSenderConnection decodes a typed request, maps it, delegates the update (which preserves
// any secret the request omits), and writes the encoded response.
func updateSenderConnection[Req any, Resp any](h *handler, w http.ResponseWriter, r *http.Request,
	senderType ncommon.NotificationSenderType, provider ncommon.NotificationProviderType,
	toDTO func(Req) (*ncommon.NotificationSenderDTO, error),
	fromDTO func(ncommon.NotificationSenderDTO) (Resp, error)) {
	ctx := r.Context()
	id := r.PathValue("id")
	if strings.TrimSpace(id) == "" {
		writeServiceError(ctx, w, &notification.ErrorInvalidSenderID)
		return
	}
	req, err := sysutils.DecodeJSONBody[Req](r)
	if err != nil {
		writeInvalidBody(ctx, w)
		return
	}
	dto, err := toDTO(*req)
	if err != nil {
		writeSenderMappingError(ctx, w, err)
		return
	}
	updated, svcErr := h.svc.updateSender(ctx, senderType, provider, id, *dto)
	if svcErr != nil {
		writeServiceError(ctx, w, svcErr)
		return
	}
	resp, err := fromDTO(*updated)
	if err != nil {
		writeServiceError(ctx, w, &tidcommon.InternalServerError)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, resp)
}

// createSenderHandler binds a vendor's mappers to createSenderConnection, yielding a registerable
// handler.
func createSenderHandler[Req any, Resp any](h *handler,
	toDTO func(Req) (*ncommon.NotificationSenderDTO, error),
	fromDTO func(ncommon.NotificationSenderDTO) (Resp, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		createSenderConnection(h, w, r, toDTO, fromDTO)
	}
}

// getSenderHandler binds a vendor's type, provider and mapper to getSenderConnection.
func getSenderHandler[Resp any](h *handler, senderType ncommon.NotificationSenderType,
	provider ncommon.NotificationProviderType,
	fromDTO func(ncommon.NotificationSenderDTO) (Resp, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		getSenderConnection(h, w, r, senderType, provider, fromDTO)
	}
}

// updateSenderHandler binds a vendor's type, provider and mappers to updateSenderConnection.
func updateSenderHandler[Req any, Resp any](h *handler, senderType ncommon.NotificationSenderType,
	provider ncommon.NotificationProviderType,
	toDTO func(Req) (*ncommon.NotificationSenderDTO, error),
	fromDTO func(ncommon.NotificationSenderDTO) (Resp, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		updateSenderConnection(h, w, r, senderType, provider, toDTO, fromDTO)
	}
}

// listSenderInstances returns a handler that lists the configured senders of a provider.
func (h *handler) listSenderInstances(senderType ncommon.NotificationSenderType,
	provider ncommon.NotificationProviderType) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		instances, svcErr := h.svc.listSendersByProvider(ctx, senderType, provider)
		if svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		summaries := make([]connectionInstanceSummary, 0, len(instances))
		for _, instance := range instances {
			summaries = append(summaries, connectionInstanceSummary{
				ID:          instance.ID,
				Name:        instance.Name,
				Description: instance.Description,
			})
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, summaries)
	}
}

// deleteSenderInstance returns a handler that deletes a sender of a provider.
func (h *handler) deleteSenderInstance(senderType ncommon.NotificationSenderType,
	provider ncommon.NotificationProviderType) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		id := r.PathValue("id")
		if strings.TrimSpace(id) == "" {
			writeServiceError(ctx, w, &notification.ErrorInvalidSenderID)
			return
		}
		if svcErr := h.svc.deleteSenderByProvider(ctx, senderType, provider, id); svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusNoContent, nil)
	}
}

// usagesSenderInstance returns a handler that lists the resources referencing a sender of a
// provider. Drives the pre-delete confirmation dialog.
func (h *handler) usagesSenderInstance(senderType ncommon.NotificationSenderType,
	provider ncommon.NotificationProviderType) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()
		id := r.PathValue("id")
		if strings.TrimSpace(id) == "" {
			writeServiceError(ctx, w, &notification.ErrorInvalidSenderID)
			return
		}
		usages, svcErr := h.svc.usagesSenderByProvider(ctx, senderType, provider, id)
		if svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, usages)
	}
}

// handleSharingPolicyPost records a sharing policy on a connection.
func (h *handler) handleSharingPolicyPost(owner ownerLookup) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()

		wire, ok := sharing.DecodePolicyBody[sharing.PolicyCreateBody](ctx, w, r, ErrorInvalidRequestFormat)
		if !ok {
			return
		}
		req := wire.ToPolicyRequest()
		// A reach not bounded by where the issuer sits is a deployment decision, so this API leaves it
		// to a resource file or an import. An edit may still restate such a section to move its
		// exclusions, and the framework refuses any edit that would introduce one.
		if req.IsDeploymentWide() {
			sysutils.WriteErrorResponse(ctx, w, http.StatusBadRequest, apierror.ErrorResponse{
				Code:        ErrorDeploymentWideSharingNotAllowed.Code,
				Message:     ErrorDeploymentWideSharingNotAllowed.Error,
				Description: ErrorDeploymentWideSharingNotAllowed.ErrorDescription,
			})
			return
		}

		policy, svcErr := h.svc.createSharingPolicy(ctx, owner, r.PathValue("id"), req)
		if svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusCreated, sharing.ToPolicyResponse(policy))
	}
}

// handleSharingPolicyList returns one page of a connection's sharing policies.
func (h *handler) handleSharingPolicyList(owner ownerLookup) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()

		limit, offset, svcErr := parsePaginationParams(r.URL.Query())
		if svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		list, svcErr := h.svc.listSharingPolicies(ctx, owner, r.PathValue("id"), limit, offset)
		if svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusOK,
			sharing.ToPolicyListResponse(list, r.URL.Path, limit, offset))
	}
}

// handleSharingPolicyGet returns one of a connection's sharing policies.
func (h *handler) handleSharingPolicyGet(owner ownerLookup) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()

		policy, svcErr := h.svc.getSharingPolicy(ctx, owner, r.PathValue("id"), r.PathValue("policyId"))
		if svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, sharing.ToPolicyResponse(policy))
	}
}

// handleSharingPolicyPut replaces a sharing policy's contents.
func (h *handler) handleSharingPolicyPut(owner ownerLookup) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()

		wire, ok := sharing.DecodePolicyBody[sharing.PolicyUpdateBody](ctx, w, r, ErrorInvalidRequestFormat)
		if !ok {
			return
		}
		policy, svcErr := h.svc.updateSharingPolicy(ctx, owner, r.PathValue("id"), r.PathValue("policyId"),
			wire.ToPolicyRequest())
		if svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, sharing.ToPolicyResponse(policy))
	}
}

// handleSharingPolicyDelete removes a sharing policy.
func (h *handler) handleSharingPolicyDelete(owner ownerLookup) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()

		if svcErr := h.svc.deleteSharingPolicy(ctx, owner, r.PathValue("id"), r.PathValue("policyId")); svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		w.WriteHeader(http.StatusNoContent)
	}
}

// handleOverlayRuleGet answers what the organization unit named in ouId may do with the connection.
func (h *handler) handleOverlayRuleGet(owner ownerLookup) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()

		overlay, svcErr := h.svc.resolveSharingOverlay(ctx, owner, r.PathValue("id"), r.URL.Query().Get("ouId"))
		if svcErr != nil {
			writeServiceError(ctx, w, svcErr)
			return
		}
		sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, sharing.ToResolvedOverlayResponse(overlay))
	}
}
