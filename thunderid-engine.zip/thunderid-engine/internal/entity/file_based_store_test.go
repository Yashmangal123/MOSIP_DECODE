// Copyright 2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package entity

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/suite"

	declarativeresource "github.com/thunder-id/thunderid/internal/system/declarative_resource"
	entitystore "github.com/thunder-id/thunderid/internal/system/declarative_resource/entity"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"
)

type FileBasedStoreTestSuite struct {
	suite.Suite
	store *entityFileBasedStore
	ctx   context.Context
}

func TestFileBasedStoreTestSuite(t *testing.T) {
	suite.Run(t, new(FileBasedStoreTestSuite))
}

func (s *FileBasedStoreTestSuite) SetupTest() {
	genericStore := declarativeresource.NewGenericFileBasedStoreForTest(entitystore.KeyTypeEntity)
	s.store = &entityFileBasedStore{GenericFileBasedStore: genericStore}
	s.ctx = context.Background()
}

func makeTestEntity(id, category, ouID string) providers.Entity {
	attrs, _ := json.Marshal(map[string]interface{}{"username": id + "-user", "email": id + "@test.com"})
	return providers.Entity{
		ID:         id,
		Category:   providers.EntityCategory(category),
		Type:       "employee",
		State:      providers.EntityStateActive,
		OUID:       ouID,
		Attributes: json.RawMessage(attrs),
	}
}

func (s *FileBasedStoreTestSuite) seedEntity(e providers.Entity) {
	entry := &entityStoreEntry{Entity: e}
	s.Require().NoError(s.store.GenericFileBasedStore.Create(e.ID, entry))
}

func (s *FileBasedStoreTestSuite) TestCreate_InvalidType() {
	err := s.store.Create("id1", "not-an-entity-store-entry")
	s.Error(err)
}

func (s *FileBasedStoreTestSuite) TestCreate_ValidType() {
	e := makeTestEntity("e1", "user", "ou1")
	entry := &entityStoreEntry{Entity: e}
	err := s.store.Create("e1", entry)
	s.NoError(err)
}

func (s *FileBasedStoreTestSuite) TestCreateEntity() {
	e := makeTestEntity("e2", "user", "ou1")
	err := s.store.CreateEntity(s.ctx, e, nil, nil)
	s.NoError(err)

	got, err := s.store.GetEntity(s.ctx, "e2")
	s.NoError(err)
	s.Equal(e.ID, got.ID)
}

func (s *FileBasedStoreTestSuite) TestGetEntity_NotFound() {
	_, err := s.store.GetEntity(s.ctx, "nonexistent")
	s.ErrorIs(err, ErrEntityNotFound)
}

func (s *FileBasedStoreTestSuite) TestGetEntity_CorruptedData() {
	s.Require().NoError(s.store.GenericFileBasedStore.Create("bad-id", "not-an-entry"))
	_, err := s.store.GetEntity(s.ctx, "bad-id")
	s.Error(err)
}

func (s *FileBasedStoreTestSuite) TestGetEntityWithCredentials_Found() {
	e := makeTestEntity("e3", "user", "ou1")
	creds := json.RawMessage(`{"password":"hashed"}`)
	sysCreds := json.RawMessage(`{"token":"abc"}`)
	s.Require().NoError(s.store.CreateEntity(s.ctx, e, creds, sysCreds))

	result, err := s.store.GetEntityWithCredentials(s.ctx, "e3")
	s.NoError(err)
	s.Equal(e.ID, result.Entity.ID)
	s.Equal(string(creds), string(result.SchemaCredentials))
	s.Equal(string(sysCreds), string(result.SystemCredentials))
}

func (s *FileBasedStoreTestSuite) TestGetEntityWithCredentials_NotFound() {
	_, err := s.store.GetEntityWithCredentials(s.ctx, "missing")
	s.ErrorIs(err, ErrEntityNotFound)
}

func (s *FileBasedStoreTestSuite) TestGetEntityWithCredentials_Corrupted() {
	s.Require().NoError(s.store.GenericFileBasedStore.Create("bad2", "corrupted"))
	_, err := s.store.GetEntityWithCredentials(s.ctx, "bad2")
	s.Error(err)
}

func (s *FileBasedStoreTestSuite) TestUnsupportedMutations() {
	e := makeTestEntity("e4", "user", "ou1")

	s.Error(s.store.UpdateEntity(s.ctx, &e))
	s.Error(s.store.UpdateSystemAttributes(s.ctx, "e4", nil))
	s.Error(s.store.UpdateCredentials(s.ctx, "e4", nil))
	s.Error(s.store.UpdateSystemCredentials(s.ctx, "e4", nil))
	s.Error(s.store.DeleteEntity(s.ctx, "e4"))
	_, err := s.store.LockEntity(s.ctx, "e4")
	s.Error(err)
}

func (s *FileBasedStoreTestSuite) TestIdentifyEntity_NoMatch() {
	s.seedEntity(makeTestEntity("e5", "user", "ou1"))
	_, err := s.store.IdentifyEntity(s.ctx, map[string]interface{}{"email": "nobody@nowhere.com"})
	s.ErrorIs(err, ErrEntityNotFound)
}

func (s *FileBasedStoreTestSuite) TestIdentifyEntity_OneMatch() {
	e := makeTestEntity("e6", "user", "ou1")
	s.seedEntity(e)
	id, err := s.store.IdentifyEntity(s.ctx, map[string]interface{}{"email": "e6@test.com"})
	s.NoError(err)
	s.Equal("e6", *id)
}

func (s *FileBasedStoreTestSuite) TestIdentifyEntity_ArrayItemMatch() {
	attrs, _ := json.Marshal(map[string]interface{}{"email": []string{"primary@test.com", "secondary@test.com"}})
	s.seedEntity(providers.Entity{ID: "arr1", Category: providers.EntityCategoryUser, Attributes: attrs})

	id, err := s.store.IdentifyEntity(s.ctx, map[string]interface{}{"email": "secondary@test.com"})
	s.NoError(err)
	s.Equal("arr1", *id)
}

func (s *FileBasedStoreTestSuite) TestIdentifyEntity_ArrayItemSharedWithScalar_Ambiguous() {
	arrayAttrs, _ := json.Marshal(map[string]interface{}{"email": []string{"shared@test.com", "other@test.com"}})
	scalarAttrs, _ := json.Marshal(map[string]interface{}{"email": "shared@test.com"})
	s.seedEntity(providers.Entity{ID: "arr2", Category: providers.EntityCategoryUser, Attributes: arrayAttrs})
	s.seedEntity(providers.Entity{ID: "scl2", Category: providers.EntityCategoryUser, Attributes: scalarAttrs})

	_, err := s.store.IdentifyEntity(s.ctx, map[string]interface{}{"email": "shared@test.com"})
	s.ErrorIs(err, ErrAmbiguousEntity)
}

func (s *FileBasedStoreTestSuite) TestIdentifyEntity_MultipleMatches() {
	attrs1, _ := json.Marshal(map[string]interface{}{"email": "dup@test.com"})
	attrs2, _ := json.Marshal(map[string]interface{}{"email": "dup@test.com"})
	e1 := providers.Entity{ID: "dup1", Category: providers.EntityCategoryUser, Attributes: json.RawMessage(attrs1)}
	e2 := providers.Entity{ID: "dup2", Category: providers.EntityCategoryUser, Attributes: json.RawMessage(attrs2)}
	s.seedEntity(e1)
	s.seedEntity(e2)

	_, err := s.store.IdentifyEntity(s.ctx, map[string]interface{}{"email": "dup@test.com"})
	s.Error(err)
}

func (s *FileBasedStoreTestSuite) seedLinkedEntity(id, linkedIDs string) {
	s.seedEntity(providers.Entity{ID: id, Category: providers.EntityCategoryUser,
		SystemAttributes: json.RawMessage(`{"linkedIds":` + linkedIDs + `}`)})
}

func (s *FileBasedStoreTestSuite) TestResolveLinkedAccounts_OneMatch() {
	s.seedLinkedEntity("linked1", `{"idp-a":{"sub-1":{}}}`)
	s.seedLinkedEntity("other1", `{"idp-a":{"sub-2":{}}}`)

	ids, err := s.store.ResolveLinkedAccounts(s.ctx, "idp-a", "sub-1")
	s.Require().NoError(err)
	s.Equal([]string{"linked1"}, ids)
}

func (s *FileBasedStoreTestSuite) TestResolveLinkedAccounts_NoMatch() {
	s.seedEntity(makeTestEntity("plain1", "user", "ou1"))
	s.seedLinkedEntity("linked2", `{"idp-b":{"sub-1":{}}}`)
	s.seedLinkedEntity("malformed1", `"not-an-object"`)

	ids, err := s.store.ResolveLinkedAccounts(s.ctx, "idp-a", "sub-1")
	s.Require().NoError(err)
	s.Empty(ids)
}

func (s *FileBasedStoreTestSuite) TestResolveLinkedAccounts_MultipleMatches() {
	s.seedLinkedEntity("linked3", `{"idp-a":{"sub-1":{}}}`)
	s.seedLinkedEntity("linked4", `{"idp-a":{"sub-1":{}}}`)

	ids, err := s.store.ResolveLinkedAccounts(s.ctx, "idp-a", "sub-1")
	s.Require().NoError(err)
	s.ElementsMatch([]string{"linked3", "linked4"}, ids)
}

func (s *FileBasedStoreTestSuite) TestGetEntityListCount_WithCategoryAndFilter() {
	s.seedEntity(makeTestEntity("u1", "user", "ou1"))
	s.seedEntity(makeTestEntity("u2", "user", "ou1"))
	s.seedEntity(makeTestEntity("a1", "app", "ou1"))

	count, err := s.store.GetEntityListCount(s.ctx, "user", nil)
	s.NoError(err)
	s.Equal(2, count)

	count, err = s.store.GetEntityListCount(s.ctx, "user", map[string]interface{}{"email": "u1@test.com"})
	s.NoError(err)
	s.Equal(1, count)
}

func (s *FileBasedStoreTestSuite) TestGetEntityList_Pagination() {
	for i := 0; i < 5; i++ {
		s.seedEntity(makeTestEntity("p"+string(rune('0'+i)), "user", "ou1"))
	}

	all, err := s.store.GetEntityList(s.ctx, "user", 0, 0, nil)
	s.NoError(err)
	s.Len(all, 5)

	page, err := s.store.GetEntityList(s.ctx, "user", 2, 1, nil)
	s.NoError(err)
	s.Len(page, 2)

	empty, err := s.store.GetEntityList(s.ctx, "user", 2, 100, nil)
	s.NoError(err)
	s.Empty(empty)

	negLimit, err := s.store.GetEntityList(s.ctx, "user", -1, 0, nil)
	s.NoError(err)
	s.Empty(negLimit)
}

func (s *FileBasedStoreTestSuite) TestGetEntityListCountByOUIDs() {
	s.seedEntity(makeTestEntity("ou1e1", "user", "ou-A"))
	s.seedEntity(makeTestEntity("ou2e1", "user", "ou-B"))
	s.seedEntity(makeTestEntity("ou3e1", "user", "ou-C"))

	count, err := s.store.GetEntityListCountByOUIDs(s.ctx, "user", []string{"ou-A", "ou-B"}, nil)
	s.NoError(err)
	s.Equal(2, count)
}

func (s *FileBasedStoreTestSuite) TestGetEntityListByOUIDs_WithFilter() {
	s.seedEntity(makeTestEntity("flt1", "user", "ou-X"))
	s.seedEntity(makeTestEntity("flt2", "user", "ou-X"))

	filter := map[string]interface{}{"email": "flt1@test.com"}
	list, err := s.store.GetEntityListByOUIDs(s.ctx, "user", []string{"ou-X"}, 0, 0, filter)
	s.NoError(err)
	s.Len(list, 1)
	s.Equal("flt1", list[0].ID)
}

// A system attribute filter matches the system attributes only, never a schema attribute of the same
// name; the other filters match as the list filters do.
func (s *FileBasedStoreTestSuite) TestGetEntityListBySystemAttributes() {
	withSystemAttrs := func(e providers.Entity, owner string) providers.Entity {
		e.SystemAttributes, _ = json.Marshal(map[string]interface{}{"owner": owner})
		return e
	}
	s.seedEntity(withSystemAttrs(makeTestEntity("own1", "agent", "ou-A"), "user-1"))
	s.seedEntity(withSystemAttrs(makeTestEntity("own2", "agent", "ou-B"), "user-1"))
	s.seedEntity(withSystemAttrs(makeTestEntity("other", "agent", "ou-A"), "user-2"))
	s.seedEntity(withSystemAttrs(makeTestEntity("app1", "app", "ou-A"), "user-1"))
	schemaOwner := makeTestEntity("schema", "agent", "ou-A")
	schemaOwner.Attributes, _ = json.Marshal(map[string]interface{}{"owner": "user-1"})
	s.seedEntity(schemaOwner)

	byOwner := SystemAttributeQuery{SystemAttributes: map[string]interface{}{"owner": "user-1"}}
	count, err := s.store.GetEntityListCountBySystemAttributes(s.ctx, "agent", byOwner)
	s.NoError(err)
	s.Equal(2, count)

	list, err := s.store.GetEntityListBySystemAttributes(s.ctx, "agent", byOwner, 1, 0)
	s.NoError(err)
	s.Len(list, 1)

	withAttr := byOwner
	withAttr.Attributes = map[string]interface{}{"email": "own1@test.com"}
	list, err = s.store.GetEntityListBySystemAttributes(s.ctx, "agent", withAttr, 10, 0)
	s.NoError(err)
	s.Require().Len(list, 1)
	s.Equal("own1", list[0].ID)

	count, err = s.store.GetEntityListCountBySystemAttributes(s.ctx, "agent", SystemAttributeQuery{})
	s.NoError(err)
	s.Zero(count, "no system attribute filter matches nothing")
}

func (s *FileBasedStoreTestSuite) TestGetEntityListBySystemAttributesAndOUIDs() {
	withOwner := func(e providers.Entity, owner string) providers.Entity {
		e.SystemAttributes, _ = json.Marshal(map[string]interface{}{"owner": owner})
		return e
	}
	s.seedEntity(withOwner(makeTestEntity("ouA1", "agent", "ou-A"), "user-1"))
	s.seedEntity(withOwner(makeTestEntity("ouB1", "agent", "ou-B"), "user-1"))
	s.seedEntity(withOwner(makeTestEntity("ouB2", "agent", "ou-B"), "user-2"))

	byOwner := SystemAttributeQuery{SystemAttributes: map[string]interface{}{"owner": "user-1"}}
	count, err := s.store.GetEntityListCountBySystemAttributesAndOUIDs(s.ctx, "agent", byOwner, []string{"ou-B"})
	s.NoError(err)
	s.Equal(1, count)

	list, err := s.store.GetEntityListBySystemAttributesAndOUIDs(
		s.ctx, "agent", byOwner, []string{"ou-A", "ou-B"}, 1, 1)
	s.NoError(err)
	s.Len(list, 1, "paginated within the OUs")

	count, err = s.store.GetEntityListCountBySystemAttributesAndOUIDs(s.ctx, "agent", byOwner, []string{})
	s.NoError(err)
	s.Zero(count, "an empty OU list matches nothing")
	count, err = s.store.GetEntityListCountBySystemAttributesAndOUIDs(s.ctx, "agent", byOwner, nil)
	s.NoError(err)
	s.Zero(count, "a nil OU list matches nothing")
}

func (s *FileBasedStoreTestSuite) TestGetGroupCountForEntity() {
	count, err := s.store.GetGroupCountForEntity(s.ctx, "any-id")
	s.NoError(err)
	s.Equal(0, count)
}

func (s *FileBasedStoreTestSuite) TestGetEntityGroups() {
	groups, err := s.store.GetEntityGroups(s.ctx, "any-id", 10, 0)
	s.NoError(err)
	s.Empty(groups)
}

func (s *FileBasedStoreTestSuite) TestValidateEntityIDs() {
	s.seedEntity(makeTestEntity("v1", "user", "ou1"))
	s.seedEntity(makeTestEntity("v2", "user", "ou1"))

	invalid, err := s.store.ValidateEntityIDs(s.ctx, []string{"v1", "v2", "missing"})
	s.NoError(err)
	s.Equal([]string{"missing"}, invalid)
}

func (s *FileBasedStoreTestSuite) TestGetEntitiesByIDs_Empty() {
	result, err := s.store.GetEntitiesByIDs(s.ctx, []string{})
	s.NoError(err)
	s.Empty(result)
}

func (s *FileBasedStoreTestSuite) TestGetEntitiesByIDs_MixedExists() {
	s.seedEntity(makeTestEntity("ge1", "user", "ou1"))

	result, err := s.store.GetEntitiesByIDs(s.ctx, []string{"ge1", "nope"})
	s.NoError(err)
	s.Len(result, 1)
	s.Equal("ge1", result[0].ID)
}

func (s *FileBasedStoreTestSuite) TestValidateEntityIDsInOUs_EmptyEntityIDs() {
	out, err := s.store.ValidateEntityIDsInOUs(s.ctx, []string{}, []string{"ou1"})
	s.NoError(err)
	s.Empty(out)
}

func (s *FileBasedStoreTestSuite) TestValidateEntityIDsInOUs_EmptyOUIDs() {
	out, err := s.store.ValidateEntityIDsInOUs(s.ctx, []string{"e1", "e2"}, []string{})
	s.NoError(err)
	s.Equal([]string{"e1", "e2"}, out)
}

func (s *FileBasedStoreTestSuite) TestValidateEntityIDsInOUs_Mixed() {
	s.seedEntity(makeTestEntity("in1", "user", "ou-A"))
	s.seedEntity(makeTestEntity("out1", "user", "ou-B"))

	outOfScope, err := s.store.ValidateEntityIDsInOUs(s.ctx, []string{"in1", "out1", "missing"}, []string{"ou-A"})
	s.NoError(err)
	s.ElementsMatch([]string{"out1", "missing"}, outOfScope)
}

func (s *FileBasedStoreTestSuite) TestIsEntityDeclarative() {
	s.seedEntity(makeTestEntity("decl1", "user", "ou1"))

	ok, err := s.store.IsEntityDeclarative(s.ctx, "decl1")
	s.NoError(err)
	s.True(ok)

	ok, err = s.store.IsEntityDeclarative(s.ctx, "nonexistent")
	s.NoError(err)
	s.False(ok)
}

func (s *FileBasedStoreTestSuite) TestGetIndexedAttributes() {
	s.Nil(s.store.GetIndexedAttributes())
}

func (s *FileBasedStoreTestSuite) TestApplyPagination() {
	entities := []providers.Entity{{ID: "a"}, {ID: "b"}, {ID: "c"}, {ID: "d"}, {ID: "e"}}

	s.Len(applyPagination(entities, 2, 0), 2)
	s.Len(applyPagination(entities, 0, 0), 5)
	s.Len(applyPagination(entities, 10, 3), 2)
	s.Empty(applyPagination(entities, 2, 10))
	s.Empty(applyPagination(entities, -1, 0))
	s.Len(applyPagination(entities, 3, -1), 3)
}

func (s *FileBasedStoreTestSuite) TestMatchesFilters() {
	attrs := json.RawMessage(`{"email":"a@b.com","nested":{"key":"val"},"count":1}`)

	s.True(matchesFilters(attrs, nil))
	s.True(matchesFilters(attrs, map[string]interface{}{"email": "a@b.com"}))
	s.False(matchesFilters(attrs, map[string]interface{}{"email": "wrong@b.com"}))
	s.True(matchesFilters(attrs, map[string]interface{}{"nested.key": "val"}))
	s.False(matchesFilters(attrs, map[string]interface{}{"nested.missing": "val"}))
	s.False(matchesFilters(nil, map[string]interface{}{"email": "a@b.com"}))
	s.False(matchesFilters(json.RawMessage(`invalid-json`), map[string]interface{}{"k": "v"}))
}

func (s *FileBasedStoreTestSuite) TestMatchesFilters_ArrayMatchesAnyElement() {
	attrs := json.RawMessage(`{"email":["a@b.com","c@d.com"],"codes":[1,2],"nested":[["a@b.com"]]}`)

	s.True(matchesFilters(attrs, map[string]interface{}{"email": "a@b.com"}))
	s.True(matchesFilters(attrs, map[string]interface{}{"email": "c@d.com"}))
	s.False(matchesFilters(attrs, map[string]interface{}{"email": "x@y.com"}))
	s.True(matchesFilters(attrs, map[string]interface{}{"codes": int64(2)}))
	s.False(matchesFilters(json.RawMessage(`{"email":[]}`), map[string]interface{}{"email": "a@b.com"}))
	s.False(matchesFilters(attrs, map[string]interface{}{"nested": "a@b.com"}), "nested arrays are not searched")
}

func (s *FileBasedStoreTestSuite) TestGetNestedValue() {
	data := map[string]interface{}{
		"a": map[string]interface{}{
			"b": "found",
		},
		"flat": "value",
	}

	val, ok := getNestedValue(data, "a.b")
	s.True(ok)
	s.Equal("found", val)

	_, ok = getNestedValue(data, "a.missing")
	s.False(ok)

	_, ok = getNestedValue(data, "flat.sub")
	s.False(ok)
}

func (s *FileBasedStoreTestSuite) TestValuesEqual() {
	s.True(valuesEqual(float64(42), int64(42)))
	s.True(valuesEqual(float64(3.14), float64(3.14)))
	s.True(valuesEqual(float64(5), int(5)))
	s.False(valuesEqual(float64(5), int64(6)))
	s.True(valuesEqual("hello", "hello"))
	s.False(valuesEqual("hello", "world"))
	s.True(valuesEqual(true, true))
	s.False(valuesEqual(true, false))
	s.False(valuesEqual(float64(1), "1"))
	s.False(valuesEqual("x", 1))
	s.False(valuesEqual(true, "true"))
}

func (s *FileBasedStoreTestSuite) TestSearchEntities_NoMatch() {
	s.seedEntity(makeTestEntity("s1", "user", "ou1"))
	_, err := s.store.SearchEntities(s.ctx, map[string]interface{}{"email": "nobody@nowhere.com"})
	s.ErrorIs(err, ErrEntityNotFound)
}

func (s *FileBasedStoreTestSuite) TestSearchEntities_OneMatch() {
	s.seedEntity(makeTestEntity("s2", "user", "ou1"))
	got, err := s.store.SearchEntities(s.ctx, map[string]interface{}{"email": "s2@test.com"})
	s.NoError(err)
	s.Len(got, 1)
	s.Equal("s2", got[0].ID)
}

func (s *FileBasedStoreTestSuite) TestSearchEntities_MultipleMatches() {
	attrs, _ := json.Marshal(map[string]interface{}{"email": "shared@test.com"})
	e1 := providers.Entity{ID: "m1", Category: providers.EntityCategoryUser, Attributes: json.RawMessage(attrs)}
	e2 := providers.Entity{ID: "m2", Category: providers.EntityCategoryUser, Attributes: json.RawMessage(attrs)}
	s.seedEntity(e1)
	s.seedEntity(e2)
	got, err := s.store.SearchEntities(s.ctx, map[string]interface{}{"email": "shared@test.com"})
	s.NoError(err)
	s.Len(got, 2)
}
