// Copyright 2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package entity

import (
	"fmt"
	"testing"

	"github.com/stretchr/testify/suite"

	"github.com/thunder-id/thunderid/internal/system/config"
	engineconfig "github.com/thunder-id/thunderid/pkg/thunderidengine/config"
)

type StoreConstantsTestSuite struct {
	suite.Suite
}

func TestStoreConstantsTestSuite(t *testing.T) {
	suite.Run(t, new(StoreConstantsTestSuite))
}

const testDeploymentID = "test-deployment"

func (s *StoreConstantsTestSuite) TestAppendOUIDsINClause_EmptyOUIDs() {
	q, args := appendOUIDsINClause(QueryGetEntityByID, []interface{}{"e1", "dep1"}, []string{})
	s.Contains(q.Query, "1=0")
	s.Len(args, 2)
}

func (s *StoreConstantsTestSuite) TestAppendOUIDsINClause_WithOUIDs() {
	q, args := appendOUIDsINClause(QueryGetEntityByID, []interface{}{"e1", "dep1"}, []string{"ou1", "ou2"})
	s.Contains(q.Query, "OU_ID IN")
	s.Len(args, 4) // original 2 + 2 OU IDs
}

func (s *StoreConstantsTestSuite) TestBuildEntityCountQueryByOUIDs_NoFilters() {
	q, args, err := buildEntityCountQueryByOUIDs("user", []string{"ou1"}, nil, nil, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildEntityCountQueryByOUIDs_WithFilters() {
	filters := map[string]interface{}{"email": "a@b.com"}
	q, args, err := buildEntityCountQueryByOUIDs("user", []string{"ou1"}, filters, nil, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildEntityListQueryByOUIDs_NoFilters() {
	q, args, err := buildEntityListQueryByOUIDs("user", []string{"ou1"}, nil, nil, 10, 0, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildEntityListQueryByOUIDs_WithFilters() {
	filters := map[string]interface{}{"email": "a@b.com"}
	q, args, err := buildEntityListQueryByOUIDs("user", []string{"ou1"}, filters, nil, 10, 0, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

// The system attribute keys are written in as literals, matching the expression indexes on them.
func (s *StoreConstantsTestSuite) TestBuildEntityCountQueryBySystemAttributes() {
	sysQuery := SystemAttributeQuery{SystemAttributes: map[string]interface{}{"owner": "u1"}}
	q, args, err := buildEntityCountQueryBySystemAttributes("agent", sysQuery, nil, testDeploymentID)
	s.NoError(err)
	s.Equal("ASQ-ENTITY_MGT-32", q.ID)
	s.Equal(`SELECT COUNT(*) as total FROM "ENTITY" WHERE CATEGORY = $1 `+
		`AND SYSTEM_ATTRIBUTES->>'owner' = $2 AND DEPLOYMENT_ID = $3`, q.PostgresQuery)
	s.Equal(`SELECT COUNT(*) as total FROM "ENTITY" WHERE CATEGORY = ? `+
		`AND json_extract(SYSTEM_ATTRIBUTES, '$.owner') = ? AND DEPLOYMENT_ID = ?`, q.SQLiteQuery)
	s.Equal(q.PostgresQuery, q.Query)
	s.Equal([]interface{}{"agent", "u1", testDeploymentID}, args)
}

func (s *StoreConstantsTestSuite) TestBuildEntityListQueryBySystemAttributes_AllConditions() {
	sysQuery := SystemAttributeQuery{
		SystemAttributes: map[string]interface{}{"owner": "u1", "agentCategory": "personal-assistant"},
		Attributes:       map[string]interface{}{"name": "Assistant"},
	}
	q, args, err := buildEntityListQueryBySystemAttributes(
		"agent", sysQuery, map[string]bool{"name": true}, 10, 20, testDeploymentID)
	s.NoError(err)
	s.Equal("ASQ-ENTITY_MGT-33", q.ID)
	s.Equal(`SELECT ID, OU_ID, CATEGORY, TYPE, ATTRIBUTES, SYSTEM_ATTRIBUTES FROM "ENTITY" WHERE CATEGORY = $1 `+
		`AND (ATTRIBUTES->>'name' = $2 OR `+fmt.Sprintf(identifierExistsCondition, "name", "$3")+`) `+
		`AND SYSTEM_ATTRIBUTES->>'agentCategory' = $4 AND SYSTEM_ATTRIBUTES->>'owner' = $5 `+
		`AND DEPLOYMENT_ID = $6 ORDER BY ID LIMIT $7 OFFSET $8`, q.PostgresQuery)
	s.Equal(`SELECT ID, OU_ID, CATEGORY, TYPE, ATTRIBUTES, SYSTEM_ATTRIBUTES FROM "ENTITY" WHERE CATEGORY = ? `+
		`AND (json_extract(ATTRIBUTES, '$.name') = ? OR `+fmt.Sprintf(identifierExistsCondition, "name", "?")+`) `+
		`AND json_extract(SYSTEM_ATTRIBUTES, '$.agentCategory') = ? `+
		`AND json_extract(SYSTEM_ATTRIBUTES, '$.owner') = ? `+
		`AND DEPLOYMENT_ID = ? ORDER BY ID LIMIT ? OFFSET ?`, q.SQLiteQuery)
	s.Equal([]interface{}{"agent", "Assistant", "Assistant", "personal-assistant", "u1",
		testDeploymentID, 10, 20}, args)
}

// The OU-scoped variants always apply the OU list, before the deployment condition.
func (s *StoreConstantsTestSuite) TestBuildEntityQueryBySystemAttributesAndOUIDs() {
	sysQuery := SystemAttributeQuery{SystemAttributes: map[string]interface{}{"owner": "u1"}}

	q, args, err := buildEntityCountQueryBySystemAttributesAndOUIDs(
		"agent", sysQuery, []string{"ou1", "ou2"}, nil, testDeploymentID)
	s.NoError(err)
	s.Equal("ASQ-ENTITY_MGT-34", q.ID)
	s.Equal(`SELECT COUNT(*) as total FROM "ENTITY" WHERE CATEGORY = $1 `+
		`AND SYSTEM_ATTRIBUTES->>'owner' = $2 AND OU_ID IN ($3, $4) AND DEPLOYMENT_ID = $5`, q.PostgresQuery)
	s.Equal(`SELECT COUNT(*) as total FROM "ENTITY" WHERE CATEGORY = ? `+
		`AND json_extract(SYSTEM_ATTRIBUTES, '$.owner') = ? AND OU_ID IN (?, ?) AND DEPLOYMENT_ID = ?`,
		q.SQLiteQuery)
	s.Equal([]interface{}{"agent", "u1", "ou1", "ou2", testDeploymentID}, args)

	q, args, err = buildEntityListQueryBySystemAttributesAndOUIDs(
		"agent", sysQuery, []string{"ou1"}, nil, 10, 0, testDeploymentID)
	s.NoError(err)
	s.Equal("ASQ-ENTITY_MGT-35", q.ID)
	s.Equal(`SELECT ID, OU_ID, CATEGORY, TYPE, ATTRIBUTES, SYSTEM_ATTRIBUTES FROM "ENTITY" WHERE CATEGORY = $1 `+
		`AND SYSTEM_ATTRIBUTES->>'owner' = $2 AND OU_ID IN ($3) AND DEPLOYMENT_ID = $4 `+
		`ORDER BY ID LIMIT $5 OFFSET $6`, q.PostgresQuery)
	s.Equal([]interface{}{"agent", "u1", "ou1", testDeploymentID, 10, 0}, args)

	q, _, err = buildEntityListQueryBySystemAttributesAndOUIDs(
		"agent", sysQuery, []string{}, nil, 10, 0, testDeploymentID)
	s.NoError(err)
	s.Contains(q.PostgresQuery, " AND 1=0", "an empty OU list matches nothing")
	s.Contains(q.SQLiteQuery, " AND 1=0", "an empty OU list matches nothing")

	_, _, err = buildEntityCountQueryBySystemAttributesAndOUIDs(
		"agent", SystemAttributeQuery{}, []string{"ou1"}, nil, testDeploymentID)
	s.Error(err)
	_, _, err = buildEntityListQueryBySystemAttributesAndOUIDs(
		"agent", SystemAttributeQuery{}, []string{"ou1"}, nil, 10, 0, testDeploymentID)
	s.Error(err)
}

func (s *StoreConstantsTestSuite) TestBuildEntityQueryBySystemAttributes_Errors() {
	_, _, err := buildEntityCountQueryBySystemAttributes("agent", SystemAttributeQuery{}, nil, testDeploymentID)
	s.Error(err, "no system attribute filter")

	badKey := SystemAttributeQuery{SystemAttributes: map[string]interface{}{"owner'--": "u1"}}
	_, _, err = buildEntityListQueryBySystemAttributes("agent", badKey, nil, 10, 0, testDeploymentID)
	s.Error(err, "invalid system attribute key")

	badAttr := SystemAttributeQuery{
		SystemAttributes: map[string]interface{}{"owner": "u1"},
		Attributes:       map[string]interface{}{"name'--": "x"},
	}
	_, _, err = buildEntityListQueryBySystemAttributes("agent", badAttr, nil, 10, 0, testDeploymentID)
	s.Error(err, "invalid attribute key")
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQuery_EmptyFilters() {
	_, _, err := buildIdentifyQuery(map[string]interface{}{}, testDeploymentID)
	s.Error(err)
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQuery_WithFilters() {
	q, args, err := buildIdentifyQuery(map[string]interface{}{"email": "a@b.com"}, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildEntityINClauseQuery_EmptyIDs() {
	baseQuery := `SELECT ID FROM "ENTITY" WHERE ID IN (%s) AND DEPLOYMENT_ID = %s`
	_, _, err := buildEntityINClauseQuery("qid", baseQuery, []string{}, testDeploymentID)
	s.Error(err)
}

func (s *StoreConstantsTestSuite) TestBuildEntityINClauseQuery_WithIDs() {
	baseQuery := `SELECT ID FROM "ENTITY" WHERE ID IN (%s) AND DEPLOYMENT_ID = %s`
	q, args, err := buildEntityINClauseQuery("qid", baseQuery, []string{"id1", "id2"}, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildBulkEntityExistsQuery_Success() {
	q, args, err := buildBulkEntityExistsQuery([]string{"id1", "id2"}, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildBulkEntityExistsQueryInOUs_EmptyEntityIDs() {
	_, _, err := buildBulkEntityExistsQueryInOUs([]string{}, []string{"ou1"}, testDeploymentID)
	s.Error(err)
}

func (s *StoreConstantsTestSuite) TestBuildBulkEntityExistsQueryInOUs_EmptyOUIDs() {
	_, _, err := buildBulkEntityExistsQueryInOUs([]string{"id1"}, []string{}, testDeploymentID)
	s.Error(err)
}

func (s *StoreConstantsTestSuite) TestBuildBulkEntityExistsQueryInOUs_WithBoth() {
	q, args, err := buildBulkEntityExistsQueryInOUs([]string{"id1", "id2"}, []string{"ou1"}, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildEntityListQuery_NoFilters() {
	q, args, err := buildEntityListQuery("user", nil, nil, 10, 0, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildEntityListQuery_WithFilters() {
	filters := map[string]interface{}{"email": "a@b.com"}
	q, args, err := buildEntityListQuery("user", filters, nil, 10, 0, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildEntityCountQuery_NoFilters() {
	q, args, err := buildEntityCountQuery("user", nil, nil, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildEntityCountQuery_WithFilters() {
	filters := map[string]interface{}{"email": "a@b.com"}
	q, args, err := buildEntityCountQuery("user", filters, nil, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQueryFromIdentifiers_EmptyFilters() {
	_, _, err := buildIdentifyQueryFromIdentifiers(map[string]interface{}{}, testDeploymentID)
	s.Error(err)
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQueryFromIdentifiers_SingleFilter() {
	q, args, err := buildIdentifyQueryFromIdentifiers(map[string]interface{}{"email": "a@b.com"}, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQueryFromIdentifiers_MultipleFilters() {
	filters := map[string]interface{}{"email": "a@b.com", "username": "user1"}
	q, args, err := buildIdentifyQueryFromIdentifiers(filters, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.Contains(q.Query, "INNER JOIN")
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQueryHybrid_EmptyIndexedFilters() {
	_, _, err := buildIdentifyQueryHybrid(map[string]interface{}{}, map[string]interface{}{"k": "v"}, testDeploymentID)
	s.Error(err)
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQueryHybrid_Success() {
	indexed := map[string]interface{}{"email": "a@b.com"}
	nonIndexed := map[string]interface{}{"username": "user1"}
	q, args, err := buildIdentifyQueryHybrid(indexed, nonIndexed, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQueryHybrid_MultipleIndexed() {
	indexed := map[string]interface{}{"email": "a@b.com", "phone": "123"}
	nonIndexed := map[string]interface{}{"username": "user1"}
	q, args, err := buildIdentifyQueryHybrid(indexed, nonIndexed, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildGetEntitiesByIDsQuery_Success() {
	q, args, err := buildGetEntitiesByIDsQuery([]string{"id1", "id2"}, testDeploymentID)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildPaginatedQuery_Success() {
	base := `SELECT * FROM "ENTITY" WHERE DEPLOYMENT_ID = $1`
	result, err := buildPaginatedQuery(base, 1, "$")
	s.NoError(err)
	s.Contains(result, "LIMIT")
	s.Contains(result, "OFFSET")
}

const testFilterBaseQuery = `SELECT * FROM "ENTITY" WHERE CATEGORY = $1`

func (s *StoreConstantsTestSuite) TestBuildFilterQueryWithOffset_Success() {
	base := testFilterBaseQuery
	filters := map[string]interface{}{"email": "a@b.com"}
	q, args, err := buildFilterQueryWithOffset("test-qid", base, filters, nil, 1)
	s.NoError(err)
	s.NotEmpty(q.Query)
	s.NotEmpty(args)
}

func (s *StoreConstantsTestSuite) TestBuildFilterQueryWithOffset_NoFilters() {
	base := testFilterBaseQuery
	q, args, err := buildFilterQueryWithOffset("test-qid", base, nil, nil, 1)
	s.NoError(err)
	s.NotEmpty(q.Query)
	_ = args
}

func (s *StoreConstantsTestSuite) TestBuildFilterQueryWithOffset_IndexedKeyMatchesIdentifierRows() {
	base := testFilterBaseQuery
	filters := map[string]interface{}{"email": "a@b.com", "nickname": "ab"}
	q, args, err := buildFilterQueryWithOffset("test-qid", base, filters, map[string]bool{"email": true}, 1)
	s.NoError(err)

	s.Equal(base+` AND (ATTRIBUTES->>'email' = $2 OR EXISTS (SELECT 1 FROM "ENTITY_IDENTIFIER" ei `+
		`WHERE ei.ENTITY_ID = "ENTITY".ID AND ei.DEPLOYMENT_ID = "ENTITY".DEPLOYMENT_ID `+
		`AND ei.SOURCE = 'attribute' AND ei.NAME = 'email' AND ei.VALUE = $3))`+
		` AND ATTRIBUTES->>'nickname' = $4`, q.PostgresQuery)
	s.Equal(`SELECT * FROM "ENTITY" WHERE CATEGORY = ?`+
		` AND (json_extract(ATTRIBUTES, '$.email') = ? OR EXISTS (SELECT 1 FROM "ENTITY_IDENTIFIER" ei `+
		`WHERE ei.ENTITY_ID = "ENTITY".ID AND ei.DEPLOYMENT_ID = "ENTITY".DEPLOYMENT_ID `+
		`AND ei.SOURCE = 'attribute' AND ei.NAME = 'email' AND ei.VALUE = ?))`+
		` AND json_extract(ATTRIBUTES, '$.nickname') = ?`, q.SQLiteQuery)
	s.Equal([]interface{}{"a@b.com", "a@b.com", "ab"}, args)
}

// TestBuildIdentifyQuery_COALESCE_* verify that the JSON fallback query searches both
// ATTRIBUTES and SYSTEM_ATTRIBUTES using COALESCE so that an entity can be found
// regardless of which column holds the filter key (e.g. clientId in SYSTEM_ATTRIBUTES).
func (s *StoreConstantsTestSuite) TestBuildIdentifyQuery_COALESCE_PostgresQuery() {
	q, args, err := buildIdentifyQuery(map[string]interface{}{"clientId": "app123"}, testDeploymentID)
	s.NoError(err)
	s.Contains(q.PostgresQuery, "COALESCE")
	s.Contains(q.PostgresQuery, "ATTRIBUTES->>'clientId'")
	s.Contains(q.PostgresQuery, "SYSTEM_ATTRIBUTES->>'clientId'")
	s.Contains(q.PostgresQuery, "$1")
	s.Contains(q.PostgresQuery, "$2")
	s.Len(args, 2)
	s.Equal("app123", args[0])
	s.Equal(testDeploymentID, args[1])
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQuery_COALESCE_SQLiteQuery() {
	q, args, err := buildIdentifyQuery(map[string]interface{}{"clientId": "app123"}, testDeploymentID)
	s.NoError(err)
	s.Contains(q.SQLiteQuery, "COALESCE")
	s.Contains(q.SQLiteQuery, "json_extract(ATTRIBUTES, '$.clientId')")
	s.Contains(q.SQLiteQuery, "json_extract(SYSTEM_ATTRIBUTES, '$.clientId')")
	_ = args
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQuery_MultipleFilters_CorrectParamIndexes() {
	// keys are sorted: clientId < name, so clientId=$1, name=$2, deploymentID=$3
	filters := map[string]interface{}{"clientId": "app123", "name": "myapp"}
	q, args, err := buildIdentifyQuery(filters, testDeploymentID)
	s.NoError(err)
	s.Contains(q.PostgresQuery, "$1")
	s.Contains(q.PostgresQuery, "$2")
	s.Contains(q.PostgresQuery, "$3")
	s.Len(args, 3)
	s.Equal(testDeploymentID, args[2])
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQuery_NestedKey_UsesPathSyntax() {
	q, _, err := buildIdentifyQuery(map[string]interface{}{"address.city": "NYC"}, testDeploymentID)
	s.NoError(err)
	s.Contains(q.PostgresQuery, "#>>")
	s.Contains(q.PostgresQuery, "{address,city}")
	s.Contains(q.SQLiteQuery, "json_extract")
	s.Contains(q.SQLiteQuery, "$.address.city")
}

func (s *StoreConstantsTestSuite) TestBuildIdentifyQueryHybrid_NonIndexed_UsesCOALESCE() {
	indexed := map[string]interface{}{"email": "a@b.com"}
	nonIndexed := map[string]interface{}{"clientId": "app123"}
	q, _, err := buildIdentifyQueryHybrid(indexed, nonIndexed, testDeploymentID)
	s.NoError(err)
	s.Contains(q.PostgresQuery, "COALESCE")
	s.Contains(q.PostgresQuery, "e.ATTRIBUTES->>'clientId'")
	s.Contains(q.PostgresQuery, "e.SYSTEM_ATTRIBUTES->>'clientId'")
	s.Contains(q.SQLiteQuery, "COALESCE")
	s.Contains(q.SQLiteQuery, "json_extract(e.ATTRIBUTES, '$.clientId')")
	s.Contains(q.SQLiteQuery, "json_extract(e.SYSTEM_ATTRIBUTES, '$.clientId')")
}

// The stores resolve their deployment from the loaded server runtime rather than holding one, so
// these tests load a runtime naming the id the query assertions below expect.
func init() {
	_ = config.InitializeServerRuntime("", &config.Config{
		Server: engineconfig.ServerConfig{Identifier: testDeploymentID},
	})
}
