// Copyright 2025-2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package entitytype

import (
	"context"
	"errors"
	"net/http"
	"strconv"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"

	serverconst "github.com/thunder-id/thunderid/internal/system/constants"
	"github.com/thunder-id/thunderid/internal/system/error/apierror"
	"github.com/thunder-id/thunderid/internal/system/log"
	sysutils "github.com/thunder-id/thunderid/internal/system/utils"
)

const entityTypeHandlerLoggerComponentName = "EntityTypeHandler"

// entityTypeHandler is the handler for entity type management operations. Each handler instance
// is bound to a single TypeCategory so the same code path serves both /user-types and
// /agent-types with the category injected at construction time.
type entityTypeHandler struct {
	entityTypeService EntityTypeServiceInterface
	category          TypeCategory
}

// newEntityTypeHandler creates a new instance of entityTypeHandler bound to the given category.
func newEntityTypeHandler(entityTypeService EntityTypeServiceInterface,
	category TypeCategory) *entityTypeHandler {
	return &entityTypeHandler{
		entityTypeService: entityTypeService,
		category:          category,
	}
}

// HandleEntityTypeListRequest handles the entity type list request.
func (h *entityTypeHandler) HandleEntityTypeListRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, entityTypeHandlerLoggerComponentName))

	limit, offset, svcErr := parsePaginationParams(r.URL.Query())
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	if limit == 0 {
		limit = serverconst.DefaultPageSize
	}

	includeDisplay := r.URL.Query().Get(sysutils.QueryParamInclude) == sysutils.IncludeValueDisplay

	entityTypeListResponse, svcErr := h.entityTypeService.GetEntityTypeList(
		ctx, h.category, limit, offset, includeDisplay)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, entityTypeListResponse)

	logger.Debug(ctx, "Successfully listed entity types with pagination",
		log.String("category", string(h.category)),
		log.Int("limit", limit), log.Int("offset", offset),
		log.Int("totalResults", entityTypeListResponse.TotalResults),
		log.Int("count", entityTypeListResponse.Count))
}

// HandleEntityTypePostRequest handles the entity type creation request.
func (h *entityTypeHandler) HandleEntityTypePostRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, entityTypeHandlerLoggerComponentName))

	createRequest, err := sysutils.DecodeJSONBody[CreateEntityTypeRequest](r)
	if err != nil {
		var valErr *sysutils.ValidationError
		if errors.As(err, &valErr) {
			sysutils.WriteStructuredErrorResponse(w, http.StatusBadRequest, "Validation Failed", valErr.Errors)
			return
		}
		errResp := apierror.ErrorResponse{
			Code:    ErrorInvalidRequestFormat.Code,
			Message: ErrorInvalidRequestFormat.Error,
			Description: tidcommon.I18nMessage{
				Key:          "error.entitytypeservice.create_schema_request_parse_failed_description",
				DefaultValue: "Failed to parse request body"},
		}

		sysutils.WriteErrorResponse(ctx, w, http.StatusBadRequest, errResp)
		return
	}

	sanitizedRequest := h.sanitizeCreateEntityTypeRequest(*createRequest)

	createdEntityType, svcErr := h.entityTypeService.CreateEntityType(ctx, h.category,
		CreateEntityTypeRequestWithID{
			Handle:                sanitizedRequest.Handle,
			DisplayName:           sanitizedRequest.DisplayName,
			OUID:                  sanitizedRequest.OUID,
			AllowSelfRegistration: sanitizedRequest.AllowSelfRegistration,
			SystemAttributes:      sanitizedRequest.SystemAttributes,
			Schema:                sanitizedRequest.Schema,
		})
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusCreated, createdEntityType)

	logger.Debug(ctx, "Successfully created entity type",
		log.String("category", string(h.category)),
		log.String("entityTypeID", createdEntityType.ID), log.String("handle", createdEntityType.Handle))
}

// HandleEntityTypeGetRequest handles the entity type get request.
func (h *entityTypeHandler) HandleEntityTypeGetRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, entityTypeHandlerLoggerComponentName))

	schemaID, idValidationFailed := extractAndValidateSchemaID(w, r)
	if idValidationFailed {
		return
	}

	includeDisplay := r.URL.Query().Get(sysutils.QueryParamInclude) == sysutils.IncludeValueDisplay

	entityType, svcErr := h.entityTypeService.GetEntityType(ctx, h.category, schemaID, includeDisplay)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, entityType)

	logger.Debug(ctx, "Successfully retrieved entity type",
		log.String("category", string(h.category)), log.String("entityTypeID", schemaID))
}

// HandleEntityTypePutRequest handles the entity type update request.
func (h *entityTypeHandler) HandleEntityTypePutRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, entityTypeHandlerLoggerComponentName))

	schemaID, idValidationFailed := extractAndValidateSchemaID(w, r)
	if idValidationFailed {
		return
	}

	sanitizedRequest, requestValidationFailed := validateUpdateEntityTypeRequest(w, r, h)
	if requestValidationFailed {
		return
	}

	updatedEntityType, svcErr := h.entityTypeService.UpdateEntityType(
		ctx, h.category, schemaID, sanitizedRequest)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, updatedEntityType)

	logger.Debug(ctx, "Successfully updated entity type",
		log.String("category", string(h.category)),
		log.String("entityTypeID", schemaID), log.String("handle", updatedEntityType.Handle))
}

// HandleEntityTypeDeleteRequest handles the entity type delete request.
func (h *entityTypeHandler) HandleEntityTypeDeleteRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, entityTypeHandlerLoggerComponentName))

	schemaID, idValidationFailed := extractAndValidateSchemaID(w, r)
	if idValidationFailed {
		return
	}

	svcErr := h.entityTypeService.DeleteEntityType(ctx, h.category, schemaID)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusNoContent, nil)
	logger.Debug(ctx, "Successfully deleted entity type",
		log.String("category", string(h.category)), log.String("entityTypeID", schemaID))
}

// parsePaginationParams parses limit and offset from query parameters.
func parsePaginationParams(query map[string][]string) (int, int, *tidcommon.ServiceError) {
	var limit, offset int
	var err error

	if limitStr := query["limit"]; len(limitStr) > 0 && limitStr[0] != "" {
		sanitizedLimit := sysutils.SanitizeString(limitStr[0])
		limit, err = strconv.Atoi(sanitizedLimit)
		if err != nil || limit <= 0 {
			return 0, 0, &ErrorInvalidLimit
		}
	}

	if offsetStr := query["offset"]; len(offsetStr) > 0 && offsetStr[0] != "" {
		sanitizedOffset := sysutils.SanitizeString(offsetStr[0])
		offset, err = strconv.Atoi(sanitizedOffset)
		if err != nil || offset < 0 {
			return 0, 0, &ErrorInvalidOffset
		}
	}

	return limit, offset, nil
}

// handleError handles service errors and converts them to appropriate HTTP responses.
func handleError(ctx context.Context, w http.ResponseWriter, svcErr *tidcommon.ServiceError) {
	var statusCode int
	if svcErr.Type == tidcommon.ClientErrorType {
		statusCode = http.StatusBadRequest
		switch svcErr.Code {
		case ErrorEntityTypeNotFound.Code:
			statusCode = http.StatusNotFound
		case ErrorEntityTypeHandleConflict.Code:
			statusCode = http.StatusConflict
		case ErrorCannotModifyDeclarativeResource.Code:
			statusCode = http.StatusForbidden
		case tidcommon.ErrorUnauthorized.Code:
			statusCode = http.StatusForbidden
		}
	} else {
		statusCode = http.StatusInternalServerError
	}

	errResp := apierror.ErrorResponse{
		Code:        svcErr.Code,
		Message:     svcErr.Error,
		Description: svcErr.ErrorDescription,
	}

	sysutils.WriteErrorResponse(ctx, w, statusCode, errResp)
}

// extractAndValidateSchemaID extracts and validates the schema ID from the URL path.
func extractAndValidateSchemaID(w http.ResponseWriter, r *http.Request) (string, bool) {
	schemaID := r.PathValue("id")
	if schemaID == "" {
		errResp := apierror.ErrorResponse{
			Code:        ErrorInvalidEntityTypeRequest.Code,
			Message:     ErrorInvalidEntityTypeRequest.Error,
			Description: ErrorInvalidEntityTypeRequest.ErrorDescription,
		}
		sysutils.WriteErrorResponse(r.Context(), w, http.StatusBadRequest, errResp)
		return "", true
	}

	return schemaID, false
}

func validateUpdateEntityTypeRequest(
	w http.ResponseWriter, r *http.Request, h *entityTypeHandler,
) (UpdateEntityTypeRequest, bool) {
	updateRequest, err := sysutils.DecodeJSONBody[UpdateEntityTypeRequest](r)
	if err != nil {
		var valErr *sysutils.ValidationError
		if errors.As(err, &valErr) {
			sysutils.WriteStructuredErrorResponse(w, http.StatusBadRequest, "Validation Failed", valErr.Errors)
			return UpdateEntityTypeRequest{}, true
		}
		errResp := apierror.ErrorResponse{
			Code:    ErrorInvalidRequestFormat.Code,
			Message: ErrorInvalidRequestFormat.Error,
			Description: tidcommon.I18nMessage{
				Key:          "error.entitytypeservice.update_schema_request_parse_failed_description",
				DefaultValue: "Failed to parse request body"},
		}
		sysutils.WriteErrorResponse(r.Context(), w, http.StatusBadRequest, errResp)
		return UpdateEntityTypeRequest{}, true
	}

	sanitizedRequest := h.sanitizeUpdateEntityTypeRequest(r.Context(), *updateRequest)
	return sanitizedRequest, false
}

// sanitizeCreateEntityTypeRequest sanitizes the create entity type request input.
func (h *entityTypeHandler) sanitizeCreateEntityTypeRequest(
	request CreateEntityTypeRequest,
) CreateEntityTypeRequest {
	sanitizedOUID := sysutils.SanitizeString(request.OUID)

	return CreateEntityTypeRequest{
		Handle:                sysutils.SanitizeString(request.Handle),
		DisplayName:           sysutils.SanitizeString(request.DisplayName),
		OUID:                  sanitizedOUID,
		AllowSelfRegistration: request.AllowSelfRegistration,
		SystemAttributes:      sanitizeSystemAttributes(request.SystemAttributes),
		Schema:                request.Schema,
	}
}

// sanitizeUpdateEntityTypeRequest sanitizes the update entity type request input.
func (h *entityTypeHandler) sanitizeUpdateEntityTypeRequest(ctx context.Context,
	request UpdateEntityTypeRequest,
) UpdateEntityTypeRequest {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, entityTypeHandlerLoggerComponentName))

	originalDisplayName := request.DisplayName
	sanitizedDisplayName := sysutils.SanitizeString(request.DisplayName)
	sanitizedOUID := sysutils.SanitizeString(request.OUID)

	if originalDisplayName != sanitizedDisplayName {
		logger.Debug(ctx, "Sanitized entity type display name in update request",
			log.MaskedString("original", originalDisplayName),
			log.MaskedString("sanitized", sanitizedDisplayName))
	}

	return UpdateEntityTypeRequest{
		Handle:                sysutils.SanitizeString(request.Handle),
		DisplayName:           sanitizedDisplayName,
		OUID:                  sanitizedOUID,
		AllowSelfRegistration: request.AllowSelfRegistration,
		SystemAttributes:      sanitizeSystemAttributes(request.SystemAttributes),
		Schema:                request.Schema,
	}
}

// sanitizeSystemAttributes sanitizes the SystemAttributes fields.
func sanitizeSystemAttributes(sa *SystemAttributes) *SystemAttributes {
	if sa == nil {
		return nil
	}
	return &SystemAttributes{
		Display:       sysutils.SanitizeString(sa.Display),
		PrimaryEmail:  sysutils.SanitizeString(sa.PrimaryEmail),
		PrimaryMobile: sysutils.SanitizeString(sa.PrimaryMobile),
	}
}
