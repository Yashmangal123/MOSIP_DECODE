// Copyright 2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package group

import (
	"context"
	"fmt"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"

	"gopkg.in/yaml.v3"

	oupkg "github.com/thunder-id/thunderid/internal/ou"
	serverconst "github.com/thunder-id/thunderid/internal/system/constants"
	declarativeresource "github.com/thunder-id/thunderid/internal/system/declarative_resource"
	"github.com/thunder-id/thunderid/internal/system/log"
	"github.com/thunder-id/thunderid/internal/system/utils"
)

const (
	resourceTypeGroup = "group"
	paramTypeGroup    = "Group"
)

// groupExporter implements declarativeresource.ResourceExporter for groups.
type groupExporter struct {
	service GroupServiceInterface
}

// newGroupExporter creates a new group exporter.
func newGroupExporter(service GroupServiceInterface) *groupExporter {
	return &groupExporter{service: service}
}

// GetResourceType returns the resource type for groups.
func (e *groupExporter) GetResourceType() string {
	return resourceTypeGroup
}

// GetParameterizerType returns the parameterizer type for groups.
func (e *groupExporter) GetParameterizerType() string {
	return paramTypeGroup
}

// GetAllResourceIDs retrieves all non-declarative group IDs.
// In composite mode this excludes YAML-backed groups so exports only capture mutable DB groups.
func (e *groupExporter) GetAllResourceIDs(ctx context.Context) ([]string, *tidcommon.ServiceError) {
	offset := 0
	limit := serverconst.MaxPageSize
	var ids []string

	for {
		groups, err := e.service.GetGroupList(ctx, limit, offset, nil, false)
		if err != nil {
			return nil, err
		}

		for _, g := range groups.Groups {
			ids = append(ids, g.ID)
		}

		offset += len(groups.Groups)

		if len(groups.Groups) == 0 {
			break
		}
	}

	return ids, nil
}

// GetResourceByID retrieves a group by its ID.
func (e *groupExporter) GetResourceByID(
	ctx context.Context, id string) (interface{}, string, *tidcommon.ServiceError) {
	grp, err := e.service.GetGroup(ctx, id, false)
	if err != nil {
		return nil, "", err
	}

	members, err := e.getAllGroupMembers(ctx, id)
	if err != nil {
		return nil, "", err
	}

	exported := &groupDeclarativeResource{
		ID:          grp.ID,
		Name:        grp.Name,
		Description: grp.Description,
		OUID:        grp.OUID,
		Members:     members,
	}

	return exported, grp.Name, nil
}

// ValidateResource validates a group resource.
func (e *groupExporter) ValidateResource(ctx context.Context,
	resource interface{}, id string, logger *log.Logger,
) (string, *declarativeresource.ExportError) {
	grp, ok := resource.(*groupDeclarativeResource)
	if !ok {
		return "", declarativeresource.CreateTypeError(resourceTypeGroup, id)
	}

	if err := declarativeresource.ValidateResourceName(ctx,
		grp.Name, resourceTypeGroup, id, "GROUP_VALIDATION_ERROR", logger); err != nil {
		return "", err
	}

	return grp.Name, nil
}

// getAllGroupMembers retrieves all members of a group across all pages.
func (e *groupExporter) getAllGroupMembers(
	ctx context.Context,
	groupID string,
) ([]Member, *tidcommon.ServiceError) {
	offset := 0
	limit := serverconst.MaxPageSize
	var members []Member

	for {
		page, err := e.service.GetGroupMembers(ctx, groupID, limit, offset, false)
		if err != nil {
			return nil, err
		}

		for _, m := range page.Members {
			members = append(members, Member{
				ID:   m.ID,
				Type: m.Type,
			})
		}

		offset += len(page.Members)

		if len(page.Members) == 0 {
			break
		}
	}

	return members, nil
}

// groupMembersPart names the collection a group's API serves at /groups/{id}/members.
const groupMembersPart = "members"

// ViewResource shows an exported group as a read of it returns it. A group read carries no members,
// which its part shows instead.
func (e *groupExporter) ViewResource(_ context.Context, document *yaml.Node) (interface{}, error) {
	return declarativeresource.DecodeView(document, func(exported *groupDeclarativeResource) (
		interface{}, error) {
		return &Group{
			ID:          exported.ID,
			Name:        exported.Name,
			Description: exported.Description,
			OUID:        exported.OUID,
		}, nil
	})
}

// ViewResourceParts shows a group's one part, "members", as a single page holding every member the
// export carries.
func (e *groupExporter) ViewResourceParts(_ context.Context, document *yaml.Node) (
	map[string]interface{}, error) {
	return declarativeresource.DecodeView(document, func(exported *groupDeclarativeResource) (
		map[string]interface{}, error) {
		members := exported.Members
		if members == nil {
			members = []Member{}
		}
		return map[string]interface{}{groupMembersPart: &MemberListResponse{
			TotalResults: len(members),
			StartIndex:   1,
			Count:        len(members),
			Members:      members,
			Links:        []utils.Link{},
		}}, nil
	})
}

// GetResourceRules returns the parameterization rules for groups.
func (e *groupExporter) GetResourceRules() *declarativeresource.ResourceRules {
	return &declarativeresource.ResourceRules{
		Variables:      []string{},
		ArrayVariables: []string{},
	}
}

// groupDeclarativeResource represents a group as serialized in YAML for export/import.
type groupDeclarativeResource struct {
	ID          string   `yaml:"id"`
	Name        string   `yaml:"name"`
	Description string   `yaml:"description,omitempty"`
	OUID        string   `yaml:"ouId,omitempty"`
	OUHandle    string   `yaml:"ouHandle,omitempty"`
	Members     []Member `yaml:"members,omitempty"`
}

// loadDeclarativeResources loads immutable group resources from YAML files into the file store.
// The dbStore parameter is optional and is used only for duplicate checking in composite mode.
// The ouService parameter is optional and is used to resolve ou_handle to ou_id.
func loadDeclarativeResources(
	fileStore *fileBasedGroupStore, dbStore groupStoreInterface, ouService oupkg.OrganizationUnitServiceInterface,
) error {
	resourceConfig := declarativeresource.ResourceConfig{
		ResourceType:  "Group",
		DirectoryName: "groups",
		Parser:        parseToGroupWrapper,
		Validator: func(data interface{}) error {
			return validateGroupWrapper(data, fileStore, dbStore, ouService)
		},
		IDExtractor: func(data interface{}) string {
			if v, ok := data.(*groupDeclarativeResource); ok {
				return v.ID
			}
			// Declarative resource loading runs during startup, outside any request.
			log.GetLogger().Error(context.Background(),
				"IDExtractor: type assertion failed for groupDeclarativeResource")
			return ""
		},
	}

	loader := declarativeresource.NewResourceLoader(resourceConfig, fileStore)
	if err := loader.LoadResources(); err != nil {
		return fmt.Errorf("failed to load group resources: %w", err)
	}

	return nil
}

// parseToGroupWrapper wraps parseToGroup to match the ResourceConfig.Parser signature.
func parseToGroupWrapper(data []byte) (interface{}, error) {
	return parseToGroup(data)
}

// parseToGroup parses YAML data into a groupDeclarativeResource. Unknown fields, such as the
// loader's resource_type routing discriminator, are ignored, consistent with the other
// declarative resource parsers (role, user, and so on).
func parseToGroup(data []byte) (*groupDeclarativeResource, error) {
	var grp groupDeclarativeResource
	if err := yaml.Unmarshal(data, &grp); err != nil {
		return nil, err
	}

	// Translate public 'user'/'app'/'agent' member types to the internal 'entity' type.
	for i, m := range grp.Members {
		if m.Type.IsEntityType() {
			grp.Members[i].Type = memberTypeEntity
		}
	}

	return &grp, nil
}

// validateGroupWrapper validates a parsed group and checks for duplicate IDs.
// When ouService is provided, OU handles are resolved before validation runs.
func validateGroupWrapper(
	data interface{},
	fileStore *fileBasedGroupStore,
	dbStore groupStoreInterface,
	ouService oupkg.OrganizationUnitServiceInterface,
) error {
	grp, ok := data.(*groupDeclarativeResource)
	if !ok {
		return fmt.Errorf("invalid type: expected *groupDeclarativeResource")
	}

	if grp.ID == "" {
		return fmt.Errorf("group ID is required")
	}
	if grp.Name == "" {
		return fmt.Errorf("group name is required")
	}

	if ouService != nil {
		if err := resolveGroupOUHandle(context.Background(), grp, ouService); err != nil {
			return fmt.Errorf("organization unit with handle %q not found for group '%s': %w",
				grp.OUHandle, grp.Name, err)
		}
	}

	if grp.OUID == "" {
		return fmt.Errorf("ouId or ouHandle is required for group '%s'", grp.Name)
	}

	if fileStore != nil {
		if existing, err := fileStore.GenericFileBasedStore.Get(grp.ID); err == nil && existing != nil {
			return fmt.Errorf("duplicate group ID '%s': group already exists in declarative resources", grp.ID)
		}
	}

	if dbStore != nil {
		grpDAO, err := dbStore.GetGroup(context.Background(), grp.ID)
		if err == nil && grpDAO.ID != "" {
			return fmt.Errorf("duplicate group ID '%s': group already exists in the database store", grp.ID)
		} else if err != nil && !isGroupNotFoundError(err) {
			return fmt.Errorf("failed to check for duplicate group ID '%s': %w", grp.ID, err)
		}
	}

	return nil
}
