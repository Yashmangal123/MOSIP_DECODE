// Copyright 2025 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package group

import (
	"fmt"
	"strings"

	dbmodel "github.com/thunder-id/thunderid/internal/system/database/model"
)

var (
	// QueryGetGroupListCount is the query to get total count of groups.
	QueryGetGroupListCount = dbmodel.DBQuery{
		ID:    "GRQ-GROUP_MGT-01",
		Query: `SELECT COUNT(*) as total FROM "GROUP" WHERE DEPLOYMENT_ID = $1`,
	}

	// QueryGetGroupList is the query to get groups with pagination.
	QueryGetGroupList = dbmodel.DBQuery{
		ID: "GRQ-GROUP_MGT-02",
		Query: `SELECT ID, OU_ID, NAME, DESCRIPTION FROM "GROUP" ` +
			`WHERE DEPLOYMENT_ID = $3 ORDER BY NAME LIMIT $1 OFFSET $2`,
	}

	// QueryGetTransitiveGroupsForMember retrieves all groups a member belongs to, including groups
	// inherited through nested group membership, using a recursive CTE.
	QueryGetTransitiveGroupsForMember = dbmodel.DBQuery{
		ID: "GRQ-GROUP_MGT-20",
		Query: `WITH RECURSIVE transitive_groups AS (
			SELECT GMR.GROUP_ID
			FROM "GROUP_MEMBER_REFERENCE" GMR
			WHERE GMR.MEMBER_ID = $1 AND GMR.DEPLOYMENT_ID = $2 AND GMR.MEMBER_TYPE <> 'group'
			UNION
			SELECT GMR.GROUP_ID
			FROM "GROUP_MEMBER_REFERENCE" GMR
			INNER JOIN transitive_groups tg ON GMR.MEMBER_ID = tg.GROUP_ID
			WHERE GMR.MEMBER_TYPE = 'group' AND GMR.DEPLOYMENT_ID = $2
		)
		SELECT G.ID, G.OU_ID, G.NAME
		FROM transitive_groups tg
		INNER JOIN "GROUP" G ON tg.GROUP_ID = G.ID AND G.DEPLOYMENT_ID = $2
		ORDER BY G.NAME`,
	}
)

// buildGetDirectGroupParentsQuery returns the query and args to retrieve the IDs of groups directly
// containing any of the given groups. Callers walk the chain level by level (see
// resolveTransitiveGroupAncestors) so that nesting edges spanning both stores resolve.
//
// It does not join "GROUP": a declarative parent has no row there, so joining would omit it.
func buildGetDirectGroupParentsQuery(
	groupIDs []string, deploymentID string,
) (dbmodel.DBQuery, []interface{}) {
	if len(groupIDs) == 0 {
		return dbmodel.DBQuery{
			ID:            "GRQ-GROUP_MGT-24",
			Query:         `SELECT GROUP_ID FROM "GROUP_MEMBER_REFERENCE" WHERE 1=0`,
			PostgresQuery: `SELECT GROUP_ID FROM "GROUP_MEMBER_REFERENCE" WHERE 1=0`,
			SQLiteQuery:   `SELECT GROUP_ID FROM "GROUP_MEMBER_REFERENCE" WHERE 1=0`,
		}, []interface{}{}
	}

	postgresPlaceholders := make([]string, len(groupIDs))
	sqlitePlaceholders := make([]string, len(groupIDs))
	for i := range groupIDs {
		postgresPlaceholders[i] = fmt.Sprintf("$%d", i+1)
		sqlitePlaceholders[i] = "?"
	}
	deploymentIDIdx := len(groupIDs) + 1

	postgresQuery := fmt.Sprintf(
		`SELECT DISTINCT GROUP_ID FROM "GROUP_MEMBER_REFERENCE" `+
			`WHERE MEMBER_TYPE = 'group' AND MEMBER_ID IN (%s) AND DEPLOYMENT_ID = $%d`,
		strings.Join(postgresPlaceholders, ","), deploymentIDIdx)
	sqliteQuery := fmt.Sprintf(
		`SELECT DISTINCT GROUP_ID FROM "GROUP_MEMBER_REFERENCE" `+
			`WHERE MEMBER_TYPE = 'group' AND MEMBER_ID IN (%s) AND DEPLOYMENT_ID = ?`,
		strings.Join(sqlitePlaceholders, ","))

	args := make([]interface{}, 0, len(groupIDs)+1)
	for _, id := range groupIDs {
		args = append(args, id)
	}
	args = append(args, deploymentID)

	return dbmodel.DBQuery{
		ID:            "GRQ-GROUP_MGT-24",
		Query:         postgresQuery,
		PostgresQuery: postgresQuery,
		SQLiteQuery:   sqliteQuery,
	}, args
}

// buildGetGroupsCountByOUIDsQuery returns the query and args to count groups
// belonging to the specified list of organization unit IDs.
func buildGetGroupsCountByOUIDsQuery(
	ouIDs []string, deploymentID string,
) (dbmodel.DBQuery, []interface{}) {
	if len(ouIDs) == 0 {
		return dbmodel.DBQuery{
			ID:            "GRQ-GROUP_MGT-22",
			Query:         "SELECT 0 WHERE 1=0",
			PostgresQuery: "SELECT 0 WHERE 1=0",
			SQLiteQuery:   "SELECT 0 WHERE 1=0",
		}, []interface{}{}
	}

	postgresPlaceholders := make([]string, len(ouIDs))
	sqlitePlaceholders := make([]string, len(ouIDs))
	for i := range ouIDs {
		postgresPlaceholders[i] = fmt.Sprintf("$%d", i+1)
		sqlitePlaceholders[i] = "?"
	}
	deploymentIDIdx := len(ouIDs) + 1

	postgresQuery := fmt.Sprintf(
		`SELECT COUNT(*) as total FROM "GROUP" WHERE OU_ID IN (%s) AND DEPLOYMENT_ID = $%d`,
		strings.Join(postgresPlaceholders, ","), deploymentIDIdx)
	sqliteQuery := fmt.Sprintf(
		`SELECT COUNT(*) as total FROM "GROUP" WHERE OU_ID IN (%s) AND DEPLOYMENT_ID = ?`,
		strings.Join(sqlitePlaceholders, ","))

	args := make([]interface{}, 0, len(ouIDs)+1)
	for _, id := range ouIDs {
		args = append(args, id)
	}
	args = append(args, deploymentID)

	return dbmodel.DBQuery{
		ID:            "GRQ-GROUP_MGT-03",
		Query:         postgresQuery,
		PostgresQuery: postgresQuery,
		SQLiteQuery:   sqliteQuery,
	}, args
}

// buildGetGroupsByOUIDsQuery returns the query and args to retrieve paginated groups
// filtered by the specified list of organization unit IDs.
func buildGetGroupsByOUIDsQuery(
	ouIDs []string, limit, offset int, deploymentID string,
) (dbmodel.DBQuery, []interface{}) {
	if len(ouIDs) == 0 {
		return dbmodel.DBQuery{
			ID:            "GRQ-GROUP_MGT-23",
			Query:         `SELECT ID, OU_ID, NAME, DESCRIPTION FROM "GROUP" WHERE 1=0`,
			PostgresQuery: `SELECT ID, OU_ID, NAME, DESCRIPTION FROM "GROUP" WHERE 1=0`,
			SQLiteQuery:   `SELECT ID, OU_ID, NAME, DESCRIPTION FROM "GROUP" WHERE 1=0`,
		}, []interface{}{}
	}

	postgresPlaceholders := make([]string, len(ouIDs))
	sqlitePlaceholders := make([]string, len(ouIDs))
	for i := range ouIDs {
		postgresPlaceholders[i] = fmt.Sprintf("$%d", i+1)
		sqlitePlaceholders[i] = "?"
	}
	deploymentIDIdx := len(ouIDs) + 1
	limitIdx := len(ouIDs) + 2
	offsetIdx := len(ouIDs) + 3

	postgresQuery := fmt.Sprintf(
		`SELECT ID, OU_ID, NAME, DESCRIPTION FROM "GROUP" `+
			`WHERE OU_ID IN (%s) AND DEPLOYMENT_ID = $%d ORDER BY NAME LIMIT $%d OFFSET $%d`,
		strings.Join(postgresPlaceholders, ","), deploymentIDIdx, limitIdx, offsetIdx)
	sqliteQuery := fmt.Sprintf(
		`SELECT ID, OU_ID, NAME, DESCRIPTION FROM "GROUP" `+
			`WHERE OU_ID IN (%s) AND DEPLOYMENT_ID = ? ORDER BY NAME LIMIT ? OFFSET ?`,
		strings.Join(sqlitePlaceholders, ","))

	args := make([]interface{}, 0, len(ouIDs)+3)
	for _, id := range ouIDs {
		args = append(args, id)
	}
	args = append(args, deploymentID, limit, offset)

	return dbmodel.DBQuery{
		ID:            "GRQ-GROUP_MGT-04",
		Query:         postgresQuery,
		PostgresQuery: postgresQuery,
		SQLiteQuery:   sqliteQuery,
	}, args
}

var (
	// QueryCreateGroup is the query to create a new group.
	QueryCreateGroup = dbmodel.DBQuery{
		ID: "GRQ-GROUP_MGT-05",
		Query: `INSERT INTO "GROUP" ` +
			`(ID, OU_ID, NAME, DESCRIPTION, DEPLOYMENT_ID, CREATED_AT, UPDATED_AT) ` +
			`VALUES ($1, $2, $3, $4, $5, $6, $7)`,
	}

	// QueryGetGroupByID is the query to get a group by id.
	QueryGetGroupByID = dbmodel.DBQuery{
		ID:    "GRQ-GROUP_MGT-06",
		Query: `SELECT ID, OU_ID, NAME, DESCRIPTION FROM "GROUP" WHERE ID = $1 AND DEPLOYMENT_ID = $2`,
	}

	// QueryGetGroupMembers is the query to get members assigned to a group.
	QueryGetGroupMembers = dbmodel.DBQuery{
		ID: "GRQ-GROUP_MGT-07",
		Query: `SELECT MEMBER_ID, MEMBER_TYPE FROM "GROUP_MEMBER_REFERENCE" ` +
			`WHERE GROUP_ID = $1 AND DEPLOYMENT_ID = $4 ORDER BY MEMBER_TYPE, MEMBER_ID LIMIT $2 OFFSET $3`,
	}

	// QueryGetGroupMemberCount is the query to get total count of members in a group.
	QueryGetGroupMemberCount = dbmodel.DBQuery{
		ID:    "GRQ-GROUP_MGT-08",
		Query: `SELECT COUNT(*) as total FROM "GROUP_MEMBER_REFERENCE" WHERE GROUP_ID = $1 AND DEPLOYMENT_ID = $2`,
	}

	// QueryUpdateGroup is the query to update a group.
	QueryUpdateGroup = dbmodel.DBQuery{
		ID: "GRQ-GROUP_MGT-09",
		Query: `UPDATE "GROUP" SET OU_ID = $2, NAME = $3, DESCRIPTION = $4, UPDATED_AT = $5 ` +
			`WHERE ID = $1 AND DEPLOYMENT_ID = $6`,
	}

	// QueryDeleteGroup is the query to delete a group.
	QueryDeleteGroup = dbmodel.DBQuery{
		ID:    "GRQ-GROUP_MGT-10",
		Query: `DELETE FROM "GROUP" WHERE ID = $1 AND DEPLOYMENT_ID = $2`,
	}

	// QueryDeleteGroupMembers is the query to delete all members assigned to a group.
	QueryDeleteGroupMembers = dbmodel.DBQuery{
		ID:    "GRQ-GROUP_MGT-11",
		Query: `DELETE FROM "GROUP_MEMBER_REFERENCE" WHERE GROUP_ID = $1 AND DEPLOYMENT_ID = $2`,
	}

	// QueryDeleteGroupMembershipsByMember deletes all group memberships for a given member across
	// groups (used to cascade-delete memberships when the member principal is deleted).
	QueryDeleteGroupMembershipsByMember = dbmodel.DBQuery{
		ID: "GRQ-GROUP_MGT-21",
		Query: `DELETE FROM "GROUP_MEMBER_REFERENCE" ` +
			`WHERE MEMBER_TYPE = $1 AND MEMBER_ID = $2 AND DEPLOYMENT_ID = $3`,
	}

	// QueryAddMemberToGroup is the query to assign member to a group.
	QueryAddMemberToGroup = dbmodel.DBQuery{
		ID: "GRQ-GROUP_MGT-12",
		Query: `INSERT INTO "GROUP_MEMBER_REFERENCE" ` +
			`(GROUP_ID, MEMBER_TYPE, MEMBER_ID, DEPLOYMENT_ID, CREATED_AT, UPDATED_AT) ` +
			`VALUES ($1, $2, $3, $4, $5, $6) ` +
			`ON CONFLICT (GROUP_ID, MEMBER_TYPE, MEMBER_ID, DEPLOYMENT_ID) DO NOTHING`,
	}

	// QueryCheckGroupNameConflict is the query to check if a group name conflicts within the same organization unit.
	QueryCheckGroupNameConflict = dbmodel.DBQuery{
		ID:    "GRQ-GROUP_MGT-13",
		Query: `SELECT COUNT(*) as count FROM "GROUP" WHERE NAME = $1 AND OU_ID = $2 AND DEPLOYMENT_ID = $3`,
	}

	// QueryCheckGroupNameConflictForUpdate is the query to check name conflict during update.
	QueryCheckGroupNameConflictForUpdate = dbmodel.DBQuery{
		ID: "GRQ-GROUP_MGT-14",
		Query: `SELECT COUNT(*) as count FROM "GROUP" ` +
			`WHERE NAME = $1 AND OU_ID = $2 AND ID != $3 AND DEPLOYMENT_ID = $4`,
	}

	// QueryGetGroupsByOrganizationUnitCount is the query to get total count of groups by organization unit.
	QueryGetGroupsByOrganizationUnitCount = dbmodel.DBQuery{
		ID:    "GRQ-GROUP_MGT-15",
		Query: `SELECT COUNT(*) as total FROM "GROUP" WHERE OU_ID = $1 AND DEPLOYMENT_ID = $2`,
	}

	// QueryGetGroupsByOrganizationUnit is the query to get groups by organization unit with pagination.
	QueryGetGroupsByOrganizationUnit = dbmodel.DBQuery{
		ID: "GRQ-GROUP_MGT-16",
		Query: `SELECT ID, OU_ID, NAME, DESCRIPTION FROM "GROUP" ` +
			`WHERE OU_ID = $1 AND DEPLOYMENT_ID = $4 ORDER BY NAME LIMIT $2 OFFSET $3`,
	}

	// QueryDeleteGroupMember is the query to delete a specific member from a group.
	QueryDeleteGroupMember = dbmodel.DBQuery{
		ID: "GRQ-GROUP_MGT-17",
		Query: `DELETE FROM "GROUP_MEMBER_REFERENCE" ` +
			`WHERE GROUP_ID = $1 AND MEMBER_TYPE = $2 AND MEMBER_ID = $3 AND DEPLOYMENT_ID = $4`,
	}
)

// buildGroupINClauseQuery constructs a query with an IN clause for group IDs.
func buildGroupINClauseQuery(
	queryID, baseQuery string, groupIDs []string, deploymentID string,
) (dbmodel.DBQuery, []interface{}, error) {
	if len(groupIDs) == 0 {
		return dbmodel.DBQuery{}, nil, fmt.Errorf("groupIDs list cannot be empty")
	}

	args := make([]interface{}, len(groupIDs)+1)

	postgresPlaceholders := make([]string, len(groupIDs))
	sqlitePlaceholders := make([]string, len(groupIDs))

	for i, groupID := range groupIDs {
		postgresPlaceholders[i] = fmt.Sprintf("$%d", i+1)
		sqlitePlaceholders[i] = "?"
		args[i] = groupID
	}
	args[len(groupIDs)] = deploymentID

	deploymentPlaceholder := fmt.Sprintf("$%d", len(groupIDs)+1)
	postgresQuery := fmt.Sprintf(baseQuery, strings.Join(postgresPlaceholders, ","), deploymentPlaceholder)
	sqliteQuery := fmt.Sprintf(baseQuery, strings.Join(sqlitePlaceholders, ","), "?")

	query := dbmodel.DBQuery{
		ID:            queryID,
		Query:         postgresQuery,
		PostgresQuery: postgresQuery,
		SQLiteQuery:   sqliteQuery,
	}

	return query, args, nil
}

// buildBulkGroupExistsQuery constructs a query to check which group IDs exist from a list.
func buildBulkGroupExistsQuery(groupIDs []string, deploymentID string) (dbmodel.DBQuery, []interface{}, error) {
	return buildGroupINClauseQuery(
		"GRQ-GROUP_MGT-18",
		`SELECT ID FROM "GROUP" WHERE ID IN (%s) AND DEPLOYMENT_ID = %s`,
		groupIDs, deploymentID,
	)
}

// buildGetGroupsByIDsQuery constructs a query to fetch groups by a list of IDs.
func buildGetGroupsByIDsQuery(groupIDs []string, deploymentID string) (dbmodel.DBQuery, []interface{}, error) {
	return buildGroupINClauseQuery(
		"GRQ-GROUP_MGT-19",
		`SELECT ID, OU_ID, NAME, DESCRIPTION FROM "GROUP" WHERE ID IN (%s) AND DEPLOYMENT_ID = %s`,
		groupIDs, deploymentID,
	)
}

// buildGetGroupsByNamesQuery constructs a query to fetch groups by a list of names, regardless of
// organization unit. A name may match more than one group, unlike an ID.
func buildGetGroupsByNamesQuery(names []string, deploymentID string) (dbmodel.DBQuery, []interface{}, error) {
	return buildGroupINClauseQuery(
		"GRQ-GROUP_MGT-25",
		`SELECT ID, OU_ID, NAME, DESCRIPTION FROM "GROUP" WHERE NAME IN (%s) AND DEPLOYMENT_ID = %s`,
		names, deploymentID,
	)
}
