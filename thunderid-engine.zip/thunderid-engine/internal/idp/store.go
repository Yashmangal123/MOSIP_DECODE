// Copyright 2025 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package idp

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/thunder-id/thunderid/internal/system/cmodels"
	dbmodel "github.com/thunder-id/thunderid/internal/system/database/model"
	"github.com/thunder-id/thunderid/internal/system/database/provider"
	"github.com/thunder-id/thunderid/internal/system/deployment"
	"github.com/thunder-id/thunderid/internal/system/log"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"
)

var getDBProvider = provider.GetDBProvider

// idpStoreInterface defines the interface for identity provider store operations.
type idpStoreInterface interface {
	CreateIdentityProvider(ctx context.Context, idp providers.IDPDTO) error
	GetIdentityProviderList(ctx context.Context) ([]BasicIDPDTO, error)
	GetIdentityProviderListCount(ctx context.Context) (int, error)
	GetIdentityProvider(ctx context.Context, idpID string) (*providers.IDPDTO, error)
	GetIdentityProviderByName(ctx context.Context, idpName string) (*providers.IDPDTO, error)
	GetIdentityProvidersByProperty(ctx context.Context, propertyKey, propertyValue string) ([]providers.IDPDTO, error)
	UpdateIdentityProvider(ctx context.Context, idp *providers.IDPDTO) error
	DeleteIdentityProvider(ctx context.Context, idpID string) error
}

// idpStore is the default implementation of IDPStoreInterface.
type idpStore struct {
	dbProvider provider.DBProviderInterface
}

// newIDPStore creates a new instance of IDPStore.
func newIDPStore() (idpStoreInterface, providers.Transactioner, error) {
	dbProvider := getDBProvider()
	client, err := dbProvider.GetConfigDBClient()
	if err != nil {
		return nil, nil, err
	}
	transactioner, err := client.GetTransactioner()
	if err != nil {
		return nil, nil, err
	}
	return &idpStore{
		dbProvider: dbProvider,
	}, transactioner, nil
}

// scope returns the deployment id this request acts for, falling back to the configured
// identifier for a context that never passed through the edge.
func (s *idpStore) scope(ctx context.Context) string {
	return deployment.Resolve(ctx)
}

// CreateIdentityProvider handles the IdP creation in the database.
func (s *idpStore) CreateIdentityProvider(ctx context.Context, idp providers.IDPDTO) error {
	dbClient, err := s.dbProvider.GetConfigDBClient()
	if err != nil {
		return fmt.Errorf("failed to get database client: %w", err)
	}

	var propertiesJSON string
	if len(idp.Properties) > 0 {
		propertiesJSON, err = cmodels.SerializePropertiesToJSONObject(idp.Properties)
		if err != nil {
			return fmt.Errorf("failed to serialize properties to JSON: %w", err)
		}
	}

	attributeConfigurationJSON, err := serializeAttributeConfiguration(idp.AttributeConfiguration)
	if err != nil {
		return err
	}

	_, err = dbClient.ExecuteContext(ctx,
		queryCreateIdentityProvider, idp.ID, idp.Name, idp.Description, idp.Type, idp.OUID, propertiesJSON,
		attributeConfigurationJSON, s.scope(ctx),
	)
	if err != nil {
		return fmt.Errorf("failed to execute query: %w", err)
	}

	return nil
}

// GetIdentityProviderList retrieves a list of IdPs from the database.
func (s *idpStore) GetIdentityProviderList(ctx context.Context) ([]BasicIDPDTO, error) {
	dbClient, err := s.dbProvider.GetConfigDBClient()
	if err != nil {
		return nil, fmt.Errorf("failed to get database client: %w", err)
	}

	results, err := dbClient.QueryContext(ctx, queryGetIdentityProviderList, s.scope(ctx))
	if err != nil {
		return nil, fmt.Errorf("failed to execute query: %w", err)
	}

	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, "IdPStore"))

	idpList := make([]BasicIDPDTO, 0)
	for _, row := range results {
		idp, err := buildIDPFromResultRow(row)
		if err != nil {
			return nil, fmt.Errorf("failed to build idp from result row: %w", err)
		}
		idp.IDJagEnabled = idJagEnabledFromRow(ctx, logger, idp.ID, row)
		idpList = append(idpList, *idp)
	}

	return idpList, nil
}

// GetIdentityProviderListCount retrieves the total count of identity providers.
func (s *idpStore) GetIdentityProviderListCount(ctx context.Context) (int, error) {
	dbClient, err := s.dbProvider.GetConfigDBClient()
	if err != nil {
		return 0, fmt.Errorf("failed to get database client: %w", err)
	}

	results, err := dbClient.QueryContext(ctx, queryGetIdentityProviderListCount, s.scope(ctx))
	if err != nil {
		return 0, fmt.Errorf("failed to execute query: %w", err)
	}

	if len(results) == 0 || len(results[0]) == 0 {
		return 0, nil
	}

	countVal, ok := results[0]["count"]
	if !ok {
		return 0, fmt.Errorf("count field not found in result")
	}

	switch v := countVal.(type) {
	case int:
		return v, nil
	case int64:
		return int(v), nil
	case float64:
		return int(v), nil
	default:
		return 0, fmt.Errorf("unexpected count type: %T", countVal)
	}
}

// GetIdentityProvider retrieves a specific idp by its ID from the database.
func (s *idpStore) GetIdentityProvider(ctx context.Context, id string) (*providers.IDPDTO, error) {
	return s.getIDP(ctx, queryGetIdentityProviderByID, id)
}

// GetIdentityProviderByName retrieves a specific idp by its name from the database.
func (s *idpStore) GetIdentityProviderByName(ctx context.Context, name string) (*providers.IDPDTO, error) {
	return s.getIDP(ctx, queryGetIdentityProviderByName, name)
}

// GetIdentityProvidersByProperty retrieves IDPs matching a given property key and value.
func (s *idpStore) GetIdentityProvidersByProperty(ctx context.Context,
	propertyKey, propertyValue string) ([]providers.IDPDTO, error) {
	dbClient, err := s.dbProvider.GetConfigDBClient()
	if err != nil {
		return nil, fmt.Errorf("failed to get database client: %w", err)
	}

	results, err := dbClient.QueryContext(ctx, queryGetIdentityProvidersByProperty,
		propertyKey, propertyValue, s.scope(ctx))
	if err != nil {
		return nil, fmt.Errorf("failed to execute query: %w", err)
	}
	if len(results) == 0 {
		return nil, ErrIDPNotFound
	}

	idps := make([]providers.IDPDTO, 0, len(results))
	for _, row := range results {
		basicIDP, err := buildIDPFromResultRow(row)
		if err != nil {
			return nil, fmt.Errorf("failed to build idp from result row: %w", err)
		}

		var properties []cmodels.Property
		var propertiesJSON string
		switch v := row["properties"].(type) {
		case string:
			propertiesJSON = v
		case []byte:
			propertiesJSON = string(v)
		}
		if propertiesJSON != "" {
			properties, err = cmodels.DeserializePropertiesFromJSONObject(propertiesJSON)
			if err != nil {
				return nil, fmt.Errorf("failed to deserialize properties from JSON: %w", err)
			}
		}

		attributeConfiguration, err := parseAttributeConfigurationFromRow(row)
		if err != nil {
			return nil, err
		}

		idps = append(idps, providers.IDPDTO{
			ID:                     basicIDP.ID,
			Name:                   basicIDP.Name,
			Description:            basicIDP.Description,
			Type:                   basicIDP.Type,
			OUID:                   basicIDP.OUID,
			Properties:             properties,
			AttributeConfiguration: attributeConfiguration,
		})
	}
	return idps, nil
}

// getIDP retrieves an IDP based on the provided query and identifier.
func (s *idpStore) getIDP(ctx context.Context, query dbmodel.DBQuery, identifier string) (*providers.IDPDTO, error) {
	dbClient, err := s.dbProvider.GetConfigDBClient()
	if err != nil {
		return nil, fmt.Errorf("failed to get database client: %w", err)
	}

	results, err := dbClient.QueryContext(ctx, query, identifier, s.scope(ctx))
	if err != nil {
		return nil, fmt.Errorf("failed to execute query: %w", err)
	}
	if len(results) == 0 {
		return nil, ErrIDPNotFound
	}
	if len(results) != 1 {
		return nil, fmt.Errorf("unexpected number of results: %d", len(results))
	}

	row := results[0]

	basicIDP, err := buildIDPFromResultRow(row)
	if err != nil {
		return nil, fmt.Errorf("failed to build idp from result row: %w", err)
	}

	var properties []cmodels.Property
	var propertiesJSON string

	// Handle both string and []byte types for properties
	switch v := row["properties"].(type) {
	case string:
		propertiesJSON = v
	case []byte:
		propertiesJSON = string(v)
	}

	if propertiesJSON != "" {
		var err error
		properties, err = cmodels.DeserializePropertiesFromJSONObject(propertiesJSON)
		if err != nil {
			return nil, fmt.Errorf("failed to deserialize properties from JSON: %w", err)
		}
	}

	attributeConfiguration, err := parseAttributeConfigurationFromRow(row)
	if err != nil {
		return nil, err
	}

	idp := &providers.IDPDTO{
		ID:                     basicIDP.ID,
		Name:                   basicIDP.Name,
		Description:            basicIDP.Description,
		Type:                   basicIDP.Type,
		OUID:                   basicIDP.OUID,
		Properties:             properties,
		AttributeConfiguration: attributeConfiguration,
	}

	return idp, nil
}

// UpdateIdentityProvider updates the idp in the database.
func (s *idpStore) UpdateIdentityProvider(ctx context.Context, idp *providers.IDPDTO) error {
	dbClient, err := s.dbProvider.GetConfigDBClient()
	if err != nil {
		return fmt.Errorf("failed to get database client: %w", err)
	}

	var propertiesJSON string
	if len(idp.Properties) > 0 {
		propertiesJSON, err = cmodels.SerializePropertiesToJSONObject(idp.Properties)
		if err != nil {
			return fmt.Errorf("failed to serialize properties to JSON: %w", err)
		}
	}

	attributeConfigurationJSON, err := serializeAttributeConfiguration(idp.AttributeConfiguration)
	if err != nil {
		return err
	}

	// Update the IDP in the database
	_, err = dbClient.ExecuteContext(ctx, queryUpdateIdentityProviderByID, idp.ID, idp.Name,
		idp.Description, idp.Type, propertiesJSON, attributeConfigurationJSON, s.scope(ctx))
	if err != nil {
		return fmt.Errorf("failed to execute query: %w", err)
	}

	return nil
}

// DeleteIdentityProvider deletes the idp from the database.
func (s *idpStore) DeleteIdentityProvider(ctx context.Context, id string) error {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, "IdPStore"))

	dbClient, err := s.dbProvider.GetConfigDBClient()
	if err != nil {
		return fmt.Errorf("failed to get database client: %w", err)
	}

	rowsAffected, err := dbClient.ExecuteContext(ctx, queryDeleteIdentityProviderByID, id, s.scope(ctx))
	if err != nil {
		return fmt.Errorf("failed to execute query: %w", err)
	}
	if rowsAffected == 0 {
		logger.Debug(ctx, "idp not found with id: "+id)
	}

	return nil
}

func buildIDPFromResultRow(row map[string]interface{}) (*BasicIDPDTO, error) {
	idpID, ok := row["id"].(string)
	if !ok {
		return nil, fmt.Errorf("failed to parse id as string")
	}

	idpName, ok := row["name"].(string)
	if !ok {
		return nil, fmt.Errorf("failed to parse name as string")
	}

	idpDescription, ok := row["description"].(string)
	if !ok {
		return nil, fmt.Errorf("failed to parse description as string")
	}

	idpType, ok := row["type"].(string)
	if !ok {
		return nil, fmt.Errorf("failed to parse type as string")
	}

	idpOUID, ok := row["ou_id"].(string)
	if !ok {
		return nil, fmt.Errorf("failed to parse ou_id as string")
	}

	idp := BasicIDPDTO{
		ID:          idpID,
		Name:        idpName,
		Description: idpDescription,
		Type:        providers.IDPType(idpType),
		OUID:        idpOUID,
	}

	return &idp, nil
}

// idJagEnabledFromRow extracts and parses the id_jag_enabled property from a query result row's
// PROPERTIES column, used only by the basic listing. A malformed PROPERTIES value only drops this
// display flag for the affected row (logged and left nil) rather than failing the whole listing.
func idJagEnabledFromRow(ctx context.Context, logger *log.Logger, idpID string, row map[string]interface{}) *bool {
	var propertiesJSON string
	switch v := row["properties"].(type) {
	case string:
		propertiesJSON = v
	case []byte:
		propertiesJSON = string(v)
	}
	if propertiesJSON == "" {
		return nil
	}

	properties, err := cmodels.DeserializePropertiesFromJSONObject(propertiesJSON)
	if err != nil {
		logger.Warn(ctx, "Failed to deserialize IDP properties; omitting idJagEnabled flag",
			log.String("idpID", idpID), log.Error(err))
		return nil
	}
	return idJagEnabledFromProperties(properties)
}

// serializeAttributeConfiguration marshals the attribute mapping to a JSON string. Returns nil when
// no mapping is configured so the database column receives SQL NULL instead of an empty string
// (required for PostgreSQL JSONB columns).
func serializeAttributeConfiguration(am *providers.AttributeConfiguration) (interface{}, error) {
	if am == nil {
		return nil, nil
	}
	bytes, err := json.Marshal(am)
	if err != nil {
		return nil, fmt.Errorf("failed to serialize attribute mapping to JSON: %w", err)
	}
	return string(bytes), nil
}

// parseAttributeConfigurationFromRow deserializes the ATTRIBUTE_CONFIGURATION column (string or []byte) into
// an providers.AttributeConfiguration, returning nil when the column is empty.
func parseAttributeConfigurationFromRow(row map[string]interface{}) (*providers.AttributeConfiguration, error) {
	var raw string
	switch v := row["attribute_configuration"].(type) {
	case string:
		raw = v
	case []byte:
		raw = string(v)
	}
	if raw == "" {
		return nil, nil
	}

	var am providers.AttributeConfiguration
	if err := json.Unmarshal([]byte(raw), &am); err != nil {
		return nil, fmt.Errorf("failed to deserialize attribute mapping from JSON: %w", err)
	}
	return &am, nil
}
