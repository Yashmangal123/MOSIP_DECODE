// Copyright 2025 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package idp

import (
	"context"
	"errors"
	"maps"
	"net/url"
	"slices"
	"strconv"
	"strings"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"

	authnprovidercm "github.com/thunder-id/thunderid/internal/authnprovider/common"
	"github.com/thunder-id/thunderid/internal/system/cmodels"
	sysconfig "github.com/thunder-id/thunderid/internal/system/config"
	"github.com/thunder-id/thunderid/internal/system/log"
	sysutils "github.com/thunder-id/thunderid/internal/system/utils"
	"github.com/thunder-id/thunderid/internal/system/valuecompare"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"
)

// GetPropertyValue returns the plain-text value for the named property from the slice,
// or an empty string if the property is absent or its value cannot be retrieved.
func GetPropertyValue(properties []cmodels.Property, name string) string {
	for i := range properties {
		if properties[i].GetName() == name {
			val, err := properties[i].GetValue()
			if err != nil {
				return ""
			}
			return val
		}
	}
	return ""
}

// idJagEnabledFromProperties returns a pointer to the parsed id_jag_enabled property value, or nil
// when the property is absent (or its value cannot be parsed as a boolean). This lets basic IDP
// listings distinguish trusted-issuer OIDC connections from plain federation ones without
// exposing full property details.
func idJagEnabledFromProperties(properties []cmodels.Property) *bool {
	for i := range properties {
		if properties[i].GetName() != PropIDJagEnabled {
			continue
		}
		val, err := properties[i].GetValue()
		if err != nil {
			return nil
		}
		enabled, err := strconv.ParseBool(val)
		if err != nil {
			return nil
		}
		return &enabled
	}
	return nil
}

// GetMappedUserType returns the resolved local user type for the IDP's attribute mapping, or an
// empty string when no mapping is configured. When claim-driven resolution is configured with a
// value mapping (ExternalAttribute + ValueMapping), the user type is derived by mapping the external
// claim value. When an external attribute is configured without a value mapping, the external claim
// value is used directly as the user type. In either case, when the claim is missing or its value is
// unmapped, the configured default user type is returned.
func GetMappedUserType(idp *providers.IDPDTO, claims map[string]interface{}) string {
	if idp == nil || idp.AttributeConfiguration == nil || idp.AttributeConfiguration.UserTypeResolution == nil {
		return ""
	}
	resolution := idp.AttributeConfiguration.UserTypeResolution
	externalAttribute := strings.TrimSpace(resolution.ExternalAttribute)
	if externalAttribute != "" {
		if value, ok := sysutils.GetNestedValue(claims, externalAttribute); ok {
			key := sysutils.ConvertInterfaceValueToString(value)
			if len(resolution.ValueMapping) > 0 {
				if userType, ok := resolution.ValueMapping[key]; ok {
					return userType
				}
			} else if trimmed := strings.TrimSpace(key); trimmed != "" {
				return trimmed
			}
		}
	}
	return resolution.Default
}

// GetAttributeMappings returns the external→local attribute mappings for the resolved user type's
// attributes entry, or nil when no mapping is configured.
func GetAttributeMappings(idp *providers.IDPDTO, claims map[string]interface{}) []providers.AttributeMapping {
	if idp == nil || idp.AttributeConfiguration == nil {
		return nil
	}
	userType := GetMappedUserType(idp, claims)
	if userType == "" {
		return nil
	}
	for i := range idp.AttributeConfiguration.UserTypeAttributeMappings {
		if idp.AttributeConfiguration.UserTypeAttributeMappings[i].UserType == userType {
			return idp.AttributeConfiguration.UserTypeAttributeMappings[i].Attributes
		}
	}
	return nil
}

// appendToken trims raw and appends it to tokens, unless it is empty or whitespace-only.
func appendToken(tokens []string, raw string) []string {
	if token := strings.TrimSpace(raw); token != "" {
		return append(tokens, token)
	}
	return tokens
}

// normalizeClaimValueTokens splits a claim value into the tokens a condition is evaluated against.
// A scalar string with no delimiter is used whole and untrimmed, since it may carry meaningful whitespace.
func normalizeClaimValueTokens(value interface{}, delimiter string) []string {
	switch v := value.(type) {
	case []interface{}:
		var tokens []string
		for _, item := range v {
			tokens = appendToken(tokens, sysutils.ConvertInterfaceValueToString(item))
		}
		return tokens
	case []string:
		var tokens []string
		for _, item := range v {
			tokens = appendToken(tokens, item)
		}
		return tokens
	case string:
		if delimiter == "" {
			if strings.TrimSpace(v) == "" {
				return nil
			}
			return []string{v}
		}
		var tokens []string
		for _, part := range strings.Split(v, delimiter) {
			tokens = appendToken(tokens, part)
		}
		return tokens
	default:
		return appendToken(nil, sysutils.ConvertInterfaceValueToString(v))
	}
}

// conditionMatches reports whether operator/value is satisfied by tokens. includes/not_includes test
// whole-set membership; every other operator matches if any one token satisfies it.
func conditionMatches(
	valueType providers.AuthorizationValueType, operator providers.AuthorizationOperator, value string, tokens []string,
) bool {
	if operator.IsMembership() {
		return valuecompare.EvaluateSet(operator, tokens, value)
	}
	for _, token := range tokens {
		if evaluateScalarCondition(valueType, operator, value, token) {
			return true
		}
	}
	return false
}

// evaluateScalarCondition reports whether token satisfies operator against value, both parsed per
// valueType. A token that fails to parse as the declared type never matches (fail-closed).
func evaluateScalarCondition(
	valueType providers.AuthorizationValueType, operator providers.AuthorizationOperator, value, token string,
) bool {
	t := compareType(valueType)
	if t != valuecompare.TypeString {
		// Whitespace around a number or boolean is never significant, so both sides are trimmed.
		value, token = strings.TrimSpace(value), strings.TrimSpace(token)
	}
	return valuecompare.Evaluate(operator, token, value, t)
}

// compareType returns the rule type a mapping's values are compared as.
func compareType(valueType providers.AuthorizationValueType) valuecompare.Type {
	switch valueType {
	case providers.AuthorizationValueTypeNumber:
		return valuecompare.TypeNumber
	case providers.AuthorizationValueTypeBoolean:
		return valuecompare.TypeBoolean
	default:
		return valuecompare.TypeString
	}
}

// GetRuleAuthorizationTargets resolves the local roles, groups, and permissions the IDP's
// AuthorizationRuleMapping grants for claims, deduplicated across every matching rule.
func GetRuleAuthorizationTargets(
	idp *providers.IDPDTO, claims map[string]interface{},
) []providers.AuthorizationTarget {
	if idp == nil || idp.AttributeConfiguration == nil || idp.AttributeConfiguration.AuthorizationMapping == nil {
		return nil
	}

	var targets []providers.AuthorizationTarget
	for _, mapping := range idp.AttributeConfiguration.AuthorizationMapping.Rules {
		value, ok := sysutils.GetNestedValue(claims, mapping.Claim)
		if !ok {
			continue
		}
		tokens := normalizeClaimValueTokens(value, mapping.Delimiter)
		valueType := mapping.EffectiveValueType()
		for _, rule := range mapping.Values {
			if conditionMatches(valueType, rule.Operator, rule.Value, tokens) {
				targets = append(targets, rule.Targets...)
			}
		}
	}
	return dedupeAuthorizationTargets(targets)
}

// SplitAuthorizationTargets separates mapped targets by kind: roles/groups go to the RBAC engine as
// subject state, permissions are direct grants with no role or group to resolve.
func SplitAuthorizationTargets(
	targets []providers.AuthorizationTarget,
) (roleIDs, groupIDs []string, permissions []providers.AuthorizationTarget) {
	for _, target := range targets {
		switch target.Type {
		case providers.AuthorizationTargetRole:
			roleIDs = append(roleIDs, target.ID)
		case providers.AuthorizationTargetGroup:
			groupIDs = append(groupIDs, target.ID)
		case providers.AuthorizationTargetPermission:
			permissions = append(permissions, target)
		}
	}
	return roleIDs, groupIDs, permissions
}

// UnionMappedPermissionTargets adds any mapped permission target for the given resource server and a
// requested permission, granting it directly without the RBAC engine.
func UnionMappedPermissionTargets(
	authorizedPermissions, requestedPermissions []string,
	mappedPermissions []providers.AuthorizationTarget,
	resourceServerID string,
) []string {
	for _, target := range mappedPermissions {
		if target.ResourceServerID != resourceServerID {
			continue
		}
		if !slices.Contains(requestedPermissions, target.Permission) {
			continue
		}
		if slices.Contains(authorizedPermissions, target.Permission) {
			continue
		}
		authorizedPermissions = append(authorizedPermissions, target.Permission)
	}
	return authorizedPermissions
}

// dedupeAuthorizationTargets removes duplicate targets while preserving first-seen order.
func dedupeAuthorizationTargets(targets []providers.AuthorizationTarget) []providers.AuthorizationTarget {
	if len(targets) == 0 {
		return targets
	}
	seen := make(map[providers.AuthorizationTarget]bool, len(targets))
	result := make([]providers.AuthorizationTarget, 0, len(targets))
	for _, target := range targets {
		if seen[target] {
			continue
		}
		seen[target] = true
		result = append(result, target)
	}
	return result
}

// ApplyAttributeMappings applies external→local attribute mappings. Mappings copy rather than rename:
// every incoming attribute is preserved and the mapped value is published under the local name as
// well. Mapped values take precedence on collision. Returns attrs unchanged when no mappings are
// configured.
//
// Copying matters because one external claim can legitimately feed two local attributes, and because
// consuming the source silently drops it. Mapping email onto a required username, for example, would
// otherwise leave the identity with no email at all.
func ApplyAttributeMappings(
	attrs map[string]interface{},
	mappings []providers.AttributeMapping,
) map[string]interface{} {
	if len(mappings) == 0 {
		return attrs
	}

	result := make(map[string]interface{}, len(attrs)+len(mappings))
	for key, value := range attrs {
		result[key] = value
	}
	for _, m := range mappings {
		if value, ok := sysutils.GetNestedValue(attrs, m.ExternalAttribute); ok {
			result[m.LocalAttribute] = value
		}
	}

	return result
}

// BuildAccountLinkingFilters returns one filter per combination of the local attributes each linking
// attribute matches on, or nil when there is nothing to match on. claims are the mapped claims. An
// attribute with a value and no local attribute yields nil, since dropping it would widen the match.
func BuildAccountLinkingFilters(linking *providers.AccountLinking, claims map[string]interface{},
	mappings []providers.AttributeMapping) []map[string]interface{} {
	if linking == nil {
		return nil
	}

	filters := []map[string]interface{}{{}}
	for _, attr := range linking.Attributes {
		targets := accountLinkingTargets(attr, claims, mappings)
		if len(targets) == 0 {
			if value, _ := sysutils.GetNestedValue(claims, attr); sysutils.ConvertInterfaceValueToString(value) != "" {
				return nil
			}
			continue
		}

		// Every value is read from the one claims map, so two linking attributes that land on the
		// same local attribute always agree on it, and a filter that already holds it is kept as is.
		combined := make([]map[string]interface{}, 0, len(filters)*len(targets))
		for _, filter := range filters {
			kept := false
			for _, target := range targets {
				if _, ok := filter[target]; ok {
					if !kept {
						combined = append(combined, filter)
						kept = true
					}
					continue
				}
				next := maps.Clone(filter)
				next[target] = sysutils.ConvertInterfaceValueToString(claims[target])
				combined = append(combined, next)
			}
		}
		filters = combined
	}

	if len(filters[0]) == 0 {
		return nil
	}
	return filters
}

// GetAccountLinkingLocalAttributes returns the local attributes with a value that the linking
// attributes match on, in linking order and without duplicates. claims are the mapped claims.
func GetAccountLinkingLocalAttributes(linking *providers.AccountLinking, claims map[string]interface{},
	mappings []providers.AttributeMapping) []string {
	if linking == nil {
		return nil
	}

	var attributes []string
	for _, attr := range linking.Attributes {
		for _, target := range accountLinkingTargets(attr, claims, mappings) {
			if !slices.Contains(attributes, target) {
				attributes = append(attributes, target)
			}
		}
	}
	return attributes
}

// accountLinkingTargets returns the valued local attributes a linking attribute may match on: its
// mapped targets in order, then the same-named attribute when queryable and not fed by another claim.
func accountLinkingTargets(attr string, claims map[string]interface{},
	mappings []providers.AttributeMapping) []string {
	targets := make([]string, 0, len(mappings)+1)
	mapped, shadowed := false, false
	for _, m := range mappings {
		switch {
		case m.ExternalAttribute == attr:
			mapped = true
			if !authnprovidercm.IsReservedLookupAttribute(m.LocalAttribute) &&
				!slices.Contains(targets, m.LocalAttribute) &&
				sysutils.ConvertInterfaceValueToString(claims[m.LocalAttribute]) != "" {
				targets = append(targets, m.LocalAttribute)
			}
		case m.LocalAttribute == attr:
			shadowed = true
		}
	}

	if (!mapped || !shadowed) && isPlainAttributeName(attr) && !authnprovidercm.IsReservedLookupAttribute(attr) &&
		!slices.Contains(targets, attr) && sysutils.ConvertInterfaceValueToString(claims[attr]) != "" {
		targets = append(targets, attr)
	}
	return targets
}

// isPlainAttributeName reports whether name is a top-level attribute name the entity store accepts
// as a lookup key: letters, digits and underscores only.
func isPlainAttributeName(name string) bool {
	return name != "" && strings.IndexFunc(name, func(r rune) bool {
		return (r < 'a' || r > 'z') && (r < 'A' || r > 'Z') && (r < '0' || r > '9') && r != '_'
	}) == -1
}

// validateAttributeMappingShape validates the external→local mappings independently of any user type
// schema: non-empty source/target names and no duplicate targets. A single external attribute may map
// to multiple local attributes, but two external attributes mapping to the same local attribute is a
// conflict and is rejected.
func validateAttributeMappingShape(mappings []providers.AttributeMapping) *tidcommon.ServiceError {
	seenTargets := make(map[string]bool, len(mappings))
	for _, m := range mappings {
		external := strings.TrimSpace(m.ExternalAttribute)
		local := strings.TrimSpace(m.LocalAttribute)
		if external == "" || local == "" {
			return tidcommon.CustomServiceError(ErrorInvalidAttributeConfiguration, tidcommon.I18nMessage{
				Key:          "error.idpservice.attribute_configuration_empty_claim_description",
				DefaultValue: "attribute mapping must not contain empty attribute names",
			})
		}
		if seenTargets[local] {
			return tidcommon.CustomServiceError(ErrorInvalidAttributeConfiguration, tidcommon.I18nMessage{
				Key: "error.idpservice.attribute_configuration_duplicate_target_description",
				DefaultValue: "local attribute name '{{param(attribute)}}' appears " +
					"as a mapping target more than once",
				Params: map[string]string{"attribute": local},
			})
		}
		seenTargets[local] = true
	}
	return nil
}

// validateAccountLinking rejects linking attributes that are empty, resolve to a reserved name, or
// cannot match by name and are not mapped for every user type.
func validateAccountLinking(profile *providers.AttributeConfiguration) *tidcommon.ServiceError {
	if profile.AccountLinking == nil {
		return nil
	}
	for _, attr := range profile.AccountLinking.Attributes {
		if strings.TrimSpace(attr) == "" {
			return tidcommon.CustomServiceError(ErrorInvalidAttributeConfiguration, tidcommon.I18nMessage{
				Key:          "error.idpservice.attribute_configuration_linking_empty_description",
				DefaultValue: "account linking attributes must not be empty",
			})
		}
		if authnprovidercm.IsReservedLookupAttribute(attr) {
			return newReservedLinkingAttributeError(attr)
		}
		for i := range profile.UserTypeAttributeMappings {
			for _, m := range profile.UserTypeAttributeMappings[i].Attributes {
				if m.ExternalAttribute == attr && authnprovidercm.IsReservedLookupAttribute(m.LocalAttribute) {
					return newReservedLinkingAttributeError(m.LocalAttribute)
				}
			}
		}
		if !isPlainAttributeName(attr) && !isMappedForEveryUserType(attr, profile.UserTypeAttributeMappings) {
			return tidcommon.CustomServiceError(ErrorInvalidAttributeConfiguration, tidcommon.I18nMessage{
				Key: "error.idpservice.attribute_configuration_linking_unmatchable_description",
				DefaultValue: "'{{param(attribute)}}' must be mapped to a local attribute for every user " +
					"type, since only names made of letters, digits and underscores match by name",
				Params: map[string]string{"attribute": attr},
			})
		}
	}
	for i := range profile.UserTypeAttributeMappings {
		entry := profile.UserTypeAttributeMappings[i]
		if count := maxAccountLinkingFilterCount(profile.AccountLinking, entry.Attributes); count >
			authnprovidercm.MaxAccountLinkingFilters {
			return tidcommon.CustomServiceError(ErrorInvalidAttributeConfiguration, tidcommon.I18nMessage{
				Key: "error.idpservice.attribute_configuration_linking_too_many_lookups_description",
				DefaultValue: "account linking attributes combine into {{param(count)}} lookups for user type " +
					"'{{param(userType)}}', more than the {{param(max)}} allowed",
				Params: map[string]string{
					"count":    strconv.Itoa(count),
					"userType": entry.UserType,
					"max":      strconv.Itoa(authnprovidercm.MaxAccountLinkingFilters),
				},
			})
		}
	}
	return nil
}

// maxAccountLinkingFilterCount returns how many filters BuildAccountLinkingFilters builds under
// mappings when every attribute it could match on has a value, which is the most it can build.
func maxAccountLinkingFilterCount(linking *providers.AccountLinking, mappings []providers.AttributeMapping) int {
	claims := make(map[string]interface{}, len(mappings)+len(linking.Attributes))
	for _, m := range mappings {
		claims[m.LocalAttribute] = "x"
	}
	for _, attr := range linking.Attributes {
		claims[attr] = "x"
	}
	return len(BuildAccountLinkingFilters(linking, claims, mappings))
}

// isMappedForEveryUserType reports whether attr is mapped to a local attribute in every user type's
// mappings, and there is at least one.
func isMappedForEveryUserType(attr string, userTypeMappings []providers.UserTypeAttributeMapping) bool {
	if len(userTypeMappings) == 0 {
		return false
	}
	for i := range userTypeMappings {
		if !slices.ContainsFunc(userTypeMappings[i].Attributes, func(m providers.AttributeMapping) bool {
			return m.ExternalAttribute == attr
		}) {
			return false
		}
	}
	return true
}

// newReservedLinkingAttributeError reports an account-linking attribute that resolves to a reserved name.
func newReservedLinkingAttributeError(attr string) *tidcommon.ServiceError {
	return tidcommon.CustomServiceError(ErrorInvalidAttributeConfiguration, tidcommon.I18nMessage{
		Key:          "error.idpservice.attribute_configuration_linking_reserved_description",
		DefaultValue: "'{{param(attribute)}}' is reserved and cannot be used for account linking",
		Params:       map[string]string{"attribute": attr},
	})
}

// validateIDP validates the identity provider details.
func validateIDP(ctx context.Context, idp *providers.IDPDTO, logger *log.Logger) *tidcommon.ServiceError {
	if idp == nil {
		return &ErrorIDPNil
	}
	if strings.TrimSpace(idp.Name) == "" {
		return &ErrorInvalidIDPName
	}

	// Validate identity provider type
	if strings.TrimSpace(string(idp.Type)) == "" {
		return &ErrorInvalidIDPType
	}
	isValidType := slices.Contains(providers.SupportedIDPTypes, idp.Type)
	if !isValidType {
		return &ErrorInvalidIDPType
	}

	// Validate and apply default properties based on IDP type
	updatedProperties, svcErr := validateIDPProperties(ctx, idp.Type, idp.Properties, logger)
	if svcErr != nil {
		return svcErr
	}
	idp.Properties = updatedProperties

	return nil
}

// ValidateIDP validates and normalizes dto in place (required properties, type defaults, openid
// scope), mirroring the checks the live /connections create and update APIs run. For use by the
// declarative connection loader, which otherwise writes straight to the file store without
// running this validation.
func ValidateIDP(dto *providers.IDPDTO) error {
	if svcErr := validateIDP(context.Background(), dto, log.GetLogger()); svcErr != nil {
		return errors.New(svcErr.Error.DefaultValue)
	}
	return nil
}

// endpointBaseURLOverride returns the configured mock base URL for the given IDP type
// (google/github only), or "" when no override is configured or the runtime is uninitialized.
// Production config leaves this empty, so the real Google/GitHub endpoints are used unchanged.
func endpointBaseURLOverride(idpType providers.IDPType) string {
	if !sysconfig.IsServerRuntimeInitialized() {
		return ""
	}
	runtime := sysconfig.GetServerRuntime()
	switch idpType {
	case providers.IDPTypeGoogle:
		return runtime.Config.IdentityProvider.GoogleBaseURL
	case providers.IDPTypeGitHub:
		return runtime.Config.IdentityProvider.GitHubBaseURL
	default:
		return ""
	}
}

// resolveEndpointDefaults returns a new map in which each endpoint value's scheme and host are
// replaced by those of base (path and query preserved). When base is empty, isn't a valid http(s)
// URL with a host, or a value fails to parse as a URL, that value is kept unchanged. The input map
// is never mutated.
func resolveEndpointDefaults(defaults map[string]string, base string) map[string]string {
	if base == "" {
		return defaults
	}
	baseURL, err := url.Parse(base)
	if err != nil || baseURL.Host == "" || (baseURL.Scheme != "http" && baseURL.Scheme != "https") {
		return defaults
	}
	resolved := make(map[string]string, len(defaults))
	for propName, value := range defaults {
		valueURL, err := url.Parse(value)
		if err != nil {
			resolved[propName] = value
			continue
		}
		valueURL.Scheme = baseURL.Scheme
		valueURL.Host = baseURL.Host
		resolved[propName] = valueURL.String()
	}
	return resolved
}

// validateIDPProperties validates the properties of the identity provider based on its type.
func validateIDPProperties(ctx context.Context, idpType providers.IDPType, properties []cmodels.Property,
	logger *log.Logger) ([]cmodels.Property, *tidcommon.ServiceError) {
	config, exists := idpPropertyConfigs[idpType]
	if !exists {
		logger.Error(ctx, "No property configuration found for IDP type",
			log.String("idpType", string(idpType)))
		return nil, &tidcommon.InternalServerError
	}

	allowedProps := make([]string, 0, len(config.Required)+len(config.Optional))
	allowedProps = append(allowedProps, config.Required...)
	allowedProps = append(allowedProps, config.Optional...)

	// Filter and validate provided properties
	filteredPropsMap := make(map[string]cmodels.Property)
	filteredPropKeys := []string{}
	for _, prop := range properties {
		propName := prop.GetName()
		if strings.TrimSpace(propName) == "" {
			return nil, tidcommon.CustomServiceError(ErrorInvalidIDPProperty, tidcommon.I18nMessage{
				Key:          "error.idpservice.property_name_empty_description",
				DefaultValue: "property names cannot be empty",
			})
		}
		if !slices.Contains(allowedProps, propName) {
			return nil, tidcommon.CustomServiceError(ErrorUnsupportedIDPProperty, tidcommon.I18nMessage{
				Key:          "error.idpservice.property_not_supported_for_type_description",
				DefaultValue: "property '{{param(property)}}' is not supported for IDP type '{{param(idpType)}}'",
				Params:       map[string]string{"property": propName, "idpType": string(idpType)},
			})
		}

		propertyValue, err := prop.GetValue()
		if err != nil {
			return nil, tidcommon.CustomServiceError(ErrorInvalidIDPProperty, tidcommon.I18nMessage{
				Key:          "error.idpservice.property_value_get_failed_description",
				DefaultValue: "failed to get value for property '{{param(property)}}': {{param(error)}}",
				Params:       map[string]string{"property": propName, "error": err.Error()},
			})
		}
		if strings.TrimSpace(propertyValue) == "" {
			return nil, tidcommon.CustomServiceError(ErrorInvalidIDPProperty, tidcommon.I18nMessage{
				Key:          "error.idpservice.property_value_empty_description",
				DefaultValue: "value cannot be empty for property '{{param(property)}}'",
				Params:       map[string]string{"property": propName},
			})
		}
		if propName == PropIDJagEnabled || propName == PropTokenExchangeEnabled {
			if propertyValue != "true" && propertyValue != "false" {
				return nil, tidcommon.CustomServiceError(ErrorInvalidIDPProperty, tidcommon.I18nMessage{
					Key: "error.idpservice.property_value_not_boolean_description",
					DefaultValue: "value for property '{{param(property)}}' must be either " +
						"'true' or 'false'",
					Params: map[string]string{"property": propName},
				})
			}
		}

		filteredPropsMap[propName] = prop
		filteredPropKeys = append(filteredPropKeys, propName)
	}

	// Check for required properties, using the token-exchange override when applicable.
	// The reduced required set also applies when id_jag_enabled is present, since that property
	// is only ever sent for trust-only connections which carry no OAuth client credentials.
	requiredProps := config.Required
	if teProps, ok := tokenExchangeRequiredProps[idpType]; ok {
		_, idJagEnabledPresent := filteredPropsMap[PropIDJagEnabled]
		tokenExchangeEnabled := false
		if prop, exists := filteredPropsMap[PropTokenExchangeEnabled]; exists {
			if val, err := prop.GetValue(); err == nil && val == "true" {
				tokenExchangeEnabled = true
			}
		}
		if tokenExchangeEnabled || idJagEnabledPresent {
			requiredProps = teProps
		}
	}
	for _, requiredProp := range requiredProps {
		if !slices.Contains(filteredPropKeys, requiredProp) {
			return nil, tidcommon.CustomServiceError(ErrorInvalidIDPProperty, tidcommon.I18nMessage{
				Key: "error.idpservice.required_property_missing_description",
				DefaultValue: "required property '{{param(property)}}' is missing " +
					"for IDP type '{{param(idpType)}}'",
				Params: map[string]string{"property": requiredProp, "idpType": string(idpType)},
			})
		}
	}

	// Apply default properties
	effectiveDefaults := resolveEndpointDefaults(config.Defaults, endpointBaseURLOverride(idpType))
	for propName, defaultValue := range effectiveDefaults {
		if _, exists := filteredPropsMap[propName]; !exists {
			err := createAndAppendProperty(ctx, filteredPropsMap, propName, defaultValue, false, logger)
			if err != nil {
				return nil, err
			}
		}
	}

	// Ensure openid scope for OIDC and Google IDPs
	if idpType == providers.IDPTypeOIDC || idpType == providers.IDPTypeGoogle {
		if err := ensureOpenIDScope(ctx, filteredPropsMap, logger); err != nil {
			return nil, err
		}
	}

	// Seed the email scope for GitHub IDPs
	if idpType == providers.IDPTypeGitHub {
		if err := ensureDefaultGitHubScopes(ctx, filteredPropsMap, logger); err != nil {
			return nil, err
		}
	}

	return propertyMapToSlice(filteredPropsMap), nil
}

// readScopesValue reads the raw value of a scopes property. Shared by the per-provider scope defaults
// so the failure is reported under a single i18n key rather than one per caller.
func readScopesValue(scopesProp cmodels.Property) (string, *tidcommon.ServiceError) {
	scopesValue, err := scopesProp.GetValue()
	if err != nil {
		return "", tidcommon.CustomServiceError(ErrorInvalidIDPProperty, tidcommon.I18nMessage{
			Key:          "error.idpservice.scopes_value_get_failed_description",
			DefaultValue: "failed to get scopes value: {{param(error)}}",
			Params:       map[string]string{"error": err.Error()},
		})
	}
	return scopesValue, nil
}

// ensureOpenIDScope ensures that the openid scope is present in the scopes property,
// defaulting to the standard OIDC scopes (openid, email, profile) when none are supplied.
func ensureOpenIDScope(ctx context.Context, propertyMap map[string]cmodels.Property,
	logger *log.Logger) *tidcommon.ServiceError {
	scopesProp, exists := propertyMap[PropScopes]
	if !exists {
		err := createAndAppendProperty(ctx, propertyMap, PropScopes, defaultOIDCScopes, false, logger)
		if err != nil {
			return err
		}
		return nil
	}

	scopesValue, svcErr := readScopesValue(scopesProp)
	if svcErr != nil {
		return svcErr
	}

	scopes := sysutils.ParseStringArray(scopesValue, ",")
	filteredScopes := make([]string, 0, len(scopes))
	for _, scope := range scopes {
		if scope != "" {
			filteredScopes = append(filteredScopes, scope)
		}
	}
	scopes = filteredScopes

	if len(scopes) == 0 {
		err := createAndAppendProperty(ctx, propertyMap, PropScopes, defaultOIDCScopes, false, logger)
		if err != nil {
			return err
		}
		return nil
	}
	if !slices.Contains(scopes, "openid") {
		scopes = append(scopes, "openid")
		updatedScopes := sysutils.StringifyStringArray(scopes, ",")
		if err := createAndAppendProperty(
			ctx, propertyMap, PropScopes, updatedScopes, scopesProp.IsSecret(), logger); err != nil {
			return err
		}
	}

	return nil
}

// ensureDefaultGitHubScopes seeds the GitHub email scope when no scopes are supplied, leaving explicitly
// configured scopes untouched. Applied here rather than through the type's default property map,
// because those values are rewritten as URLs by resolveEndpointDefaults.
func ensureDefaultGitHubScopes(ctx context.Context, propertyMap map[string]cmodels.Property,
	logger *log.Logger) *tidcommon.ServiceError {
	scopesProp, exists := propertyMap[PropScopes]
	if !exists {
		return createAndAppendProperty(ctx, propertyMap, PropScopes, defaultGitHubScopes, false, logger)
	}

	scopesValue, svcErr := readScopesValue(scopesProp)
	if svcErr != nil {
		return svcErr
	}

	for _, scope := range sysutils.ParseStringArray(scopesValue, ",") {
		if scope != "" {
			return nil
		}
	}

	return createAndAppendProperty(ctx, propertyMap, PropScopes, defaultGitHubScopes, false, logger)
}

// scopesGrantEmail reports whether the effective scopes let the connection read an email address.
// Generic OAuth is absent by design as we cannot infer an arbitrary provider's scope semantics.
func scopesGrantEmail(idpType providers.IDPType, scopes []string) bool {
	switch idpType {
	case providers.IDPTypeGoogle, providers.IDPTypeOIDC:
		return slices.Contains(scopes, emailScope)
	case providers.IDPTypeGitHub:
		return slices.Contains(scopes, gitHubUserEmailScope) || slices.Contains(scopes, gitHubUserScope)
	default:
		return false
	}
}

// defaultUsernameSourceAttribute returns the external claim used for the default username mapping,
// or "" when the provider has none. Google and OIDC use email, while GitHub uses its login claim.
func defaultUsernameSourceAttribute(idpType providers.IDPType) string {
	switch idpType {
	case providers.IDPTypeGoogle, providers.IDPTypeOIDC:
		return emailClaim
	case providers.IDPTypeGitHub:
		return gitHubLoginClaim
	default:
		return ""
	}
}

// ensureAttributeConfiguration returns the attribute configuration, creating it when absent.
func ensureAttributeConfiguration(idp *providers.IDPDTO) *providers.AttributeConfiguration {
	if idp.AttributeConfiguration == nil {
		idp.AttributeConfiguration = &providers.AttributeConfiguration{}
	}
	return idp.AttributeConfiguration
}

// createAndAppendProperty creates a new property and appends it to the property map.
func createAndAppendProperty(ctx context.Context, propertyMap map[string]cmodels.Property,
	name, value string, isSecret bool, logger *log.Logger,
) *tidcommon.ServiceError {
	prop, err := cmodels.NewProperty(name, value, isSecret)
	if err != nil {
		logger.Error(ctx, "Failed to create property", log.String("propertyName", name), log.Error(err))
		return &tidcommon.InternalServerError
	}
	propertyMap[name] = *prop
	return nil
}

// propertyMapToSlice converts a property map to a slice.
func propertyMapToSlice(propertyMap map[string]cmodels.Property) []cmodels.Property {
	properties := make([]cmodels.Property, 0, len(propertyMap))
	for _, prop := range propertyMap {
		properties = append(properties, prop)
	}
	return properties
}
