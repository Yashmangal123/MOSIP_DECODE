// Copyright 2025 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package idp

import (
	"context"
	"testing"

	engineconfig "github.com/thunder-id/thunderid/pkg/thunderidengine/config"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"

	"github.com/stretchr/testify/suite"

	"github.com/thunder-id/thunderid/internal/system/cmodels"
	"github.com/thunder-id/thunderid/internal/system/config"
	"github.com/thunder-id/thunderid/internal/system/log"
)

type IDPUtilsTestSuite struct {
	suite.Suite
	logger *log.Logger
}

func TestIDPUtilsTestSuite(t *testing.T) {
	suite.Run(t, new(IDPUtilsTestSuite))
}

func (s *IDPUtilsTestSuite) SetupTest() {
	s.logger = log.GetLogger()
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_OAuth_AllRequired() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "http://idp/auth", false)
	prop5, _ := cmodels.NewProperty(PropTokenEndpoint, "http://idp/token", false)
	prop6, _ := cmodels.NewProperty(PropUserInfoEndpoint, "http://idp/userinfo", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4, *prop5, *prop6}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)
	s.Len(result, 6)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_OAuth_WithOptional() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "http://idp/auth", false)
	prop5, _ := cmodels.NewProperty(PropTokenEndpoint, "http://idp/token", false)
	prop6, _ := cmodels.NewProperty(PropUserInfoEndpoint, "http://idp/userinfo", false)
	prop7, _ := cmodels.NewProperty(PropScopes, "profile,email", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4, *prop5, *prop6, *prop7}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)
	s.Len(result, 7)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_OAuth_WithoutUserInfoEndpoint() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "http://idp/auth", false)
	prop5, _ := cmodels.NewProperty(PropTokenEndpoint, "http://idp/token", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4, *prop5}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)
	s.Len(result, 5)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_OAuth_MissingRequired() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)

	properties := []cmodels.Property{*prop1, *prop2}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "required property")
	s.Contains(err.ErrorDescription.DefaultValue, "missing")
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_OIDC_AllRequired() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "http://idp/auth", false)
	prop5, _ := cmodels.NewProperty(PropTokenEndpoint, "http://idp/token", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4, *prop5}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)
	s.GreaterOrEqual(len(result), 6)

	hasOpenIDScope := false
	for _, prop := range result {
		if prop.GetName() == PropScopes {
			value, _ := prop.GetValue()
			s.Contains(value, "openid")
			hasOpenIDScope = true
		}
	}
	s.True(hasOpenIDScope, "OIDC should have openid scope added")
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_OIDC_WithExistingScopes() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "http://idp/auth", false)
	prop5, _ := cmodels.NewProperty(PropTokenEndpoint, "http://idp/token", false)
	prop6, _ := cmodels.NewProperty(PropScopes, "profile,email", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4, *prop5, *prop6}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)

	for _, prop := range result {
		if prop.GetName() == PropScopes {
			value, _ := prop.GetValue()
			s.Contains(value, "openid")
			s.Contains(value, "profile")
			s.Contains(value, "email")
		}
	}
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_OIDC_ScopesAlreadyHasOpenID() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "http://idp/auth", false)
	prop5, _ := cmodels.NewProperty(PropTokenEndpoint, "http://idp/token", false)
	prop6, _ := cmodels.NewProperty(PropScopes, "openid,profile,email", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4, *prop5, *prop6}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)

	for _, prop := range result {
		if prop.GetName() == PropScopes {
			value, _ := prop.GetValue()
			s.Contains(value, "openid")
		}
	}
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_Google_WithDefaults() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGoogle, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)
	s.GreaterOrEqual(len(result), 7)

	foundProperties := make(map[string]string)
	for _, prop := range result {
		value, _ := prop.GetValue()
		foundProperties[prop.GetName()] = value
	}

	s.Equal(googleAuthorizationEndpoint, foundProperties[PropAuthorizationEndpoint])
	s.Equal(googleTokenEndpoint, foundProperties[PropTokenEndpoint])
	s.Equal(googleUserInfoEndpoint, foundProperties[PropUserInfoEndpoint])
	s.Equal(googleJwksEndpoint, foundProperties[PropJwksEndpoint])
	s.Equal("openid,email,profile", foundProperties[PropScopes])
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_Google_WithCustomEndpoints() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "http://custom/auth", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGoogle, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)

	foundProperties := make(map[string]string)
	for _, prop := range result {
		value, _ := prop.GetValue()
		foundProperties[prop.GetName()] = value
	}

	s.Equal("http://custom/auth", foundProperties[PropAuthorizationEndpoint])
	s.Equal(googleTokenEndpoint, foundProperties[PropTokenEndpoint])
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_GitHub_WithDefaults() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGitHub, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)
	s.GreaterOrEqual(len(result), 6)

	foundProperties := make(map[string]string)
	for _, prop := range result {
		value, _ := prop.GetValue()
		foundProperties[prop.GetName()] = value
	}

	s.Equal(gitHubAuthorizationEndpoint, foundProperties[PropAuthorizationEndpoint])
	s.Equal(gitHubTokenEndpoint, foundProperties[PropTokenEndpoint])
	s.Equal(gitHubUserInfoEndpoint, foundProperties[PropUserInfoEndpoint])
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_GitHub_WithCustomEndpoints() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropTokenEndpoint, "http://custom/token", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGitHub, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)

	foundProperties := make(map[string]string)
	for _, prop := range result {
		value, _ := prop.GetValue()
		foundProperties[prop.GetName()] = value
	}

	s.Equal("http://custom/token", foundProperties[PropTokenEndpoint])
	s.Equal(gitHubAuthorizationEndpoint, foundProperties[PropAuthorizationEndpoint])
}

// GitHub returns no email at all without an email scope, so a connection created without scopes gets one.
func (s *IDPUtilsTestSuite) TestValidateIDPProperties_GitHub_DefaultsScopes() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGitHub, properties, s.logger)

	s.Nil(err)
	s.Equal(defaultGitHubScopes, GetPropertyValue(result, PropScopes))
}

// A deliberately narrow scope list is a choice, not an omission, even when it cannot yield an email.
func (s *IDPUtilsTestSuite) TestValidateIDPProperties_GitHub_PreservesExplicitScopes() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropScopes, "read:user", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGitHub, properties, s.logger)

	s.Nil(err)
	s.Equal("read:user", GetPropertyValue(result, PropScopes))
}

// An explicitly empty scope string is rejected by the generic empty-value check that applies to every
// property, so it never reaches scope defaulting.
func (s *IDPUtilsTestSuite) TestValidateIDPProperties_GitHub_EmptyScopesRejected() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropScopes, "", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGitHub, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
}

// A scope value that survives the empty-value check but parses to no scopes still defaults.
func (s *IDPUtilsTestSuite) TestValidateIDPProperties_GitHub_BlankScopeListDefaults() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropScopes, ",", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGitHub, properties, s.logger)

	s.Nil(err)
	s.Equal(defaultGitHubScopes, GetPropertyValue(result, PropScopes))
}

// An empty value reaches the defaulting step as a present-but-blank property, not a missing one.
func (s *IDPUtilsTestSuite) TestEnsureGitHubScopes_EmptyScopesValue() {
	prop, _ := cmodels.NewProperty(PropScopes, "", false)
	propertyMap := map[string]cmodels.Property{
		PropScopes: *prop,
	}

	err := ensureDefaultGitHubScopes(context.Background(), propertyMap, s.logger)

	s.Nil(err)

	scopesProp := propertyMap[PropScopes]
	value, _ := scopesProp.GetValue()
	s.Equal(defaultGitHubScopes, value)
}

// The property is created, not just populated, when the connection omits scopes entirely.
func (s *IDPUtilsTestSuite) TestEnsureGitHubScopes_NoExistingScopes() {
	propertyMap := map[string]cmodels.Property{}

	err := ensureDefaultGitHubScopes(context.Background(), propertyMap, s.logger)

	s.Nil(err)

	scopesProp := propertyMap[PropScopes]
	value, _ := scopesProp.GetValue()
	s.Equal(defaultGitHubScopes, value)
}

// The scope default must not travel through resolveEndpointDefaults: that rewrites each value's
// scheme and host, and "user:email" parses as a URL with scheme "user", so a base URL override would
// corrupt it.
func (s *IDPUtilsTestSuite) TestValidateIDPProperties_GitHub_ScopesSurviveBaseURLOverride() {
	config.ResetServerRuntime()
	_ = config.InitializeServerRuntime("/tmp/test", &config.Config{
		IdentityProvider: config.IdentityProviderConfig{
			GitHubBaseURL: "http://localhost:8092",
		},
	})
	defer config.ResetServerRuntime()

	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGitHub, properties, s.logger)

	s.Nil(err)
	s.Equal(defaultGitHubScopes, GetPropertyValue(result, PropScopes))
	s.Contains(GetPropertyValue(result, PropAuthorizationEndpoint), "localhost:8092")
}

// Generic OAuth has no known email scope to guess, so it keeps no scopes rather than inheriting one.
func (s *IDPUtilsTestSuite) TestValidateIDPProperties_OAuth_NoScopeDefault() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "http://idp/auth", false)
	prop5, _ := cmodels.NewProperty(PropTokenEndpoint, "http://idp/token", false)
	prop6, _ := cmodels.NewProperty(PropUserInfoEndpoint, "http://idp/userinfo", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4, *prop5, *prop6}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.Nil(err)
	s.Empty(GetPropertyValue(result, PropScopes))
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_EmptyPropertyName() {
	prop1, _ := cmodels.NewProperty("", "test-value", false)

	properties := []cmodels.Property{*prop1}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "property names cannot be empty")
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_EmptyPropertyValue() {
	prop1, _ := cmodels.NewProperty(PropClientID, "", false)

	properties := []cmodels.Property{*prop1}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "value cannot be empty")
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_UnsupportedProperty() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty("unsupported_prop", "value", false)

	properties := []cmodels.Property{*prop1, *prop2}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorUnsupportedIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.String(), "unsupported_prop")
	s.Contains(err.ErrorDescription.DefaultValue, "not supported")
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_InvalidIDPType() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)

	properties := []cmodels.Property{*prop1}

	result, err := validateIDPProperties(context.Background(), providers.IDPType("INVALID"), properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (s *IDPUtilsTestSuite) TestPropertyMapToSlice() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)

	propertyMap := map[string]cmodels.Property{
		PropClientID:     *prop1,
		PropClientSecret: *prop2,
	}

	result := propertyMapToSlice(propertyMap)

	s.NotNil(result)
	s.Len(result, 2)

	names := make([]string, 0, len(result))
	for _, prop := range result {
		names = append(names, prop.GetName())
	}
	s.Contains(names, PropClientID)
	s.Contains(names, PropClientSecret)
}

func (s *IDPUtilsTestSuite) TestEnsureOpenIDScope_NoExistingScopes() {
	propertyMap := make(map[string]cmodels.Property)

	err := ensureOpenIDScope(context.Background(), propertyMap, s.logger)

	s.Nil(err)
	s.Contains(propertyMap, PropScopes)

	scopesProp := propertyMap[PropScopes]
	value, _ := scopesProp.GetValue()
	s.Equal("openid,email,profile", value)
}

func (s *IDPUtilsTestSuite) TestEnsureOpenIDScope_WithExistingScopes() {
	prop, _ := cmodels.NewProperty(PropScopes, "profile,email", false)
	propertyMap := map[string]cmodels.Property{
		PropScopes: *prop,
	}

	err := ensureOpenIDScope(context.Background(), propertyMap, s.logger)

	s.Nil(err)

	scopesProp := propertyMap[PropScopes]
	value, _ := scopesProp.GetValue()
	s.Contains(value, "openid")
	s.Contains(value, "profile")
	s.Contains(value, "email")
}

func (s *IDPUtilsTestSuite) TestEnsureOpenIDScope_AlreadyHasOpenID() {
	prop, _ := cmodels.NewProperty(PropScopes, "openid,profile", false)
	propertyMap := map[string]cmodels.Property{
		PropScopes: *prop,
	}

	err := ensureOpenIDScope(context.Background(), propertyMap, s.logger)

	s.Nil(err)

	scopesProp := propertyMap[PropScopes]
	value, _ := scopesProp.GetValue()
	s.Contains(value, "openid")
	s.Contains(value, "profile")
}

func (s *IDPUtilsTestSuite) TestEnsureOpenIDScope_EmptyScopesValue() {
	prop, _ := cmodels.NewProperty(PropScopes, "", false)
	propertyMap := map[string]cmodels.Property{
		PropScopes: *prop,
	}

	err := ensureOpenIDScope(context.Background(), propertyMap, s.logger)

	s.Nil(err)

	scopesProp := propertyMap[PropScopes]
	value, _ := scopesProp.GetValue()
	s.Equal("openid,email,profile", value)
}

func (s *IDPUtilsTestSuite) TestValidateIDP_ValidOAuth() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "http://idp/auth", false)
	prop5, _ := cmodels.NewProperty(PropTokenEndpoint, "http://idp/token", false)
	prop6, _ := cmodels.NewProperty(PropUserInfoEndpoint, "http://idp/userinfo", false)

	idp := &providers.IDPDTO{
		Name:       "Test OAuth IDP",
		Type:       providers.IDPTypeOAuth,
		Properties: []cmodels.Property{*prop1, *prop2, *prop3, *prop4, *prop5, *prop6},
	}

	err := validateIDP(context.Background(), idp, s.logger)

	s.Nil(err)
	s.NotNil(idp.Properties)
}

func (s *IDPUtilsTestSuite) TestValidateIDP_NilIDP() {
	err := validateIDP(context.Background(), nil, s.logger)

	s.NotNil(err)
	s.Equal(ErrorIDPNil.Code, err.Code)
}

func (s *IDPUtilsTestSuite) TestValidateIDP_EmptyName() {
	idp := &providers.IDPDTO{
		Name: "",
		Type: providers.IDPTypeOAuth,
	}

	err := validateIDP(context.Background(), idp, s.logger)

	s.NotNil(err)
	s.Equal(ErrorInvalidIDPName.Code, err.Code)
}

func (s *IDPUtilsTestSuite) TestValidateIDP_EmptyType() {
	idp := &providers.IDPDTO{
		Name: "Test IDP",
		Type: "",
	}

	err := validateIDP(context.Background(), idp, s.logger)

	s.NotNil(err)
	s.Equal(ErrorInvalidIDPType.Code, err.Code)
}

func (s *IDPUtilsTestSuite) TestValidateIDP_InvalidType() {
	idp := &providers.IDPDTO{
		Name: "Test IDP",
		Type: "INVALID",
	}

	err := validateIDP(context.Background(), idp, s.logger)

	s.NotNil(err)
	s.Equal(ErrorInvalidIDPType.Code, err.Code)
}

func (s *IDPUtilsTestSuite) TestValidateIDP_WithWhitespaceName() {
	prop1, _ := cmodels.NewProperty(PropClientID, "test-client", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "test-secret", false)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "http://localhost/callback", false)
	prop4, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "http://idp/auth", false)
	prop5, _ := cmodels.NewProperty(PropTokenEndpoint, "http://idp/token", false)
	prop6, _ := cmodels.NewProperty(PropUserInfoEndpoint, "http://idp/userinfo", false)

	idp := &providers.IDPDTO{
		Name:       "   ",
		Type:       providers.IDPTypeOAuth,
		Properties: []cmodels.Property{*prop1, *prop2, *prop3, *prop4, *prop5, *prop6},
	}

	err := validateIDP(context.Background(), idp, s.logger)

	s.NotNil(err)
	s.Equal(ErrorInvalidIDPName.Code, err.Code)
}

func (s *IDPUtilsTestSuite) TestValidateIDP_WithWhitespaceType() {
	idp := &providers.IDPDTO{
		Name: "Test IDP",
		Type: "   ",
	}

	err := validateIDP(context.Background(), idp, s.logger)

	s.NotNil(err)
	s.Equal(ErrorInvalidIDPType.Code, err.Code)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_WithWhitespacePropertyName() {
	prop1, _ := cmodels.NewProperty("   ", "test-value", false)

	properties := []cmodels.Property{*prop1}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "property names cannot be empty")
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_WithWhitespacePropertyValue() {
	prop1, _ := cmodels.NewProperty(PropClientID, "   ", false)

	properties := []cmodels.Property{*prop1}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "value cannot be empty")
}

func (s *IDPUtilsTestSuite) TestCreateAndAppendProperty_Success() {
	propertyMap := make(map[string]cmodels.Property)

	err := createAndAppendProperty(context.Background(), propertyMap, "test_prop", "test_value", false, s.logger)

	s.Nil(err)
	s.Contains(propertyMap, "test_prop")

	prop := propertyMap["test_prop"]
	value, _ := prop.GetValue()
	s.Equal("test_value", value)
	s.False(prop.IsSecret())
}

func (s *IDPUtilsTestSuite) TestCreateAndAppendProperty_OverwriteExisting() {
	prop1, _ := cmodels.NewProperty("test_prop", "old_value", false)
	propertyMap := map[string]cmodels.Property{
		"test_prop": *prop1,
	}

	err := createAndAppendProperty(context.Background(), propertyMap, "test_prop", "new_value", false, s.logger)

	s.Nil(err)
	s.Contains(propertyMap, "test_prop")

	prop := propertyMap["test_prop"]
	value, _ := prop.GetValue()
	s.Equal("new_value", value)
}

func (s *IDPUtilsTestSuite) TestEnsureOpenIDScope_WithWhitespaceScopes() {
	prop, _ := cmodels.NewProperty(PropScopes, "   ", false)
	propertyMap := map[string]cmodels.Property{
		PropScopes: *prop,
	}

	err := ensureOpenIDScope(context.Background(), propertyMap, s.logger)

	s.Nil(err)

	scopesProp := propertyMap[PropScopes]
	value, _ := scopesProp.GetValue()
	s.Equal("openid,email,profile", value)
}

func (s *IDPUtilsTestSuite) TestEnsureOpenIDScope_CommaSeparatedScopes() {
	prop, _ := cmodels.NewProperty(PropScopes, "profile,email,address", false)
	propertyMap := map[string]cmodels.Property{
		PropScopes: *prop,
	}

	err := ensureOpenIDScope(context.Background(), propertyMap, s.logger)

	s.Nil(err)

	scopesProp := propertyMap[PropScopes]
	value, _ := scopesProp.GetValue()
	// Should have openid added
	s.Contains(value, "openid")
	s.Contains(value, "profile")
	s.Contains(value, "email")
	s.Contains(value, "address")
	// Verify comma separation
	s.NotContains(value, " ")
}

func (s *IDPUtilsTestSuite) TestEnsureOpenIDScope_WithEmptyStringInScopes() {
	prop, _ := cmodels.NewProperty(PropScopes, "profile,,email,,", false)
	propertyMap := map[string]cmodels.Property{
		PropScopes: *prop,
	}

	err := ensureOpenIDScope(context.Background(), propertyMap, s.logger)
	s.Nil(err)

	scopesProp := propertyMap[PropScopes]
	value, _ := scopesProp.GetValue()
	// Should have openid added and empty strings filtered out
	s.Contains(value, "openid")
	s.Contains(value, "profile")
	s.Contains(value, "email")
	// Should not have consecutive commas
	s.NotContains(value, ",,")
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_TokenExchangeOnly_OIDC_Succeeds() {
	// OIDC IDP with only the token-exchange required props and token_exchange_enabled=true should succeed.
	// client_id is no longer required for token exchange; issuer and jwks_endpoint are sufficient.
	prop1, _ := cmodels.NewProperty(PropIssuer, "https://idp.example.com/oauth2/token", false)
	prop2, _ := cmodels.NewProperty(PropJwksEndpoint, "https://idp.example.com/oauth2/jwks", false)
	prop3, _ := cmodels.NewProperty(PropTokenExchangeEnabled, "true", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_TokenExchangeAudience_OIDC_Succeeds() {
	propIssuer, _ := cmodels.NewProperty(PropIssuer, "https://accounts.google.com", false)
	propJWKS, _ := cmodels.NewProperty(PropJwksEndpoint, "https://www.googleapis.com/oauth2/v3/certs", false)
	propTokenExchange, _ := cmodels.NewProperty(PropTokenExchangeEnabled, "true", false)
	propAudience, _ := cmodels.NewProperty(
		PropTrustedTokenAudience, "407408718192.apps.googleusercontent.com", false)

	properties := []cmodels.Property{*propIssuer, *propJWKS, *propTokenExchange, *propAudience}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_TokenExchangeEnabled_MissingIssuer_Fails() {
	// OIDC IDP with token_exchange_enabled=true but missing issuer should fail.
	prop1, _ := cmodels.NewProperty(PropClientID, "your_client_id", false)
	prop2, _ := cmodels.NewProperty(PropJwksEndpoint, "https://idp.example.com/oauth2/jwks", false)
	prop3, _ := cmodels.NewProperty(PropTokenExchangeEnabled, "true", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "required property")
	s.Contains(err.ErrorDescription.String(), PropIssuer)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_TokenExchangeEnabled_MissingJWKS_Fails() {
	// OIDC IDP with token_exchange_enabled=true but missing jwks_endpoint should fail.
	prop1, _ := cmodels.NewProperty(PropClientID, "your_client_id", false)
	prop2, _ := cmodels.NewProperty(PropIssuer, "https://idp.example.com/oauth2/token", false)
	prop3, _ := cmodels.NewProperty(PropTokenExchangeEnabled, "true", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "required property")
	s.Contains(err.ErrorDescription.String(), PropJwksEndpoint)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_OIDCWithoutTokenExchange_StillRequiresRedirectProps() {
	// OIDC IDP without token_exchange_enabled must still require all 5 redirect-flow props.
	prop1, _ := cmodels.NewProperty(PropClientID, "your_client_id", false)
	prop2, _ := cmodels.NewProperty(PropIssuer, "https://idp.example.com/oauth2/token", false)
	prop3, _ := cmodels.NewProperty(PropJwksEndpoint, "https://idp.example.com/oauth2/jwks", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "required property")
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_OIDCWithoutTokenExchange_MissingClientSecret_Fails() {
	// OIDC IDP without token_exchange_enabled must fail when client_secret is missing.
	prop1, _ := cmodels.NewProperty(PropClientID, "your_client_id", false)
	prop2, _ := cmodels.NewProperty(PropRedirectURI, "https://thunder.example.com/callback", false)
	prop3, _ := cmodels.NewProperty(PropAuthorizationEndpoint, "https://idp.example.com/oauth2/authorize",
		false)
	prop4, _ := cmodels.NewProperty(PropTokenEndpoint, "https://idp.example.com/oauth2/token", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "required property")
	s.Contains(err.ErrorDescription.String(), PropClientSecret)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_IDJagEnabledTrue_OIDC_Succeeds() {
	// OIDC IDP with id_jag_enabled=true and no client credentials should succeed;
	// issuer and jwks_endpoint alone are sufficient for trust-only connections.
	prop1, _ := cmodels.NewProperty(PropIssuer, "https://idp.example.com/oauth2/token", false)
	prop2, _ := cmodels.NewProperty(PropJwksEndpoint, "https://idp.example.com/oauth2/jwks", false)
	prop3, _ := cmodels.NewProperty(PropIDJagEnabled, "true", false)
	prop4, _ := cmodels.NewProperty(PropTokenExchangeEnabled, "false", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_IDJagEnabledFalse_OIDC_Succeeds() {
	// OIDC IDP with id_jag_enabled=false (still present) should succeed without client credentials,
	// since the mere presence of id_jag_enabled identifies a trust-only connection.
	prop1, _ := cmodels.NewProperty(PropIssuer, "https://idp.example.com/oauth2/token", false)
	prop2, _ := cmodels.NewProperty(PropJwksEndpoint, "https://idp.example.com/oauth2/jwks", false)
	prop3, _ := cmodels.NewProperty(PropIDJagEnabled, "false", false)
	prop4, _ := cmodels.NewProperty(PropTokenExchangeEnabled, "false", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3, *prop4}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.Nil(err)
	s.NotNil(result)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_IDJagEnabled_MissingIssuer_Fails() {
	// OIDC IDP with id_jag_enabled present but missing issuer should fail.
	prop1, _ := cmodels.NewProperty(PropJwksEndpoint, "https://idp.example.com/oauth2/jwks", false)
	prop2, _ := cmodels.NewProperty(PropIDJagEnabled, "true", false)

	properties := []cmodels.Property{*prop1, *prop2}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "required property")
	s.Contains(err.ErrorDescription.String(), PropIssuer)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_IDJagEnabled_MissingJWKS_Fails() {
	// OIDC IDP with id_jag_enabled present but missing jwks_endpoint should fail.
	prop1, _ := cmodels.NewProperty(PropIssuer, "https://idp.example.com/oauth2/token", false)
	prop2, _ := cmodels.NewProperty(PropIDJagEnabled, "true", false)

	properties := []cmodels.Property{*prop1, *prop2}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "required property")
	s.Contains(err.ErrorDescription.String(), PropJwksEndpoint)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_IDJagEnabled_NonBooleanValue_Fails() {
	// OIDC IDP with id_jag_enabled set to a non-boolean value should fail validation.
	prop1, _ := cmodels.NewProperty(PropIssuer, "https://idp.example.com/oauth2/token", false)
	prop2, _ := cmodels.NewProperty(PropJwksEndpoint, "https://idp.example.com/oauth2/jwks", false)
	prop3, _ := cmodels.NewProperty(PropIDJagEnabled, "x", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.String(), PropIDJagEnabled)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_TokenExchangeEnabled_NonBooleanValue_Fails() {
	// OIDC IDP with token_exchange_enabled set to a non-boolean value should fail validation.
	prop1, _ := cmodels.NewProperty(PropIssuer, "https://idp.example.com/oauth2/token", false)
	prop2, _ := cmodels.NewProperty(PropJwksEndpoint, "https://idp.example.com/oauth2/jwks", false)
	prop3, _ := cmodels.NewProperty(PropTokenExchangeEnabled, "yes", false)

	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.String(), PropTokenExchangeEnabled)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_PlainOIDCWithoutIDJagOrTokenExchange_StillFails() {
	// Plain OIDC IDP without id_jag_enabled or token_exchange_enabled and without client
	// credentials must still fail (regression guard for the full required set).
	prop1, _ := cmodels.NewProperty(PropIssuer, "https://idp.example.com/oauth2/token", false)
	prop2, _ := cmodels.NewProperty(PropJwksEndpoint, "https://idp.example.com/oauth2/jwks", false)

	properties := []cmodels.Property{*prop1, *prop2}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOIDC, properties, s.logger)

	s.NotNil(err)
	s.Nil(result)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
	s.Contains(err.ErrorDescription.DefaultValue, "required property")
	s.Contains(err.ErrorDescription.String(), PropClientID)
}

func (s *IDPUtilsTestSuite) TestValidateIDP_PropertyValidationFailure() {
	prop, _ := cmodels.NewProperty("", "value", false)
	idp := &providers.IDPDTO{
		Name:       "Test IDP",
		Type:       providers.IDPTypeOAuth,
		Properties: []cmodels.Property{*prop},
	}

	err := validateIDP(context.Background(), idp, s.logger)

	s.NotNil(err)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_SecretPropertyValueUnreadable() {
	// Initialize the server runtime with the test crypto key; the secret
	// property below holds a value that is not valid ciphertext, so reading
	// it fails on decryption.
	config.ResetServerRuntime()
	_ = config.InitializeServerRuntime("/tmp/test", &config.Config{
		Crypto: config.CryptoConfig{
			Encryption: engineconfig.EncryptionConfig{
				Key: testCryptoKey,
			},
		},
	})
	defer config.ResetServerRuntime()

	properties, dErr := cmodels.DeserializePropertiesFromJSONObject(
		`{"client_secret":{"value":"not-valid-ciphertext","isSecret":true}}`)
	s.NoError(dErr)

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeOAuth, properties, s.logger)

	s.Nil(result)
	s.NotNil(err)
	s.Equal(ErrorInvalidIDPProperty.Code, err.Code)
}

func (s *IDPUtilsTestSuite) TestResolveEndpointDefaults_EmptyBase_ReturnsInputUnchanged() {
	defaults := map[string]string{PropAuthorizationEndpoint: googleAuthorizationEndpoint}

	result := resolveEndpointDefaults(defaults, "")

	s.Equal(defaults[PropAuthorizationEndpoint], result[PropAuthorizationEndpoint])
}

func (s *IDPUtilsTestSuite) TestResolveEndpointDefaults_RewritesSchemeAndHostOnly() {
	defaults := map[string]string{
		PropAuthorizationEndpoint: googleAuthorizationEndpoint,
		PropTokenEndpoint:         googleTokenEndpoint,
	}

	result := resolveEndpointDefaults(defaults, "http://localhost:8093")

	s.Equal("http://localhost:8093/o/oauth2/v2/auth", result[PropAuthorizationEndpoint])
	s.Equal("http://localhost:8093/token", result[PropTokenEndpoint])
	// Original map must not be mutated.
	s.Equal(googleAuthorizationEndpoint, defaults[PropAuthorizationEndpoint])
}

func (s *IDPUtilsTestSuite) TestResolveEndpointDefaults_InvalidBase_ReturnsInputUnchanged() {
	defaults := map[string]string{PropAuthorizationEndpoint: googleAuthorizationEndpoint}

	result := resolveEndpointDefaults(defaults, "://not-a-valid-url")

	s.Equal(defaults[PropAuthorizationEndpoint], result[PropAuthorizationEndpoint])
}

func (s *IDPUtilsTestSuite) TestResolveEndpointDefaults_HostlessBase_ReturnsInputUnchanged() {
	defaults := map[string]string{PropAuthorizationEndpoint: googleAuthorizationEndpoint}

	result := resolveEndpointDefaults(defaults, "/mock")

	s.Equal(defaults[PropAuthorizationEndpoint], result[PropAuthorizationEndpoint])
}

func (s *IDPUtilsTestSuite) TestResolveEndpointDefaults_NonHTTPBase_ReturnsInputUnchanged() {
	defaults := map[string]string{PropAuthorizationEndpoint: googleAuthorizationEndpoint}

	result := resolveEndpointDefaults(defaults, "localhost:8093")

	s.Equal(defaults[PropAuthorizationEndpoint], result[PropAuthorizationEndpoint])
}

func (s *IDPUtilsTestSuite) TestResolveEndpointDefaults_InvalidValue_KeepsOriginal() {
	defaults := map[string]string{PropAuthorizationEndpoint: "http://exa\nmple.com"}

	result := resolveEndpointDefaults(defaults, "http://localhost:8093")

	s.Equal(defaults[PropAuthorizationEndpoint], result[PropAuthorizationEndpoint])
}

func (s *IDPUtilsTestSuite) TestEndpointBaseURLOverride_GitHub_ReturnsConfiguredValue() {
	config.ResetServerRuntime()
	_ = config.InitializeServerRuntime("/tmp/test", &config.Config{
		IdentityProvider: config.IdentityProviderConfig{
			GitHubBaseURL: "http://localhost:8092",
		},
	})
	defer config.ResetServerRuntime()

	result := endpointBaseURLOverride(providers.IDPTypeGitHub)

	s.Equal("http://localhost:8092", result)
}

func (s *IDPUtilsTestSuite) TestEndpointBaseURLOverride_NilRuntime_ReturnsEmpty() {
	config.ResetServerRuntime()

	result := endpointBaseURLOverride(providers.IDPTypeGoogle)

	s.Empty(result)
}

func (s *IDPUtilsTestSuite) TestEndpointBaseURLOverride_NonGoogleGitHubType_ReturnsEmpty() {
	config.ResetServerRuntime()
	_ = config.InitializeServerRuntime("/tmp/test", &config.Config{
		IdentityProvider: config.IdentityProviderConfig{
			GoogleBaseURL: "http://localhost:8093",
			GitHubBaseURL: "http://localhost:8092",
		},
	})
	defer config.ResetServerRuntime()

	result := endpointBaseURLOverride(providers.IDPTypeOAuth)

	s.Empty(result)
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_AppliesEndpointOverride_WhenConfigured() {
	config.ResetServerRuntime()
	_ = config.InitializeServerRuntime("/tmp/test", &config.Config{
		Crypto: config.CryptoConfig{
			Encryption: engineconfig.EncryptionConfig{Key: testCryptoKey},
		},
		IdentityProvider: config.IdentityProviderConfig{
			GoogleBaseURL: "http://localhost:8093",
		},
	})
	defer config.ResetServerRuntime()

	prop1, _ := cmodels.NewProperty(PropClientID, "client-id", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "client-secret", true)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "https://app/callback", false)
	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGoogle, properties, s.logger)

	s.Nil(err)
	s.Equal("http://localhost:8093/o/oauth2/v2/auth", GetPropertyValue(result, PropAuthorizationEndpoint))
	s.Equal("http://localhost:8093/token", GetPropertyValue(result, PropTokenEndpoint))
}

func (s *IDPUtilsTestSuite) TestValidateIDPProperties_NoEndpointOverride_UsesRealEndpoints() {
	config.ResetServerRuntime()
	_ = config.InitializeServerRuntime("/tmp/test", &config.Config{
		Crypto: config.CryptoConfig{
			Encryption: engineconfig.EncryptionConfig{Key: testCryptoKey},
		},
	})
	defer config.ResetServerRuntime()

	prop1, _ := cmodels.NewProperty(PropClientID, "client-id", false)
	prop2, _ := cmodels.NewProperty(PropClientSecret, "client-secret", true)
	prop3, _ := cmodels.NewProperty(PropRedirectURI, "https://app/callback", false)
	properties := []cmodels.Property{*prop1, *prop2, *prop3}

	result, err := validateIDPProperties(context.Background(), providers.IDPTypeGoogle, properties, s.logger)

	s.Nil(err)
	s.Equal(googleAuthorizationEndpoint, GetPropertyValue(result, PropAuthorizationEndpoint))
	s.Equal(googleTokenEndpoint, GetPropertyValue(result, PropTokenEndpoint))
}

func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_NilMappings_NoOp() {
	attrs := map[string]interface{}{"email": "user@example.com"}
	result := ApplyAttributeMappings(attrs, nil)
	s.Equal(attrs, result)
}

func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_EmptyMappings_NoOp() {
	attrs := map[string]interface{}{"email": "user@example.com"}
	result := ApplyAttributeMappings(attrs, []providers.AttributeMapping{})
	s.Equal(attrs, result)
}

// Mappings copy rather than rename, so the source claim survives alongside the local attribute.
func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_PublishesMappedClaimAndKeepsSource() {
	attrs := map[string]interface{}{
		"http://schemas.example.com/emailaddress": "user@example.com",
	}
	result := ApplyAttributeMappings(attrs, []providers.AttributeMapping{
		{ExternalAttribute: "http://schemas.example.com/emailaddress", LocalAttribute: "email"},
	})
	s.Equal("user@example.com", result["email"])
	s.Equal("user@example.com", result["http://schemas.example.com/emailaddress"])
}

// The case the copy semantics exist for: mapping an email onto a required username must not leave the
// identity without an email.
func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_EmailSurvivesAUsernameMapping() {
	attrs := map[string]interface{}{"email": "user@example.com", "sub": "user-123"}
	result := ApplyAttributeMappings(attrs, []providers.AttributeMapping{
		{ExternalAttribute: "email", LocalAttribute: "username"},
	})
	s.Equal("user@example.com", result["username"])
	s.Equal("user@example.com", result["email"])
	s.Equal("user-123", result["sub"])
}

func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_OneSourceToMultipleTargets() {
	attrs := map[string]interface{}{"email": "user@example.com"}
	result := ApplyAttributeMappings(attrs, []providers.AttributeMapping{
		{ExternalAttribute: "email", LocalAttribute: "email"},
		{ExternalAttribute: "email", LocalAttribute: "contactEmail"},
	})
	s.Equal("user@example.com", result["email"])
	s.Equal("user@example.com", result["contactEmail"])
}

func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_UnmappedPassesThrough() {
	attrs := map[string]interface{}{
		"given_name": "Jane",
		"department": "engineering",
	}
	result := ApplyAttributeMappings(
		attrs, []providers.AttributeMapping{{ExternalAttribute: "given_name", LocalAttribute: "firstName"}})
	s.Equal("Jane", result["firstName"])
	s.Equal("engineering", result["department"])
	s.Equal("Jane", result["given_name"])
}

func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_MappedValueOverridesCollision() {
	attrs := map[string]interface{}{
		"given_name": "Jane",
		"firstName":  "stale",
	}
	result := ApplyAttributeMappings(
		attrs, []providers.AttributeMapping{{ExternalAttribute: "given_name", LocalAttribute: "firstName"}})
	s.Equal("Jane", result["firstName"])
}

func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_MissingExternalClaimIgnored() {
	attrs := map[string]interface{}{"email": "user@example.com"}
	result := ApplyAttributeMappings(
		attrs, []providers.AttributeMapping{{ExternalAttribute: "given_name", LocalAttribute: "firstName"}})
	s.Equal("user@example.com", result["email"])
	_, present := result["firstName"]
	s.False(present)
}

func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_NestedSourcePath() {
	attrs := map[string]interface{}{
		"address": map[string]interface{}{
			"email": "user@example.com",
		},
		"keep": "value",
	}
	result := ApplyAttributeMappings(
		attrs, []providers.AttributeMapping{{ExternalAttribute: "address.email", LocalAttribute: "email"}})
	s.Equal("user@example.com", result["email"])
	// The containing nested object is read non-destructively and passes through.
	s.Equal(attrs["address"], result["address"])
	s.Equal("value", result["keep"])
}

func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_DottedKeyMatchedLiterallyBeforePath() {
	// A URI-style claim name containing dots must be matched literally, not split into a path.
	attrs := map[string]interface{}{
		"http://schemas.example.com/emailaddress": "user@example.com",
	}
	result := ApplyAttributeMappings(attrs, []providers.AttributeMapping{
		{ExternalAttribute: "http://schemas.example.com/emailaddress", LocalAttribute: "email"},
	})
	s.Equal("user@example.com", result["email"])
}

func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_SubPreservedWhenMappedToMultipleTargets() {
	attrs := map[string]interface{}{"sub": "user-123"}
	result := ApplyAttributeMappings(attrs, []providers.AttributeMapping{
		{ExternalAttribute: "sub", LocalAttribute: "username"},
		{ExternalAttribute: "sub", LocalAttribute: "email"},
	})
	s.Equal("user-123", result["sub"])
	s.Equal("user-123", result["username"])
	s.Equal("user-123", result["email"])
}

// sub needed a carve-out under rename semantics; under copy semantics every source is preserved and
// it is no longer a special case.
func (s *IDPUtilsTestSuite) TestApplyAttributeMappings_AllSourcesPreserved() {
	attrs := map[string]interface{}{
		"sub":        "user-123",
		"given_name": "Jane",
	}
	result := ApplyAttributeMappings(attrs, []providers.AttributeMapping{
		{ExternalAttribute: "sub", LocalAttribute: "picture"},
		{ExternalAttribute: "given_name", LocalAttribute: "firstName"},
	})
	s.Equal("user-123", result["sub"])
	s.Equal("user-123", result["picture"])
	s.Equal("Jane", result["firstName"])
	s.Equal("Jane", result["given_name"])
}

func (s *IDPUtilsTestSuite) TestGetAttributeMappings_NilIDP() {
	s.Nil(GetAttributeMappings(nil, nil))
}

func (s *IDPUtilsTestSuite) TestGetAttributeMappings_NilAttributeConfiguration() {
	s.Nil(GetAttributeMappings(&providers.IDPDTO{}, nil))
}

func (s *IDPUtilsTestSuite) TestGetAttributeMappings_ReturnsMappings() {
	mappings := []providers.AttributeMapping{{ExternalAttribute: "given_name", LocalAttribute: "firstName"}}
	idpDTO := &providers.IDPDTO{AttributeConfiguration: &providers.AttributeConfiguration{
		UserTypeResolution:        &providers.UserTypeResolution{Default: "person"},
		UserTypeAttributeMappings: []providers.UserTypeAttributeMapping{{UserType: "person", Attributes: mappings}},
	}}
	s.Equal(mappings, GetAttributeMappings(idpDTO, nil))
}

func (s *IDPUtilsTestSuite) TestGetAttributeMappings_ResolvedByClaim() {
	personMappings := []providers.AttributeMapping{{ExternalAttribute: "given_name", LocalAttribute: "firstName"}}
	employeeMappings := []providers.AttributeMapping{{ExternalAttribute: "emp_id", LocalAttribute: "employeeNumber"}}
	idpDTO := &providers.IDPDTO{AttributeConfiguration: &providers.AttributeConfiguration{
		UserTypeResolution: &providers.UserTypeResolution{
			Default:           "person",
			ExternalAttribute: "user_type",
			ValueMapping:      map[string]string{"staff": "employee"},
		},
		UserTypeAttributeMappings: []providers.UserTypeAttributeMapping{
			{UserType: "person", Attributes: personMappings},
			{UserType: "employee", Attributes: employeeMappings},
		},
	}}
	s.Equal(employeeMappings, GetAttributeMappings(idpDTO, map[string]interface{}{"user_type": "staff"}))
}

func (s *IDPUtilsTestSuite) TestGetMappedUserType_NilIDP() {
	s.Equal("", GetMappedUserType(nil, nil))
}

func (s *IDPUtilsTestSuite) TestGetMappedUserType_NilAttributeConfiguration() {
	s.Equal("", GetMappedUserType(&providers.IDPDTO{}, nil))
}

func (s *IDPUtilsTestSuite) TestGetMappedUserType_ReturnsEntityType() {
	s.Equal("person", GetMappedUserType(&providers.IDPDTO{AttributeConfiguration: &providers.AttributeConfiguration{
		UserTypeResolution: &providers.UserTypeResolution{Default: "person"},
	}}, nil))
}

func (s *IDPUtilsTestSuite) TestGetMappedUserType_DynamicResolution() {
	idpDTO := &providers.IDPDTO{AttributeConfiguration: &providers.AttributeConfiguration{
		UserTypeResolution: &providers.UserTypeResolution{
			Default:           "person",
			ExternalAttribute: "user_type",
			ValueMapping:      map[string]string{"staff": "employee", "client": "customer"},
		},
	}}

	// Mapped value resolves to its user type.
	s.Equal("employee", GetMappedUserType(idpDTO, map[string]interface{}{"user_type": "staff"}))
	// Unmapped value falls back to the default.
	s.Equal("person", GetMappedUserType(idpDTO, map[string]interface{}{"user_type": "guest"}))
	// Missing attribute falls back to the default.
	s.Equal("person", GetMappedUserType(idpDTO, map[string]interface{}{"other": "x"}))
	// Nil claims fall back to the default.
	s.Equal("person", GetMappedUserType(idpDTO, nil))
}

func (s *IDPUtilsTestSuite) TestGetMappedUserType_DirectValueResolution() {
	idpDTO := &providers.IDPDTO{AttributeConfiguration: &providers.AttributeConfiguration{
		UserTypeResolution: &providers.UserTypeResolution{
			Default:           "person",
			ExternalAttribute: "user_type",
		},
	}}

	// With no value mapping, the external claim value is used directly as the user type.
	s.Equal("employee", GetMappedUserType(idpDTO, map[string]interface{}{"user_type": "employee"}))
	// Missing attribute falls back to the default.
	s.Equal("person", GetMappedUserType(idpDTO, map[string]interface{}{"other": "x"}))
	// Empty claim value falls back to the default.
	s.Equal("person", GetMappedUserType(idpDTO, map[string]interface{}{"user_type": "  "}))
	// Nil claims fall back to the default.
	s.Equal("person", GetMappedUserType(idpDTO, nil))
}

func (s *IDPUtilsTestSuite) TestGetMappedUserType_DynamicResolutionNestedClaim() {
	idpDTO := &providers.IDPDTO{AttributeConfiguration: &providers.AttributeConfiguration{
		UserTypeResolution: &providers.UserTypeResolution{
			Default:           "person",
			ExternalAttribute: "profile.role",
			ValueMapping:      map[string]string{"admin": "employee"},
		},
	}}
	claims := map[string]interface{}{"profile": map[string]interface{}{"role": "admin"}}
	s.Equal("employee", GetMappedUserType(idpDTO, claims))
}

func (s *IDPUtilsTestSuite) TestIDJagEnabledFromProperties_True() {
	prop, err := cmodels.NewProperty(PropIDJagEnabled, "true", false)
	s.NoError(err)

	got := idJagEnabledFromProperties([]cmodels.Property{*prop})
	s.Require().NotNil(got)
	s.True(*got)
}

func (s *IDPUtilsTestSuite) TestIDJagEnabledFromProperties_False() {
	prop, err := cmodels.NewProperty(PropIDJagEnabled, "false", false)
	s.NoError(err)

	got := idJagEnabledFromProperties([]cmodels.Property{*prop})
	s.Require().NotNil(got)
	s.False(*got)
}

func (s *IDPUtilsTestSuite) TestIDJagEnabledFromProperties_Absent() {
	prop, err := cmodels.NewProperty("client_id", "abc", false)
	s.NoError(err)

	s.Nil(idJagEnabledFromProperties([]cmodels.Property{*prop}))
	s.Nil(idJagEnabledFromProperties(nil))
}

func (s *IDPUtilsTestSuite) TestIDJagEnabledFromProperties_InvalidValue() {
	prop, err := cmodels.NewProperty(PropIDJagEnabled, "not-a-bool", false)
	s.NoError(err)

	s.Nil(idJagEnabledFromProperties([]cmodels.Property{*prop}))
}

// ----- AuthorizationRuleMapping resolution -----

type AuthorizationRuleMappingResolveTestSuite struct {
	suite.Suite
}

func TestAuthorizationRuleMappingResolveTestSuite(t *testing.T) {
	suite.Run(t, new(AuthorizationRuleMappingResolveTestSuite))
}

func (suite *AuthorizationRuleMappingResolveTestSuite) TestNilIDPReturnsNil() {
	suite.Nil(GetRuleAuthorizationTargets(nil, map[string]interface{}{"groups": []interface{}{"engineering"}}))
}

func (suite *AuthorizationRuleMappingResolveTestSuite) TestNoAttributeConfigurationReturnsNil() {
	idp := &providers.IDPDTO{}
	suite.Nil(GetRuleAuthorizationTargets(idp, map[string]interface{}{"groups": []interface{}{"engineering"}}))
}

// A list-valued claim must resolve every element, not the joined string. This is the array-parsing
// bug the shared string-conversion helper would otherwise reintroduce: joining ["engineering",
// "platform-admins"] into "engineering,platform-admins" before lookup would match nothing.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestListValuedClaimResolvesEachElement() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim: "groups",
					Values: []providers.AuthorizationRule{
						equalsRule("engineering", roleTarget("role-eng")),
						equalsRule("platform-admins", roleTarget("role-platform-admin")),
					},
				},
			}},
		},
	}
	claims := map[string]interface{}{"groups": []interface{}{"engineering", "platform-admins"}}

	targets := GetRuleAuthorizationTargets(idp, claims)

	suite.ElementsMatch(
		[]providers.AuthorizationTarget{roleTarget("role-eng"), roleTarget("role-platform-admin")}, targets)
}

func (suite *AuthorizationRuleMappingResolveTestSuite) TestSpaceDelimitedStringClaimSplitsOnConfiguredDelimiter() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "scope",
					Delimiter: " ",
					Values: []providers.AuthorizationRule{
						equalsRule("orders.write", roleTarget("role-orders-write")),
					},
				},
			}},
		},
	}
	claims := map[string]interface{}{"scope": "orders.read orders.write"}

	targets := GetRuleAuthorizationTargets(idp, claims)

	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-orders-write")}, targets)
}

func (suite *AuthorizationRuleMappingResolveTestSuite) TestScalarStringClaimWithNoDelimiterIsOneToken() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:  "department",
					Values: []providers.AuthorizationRule{equalsRule("platform", groupTarget("group-platform"))},
				},
			}},
		},
	}
	claims := map[string]interface{}{"department": "platform"}

	targets := GetRuleAuthorizationTargets(idp, claims)

	suite.Equal([]providers.AuthorizationTarget{groupTarget("group-platform")}, targets)
}

// An unmapped value confers nothing, even where it matches the name of a local role or group.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestUnmappedValueConfersNothing() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:  "groups",
					Values: []providers.AuthorizationRule{equalsRule("engineering", roleTarget("role-eng"))},
				},
			}},
		},
	}
	claims := map[string]interface{}{"groups": []interface{}{"marketing"}}

	suite.Empty(GetRuleAuthorizationTargets(idp, claims))
}

func (suite *AuthorizationRuleMappingResolveTestSuite) TestMissingClaimConfersNothing() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:  "groups",
					Values: []providers.AuthorizationRule{equalsRule("engineering", roleTarget("role-eng"))},
				},
			}},
		},
	}

	suite.Empty(GetRuleAuthorizationTargets(idp, map[string]interface{}{}))
}

func (suite *AuthorizationRuleMappingResolveTestSuite) TestDuplicateTargetsAcrossMappingsAreDeduped() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:  "groups",
					Values: []providers.AuthorizationRule{equalsRule("engineering", roleTarget("role-eng"))},
				},
				{
					Claim:  "department",
					Values: []providers.AuthorizationRule{equalsRule("engineering", roleTarget("role-eng"))},
				},
			}},
		},
	}
	claims := map[string]interface{}{"groups": []interface{}{"engineering"}, "department": "engineering"}

	targets := GetRuleAuthorizationTargets(idp, claims)

	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-eng")}, targets)
}

// not_equals matches element-wise: a rule contributes if any one of the claim's values satisfies it,
// so a list carrying an unrelated value alongside the excluded one still grants.
// This declares "groups" as a single value (the default string type, no delimiter), even though the
// claim actually resolves to two elements at runtime — a declared/actual shape mismatch the resolver
// tolerates rather than rejects (see AuthorizationRuleMapping.IsMultiValued). not_equals is a per-token,
// any-match comparison, so it matches here because "engineering" differs from "guest", even though
// "guest" itself is also present. That is exactly the ambiguous reading includes/not_includes exist
// to avoid for a claim genuinely declared multi-valued: see
// TestNotIncludesRequiresWholeSetAbsenceUnlikeNotEquals below for the contrast.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestNotEqualsOperatorMatchesWhenAnyTokenDiffers() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim: "groups",
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorNotEquals,
							Value:    "guest",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-non-guest")},
						},
					},
				},
			}},
		},
	}
	claims := map[string]interface{}{"groups": []interface{}{"guest", "engineering"}}

	targets := GetRuleAuthorizationTargets(idp, claims)

	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-non-guest")}, targets)
}

// The motivating case for includes/not_includes: on the identical claim data as the test above,
// not_includes correctly withholds the grant, because "guest" is present in the set. not_equals
// (element-wise, any-match) granted access to a user who unambiguously is still a guest; not_includes
// (whole-set) does not, since it tests absence from the entire set rather than difference from any
// one element.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestNotIncludesRequiresWholeSetAbsenceUnlikeNotEquals() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "groups",
					ValueType: providers.AuthorizationValueTypeArray,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorNotIncludes,
							Value:    "guest",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-non-guest")},
						},
					},
				},
			}},
		},
	}

	suite.Empty(
		GetRuleAuthorizationTargets(idp, map[string]interface{}{"groups": []interface{}{"guest", "engineering"}}),
		"not_includes must not grant when the excluded value is present in the set, even alongside others")
	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-non-guest")},
		GetRuleAuthorizationTargets(idp, map[string]interface{}{"groups": []interface{}{"engineering"}}),
		"not_includes must grant when the excluded value is absent from the set")
}

// includes is a straightforward membership test: it matches when the named value is one of the set's
// elements, and does not match when it is absent.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestIncludesOperatorTestsSetMembershipForArrayType() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "groups",
					ValueType: providers.AuthorizationValueTypeArray,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorIncludes,
							Value:    "platform-admins",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-platform-admin")},
						},
					},
				},
			}},
		},
	}

	claims := map[string]interface{}{"groups": []interface{}{"engineering", "platform-admins"}}
	suite.Equal(
		[]providers.AuthorizationTarget{roleTarget("role-platform-admin")}, GetRuleAuthorizationTargets(idp, claims))
	suite.Empty(GetRuleAuthorizationTargets(idp, map[string]interface{}{"groups": []interface{}{"engineering"}}))
}

// includes/not_includes apply identically to a delimited string, the other declared shape
// IsMultiValued recognizes: the string is split on the delimiter, and membership is tested across
// the resulting tokens exactly as it would be for a native array.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestIncludesOperatorTestsSetMembershipForDelimitedString() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "scope",
					ValueType: providers.AuthorizationValueTypeString,
					Delimiter: " ",
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorIncludes,
							Value:    "orders.write",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-orders-write")},
						},
					},
				},
			}},
		},
	}

	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-orders-write")},
		GetRuleAuthorizationTargets(idp, map[string]interface{}{"scope": "orders.read orders.write"}))
	suite.Empty(GetRuleAuthorizationTargets(idp, map[string]interface{}{"scope": "orders.read"}))
}

// A claim that is present but resolves to no tokens at all (an empty array, or an all-empty delimited
// string) still unambiguously does not include anything.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestNotIncludesGrantsWhenClaimResolvesToNoTokens() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "groups",
					ValueType: providers.AuthorizationValueTypeArray,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorNotIncludes,
							Value:    "guest",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-non-guest")},
						},
					},
				},
			}},
		},
	}

	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-non-guest")},
		GetRuleAuthorizationTargets(idp, map[string]interface{}{"groups": []interface{}{}}))
}

func (suite *AuthorizationRuleMappingResolveTestSuite) TestGreaterThanOperatorGrantsForNumericClaim() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "level",
					ValueType: providers.AuthorizationValueTypeNumber,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorGreaterThan,
							Value:    "5",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-senior")},
						},
					},
				},
			}},
		},
	}

	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-senior")},
		GetRuleAuthorizationTargets(idp, map[string]interface{}{"level": "10"}))
	suite.Empty(GetRuleAuthorizationTargets(idp, map[string]interface{}{"level": "3"}))
}

func (suite *AuthorizationRuleMappingResolveTestSuite) TestBooleanValueTypeEquals() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "is_admin",
					ValueType: providers.AuthorizationValueTypeBoolean,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorEquals,
							Value:    "true",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-admin")},
						},
					},
				},
			}},
		},
	}

	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-admin")},
		GetRuleAuthorizationTargets(idp, map[string]interface{}{"is_admin": "true"}))
	suite.Empty(GetRuleAuthorizationTargets(idp, map[string]interface{}{"is_admin": "false"}))
}

// A JSON-decoded claim carries a genuine float64, not a quoted string (encoding/json unmarshals every
// JSON number into float64 when the target is interface{}). The number comparison must work on that
// native type just as it does on a claim an IdP happens to stringify.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestNumberValueTypeMatchesNativeJSONNumberClaim() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "level",
					ValueType: providers.AuthorizationValueTypeNumber,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorGreaterThan,
							Value:    "5",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-senior")},
						},
					},
				},
			}},
		},
	}

	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-senior")},
		GetRuleAuthorizationTargets(idp, map[string]interface{}{"level": float64(10)}))
	suite.Empty(GetRuleAuthorizationTargets(idp, map[string]interface{}{"level": float64(3)}))
}

// A JSON-decoded claim carries a genuine bool, not a quoted "true"/"false" string. The equals
// comparison must work on that native type just as it does on a claim an IdP happens to stringify.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestBooleanValueTypeMatchesNativeJSONBooleanClaim() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "is_admin",
					ValueType: providers.AuthorizationValueTypeBoolean,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorEquals,
							Value:    "true",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-admin")},
						},
					},
				},
			}},
		},
	}

	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-admin")},
		GetRuleAuthorizationTargets(idp, map[string]interface{}{"is_admin": true}))
	suite.Empty(GetRuleAuthorizationTargets(idp, map[string]interface{}{"is_admin": false}))
}

// Whitespace around a number or boolean token is never significant, unlike a string comparison where
// it may be part of the value being matched, so it must not prevent an otherwise-valid match. This
// covers the one case where such whitespace can reach evaluation: a scalar string claim with no
// delimiter is deliberately left untrimmed for the string-equality case (a value there may carry
// meaningful whitespace), so a number/boolean-typed mapping inherits that untrimmed token and must
// trim it itself before parsing.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestNumberBooleanComparisonTrimsWhitespaceAroundToken() {
	numberIDP := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "level",
					ValueType: providers.AuthorizationValueTypeNumber,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorGreaterThan,
							Value:    "5",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-senior")},
						},
					},
				},
			}},
		},
	}
	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-senior")},
		GetRuleAuthorizationTargets(numberIDP, map[string]interface{}{"level": " 10 "}))

	booleanIDP := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "is_admin",
					ValueType: providers.AuthorizationValueTypeBoolean,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorEquals,
							Value:    "true",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-admin")},
						},
					},
				},
			}},
		},
	}
	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-admin")},
		GetRuleAuthorizationTargets(booleanIDP, map[string]interface{}{"is_admin": " true "}))
}

// A list carrying a mix of parseable and unparseable elements still matches on the elements that do
// parse; one malformed element must not poison the whole rule.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestNumberComparisonSkipsUnparseableElementsInList() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "levels",
					ValueType: providers.AuthorizationValueTypeNumber,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorGreaterThan,
							Value:    "5",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-senior")},
						},
					},
				},
			}},
		},
	}

	targets := GetRuleAuthorizationTargets(
		idp, map[string]interface{}{"levels": []interface{}{"not-a-number", "10"}})
	suite.Equal([]providers.AuthorizationTarget{roleTarget("role-senior")}, targets)
}

// A claim token that does not parse as the mapping's declared value type never matches, the same
// fail-closed behavior as an unmapped value.
func (suite *AuthorizationRuleMappingResolveTestSuite) TestNonParseableNumericTokenConfersNothing() {
	idp := &providers.IDPDTO{
		AttributeConfiguration: &providers.AttributeConfiguration{
			AuthorizationMapping: &providers.AuthorizationMapping{Rules: []providers.AuthorizationRuleMapping{
				{
					Claim:     "level",
					ValueType: providers.AuthorizationValueTypeNumber,
					Values: []providers.AuthorizationRule{
						{
							Operator: providers.AuthorizationOperatorGreaterThan,
							Value:    "5",
							Targets:  []providers.AuthorizationTarget{roleTarget("role-senior")},
						},
					},
				},
			}},
		},
	}

	suite.Empty(GetRuleAuthorizationTargets(idp, map[string]interface{}{"level": "not-a-number"}))
}

func (suite *AuthorizationRuleMappingResolveTestSuite) TestSplitAuthorizationTargets() {
	roleIDs, groupIDs, permissions := SplitAuthorizationTargets([]providers.AuthorizationTarget{
		{Type: providers.AuthorizationTargetRole, ID: "role-1"},
		{Type: providers.AuthorizationTargetGroup, ID: "group-1"},
		{Type: providers.AuthorizationTargetPermission, ResourceServerID: "rs-1", Permission: "read"},
		{Type: providers.AuthorizationTargetRole, ID: "role-2"},
	})
	suite.Equal([]string{"role-1", "role-2"}, roleIDs)
	suite.Equal([]string{"group-1"}, groupIDs)
	suite.Equal([]providers.AuthorizationTarget{
		{Type: providers.AuthorizationTargetPermission, ResourceServerID: "rs-1", Permission: "read"},
	}, permissions)
}

func (suite *AuthorizationRuleMappingResolveTestSuite) TestUnionMappedPermissionTargets() {
	targets := []providers.AuthorizationTarget{
		{Type: providers.AuthorizationTargetPermission, ResourceServerID: "rs-1", Permission: "read"},
		{Type: providers.AuthorizationTargetPermission, ResourceServerID: "rs-1", Permission: "write"},
		{Type: providers.AuthorizationTargetPermission, ResourceServerID: "rs-2", Permission: "read"},
	}
	result := UnionMappedPermissionTargets([]string{"write"}, []string{"read", "write"}, targets, "rs-1")
	suite.Equal([]string{"write", "read"}, result)
}

func linkingOn(attrs ...string) *providers.AccountLinking {
	return &providers.AccountLinking{Attributes: attrs}
}

// linkingFilters runs the resolver the way BuildFederatedAuthResult does, on the mapped claims.
func linkingFilters(linking *providers.AccountLinking, claims map[string]interface{},
	mappings []providers.AttributeMapping) []map[string]interface{} {
	return BuildAccountLinkingFilters(linking, ApplyAttributeMappings(claims, mappings), mappings)
}

func (s *IDPUtilsTestSuite) TestGetAccountLinkingLocalAttributes() {
	mappings := []providers.AttributeMapping{
		{ExternalAttribute: "email", LocalAttribute: "username"},
		{ExternalAttribute: "phone_number", LocalAttribute: "mobileNumber"},
	}
	claims := ApplyAttributeMappings(map[string]interface{}{
		"email": "a@example.com", "phone_number": "+15550001", "userID": "u1",
	}, mappings)

	s.Nil(GetAccountLinkingLocalAttributes(nil, claims, mappings))
	s.Equal([]string{"username", "email", "mobileNumber", "phone_number"},
		GetAccountLinkingLocalAttributes(linkingOn("email", "phone_number", "email"), claims, mappings))
	s.Empty(GetAccountLinkingLocalAttributes(linkingOn("userID", "nickname"), claims, mappings))
}

// The seeded Google and OIDC shape: email feeds the required username, and mappings copy, so the
// email claim still lands in the local email attribute and must be matched there too.
func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_MatchesMappedTargetAndSameNamedAttribute() {
	filters := linkingFilters(linkingOn("email"),
		map[string]interface{}{"email": "a@example.com"},
		[]providers.AttributeMapping{{ExternalAttribute: "email", LocalAttribute: "username"}})

	s.Equal([]map[string]interface{}{
		{"username": "a@example.com"},
		{"email": "a@example.com"},
	}, filters)
}

func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_ExplicitSameNameMappingIsNotDuplicated() {
	filters := linkingFilters(linkingOn("email"),
		map[string]interface{}{"email": "a@example.com"},
		[]providers.AttributeMapping{
			{ExternalAttribute: "email", LocalAttribute: "email"},
			{ExternalAttribute: "email", LocalAttribute: "username"},
		})

	s.Equal([]map[string]interface{}{
		{"email": "a@example.com"},
		{"username": "a@example.com"},
	}, filters)
}

func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_UnmappedAttributeMatchesItsOwnName() {
	filters := linkingFilters(linkingOn("email"), map[string]interface{}{"email": "a@example.com"}, nil)

	s.Equal([]map[string]interface{}{{"email": "a@example.com"}}, filters)
}

// A dotted path is read through nested claims, but a local attribute never carries that name, so only
// the explicit target can match. Unmapped, the value has nowhere to match and linking is off.
func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_NestedClaimMatchesOnlyItsMappedTarget() {
	claims := map[string]interface{}{"profile": map[string]interface{}{"mail": "a@example.com"}}

	s.Equal([]map[string]interface{}{{"email": "a@example.com"}},
		linkingFilters(linkingOn("profile.mail"), claims,
			[]providers.AttributeMapping{{ExternalAttribute: "profile.mail", LocalAttribute: "email"}}))
	s.Nil(linkingFilters(linkingOn("profile.mail"), claims, nil))
}

// A claim name the entity store cannot query is never searched under its own name.
func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_UnqueryableClaimNameMatchesOnlyItsMappedTarget() {
	claims := map[string]interface{}{"custom:email": "a@example.com"}

	s.Equal([]map[string]interface{}{{"email": "a@example.com"}},
		linkingFilters(linkingOn("custom:email"), claims,
			[]providers.AttributeMapping{{ExternalAttribute: "custom:email", LocalAttribute: "email"}}))
	s.Nil(linkingFilters(linkingOn("custom:email"), claims, nil))
}

// A mapped claim is not matched against a same-named local attribute another claim feeds, because
// that claim's value is what gets stored there.
func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_MappedClaimSkipsSameNamedAttributeFedByAnotherClaim() {
	s.Equal([]map[string]interface{}{{"username": "a@example.com"}},
		linkingFilters(linkingOn("email"),
			map[string]interface{}{"email": "a@example.com", "mail": "b@example.com"},
			[]providers.AttributeMapping{
				{ExternalAttribute: "email", LocalAttribute: "username"},
				{ExternalAttribute: "mail", LocalAttribute: "email"},
			}))
}

// An unmapped linking attribute matches its local attribute on whatever is stored there, which is how
// a connection links on a local attribute another claim is mapped to.
func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_UnmappedAttributeMatchesTheValueAnotherClaimFeeds() {
	s.Equal([]map[string]interface{}{{"costCenter": "CC-1"}},
		linkingFilters(linkingOn("costCenter"), map[string]interface{}{"cost_code": "CC-1"},
			[]providers.AttributeMapping{{ExternalAttribute: "cost_code", LocalAttribute: "costCenter"}}))
}

func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_CombinesEveryAlternativeOfEachAttribute() {
	filters := linkingFilters(linkingOn("email", "phone"),
		map[string]interface{}{"email": "a@example.com", "phone": "123"},
		[]providers.AttributeMapping{{ExternalAttribute: "email", LocalAttribute: "username"}})

	s.Equal([]map[string]interface{}{
		{"username": "a@example.com", "phone": "123"},
		{"email": "a@example.com", "phone": "123"},
	}, filters)
}

// Two linking attributes landing on one local attribute read the same stored value, so they merge.
func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_MergesAttributesLandingOnOneLocalAttribute() {
	filters := linkingFilters(linkingOn("costCenter", "cost_code"),
		map[string]interface{}{"cost_code": "CC-1"},
		[]providers.AttributeMapping{{ExternalAttribute: "cost_code", LocalAttribute: "costCenter"}})

	s.Equal([]map[string]interface{}{
		{"costCenter": "CC-1"},
		{"costCenter": "CC-1", "cost_code": "CC-1"},
	}, filters)
}

func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_LeavesOutAttributesWithoutValues() {
	filters := linkingFilters(linkingOn("email", "phone"),
		map[string]interface{}{"email": "a@example.com", "phone": ""}, nil)

	s.Equal([]map[string]interface{}{{"email": "a@example.com"}}, filters)
	s.Nil(linkingFilters(linkingOn("email"), map[string]interface{}{}, nil))
	s.Nil(linkingFilters(nil, map[string]interface{}{"email": "a@example.com"}, nil))
}

// An attribute with a value but nowhere to match on disables linking rather than being dropped, which
// would widen the match to the attributes that remain.
func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_AttributeWithNoTargetDisablesLinking() {
	s.Nil(linkingFilters(linkingOn("email", "custom:tenant"),
		map[string]interface{}{"email": "a@example.com", "custom:tenant": "acme"}, nil))
}

// A reserved name would let the identity provider pick the account, so it never reaches a filter.
func (s *IDPUtilsTestSuite) TestBuildAccountLinkingFilters_NeverMatchesOnReservedNames() {
	for _, reserved := range []string{"userID", "federatedIdpId", "credentialUpdatedAt", "linkedIds"} {
		s.Nil(linkingFilters(linkingOn(reserved), map[string]interface{}{reserved: "x"}, nil), reserved)
		s.Equal([]map[string]interface{}{{"email": "x"}},
			linkingFilters(linkingOn("email"), map[string]interface{}{"email": "x"},
				[]providers.AttributeMapping{{ExternalAttribute: "email", LocalAttribute: reserved}}), reserved)
	}
	s.Nil(linkingFilters(linkingOn("custom:email"), map[string]interface{}{"custom:email": "x"},
		[]providers.AttributeMapping{{ExternalAttribute: "custom:email", LocalAttribute: "linkedIds.idp-1"}}))
}

func (s *IDPUtilsTestSuite) TestValidateAccountLinking() {
	cases := []struct {
		name    string
		profile providers.AttributeConfiguration
		errKey  string
	}{
		{name: "no linking", profile: providers.AttributeConfiguration{}},
		{
			name: "mapped attribute",
			profile: providers.AttributeConfiguration{
				AccountLinking: linkingOn("email"),
				UserTypeAttributeMappings: []providers.UserTypeAttributeMapping{{UserType: "person",
					Attributes: []providers.AttributeMapping{
						{ExternalAttribute: "email", LocalAttribute: "username"}}}},
			},
		},
		{
			name: "local attribute another claim feeds",
			profile: providers.AttributeConfiguration{
				AccountLinking: linkingOn("costCenter"),
				UserTypeAttributeMappings: []providers.UserTypeAttributeMapping{{UserType: "person",
					Attributes: []providers.AttributeMapping{
						{ExternalAttribute: "cost_code", LocalAttribute: "costCenter"}}}},
			},
		},
		{
			name:    "empty attribute",
			profile: providers.AttributeConfiguration{AccountLinking: linkingOn(" ")},
			errKey:  "error.idpservice.attribute_configuration_linking_empty_description",
		},
		{
			name:    "reserved attribute",
			profile: providers.AttributeConfiguration{AccountLinking: linkingOn("userID")},
			errKey:  "error.idpservice.attribute_configuration_linking_reserved_description",
		},
		{
			name: "unqueryable name mapped for every user type",
			profile: providers.AttributeConfiguration{
				AccountLinking: linkingOn("custom:email"),
				UserTypeAttributeMappings: []providers.UserTypeAttributeMapping{
					{UserType: "person", Attributes: []providers.AttributeMapping{
						{ExternalAttribute: "custom:email", LocalAttribute: "email"}}},
					{UserType: "staff", Attributes: []providers.AttributeMapping{
						{ExternalAttribute: "custom:email", LocalAttribute: "workEmail"}}},
				},
			},
		},
		{
			name:    "unqueryable name with no mappings",
			profile: providers.AttributeConfiguration{AccountLinking: linkingOn("email.work")},
			errKey:  "error.idpservice.attribute_configuration_linking_unmatchable_description",
		},
		{
			name: "unqueryable name unmapped for one user type",
			profile: providers.AttributeConfiguration{
				AccountLinking: linkingOn("cost-center"),
				UserTypeAttributeMappings: []providers.UserTypeAttributeMapping{
					{UserType: "person", Attributes: []providers.AttributeMapping{
						{ExternalAttribute: "cost-center", LocalAttribute: "costCenter"}}},
					{UserType: "staff", Attributes: []providers.AttributeMapping{
						{ExternalAttribute: "email", LocalAttribute: "email"}}},
				},
			},
			errKey: "error.idpservice.attribute_configuration_linking_unmatchable_description",
		},
		{
			name: "mapped onto a reserved attribute",
			profile: providers.AttributeConfiguration{
				AccountLinking: linkingOn("email"),
				UserTypeAttributeMappings: []providers.UserTypeAttributeMapping{{UserType: "person",
					Attributes: []providers.AttributeMapping{
						{ExternalAttribute: "email", LocalAttribute: "linkedIds.x"}}}},
			},
			errKey: "error.idpservice.attribute_configuration_linking_reserved_description",
		},
		{
			// email and phone match on three local attributes each: 3 x 3 = 9 lookups.
			name: "lookups within the bound",
			profile: providers.AttributeConfiguration{
				AccountLinking: linkingOn("email", "phone"),
				UserTypeAttributeMappings: []providers.UserTypeAttributeMapping{{UserType: "person",
					Attributes: []providers.AttributeMapping{
						{ExternalAttribute: "email", LocalAttribute: "username"},
						{ExternalAttribute: "email", LocalAttribute: "workEmail"},
						{ExternalAttribute: "phone", LocalAttribute: "mobile"},
						{ExternalAttribute: "phone", LocalAttribute: "workPhone"}}}},
			},
		},
		{
			// Adding a third such attribute makes it 27 lookups for staff.
			name: "lookups past the bound for one user type",
			profile: providers.AttributeConfiguration{
				AccountLinking: linkingOn("email", "phone", "employeeId"),
				UserTypeAttributeMappings: []providers.UserTypeAttributeMapping{
					{UserType: "person", Attributes: []providers.AttributeMapping{
						{ExternalAttribute: "email", LocalAttribute: "username"}}},
					{UserType: "staff", Attributes: []providers.AttributeMapping{
						{ExternalAttribute: "email", LocalAttribute: "username"},
						{ExternalAttribute: "email", LocalAttribute: "workEmail"},
						{ExternalAttribute: "phone", LocalAttribute: "mobile"},
						{ExternalAttribute: "phone", LocalAttribute: "workPhone"},
						{ExternalAttribute: "employeeId", LocalAttribute: "staffId"},
						{ExternalAttribute: "employeeId", LocalAttribute: "badgeId"}}},
				},
			},
			errKey: "error.idpservice.attribute_configuration_linking_too_many_lookups_description",
		},
	}
	for _, tc := range cases {
		s.Run(tc.name, func() {
			svcErr := validateAccountLinking(&tc.profile)
			if tc.errKey == "" {
				s.Nil(svcErr)
				return
			}
			s.Require().NotNil(svcErr)
			s.Equal(ErrorInvalidAttributeConfiguration.Code, svcErr.Code)
			s.Equal(tc.errKey, svcErr.ErrorDescription.Key)
		})
	}
}
