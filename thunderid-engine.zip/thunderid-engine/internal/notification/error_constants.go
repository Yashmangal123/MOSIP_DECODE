// Copyright 2025 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package notification

import (
	"errors"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"
)

// Client errors for notification sender operations.
var (
	// ErrorSenderNotFound is the error returned when a notification sender is not found.
	ErrorSenderNotFound = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1001",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.sender_not_found",
			DefaultValue: "Sender not found",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.sender_not_found_description",
			DefaultValue: "The requested notification sender could not be found",
		},
	}
	// ErrorInvalidSenderID is the error returned when an invalid sender ID is provided.
	ErrorInvalidSenderID = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1002",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_sender_id",
			DefaultValue: "Invalid sender ID",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_sender_id_description",
			DefaultValue: "The provided sender ID is invalid",
		},
	}
	// ErrorInvalidSenderName is the error returned when an invalid sender name is provided.
	ErrorInvalidSenderName = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1003",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_sender_name",
			DefaultValue: "Invalid sender name",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_sender_name_description",
			DefaultValue: "The provided sender name is invalid",
		},
	}
	// ErrorInvalidProvider is the error returned when an invalid provider is specified.
	ErrorInvalidProvider = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1004",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_notification_provider",
			DefaultValue: "Invalid notification provider",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_notification_provider_description",
			DefaultValue: "The specified notification provider is invalid or unsupported",
		},
	}
	// ErrorDuplicateSenderName is the error returned when a sender with the same name already exists.
	ErrorDuplicateSenderName = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1005",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.duplicate_sender_name",
			DefaultValue: "Duplicate sender name",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.duplicate_sender_name_description",
			DefaultValue: "A sender with the same name already exists",
		},
	}
	// ErrorInvalidRequestFormat is the error returned when the request format is invalid.
	ErrorInvalidRequestFormat = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1006",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_request_format",
			DefaultValue: "Invalid request format",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_request_format_description",
			DefaultValue: "The request body is malformed or contains invalid data",
		},
	}
	// ErrorInvalidSenderType is the error returned when an invalid sender type is provided.
	ErrorInvalidSenderType = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1007",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_sender_type",
			DefaultValue: "Invalid sender type",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_sender_type_description",
			DefaultValue: "The provided sender type is invalid or unsupported",
		},
	}
	// ErrorSenderTypeUpdateNotAllowed is the error when trying to update the sender type.
	ErrorSenderTypeUpdateNotAllowed = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1008",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.update_not_allowed",
			DefaultValue: "Update not allowed",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.update_not_allowed_description",
			DefaultValue: "Updating the sender type is not allowed",
		},
	}
	// ErrorRequestedSenderIsNotOfExpectedType is the error when the requested sender is not of the expected type.
	ErrorRequestedSenderIsNotOfExpectedType = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1009",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.sender_type_mismatch",
			DefaultValue: "Sender type mismatch",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.sender_type_mismatch_description",
			DefaultValue: "The requested sender is not of the expected type",
		},
	}
	// ErrorInvalidRecipient is the error returned when an invalid recipient is provided.
	ErrorInvalidRecipient = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1010",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_recipient",
			DefaultValue: "Invalid recipient",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_recipient_description",
			DefaultValue: "The provided recipient is invalid",
		},
	}
	// ErrorUnsupportedChannel is the error returned when an unsupported channel is provided.
	ErrorUnsupportedChannel = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1012",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.unsupported_channel",
			DefaultValue: "Unsupported channel",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.unsupported_channel_description",
			DefaultValue: "The provided channel is not supported",
		},
	}
	// ErrorInvalidOTP is the error returned when an invalid OTP is provided.
	ErrorInvalidOTP = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1013",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_otp",
			DefaultValue: "Invalid OTP",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_otp_description",
			DefaultValue: "The provided OTP is invalid",
		},
	}
	// ErrorInvalidSessionToken is the error returned when an invalid session token is provided.
	ErrorInvalidSessionToken = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1014",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_session_token",
			DefaultValue: "Invalid session token",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_session_token_description",
			DefaultValue: "The provided session token is invalid, malformed, or expired",
		},
	}
	// ErrorSenderHasBlockingDependencies is returned when a notification sender cannot be deleted
	// because other resources depend on it in a way that forbids deletion (e.g. flows that reference it).
	ErrorSenderHasBlockingDependencies = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1016",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.sender_has_blocking_dependencies",
			DefaultValue: "Notification sender cannot be deleted",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.notificationservice.sender_has_blocking_dependencies_description",
			DefaultValue: "The notification sender cannot be deleted because other resources depend on it. " +
				"Remove or reassign them first.",
		},
	}
	// ErrorEmailSenderNotSpecified is the error returned when an email is dispatched without
	// naming a provider. Email providers are managed as connections and selected per flow node;
	// there is no deployment-wide default.
	ErrorEmailSenderNotSpecified = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1017",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.email_sender_not_specified",
			DefaultValue: "Email provider not specified",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.notificationservice.email_sender_not_specified_description",
			DefaultValue: "An email provider must be selected. Create an email provider connection " +
				"and select it on the flow node.",
		},
	}
	// ErrorInvalidSenderOU is the error returned when the organization unit given for a notification sender does not
	// exist.
	ErrorInvalidSenderOU = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1018",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_sender_ou",
			DefaultValue: "Invalid organization unit",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.invalid_sender_ou_description",
			DefaultValue: "The organization unit given for the notification sender does not exist",
		},
	}
	// ErrorSenderOUUpdateNotAllowed is the error returned when attempting to change the organization unit of a
	// notification sender.
	ErrorSenderOUUpdateNotAllowed = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1019",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.sender_ou_update_not_allowed",
			DefaultValue: "Organization unit update not allowed",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.sender_ou_update_not_allowed_description",
			DefaultValue: "The organization unit of a notification sender cannot be changed",
		},
	}
	// ErrorSenderOURequired is the error returned when a notification sender is created without an organization unit.
	ErrorSenderOURequired = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "MNS-1020",
		Error: tidcommon.I18nMessage{
			Key:          "error.notificationservice.sender_ou_required",
			DefaultValue: "Organization unit required",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.notificationservice.sender_ou_required_description",
			DefaultValue: "A notification sender needs an organization unit. Give its ouId in the request",
		},
	}
)

// Sentinel errors for validating the "notification" server-config section.
var (
	// errDeclarativeSenderLocked is returned when a declarative default sender is overridden.
	errDeclarativeSenderLocked = errors.New(
		"default email sender is set declaratively and cannot be overridden")
)
