// Copyright 2025 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

// Package notification contains the implementation of notification and otp sender services.
package notification

import (
	"context"
	"errors"
	"fmt"
	"strings"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"

	"github.com/thunder-id/thunderid/internal/notification/common"
	"github.com/thunder-id/thunderid/internal/ou"
	declarativeresource "github.com/thunder-id/thunderid/internal/system/declarative_resource"
	"github.com/thunder-id/thunderid/internal/system/log"
	"github.com/thunder-id/thunderid/internal/system/resourcedependency"
	sysutils "github.com/thunder-id/thunderid/internal/system/utils"
)

// NotificationSenderMgtSvcInterface defines the interface for managing notification senders.
type NotificationSenderMgtSvcInterface interface {
	CreateSender(ctx context.Context, sender common.NotificationSenderDTO) (*common.NotificationSenderDTO,
		*tidcommon.ServiceError)
	ListSenders(ctx context.Context) ([]common.NotificationSenderDTO, *tidcommon.ServiceError)
	ListSendersByType(ctx context.Context, senderType common.NotificationSenderType) ([]common.NotificationSenderDTO,
		*tidcommon.ServiceError)
	GetSender(ctx context.Context, id string) (*common.NotificationSenderDTO, *tidcommon.ServiceError)
	GetSenderByName(ctx context.Context, name string) (*common.NotificationSenderDTO, *tidcommon.ServiceError)
	UpdateSender(ctx context.Context, id string, sender common.NotificationSenderDTO) (*common.NotificationSenderDTO,
		*tidcommon.ServiceError)
	DeleteSender(ctx context.Context, id string) *tidcommon.ServiceError
	GetSenderUsages(ctx context.Context, id string) (*resourcedependency.DependenciesResponse,
		*tidcommon.ServiceError)
	SetDependencyRegistry(r resourcedependency.Registry)
	ResolveSenderOU(ctx context.Context, sender *common.NotificationSenderDTO) *tidcommon.ServiceError
}

// ownerErrors are the errors given when the organization unit of a notification sender is refused.
var ownerErrors = ou.OwnerErrors{
	Required: ErrorSenderOURequired,
	NotFound: ErrorInvalidSenderOU,
	Changed:  ErrorSenderOUUpdateNotAllowed,
}

// notificationSenderMgtService implements the NotificationSenderMgtSvcInterface.
type notificationSenderMgtService struct {
	notificationStore  notificationStoreInterface
	ouService          ou.OrganizationUnitServiceInterface
	transactioner      providers.Transactioner
	dependencyRegistry resourcedependency.Registry
	uuidGenerator      func() (string, error)
}

// newNotificationSenderMgtService returns a new instance of NotificationSenderMgtSvcInterface.
func newNotificationSenderMgtService(
	store notificationStoreInterface, tx providers.Transactioner,
	ouService ou.OrganizationUnitServiceInterface) NotificationSenderMgtSvcInterface {
	return &notificationSenderMgtService{
		notificationStore: store,
		ouService:         ouService,
		transactioner:     tx,
		uuidGenerator:     sysutils.GenerateUUIDv7,
	}
}

// CreateSender creates a new notification sender.
func (s *notificationSenderMgtService) CreateSender(
	ctx context.Context, sender common.NotificationSenderDTO) (
	*common.NotificationSenderDTO, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, "NotificationSenderMgtService"))
	logger.Debug(ctx, "Creating notification sender", log.String("name", sender.Name))

	if err := declarativeresource.CheckDeclarativeCreate(); err != nil {
		return nil, err
	}

	if err := validateNotificationSender(sender); err != nil {
		return nil, err
	}
	if svcErr := s.ResolveSenderOU(ctx, &sender); svcErr != nil {
		return nil, svcErr
	}

	applyDefaultSenderProperties(&sender)

	if sender.ID == "" {
		id, err := s.uuidGenerator()
		if err != nil {
			logger.Error(ctx, "Failed to generate UUID", log.Error(err))
			return nil, &tidcommon.InternalServerError
		}
		sender.ID = id
	}

	var svcErr *tidcommon.ServiceError
	transactErr := s.transactioner.Transact(ctx, func(txCtx context.Context) error {
		// Check if sender with same name already exists
		senderRetv, err := s.notificationStore.getSenderByName(txCtx, sender.Name)
		if err != nil {
			return err
		}
		if senderRetv != nil {
			logger.Debug(ctx, "Notification sender already exists", log.String("name", sender.Name),
				log.String("id", senderRetv.ID))
			svcErr = &ErrorDuplicateSenderName
			return errors.New("sender already exists")
		}

		// Create the sender
		err = s.notificationStore.createSender(txCtx, sender)
		if err != nil {
			return err
		}
		return nil
	})

	if svcErr != nil {
		return nil, svcErr
	}
	if transactErr != nil {
		logger.Error(ctx, "Failed to create notification sender",
			log.Error(transactErr), log.String("name", sender.Name))
		return nil, &tidcommon.InternalServerError
	}

	return &common.NotificationSenderDTO{
		ID:          sender.ID,
		Name:        sender.Name,
		Description: sender.Description,
		Type:        sender.Type,
		OUID:        sender.OUID,
		Provider:    sender.Provider,
		Properties:  sender.Properties,
	}, nil
}

// ResolveSenderOU sets the organization unit a notification sender is owned by. The owner is named by id or by handle,
// and a handle is resolved to the id of the unit it names; when both are given the id wins. A sender has to name an
// organization unit, and it has to exist.
func (s *notificationSenderMgtService) ResolveSenderOU(
	ctx context.Context, sender *common.NotificationSenderDTO) *tidcommon.ServiceError {
	ouID, svcErr := s.ouService.ResolveOwner(ctx, sender.OUID, sender.OUHandle, ownerErrors)
	if svcErr != nil {
		return svcErr
	}
	sender.OUID = ouID
	return nil
}

// ListSenders retrieves all notification senders.
func (s *notificationSenderMgtService) ListSenders(ctx context.Context) ([]common.NotificationSenderDTO,
	*tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, "NotificationSenderMgtService"))
	logger.Debug(ctx, "Listing all notification senders")

	senders, err := s.notificationStore.listSenders(ctx)
	if err != nil {
		logger.Error(ctx, "Failed to list notification senders", log.Error(err))
		return nil, &tidcommon.InternalServerError
	}

	return senders, nil
}

// ListSendersByType retrieves all notification senders of the given type (e.g. only
// message/SMS senders, excluding email senders).
func (s *notificationSenderMgtService) ListSendersByType(
	ctx context.Context, senderType common.NotificationSenderType,
) ([]common.NotificationSenderDTO, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, "NotificationSenderMgtService"))
	logger.Debug(ctx, "Listing notification senders by type", log.String("type", string(senderType)))

	senders, err := s.notificationStore.listSendersByType(ctx, senderType)
	if err != nil {
		logger.Error(ctx, "Failed to list notification senders by type", log.Error(err))
		return nil, &tidcommon.InternalServerError
	}

	return senders, nil
}

// GetSender retrieves a notification sender by ID.
func (s *notificationSenderMgtService) GetSender(ctx context.Context, id string) (*common.NotificationSenderDTO,
	*tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, "NotificationSenderMgtService"))
	logger.Debug(ctx, "Retrieving notification sender", log.String("id", id))

	if id == "" {
		return nil, &ErrorInvalidSenderID
	}

	sender, err := s.notificationStore.getSenderByID(ctx, id)
	if err != nil {
		logger.Error(ctx, "Failed to retrieve notification sender", log.String("id", id), log.Error(err))
		return nil, &tidcommon.InternalServerError
	}

	if sender == nil {
		return nil, &ErrorSenderNotFound
	}

	return sender, nil
}

// GetSenderByName retrieves a notification sender by name.
func (s *notificationSenderMgtService) GetSenderByName(ctx context.Context, name string) (*common.NotificationSenderDTO,
	*tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, "NotificationSenderMgtService"))
	logger.Debug(ctx, "Retrieving notification sender by name", log.String("name", name))

	if name == "" {
		return nil, &ErrorInvalidSenderName
	}

	sender, err := s.notificationStore.getSenderByName(ctx, name)
	if err != nil {
		logger.Error(ctx, "Failed to retrieve notification sender", log.String("name", name), log.Error(err))
		return nil, &tidcommon.InternalServerError
	}

	if sender == nil {
		return nil, &ErrorSenderNotFound
	}

	return sender, nil
}

// UpdateSender updates an existing notification sender
func (s *notificationSenderMgtService) UpdateSender(ctx context.Context, id string,
	sender common.NotificationSenderDTO) (*common.NotificationSenderDTO, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, "NotificationSenderMgtService"))
	logger.Debug(ctx, "Updating notification sender", log.String("id", id), log.String("name", sender.Name))

	if err := declarativeresource.CheckDeclarativeUpdate(); err != nil {
		return nil, err
	}

	if id == "" {
		return nil, &ErrorInvalidSenderID
	}
	if err := validateNotificationSender(sender); err != nil {
		return nil, err
	}

	applyDefaultSenderProperties(&sender)

	var svcErr *tidcommon.ServiceError
	transactErr := s.transactioner.Transact(ctx, func(txCtx context.Context) error {
		// Check if sender exists
		senderRetv, err := s.notificationStore.getSenderByID(txCtx, id)
		if err != nil {
			return err
		}
		if senderRetv == nil {
			logger.Debug(ctx, "Notification sender not found", log.String("id", id))
			svcErr = &ErrorSenderNotFound
			return errors.New("sender not found")
		}

		// If the name is being updated, check for duplicates
		if sender.Name != senderRetv.Name {
			senderWithUpdatedName, err := s.notificationStore.getSenderByName(txCtx, sender.Name)
			if err != nil {
				return err
			}
			if senderWithUpdatedName != nil && senderWithUpdatedName.ID != id {
				logger.Debug(ctx, "Another sender with the same name already exists",
					log.String("name", sender.Name), log.String("existingID", senderWithUpdatedName.ID))
				svcErr = &ErrorDuplicateSenderName
				return errors.New("duplicate name")
			}
		}

		// An owner cannot change. Leaving it out keeps the one the sender has.
		ouID, ouErr := s.ouService.ResolveOwnerForUpdate(
			txCtx, sender.OUID, sender.OUHandle, senderRetv.OUID, ownerErrors)
		if ouErr != nil {
			svcErr = ouErr
			return errors.New("organization unit of a notification sender cannot be resolved")
		}
		sender.OUID = ouID

		// Ensure the type is not changed
		if sender.Type != senderRetv.Type {
			logger.Debug(ctx, "Attempting to change sender type", log.String("id", id),
				log.String("originalType", string(senderRetv.Type)), log.String("newType", string(sender.Type)))
			svcErr = &ErrorSenderTypeUpdateNotAllowed
			return errors.New("cannot change type")
		}

		// Update the sender
		if err := s.notificationStore.updateSender(txCtx, id, sender); err != nil {
			return err
		}

		return nil
	})

	if svcErr != nil {
		return nil, svcErr
	}
	if transactErr != nil {
		logger.Error(ctx, "Failed to update notification sender",
			log.Error(transactErr), log.String("id", id))
		return nil, &tidcommon.InternalServerError
	}

	return &common.NotificationSenderDTO{
		ID:          id,
		Name:        sender.Name,
		Description: sender.Description,
		Type:        sender.Type,
		OUID:        sender.OUID,
		Provider:    sender.Provider,
		Properties:  sender.Properties,
	}, nil
}

// DeleteSender deletes a notification sender
func (s *notificationSenderMgtService) DeleteSender(ctx context.Context, id string) *tidcommon.ServiceError {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, "NotificationSenderMgtService"))
	logger.Debug(ctx, "Deleting notification sender", log.String("id", id))

	if err := declarativeresource.CheckDeclarativeDelete(); err != nil {
		return err
	}

	if id == "" {
		return &ErrorInvalidSenderID
	}

	// Refuse deletion while other resources block it (e.g. flows that reference the sender).
	if svcErr := s.ensureNoBlockingDependencies(ctx, id, logger); svcErr != nil {
		return svcErr
	}

	transactErr := s.transactioner.Transact(ctx, func(txCtx context.Context) error {
		if err := s.notificationStore.deleteSender(txCtx, id); err != nil {
			return err
		}
		return nil
	})

	if transactErr != nil {
		logger.Error(ctx, "Failed to delete notification sender",
			log.Error(transactErr), log.String("id", id))
		return &tidcommon.InternalServerError
	}

	return nil
}

// SetDependencyRegistry injects the dependency registry. Called by servicemanager after the
// provider services are initialized to avoid a cyclic import.
func (s *notificationSenderMgtService) SetDependencyRegistry(r resourcedependency.Registry) {
	s.dependencyRegistry = r
}

// GetSenderUsages returns the resources that reference this notification sender, such as flows that
// use it. It is informational — it drives the pre-delete confirmation dialog and does not gate
// deletion on the server (deletion is gated separately by ensureNoBlockingDependencies).
func (s *notificationSenderMgtService) GetSenderUsages(
	ctx context.Context, id string,
) (*resourcedependency.DependenciesResponse, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, "NotificationSenderMgtService"))

	if strings.TrimSpace(id) == "" {
		return nil, &ErrorInvalidSenderID
	}

	sender, err := s.notificationStore.getSenderByID(ctx, id)
	if err != nil {
		logger.Error(ctx, "Failed to retrieve notification sender", log.String("id", id), log.Error(err))
		return nil, &tidcommon.InternalServerError
	}
	if sender == nil {
		return nil, &ErrorSenderNotFound
	}

	if s.dependencyRegistry == nil {
		logger.Warn(ctx, "Dependency registry not set; returning unknown dependencies", log.String("id", id))
		return &resourcedependency.DependenciesResponse{
			TotalResults: nil,
			Count:        0,
			Summary:      nil,
			Usages:       []resourcedependency.ResourceDependency{},
		}, nil
	}

	result, depErr := s.dependencyRegistry.GetDependencies(
		ctx, resourcedependency.ResourceTypeNotificationSender, id)
	if depErr != nil {
		logger.Error(ctx, "Failed to get notification sender usages", log.Error(depErr), log.String("id", id))
		return nil, &tidcommon.InternalServerError
	}

	return result, nil
}

// ensureNoBlockingDependencies refuses deletion when other resources depend on the notification
// sender in a way that forbids it (behaviorOnDelete == restrict), such as flows that reference it.
// Because deletion is destructive, it fails closed: if dependency data cannot be determined, the
// deletion is refused rather than allowed.
func (s *notificationSenderMgtService) ensureNoBlockingDependencies(
	ctx context.Context, id string, logger *log.Logger) *tidcommon.ServiceError {
	if s.dependencyRegistry == nil {
		logger.Error(ctx, "Dependency registry not set; refusing to delete notification sender",
			log.String("id", id))
		return &tidcommon.InternalServerError
	}

	deps, err := s.dependencyRegistry.GetDependencies(ctx, resourcedependency.ResourceTypeNotificationSender, id)
	if err != nil {
		logger.Error(ctx, "Failed to evaluate notification sender dependencies",
			log.Error(err), log.String("id", id))
		return &tidcommon.InternalServerError
	}
	// Fail closed: nil TotalResults means a provider failed to report, so usage is unknown.
	if deps == nil || deps.TotalResults == nil {
		logger.Error(ctx, "Notification sender dependency data unavailable; refusing to delete",
			log.String("id", id))
		return &tidcommon.InternalServerError
	}

	blocking := resourcedependency.BlockingUsages(deps)
	if len(blocking) == 0 {
		return nil
	}

	logger.Debug(ctx, "Notification sender has blocking dependencies; deletion refused",
		log.String("id", id), log.Int("blockingCount", len(blocking)))
	return tidcommon.CustomServiceError(ErrorSenderHasBlockingDependencies, tidcommon.I18nMessage{
		Key: "error.notificationservice.sender_has_blocking_dependencies_description",
		DefaultValue: fmt.Sprintf(
			"The notification sender cannot be deleted because %s depend on it. Remove or reassign them first.",
			resourcedependency.SummarizeBlockingUsages(blocking)),
	})
}
