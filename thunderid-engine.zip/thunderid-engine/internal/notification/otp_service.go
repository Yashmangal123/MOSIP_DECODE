// Copyright 2025 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package notification

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"fmt"
	"math/big"
	"strings"
	"time"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"

	"github.com/thunder-id/thunderid/internal/notification/common"
	notificationconfig "github.com/thunder-id/thunderid/internal/notification/config"
	"github.com/thunder-id/thunderid/internal/system/config"
	"github.com/thunder-id/thunderid/internal/system/cryptolib"
	"github.com/thunder-id/thunderid/internal/system/jose/jwt"
	"github.com/thunder-id/thunderid/internal/system/log"
)

const otpSessionAudience = "otp-svc"

// otpSessionData holds the data encoded in the OTP session JWT.
// JSON field names match those used by authn/otp for session token compatibility.
type otpSessionData struct {
	Recipient     string `json:"recipient"`
	RecipientAttr string `json:"recipientAttr,omitempty"`
	OTPValue      string `json:"otp_value"`
	ExpiryTime    int64  `json:"expiry_time"`
}

// generatedOTP holds the raw OTP value and its expiry timestamp.
type generatedOTP struct {
	Value              string
	ExpiryTimeInMillis int64
}

// OTPServiceInterface defines the interface for OTP operations.
type OTPServiceInterface interface {
	GenerateOTP(ctx context.Context, recipient, recipientAttr string, otpCfg *common.OTPConfig) (
		sessionToken string, otpValue string, expirySeconds int64, svcErr *tidcommon.ServiceError)
	VerifyOTP(ctx context.Context, request common.VerifyOTPDTO) (
		*common.VerifyOTPResultDTO, *tidcommon.ServiceError)
}

// otpService implements the OTPServiceInterface.
type otpService struct {
	logger     *log.Logger
	jwtService jwt.JWTServiceInterface
	cfg        notificationconfig.Config
}

// newOTPService returns a new instance of OTPServiceInterface.
func newOTPService(jwtSvc jwt.JWTServiceInterface, cfg notificationconfig.Config) OTPServiceInterface {
	return &otpService{
		logger:     log.GetLogger().With(log.String(log.LoggerKeyComponentName, "OTPService")),
		jwtService: jwtSvc,
		cfg:        cfg,
	}
}

// GenerateOTP generates an OTP and session token for the recipient without delivering it.
// An optional otpCfg overrides the configured OTP defaults (pass nil to use defaults).
func (s *otpService) GenerateOTP(ctx context.Context, recipient, recipientAttr string, otpCfg *common.OTPConfig) (
	string, string, int64, *tidcommon.ServiceError) {
	logger := s.logger

	recipient = strings.TrimSpace(recipient)
	if recipient == "" {
		return "", "", 0, &ErrorInvalidRecipient
	}

	otp, err := s.generateOTP(otpCfg)
	if err != nil {
		logger.Error(ctx, "Failed to generate OTP", log.Error(err))
		return "", "", 0, &tidcommon.InternalServerError
	}

	sessionData := otpSessionData{
		Recipient:     recipient,
		RecipientAttr: recipientAttr,
		OTPValue:      cryptolib.GenerateThumbprintFromString(otp.Value),
		ExpiryTime:    otp.ExpiryTimeInMillis,
	}

	sessionToken, err := s.createSessionToken(ctx, sessionData)
	if err != nil {
		logger.Error(ctx, "Failed to create OTP session token", log.Error(err))
		return "", "", 0, &tidcommon.InternalServerError
	}

	expirySeconds := s.getOTPValidityPeriodInMillis(otpCfg) / 1000
	logger.Debug(ctx, "OTP generated successfully", log.MaskedString("recipient", recipient))
	return sessionToken, otp.Value, expirySeconds, nil
}

// VerifyOTP verifies the provided OTP against the session token.
func (s *otpService) VerifyOTP(
	ctx context.Context, otpDTO common.VerifyOTPDTO) (*common.VerifyOTPResultDTO, *tidcommon.ServiceError) {
	logger := s.logger
	logger.Debug(ctx, "Verifying OTP")

	if err := s.validateOTPVerifyRequest(otpDTO); err != nil {
		return nil, err
	}

	sessionData, svcErr := s.verifyAndDecodeSessionToken(ctx, otpDTO.SessionToken, logger)
	if svcErr != nil {
		return nil, svcErr
	}

	if time.Now().UnixMilli() > sessionData.ExpiryTime {
		logger.Debug(ctx, "OTP has expired")
		return &common.VerifyOTPResultDTO{
			Status:        common.OTPVerifyStatusExpired,
			Recipient:     sessionData.Recipient,
			RecipientAttr: sessionData.RecipientAttr,
		}, nil
	}

	if cryptolib.GenerateThumbprintFromString(otpDTO.OTPCode) != sessionData.OTPValue {
		logger.Debug(ctx, "Invalid OTP provided")
		return &common.VerifyOTPResultDTO{
			Status:        common.OTPVerifyStatusInvalid,
			Recipient:     sessionData.Recipient,
			RecipientAttr: sessionData.RecipientAttr,
		}, nil
	}

	return &common.VerifyOTPResultDTO{
		Status:        common.OTPVerifyStatusVerified,
		Recipient:     sessionData.Recipient,
		RecipientAttr: sessionData.RecipientAttr,
	}, nil
}

// validateOTPVerifyRequest validates the OTP verify request.
func (s *otpService) validateOTPVerifyRequest(request common.VerifyOTPDTO) *tidcommon.ServiceError {
	if request.SessionToken == "" {
		return &ErrorInvalidSessionToken
	}
	if request.OTPCode == "" {
		return &ErrorInvalidOTP
	}
	return nil
}

// generateOTP generates a random OTP value based on server configuration.
// An optional otpCfg override can override specific fields (length, numeric-only, validity).
func (s *otpService) generateOTP(otpCfg *common.OTPConfig) (generatedOTP, error) {
	mergedCfg := s.resolveOTPConfig(otpCfg)
	charSet := s.getOTPCharset(mergedCfg.UsesNumericOnly())
	length := mergedCfg.Length

	chars := []rune(charSet)
	result := make([]rune, length)
	for i := 0; i < length; i++ {
		n, err := rand.Int(rand.Reader, big.NewInt(int64(len(chars))))
		if err != nil {
			return generatedOTP{}, fmt.Errorf("failed to generate random number: %w", err)
		}
		result[i] = chars[n.Int64()]
	}

	now := time.Now().UnixMilli()
	validity := int64(mergedCfg.ValidityPeriodSeconds) * 1000
	return generatedOTP{
		Value:              string(result),
		ExpiryTimeInMillis: now + validity,
	}, nil
}

// createSessionToken creates a JWT containing the OTP session data.
func (s *otpService) createSessionToken(ctx context.Context, sessionData otpSessionData) (string, error) {
	claims := map[string]interface{}{
		"otp_data": sessionData,
		"aud":      otpSessionAudience,
	}
	validitySeconds := (sessionData.ExpiryTime - time.Now().UnixMilli()) / 1000
	jwtConfig := s.cfg.JWT

	token, _, err := s.jwtService.GenerateJWT(
		ctx, otpSessionAudience, jwtConfig.Issuer, validitySeconds, claims, jwt.TokenTypeJWT, "")
	if err != nil {
		return "", fmt.Errorf("failed to generate JWT token: %v", err)
	}
	return token, nil
}

// verifyAndDecodeSessionToken verifies the JWT signature and decodes the embedded OTP session data.
func (s *otpService) verifyAndDecodeSessionToken(ctx context.Context, token string,
	logger *log.Logger) (*otpSessionData, *tidcommon.ServiceError) {
	jwtConfig := s.cfg.JWT
	if svcErr := s.jwtService.VerifyJWT(ctx, token, otpSessionAudience, jwtConfig.Issuer); svcErr != nil {
		logger.Debug(ctx, "Invalid OTP session token", log.String("error", svcErr.Error.DefaultValue))
		return nil, &ErrorInvalidSessionToken
	}

	payload, err := jwt.DecodeJWTPayload(token)
	if err != nil {
		return nil, &ErrorInvalidSessionToken
	}

	otpDataClaim, ok := payload["otp_data"]
	if !ok {
		return nil, &ErrorInvalidSessionToken
	}

	otpDataBytes, err := json.Marshal(otpDataClaim)
	if err != nil {
		return nil, &ErrorInvalidSessionToken
	}

	var sessionData otpSessionData
	if err := json.Unmarshal(otpDataBytes, &sessionData); err != nil {
		return nil, &ErrorInvalidSessionToken
	}

	return &sessionData, nil
}

// resolveOTPConfig returns the effective OTP configuration for this otpService.
// An optional override replaces specific configured fields (pass nil to use defaults).
func (s *otpService) resolveOTPConfig(otpCfg *common.OTPConfig) config.OTPConfig {
	cfg := s.cfg.OTP

	if otpCfg == nil {
		return cfg
	}

	if otpCfg.Length != nil {
		if *otpCfg.Length >= 4 && *otpCfg.Length <= 10 {
			cfg.Length = *otpCfg.Length
		}
	}
	if otpCfg.UseNumericOnly != nil {
		cfg.UseNumericOnly = otpCfg.UseNumericOnly
	}
	if otpCfg.ValidityPeriodSeconds != nil {
		if *otpCfg.ValidityPeriodSeconds >= 30 && *otpCfg.ValidityPeriodSeconds <= 600 {
			cfg.ValidityPeriodSeconds = *otpCfg.ValidityPeriodSeconds
		}
	}

	return cfg
}

// getOTPCharset returns the character set for OTP generation.
func (s *otpService) getOTPCharset(useNumericOnly bool) string {
	if useNumericOnly {
		return "9245378016"
	}
	return "KIGXHOYSPRWCEFMVUQLZDNABJT9245378016"
}

// getOTPValidityPeriodInMillis returns the OTP validity period in milliseconds.
func (s *otpService) getOTPValidityPeriodInMillis(otpCfg *common.OTPConfig) int64 {
	mergedCfg := s.resolveOTPConfig(otpCfg)
	return int64(mergedCfg.ValidityPeriodSeconds) * 1000
}
