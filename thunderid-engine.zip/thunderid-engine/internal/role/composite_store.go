// Copyright 2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package role

import (
	"context"
	"errors"
	"fmt"
	"slices"

	serverconst "github.com/thunder-id/thunderid/internal/system/constants"
	declarativeresource "github.com/thunder-id/thunderid/internal/system/declarative_resource"
	"github.com/thunder-id/thunderid/internal/system/log"
)

// compositeRoleStore implements a composite store that combines file-based (immutable) and
// database (mutable) stores.
// - Read operations query both stores and merge results
// - Write operations (Create/Update/Delete) only affect the database store
// - Declarative roles (from YAML files) cannot be modified or deleted
type compositeRoleStore struct {
	fileStore roleStoreInterface
	dbStore   roleStoreInterface
}

// newCompositeRoleStore creates a new composite store with both file-based and database stores.
func newCompositeRoleStore(fileStore, dbStore roleStoreInterface) roleStoreInterface {
	return &compositeRoleStore{
		fileStore: fileStore,
		dbStore:   dbStore,
	}
}

// GetRoleListCount retrieves the total count of unique roles across both stores.
func (c *compositeRoleStore) GetRoleListCount(ctx context.Context) (int, error) {
	capCount := func(fn func(context.Context) (int, error)) func() (int, error) {
		return func() (int, error) {
			count, err := fn(ctx)
			if err != nil {
				return 0, err
			}
			return min(count, serverconst.MaxCompositeStoreRecords), nil
		}
	}
	roles, limitExceeded, err := declarativeresource.CompositeMergeListHelperWithLimit(
		capCount(c.dbStore.GetRoleListCount),
		capCount(c.fileStore.GetRoleListCount),
		func(count int) ([]Role, error) { return c.dbStore.GetRoleList(ctx, count, 0) },
		func(count int) ([]Role, error) { return c.fileStore.GetRoleList(ctx, count, 0) },
		mergeRoles,
		serverconst.MaxCompositeStoreRecords+1,
		0,
		serverconst.MaxCompositeStoreRecords,
	)
	if err != nil {
		return 0, err
	}
	if limitExceeded {
		return 0, errResultLimitExceededInCompositeMode
	}

	return len(roles), nil
}

// GetRoleList retrieves roles from both stores and merges them.
func (c *compositeRoleStore) GetRoleList(ctx context.Context, limit, offset int) ([]Role, error) {
	capCount := func(fn func(context.Context) (int, error)) func() (int, error) {
		return func() (int, error) {
			count, err := fn(ctx)
			if err != nil {
				return 0, err
			}
			return min(count, serverconst.MaxCompositeStoreRecords), nil
		}
	}
	roles, limitExceeded, err := declarativeresource.CompositeMergeListHelperWithLimit(
		capCount(c.dbStore.GetRoleListCount),
		capCount(c.fileStore.GetRoleListCount),
		func(count int) ([]Role, error) { return c.dbStore.GetRoleList(ctx, count, 0) },
		func(count int) ([]Role, error) { return c.fileStore.GetRoleList(ctx, count, 0) },
		mergeRoles,
		limit,
		offset,
		serverconst.MaxCompositeStoreRecords,
	)
	if err != nil {
		return nil, err
	}
	if limitExceeded {
		return nil, errResultLimitExceededInCompositeMode
	}
	return roles, nil
}

// GetRoleListCountByOUID retrieves the total count of unique roles belonging to the given
// organization unit across both stores.
func (c *compositeRoleStore) GetRoleListCountByOUID(ctx context.Context, ouID string) (int, error) {
	capCount := func(fn func(context.Context, string) (int, error)) func() (int, error) {
		return func() (int, error) {
			count, err := fn(ctx, ouID)
			if err != nil {
				return 0, err
			}
			return min(count, serverconst.MaxCompositeStoreRecords), nil
		}
	}
	roles, limitExceeded, err := declarativeresource.CompositeMergeListHelperWithLimit(
		capCount(c.dbStore.GetRoleListCountByOUID),
		capCount(c.fileStore.GetRoleListCountByOUID),
		func(count int) ([]Role, error) { return c.dbStore.GetRoleListByOUID(ctx, ouID, count, 0) },
		func(count int) ([]Role, error) { return c.fileStore.GetRoleListByOUID(ctx, ouID, count, 0) },
		mergeRoles,
		serverconst.MaxCompositeStoreRecords+1,
		0,
		serverconst.MaxCompositeStoreRecords,
	)
	if err != nil {
		return 0, err
	}
	if limitExceeded {
		return 0, errResultLimitExceededInCompositeMode
	}

	return len(roles), nil
}

// GetRoleListByOUID retrieves roles belonging to the given organization unit from both stores
// and merges them.
func (c *compositeRoleStore) GetRoleListByOUID(
	ctx context.Context, ouID string, limit, offset int,
) ([]Role, error) {
	capCount := func(fn func(context.Context, string) (int, error)) func() (int, error) {
		return func() (int, error) {
			count, err := fn(ctx, ouID)
			if err != nil {
				return 0, err
			}
			return min(count, serverconst.MaxCompositeStoreRecords), nil
		}
	}
	roles, limitExceeded, err := declarativeresource.CompositeMergeListHelperWithLimit(
		capCount(c.dbStore.GetRoleListCountByOUID),
		capCount(c.fileStore.GetRoleListCountByOUID),
		func(count int) ([]Role, error) { return c.dbStore.GetRoleListByOUID(ctx, ouID, count, 0) },
		func(count int) ([]Role, error) { return c.fileStore.GetRoleListByOUID(ctx, ouID, count, 0) },
		mergeRoles,
		limit,
		offset,
		serverconst.MaxCompositeStoreRecords,
	)
	if err != nil {
		return nil, err
	}
	if limitExceeded {
		return nil, errResultLimitExceededInCompositeMode
	}
	return roles, nil
}

// CreateRole creates a new role in the database store only.
func (c *compositeRoleStore) CreateRole(ctx context.Context, id string, role RoleCreationDetail) error {
	return c.dbStore.CreateRole(ctx, id, role)
}

// GetRole retrieves a role from either store.
// Checks database store first, then falls back to file store.
func (c *compositeRoleStore) GetRole(ctx context.Context, id string) (RoleWithPermissions, error) {
	role, err := declarativeresource.CompositeGetHelper(
		func() (*RoleWithPermissions, error) {
			r, err := c.dbStore.GetRole(ctx, id)
			return &r, err
		},
		func() (*RoleWithPermissions, error) {
			r, err := c.fileStore.GetRole(ctx, id)
			return &r, err
		},
		ErrRoleNotFound,
	)
	if role != nil {
		return *role, err
	}
	return RoleWithPermissions{}, err
}

// GetRolesByNames returns roles matching the given names from both stores. Unlike an ID lookup, a
// name is not unique across organization units, so both stores are always queried in full rather than
// stopping once a name is found in one of them.
func (c *compositeRoleStore) GetRolesByNames(ctx context.Context, names []string) ([]Role, error) {
	dbRoles, err := c.dbStore.GetRolesByNames(ctx, names)
	if err != nil {
		return nil, err
	}

	fileRoles, err := c.fileStore.GetRolesByNames(ctx, names)
	if err != nil {
		return nil, err
	}

	return mergeRoles(dbRoles, fileRoles), nil
}

// GetRolesByIDs retrieves the roles with the given IDs from both stores.
func (c *compositeRoleStore) GetRolesByIDs(ctx context.Context, ids []string) ([]Role, error) {
	dbRoles, err := c.dbStore.GetRolesByIDs(ctx, ids)
	if err != nil {
		return nil, err
	}

	fileRoles, err := c.fileStore.GetRolesByIDs(ctx, ids)
	if err != nil {
		return nil, err
	}

	return mergeRoles(dbRoles, fileRoles), nil
}

// IsRoleExist checks if a role exists in either store.
func (c *compositeRoleStore) IsRoleExist(ctx context.Context, id string) (bool, error) {
	return declarativeresource.CompositeBooleanCheckHelper(
		func() (bool, error) { return c.fileStore.IsRoleExist(ctx, id) },
		func() (bool, error) { return c.dbStore.IsRoleExist(ctx, id) },
	)
}

// GetRoleAssignments retrieves role assignments from both stores.
func (c *compositeRoleStore) GetRoleAssignments(
	ctx context.Context,
	id, ouID string,
	limit, offset int,
) ([]RoleAssignment, error) {
	return c.getCompositeAssignments(ctx, id, limit, offset,
		func(ctx context.Context, id string) (int, error) {
			return c.dbStore.GetRoleAssignmentsCount(ctx, id, ouID)
		},
		func(ctx context.Context, id string) (int, error) {
			return c.fileStore.GetRoleAssignmentsCount(ctx, id, ouID)
		},
		func(count int) ([]RoleAssignment, error) {
			return c.dbStore.GetRoleAssignments(ctx, id, ouID, count, 0)
		},
		func(count int) ([]RoleAssignment, error) {
			return c.fileStore.GetRoleAssignments(ctx, id, ouID, count, 0)
		},
	)
}

// GetRoleAssignmentsByType retrieves assignments filtered by assignee type across both stores.
func (c *compositeRoleStore) GetRoleAssignmentsByType(
	ctx context.Context,
	id, ouID string,
	limit, offset int,
	assigneeType string,
) ([]RoleAssignment, error) {
	return c.getCompositeAssignments(ctx, id, limit, offset,
		func(ctx context.Context, id string) (int, error) {
			return c.dbStore.GetRoleAssignmentsCountByType(ctx, id, ouID, assigneeType)
		},
		func(ctx context.Context, id string) (int, error) {
			return c.fileStore.GetRoleAssignmentsCountByType(ctx, id, ouID, assigneeType)
		},
		func(count int) ([]RoleAssignment, error) {
			return c.dbStore.GetRoleAssignmentsByType(ctx, id, ouID, count, 0, assigneeType)
		},
		func(count int) ([]RoleAssignment, error) {
			return c.fileStore.GetRoleAssignmentsByType(ctx, id, ouID, count, 0, assigneeType)
		},
	)
}

// getCompositeAssignments is the shared logic for merging assignments from both stores.
func (c *compositeRoleStore) getCompositeAssignments(
	ctx context.Context,
	id string,
	limit, offset int,
	dbCountFn, fileCountFn func(context.Context, string) (int, error),
	dbListFn, fileListFn func(int) ([]RoleAssignment, error),
) ([]RoleAssignment, error) {
	capCount := func(fn func(context.Context, string) (int, error)) func() (int, error) {
		return func() (int, error) {
			count, err := fn(ctx, id)
			if err != nil {
				return 0, err
			}
			return min(count, serverconst.MaxCompositeStoreRecords), nil
		}
	}
	assignments, limitExceeded, err := declarativeresource.CompositeMergeListHelperWithLimit(
		capCount(dbCountFn),
		capCount(fileCountFn),
		dbListFn,
		fileListFn,
		mergeAssignments,
		limit,
		offset,
		serverconst.MaxCompositeStoreRecords,
	)
	if err != nil {
		return nil, err
	}
	if limitExceeded {
		return nil, errResultLimitExceededInCompositeMode
	}
	return assignments, nil
}

// GetRoleAssignmentsCount retrieves the count of unique role assignments across both stores.
func (c *compositeRoleStore) GetRoleAssignmentsCount(ctx context.Context, id, ouID string) (int, error) {
	return c.getCompositeAssignmentsCount(ctx, id,
		func(ctx context.Context, id string) (int, error) {
			return c.dbStore.GetRoleAssignmentsCount(ctx, id, ouID)
		},
		func(ctx context.Context, id string) (int, error) {
			return c.fileStore.GetRoleAssignmentsCount(ctx, id, ouID)
		},
		func(count int) ([]RoleAssignment, error) {
			return c.dbStore.GetRoleAssignments(ctx, id, ouID, count, 0)
		},
		func(count int) ([]RoleAssignment, error) {
			return c.fileStore.GetRoleAssignments(ctx, id, ouID, count, 0)
		},
	)
}

// GetRoleAssignmentsCountByType retrieves the count of unique role assignments filtered by type.
func (c *compositeRoleStore) GetRoleAssignmentsCountByType(
	ctx context.Context, id, ouID string, assigneeType string,
) (int, error) {
	return c.getCompositeAssignmentsCount(ctx, id,
		func(ctx context.Context, id string) (int, error) {
			return c.dbStore.GetRoleAssignmentsCountByType(ctx, id, ouID, assigneeType)
		},
		func(ctx context.Context, id string) (int, error) {
			return c.fileStore.GetRoleAssignmentsCountByType(ctx, id, ouID, assigneeType)
		},
		func(count int) ([]RoleAssignment, error) {
			return c.dbStore.GetRoleAssignmentsByType(ctx, id, ouID, count, 0, assigneeType)
		},
		func(count int) ([]RoleAssignment, error) {
			return c.fileStore.GetRoleAssignmentsByType(ctx, id, ouID, count, 0, assigneeType)
		},
	)
}

// getCompositeAssignmentsCount is the shared logic for counting merged assignments.
func (c *compositeRoleStore) getCompositeAssignmentsCount(
	ctx context.Context,
	id string,
	dbCountFn, fileCountFn func(context.Context, string) (int, error),
	dbListFn, fileListFn func(int) ([]RoleAssignment, error),
) (int, error) {
	capCount := func(fn func(context.Context, string) (int, error)) func() (int, error) {
		return func() (int, error) {
			count, err := fn(ctx, id)
			if err != nil {
				return 0, err
			}
			return min(count, serverconst.MaxCompositeStoreRecords), nil
		}
	}
	assignments, limitExceeded, err := declarativeresource.CompositeMergeListHelperWithLimit(
		capCount(dbCountFn),
		capCount(fileCountFn),
		dbListFn,
		fileListFn,
		mergeAssignments,
		serverconst.MaxCompositeStoreRecords+1,
		0,
		serverconst.MaxCompositeStoreRecords,
	)
	if err != nil {
		return 0, err
	}
	if limitExceeded {
		return 0, errResultLimitExceededInCompositeMode
	}

	count := len(assignments)
	if count > serverconst.MaxCompositeStoreRecords*9/10 {
		log.GetLogger().Warn(ctx,
			"Role assignment count approaches composite store limit; consider API pagination",
			log.String("id", id),
			log.Int("count", count),
			log.Int("limit", serverconst.MaxCompositeStoreRecords))
	}
	return count, nil
}

// UpdateRole updates a role in the database store only.
// Immutability checks are handled at the service layer.
func (c *compositeRoleStore) UpdateRole(ctx context.Context, id string, role RoleUpdateDetail) error {
	return c.dbStore.UpdateRole(ctx, id, role)
}

// DeleteRole deletes a role from the database store only.
// Immutability checks are handled at the service layer.
func (c *compositeRoleStore) DeleteRole(ctx context.Context, id string) error {
	return c.dbStore.DeleteRole(ctx, id)
}

// DeleteAssignmentsByRoleID deletes all assignments for a role from the database store only.
func (c *compositeRoleStore) DeleteAssignmentsByRoleID(ctx context.Context, id string) error {
	return c.dbStore.DeleteAssignmentsByRoleID(ctx, id)
}

// DeleteAssignmentsInOU deletes the assignments made in one organization unit from the database
// store only. A declared assignment is made in the role's owner, which never loses sight of it.
func (c *compositeRoleStore) DeleteAssignmentsInOU(ctx context.Context, id, ouID string) error {
	return c.dbStore.DeleteAssignmentsInOU(ctx, id, ouID)
}

// DeleteAssignmentsByAssignee deletes assignments for the assignee from the database store only.
func (c *compositeRoleStore) DeleteAssignmentsByAssignee(
	ctx context.Context, assigneeType, assigneeID string) (int64, error) {
	return c.dbStore.DeleteAssignmentsByAssignee(ctx, assigneeType, assigneeID)
}

// GetReferencedPermissions returns the permissions referenced by database-backed roles only.
// Declarative roles are immutable, so their permissions are never pruned.
func (c *compositeRoleStore) GetReferencedPermissions(ctx context.Context) ([]ResourcePermissions, error) {
	return c.dbStore.GetReferencedPermissions(ctx)
}

// DeleteRolePermission removes the permission from the database store only.
func (c *compositeRoleStore) DeleteRolePermission(
	ctx context.Context, resourceServerID, permission string) (int64, error) {
	return c.dbStore.DeleteRolePermission(ctx, resourceServerID, permission)
}

// AddAssignments adds assignments to a role in the database store only.
func (c *compositeRoleStore) AddAssignments(ctx context.Context, id string, assignments []RoleAssignment) error {
	return c.dbStore.AddAssignments(ctx, id, assignments)
}

// RemoveAssignments removes assignments from a role in the database store only.
func (c *compositeRoleStore) RemoveAssignments(ctx context.Context, id string, assignments []RoleAssignment) error {
	return c.dbStore.RemoveAssignments(ctx, id, assignments)
}

// CheckRoleNameExists checks if a role with the given name exists in either store.
func (c *compositeRoleStore) CheckRoleNameExists(ctx context.Context, ouID, name string) (bool, error) {
	return declarativeresource.CompositeBooleanCheckHelper(
		func() (bool, error) { return c.fileStore.CheckRoleNameExists(ctx, ouID, name) },
		func() (bool, error) { return c.dbStore.CheckRoleNameExists(ctx, ouID, name) },
	)
}

// CheckRoleNameExistsExcludingID checks if a role exists excluding a specific ID in either store.
func (c *compositeRoleStore) CheckRoleNameExistsExcludingID(
	ctx context.Context,
	ouID, name, excludeRoleID string,
) (bool, error) {
	return declarativeresource.CompositeBooleanCheckHelper(
		func() (bool, error) {
			return c.fileStore.CheckRoleNameExistsExcludingID(ctx, ouID, name, excludeRoleID)
		},
		func() (bool, error) { return c.dbStore.CheckRoleNameExistsExcludingID(ctx, ouID, name, excludeRoleID) },
	)
}

// GetAuthorizedPermissionsByResourceServer retrieves authorized permissions (scoped to a resource server when
// provided) assembled from three sources:
//
//  1. dbStore — DB-managed roles, where both ROLE_PERMISSION and ROLE_ASSIGNMENT rows exist.
//     The single SQL INNER JOIN resolves these.
//  2. fileStore (static) — declarative roles whose YAML carries an explicit `assignments:`
//     list for the entity/group. Returned by fileStore.GetAuthorizedPermissionsByResourceServer.
//  3. Cross-store (file/db) — declarative roles whose definition lives in the file store
//     but whose assignment was added at runtime via the role assignments API and therefore
//     lives in the DB. Neither store can answer this alone: dbStore drops the row in its
//     INNER JOIN against the (absent) ROLE_PERMISSION rows, and fileStore's matching only
//     consults the YAML-declared assignments. The composite resolves it by reading the
//     DB-stored role IDs for the entity, looking each role up in the file store, and
//     intersecting its permissions with the requested set.
func (c *compositeRoleStore) GetAuthorizedPermissionsByResourceServer(
	ctx context.Context,
	entityID string,
	groupIDs, roleIDs []string,
	assignmentOUID, resourceServerID string,
	requestPermissions []string,
) ([]string, error) {
	if len(requestPermissions) == 0 {
		return []string{}, nil
	}

	dbPerms, err := c.dbStore.GetAuthorizedPermissionsByResourceServer(
		ctx, entityID, groupIDs, roleIDs, assignmentOUID, resourceServerID, requestPermissions)
	if err != nil {
		return nil, err
	}

	filePerms, err := c.fileStore.GetAuthorizedPermissionsByResourceServer(
		ctx, entityID, groupIDs, roleIDs, assignmentOUID, resourceServerID, requestPermissions)
	if err != nil {
		return nil, err
	}

	// roleIDs are resolved directly, not through an entity/group assignment, so the cross-store
	// (DB assignment + file-defined role) case does not apply to them.
	crossStorePerms, err := c.crossStoreAuthorizedPermissions(
		ctx, entityID, groupIDs, assignmentOUID, resourceServerID, requestPermissions)
	if err != nil {
		return nil, err
	}

	return mergePermissions(mergePermissions(dbPerms, filePerms), crossStorePerms), nil
}

// crossStoreAuthorizedPermissions resolves permissions for the (declarative role definition
// in file store) + (runtime assignment row in DB) case. It is intentionally narrow: it skips
// any role ID that does not exist in the file store, because such roles are entirely DB-backed
// and were already covered by dbStore.GetAuthorizedPermissions.
func (c *compositeRoleStore) crossStoreAuthorizedPermissions(
	ctx context.Context,
	entityID string,
	groupIDs []string,
	assignmentOUID, resourceServerID string,
	requestPermissions []string,
) ([]string, error) {
	if entityID == "" && len(groupIDs) == 0 {
		return []string{}, nil
	}

	roleIDs, err := c.dbStore.GetEntityRoleIDs(ctx, entityID, groupIDs, assignmentOUID)
	if err != nil {
		return nil, err
	}
	if len(roleIDs) == 0 {
		return []string{}, nil
	}

	requestedSet := make(map[string]bool, len(requestPermissions))
	for _, p := range requestPermissions {
		requestedSet[p] = true
	}

	granted := make(map[string]bool)
	for _, id := range roleIDs {
		exists, err := c.fileStore.IsRoleExist(ctx, id)
		if err != nil {
			return nil, err
		}
		if !exists {
			// Role is DB-only; permissions already covered by the DB-store scoped permission lookup.
			continue
		}
		role, err := c.fileStore.GetRole(ctx, id)
		if err != nil {
			// Benign cases — skip silently:
			//   * ErrRoleNotFound: YAML was removed between assignment-time and lookup-time.
			//   * ErrRoleDataCorrupted: parse/type-assertion failure, already logged by fileStore.
			// Anything else is an actionable storage/IO error and must not be dropped:
			// authorization decisions made on a silently-empty permission set could
			// over- or under-authorize, so propagate with context.
			if errors.Is(err, ErrRoleNotFound) || errors.Is(err, ErrRoleDataCorrupted) {
				continue
			}
			log.GetLogger().Error(ctx,
				"Failed to load declarative role for cross-store permission resolution",
				log.String("roleID", id), log.Error(err))
			return nil, fmt.Errorf("composite role store: load declarative role %q: %w", id, err)
		}
		for _, rp := range role.Permissions {
			if resourceServerID != "" && rp.ResourceServerID != resourceServerID {
				continue
			}
			for _, perm := range rp.Permissions {
				if requestedSet[perm] {
					granted[perm] = true
				}
			}
		}
	}

	result := make([]string, 0, len(granted))
	for _, perm := range requestPermissions {
		if granted[perm] {
			result = append(result, perm)
		}
	}
	return result, nil
}

// GetAllPermissionsForAssignees returns every permission the entity and/or groups hold, unioned
// across the three places a role-to-assignee binding can live: a database role with a database
// assignment, a declarative role with a YAML-declared assignment, and a declarative role whose
// assignment was added at runtime. The third case is why no single store can answer this.
func (c *compositeRoleStore) GetAllPermissionsForAssignees(
	ctx context.Context, entityID string, groupIDs []string,
) ([]ResourcePermissions, error) {
	if entityID == "" && len(groupIDs) == 0 {
		return []ResourcePermissions{}, nil
	}

	dbPerms, err := c.dbStore.GetAllPermissionsForAssignees(ctx, entityID, groupIDs)
	if err != nil {
		return nil, err
	}

	filePerms, err := c.fileStore.GetAllPermissionsForAssignees(ctx, entityID, groupIDs)
	if err != nil {
		return nil, err
	}

	crossStorePerms, err := c.crossStoreAllPermissions(ctx, entityID, groupIDs)
	if err != nil {
		return nil, err
	}

	return mergeResourcePermissions(dbPerms, filePerms, crossStorePerms), nil
}

// crossStoreAllPermissions resolves declarative roles whose assignment rows live in the database.
// It differs from crossStoreAuthorizedPermissions on corruption: a removed role (ErrRoleNotFound)
// confers nothing and is skipped, while a corrupt one is returned as an error, since its contents
// are unknown.
func (c *compositeRoleStore) crossStoreAllPermissions(
	ctx context.Context, entityID string, groupIDs []string,
) ([]ResourcePermissions, error) {
	roleIDs, err := c.dbStore.GetEntityRoleIDs(ctx, entityID, groupIDs, "")
	if err != nil {
		return nil, err
	}
	if len(roleIDs) == 0 {
		return []ResourcePermissions{}, nil
	}

	byResourceServer := make(map[string][]string)
	for _, id := range roleIDs {
		exists, err := c.fileStore.IsRoleExist(ctx, id)
		if err != nil {
			return nil, err
		}
		if !exists {
			// Role is DB-only; already covered by the DB-store enumeration.
			continue
		}
		role, err := c.fileStore.GetRole(ctx, id)
		if err != nil {
			if errors.Is(err, ErrRoleNotFound) {
				continue
			}
			log.GetLogger().Error(ctx,
				"Failed to load declarative role for cross-store permission enumeration",
				log.String("roleID", id), log.Error(err))
			return nil, fmt.Errorf("composite role store: load declarative role %q: %w", id, err)
		}
		for _, rp := range role.Permissions {
			byResourceServer[rp.ResourceServerID] = append(
				byResourceServer[rp.ResourceServerID], rp.Permissions...)
		}
	}

	return resourcePermissionsFromMap(byResourceServer), nil
}

// GetEntityRoleIDs returns the IDs of roles assigned to an entity (directly or via groups).
// Delegates to the database store since assignments are persisted there even for declarative
// roles. The file store has no independent record of API-added assignments.
func (c *compositeRoleStore) GetEntityRoleIDs(
	ctx context.Context, entityID string, groupIDs []string, assignmentOUID string,
) ([]string, error) {
	return c.dbStore.GetEntityRoleIDs(ctx, entityID, groupIDs, assignmentOUID)
}

// GetUserRoles retrieves role names assigned to an entity from both stores.
func (c *compositeRoleStore) GetUserRoles(
	ctx context.Context, entityID string, groupIDs []string, assignmentOUID string,
) ([]string, error) {
	dbRoleNames, err := c.dbStore.GetUserRoles(ctx, entityID, groupIDs, assignmentOUID)
	if err != nil {
		return nil, err
	}

	fileRoleNames, err := c.fileStore.GetUserRoles(ctx, entityID, groupIDs, assignmentOUID)
	if err != nil {
		return nil, err
	}

	crossStoreRoleNames, err := c.crossStoreRoleNames(ctx, entityID, groupIDs, assignmentOUID)
	if err != nil {
		return nil, err
	}

	return mergePermissions(mergePermissions(dbRoleNames, fileRoleNames), crossStoreRoleNames), nil
}

// crossStoreRoleNames returns the names of declarative roles whose assignment rows live in the
// database. Neither store finds them alone: the database store joins the ROLE table, which holds no
// declarative role, and the file store reads only the assignments its files declare.
func (c *compositeRoleStore) crossStoreRoleNames(
	ctx context.Context, entityID string, groupIDs []string, assignmentOUID string,
) ([]string, error) {
	if entityID == "" && len(groupIDs) == 0 {
		return []string{}, nil
	}

	roleIDs, err := c.dbStore.GetEntityRoleIDs(ctx, entityID, groupIDs, assignmentOUID)
	if err != nil {
		return nil, err
	}

	names := make([]string, 0, len(roleIDs))
	for _, id := range roleIDs {
		role, err := c.fileStore.GetRole(ctx, id)
		if err != nil {
			// A role that is not declarative was named by the database store already, and one whose
			// file was removed confers nothing.
			if errors.Is(err, ErrRoleNotFound) {
				continue
			}
			return nil, fmt.Errorf("composite role store: load declarative role %q: %w", id, err)
		}
		names = append(names, role.Name)
	}
	return names, nil
}

// IsRoleDeclarative checks if a role is immutable (exists in file store).
func (c *compositeRoleStore) IsRoleDeclarative(ctx context.Context, roleID string) (bool, error) {
	fileExists, err := c.fileStore.IsRoleExist(ctx, roleID)
	if err != nil {
		return false, err
	}
	return fileExists, nil
}

// mergeRoles deduplicates and merges roles from database and file stores.
// Database roles take precedence over file-based roles with the same ID.
func mergeRoles(dbRoles, fileRoles []Role) []Role {
	seen := make(map[string]bool)
	result := make([]Role, 0, len(dbRoles)+len(fileRoles))

	// Add database roles first (they take precedence) - mark as mutable (IsReadOnly=false)
	for i := range dbRoles {
		dbRoles[i].IsReadOnly = false
		result = append(result, dbRoles[i])
		seen[dbRoles[i].ID] = true
	}

	// Add file-based roles only if not already seen - mark as immutable (IsReadOnly=true)
	for i := range fileRoles {
		if !seen[fileRoles[i].ID] {
			fileRoles[i].IsReadOnly = true
			result = append(result, fileRoles[i])
			seen[fileRoles[i].ID] = true
		}
	}

	return result
}

// mergeAssignments deduplicates and merges assignments from database and file stores.
// Database assignments take precedence over file-based assignments with the same ID and type.
func mergeAssignments(dbAssignments, fileAssignments []RoleAssignment) []RoleAssignment {
	seen := make(map[string]bool)
	result := make([]RoleAssignment, 0, len(dbAssignments)+len(fileAssignments))

	// Add database assignments first (they take precedence)
	for _, assignment := range dbAssignments {
		key := assignment.OUID + ":" + string(assignment.Type) + ":" + assignment.ID
		result = append(result, assignment)
		seen[key] = true
	}

	// Add file-based assignments only if not already seen
	for _, assignment := range fileAssignments {
		key := assignment.OUID + ":" + string(assignment.Type) + ":" + assignment.ID
		if !seen[key] {
			result = append(result, assignment)
			seen[key] = true
		}
	}

	return result
}

// mergePermissions deduplicates and merges permissions from database and file stores. The result is
// sorted, because map iteration order is randomized: callers that page over the merged list (such as
// GetUserRoles) would otherwise return a different order on every call, repeating entries on one page
// and dropping them from another.
func mergePermissions(dbPerms, filePerms []string) []string {
	permMap := make(map[string]bool)

	for _, perm := range filePerms {
		permMap[perm] = true
	}

	for _, perm := range dbPerms {
		permMap[perm] = true
	}

	result := make([]string, 0, len(permMap))
	for perm := range permMap {
		result = append(result, perm)
	}
	slices.Sort(result)
	return result
}
