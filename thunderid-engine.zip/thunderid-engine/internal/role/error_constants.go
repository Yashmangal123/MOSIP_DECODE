// Copyright 2025-2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package role

import (
	"errors"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"

	"github.com/thunder-id/thunderid/internal/sharing"
)

// Client errors for role management operations.
var (
	// ErrorInvalidRequestFormat is the error returned when the request format is invalid.
	ErrorInvalidRequestFormat = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1001",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_request_format",
			DefaultValue: "Invalid request format",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_request_format_description",
			DefaultValue: "The request body is malformed or contains invalid data",
		},
	}
	// ErrorMissingRoleID is the error returned when role ID is missing.
	ErrorMissingRoleID = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1002",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.missing_role_id",
			DefaultValue: "Invalid request format",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.missing_role_id_description",
			DefaultValue: "Role ID is required",
		},
	}
	// ErrorRoleNotFound is the error returned when a role is not found.
	ErrorRoleNotFound = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1003",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.role_not_found",
			DefaultValue: "Role not found",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.role_not_found_description",
			DefaultValue: "The role with the specified id does not exist",
		},
	}
	// ErrorRoleNameConflict is the error returned when a role name already exists in the organization unit.
	ErrorRoleNameConflict = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1004",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.role_name_conflict",
			DefaultValue: "Role name conflict",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.role_name_conflict_description",
			DefaultValue: "A role with the same name is owned by or shared with the organization unit",
		},
	}
	// ErrorOrganizationUnitNotFound is the error returned when organization unit is not found.
	ErrorOrganizationUnitNotFound = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1005",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.organization_unit_not_found",
			DefaultValue: "Organization unit not found",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.organization_unit_not_found_description",
			DefaultValue: "Organization unit not found",
		},
	}
	// ErrorInvalidAssignmentID is the error returned when assignment ID is invalid.
	ErrorInvalidAssignmentID = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1007",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_assignment_id",
			DefaultValue: "Invalid assignment ID",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.roleservice.invalid_assignment_id_description",
			DefaultValue: "One or more assignment IDs in the request do not exist " +
				"or do not match the claimed type",
		},
	}
	// ErrorInvalidLimit is the error returned when limit parameter is invalid.
	ErrorInvalidLimit = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1008",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_limit_parameter",
			DefaultValue: "Invalid limit parameter",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_limit_parameter_description",
			DefaultValue: "The limit parameter must be a positive integer",
		},
	}
	// ErrorInvalidOffset is the error returned when offset parameter is invalid.
	ErrorInvalidOffset = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1009",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_offset_parameter",
			DefaultValue: "Invalid offset parameter",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_offset_parameter_description",
			DefaultValue: "The offset parameter must be a non-negative integer",
		},
	}
	// ErrorEmptyAssignments is the error returned when assignments list is empty.
	ErrorEmptyAssignments = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1010",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.empty_assignments_list",
			DefaultValue: "Empty assignments list",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.empty_assignments_list_description",
			DefaultValue: "At least one assignment must be provided",
		},
	}
	// ErrorMissingEntityOrGroups is the error returned when both entity ID and groups are missing.
	ErrorMissingEntityOrGroups = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1011",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.missing_entity_or_groups",
			DefaultValue: "Invalid request format",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.roleservice." +
				"either_entity_id_or_groups_must_be_provided_for_authorization_check_description",
			DefaultValue: "Either entityId or groups must be provided for authorization check",
		},
	}
	// ErrorInvalidPermissions is returned when one or more permissions are invalid.
	ErrorInvalidPermissions = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1012",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_permissions",
			DefaultValue: "Invalid permissions",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_permissions_description",
			DefaultValue: "One or more permissions do not exist in the resource management system",
		},
	}
	// ErrorImmutableRole is the error returned when attempting to modify a declarative role.
	ErrorImmutableRole = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1013",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.cannot_modify_declarative_role",
			DefaultValue: "Cannot modify declarative role",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.cannot_modify_declarative_role_description",
			DefaultValue: "The role is defined in declarative configuration and cannot be modified",
		},
	}
	// ErrorDeclarativeModeCreateNotAllowed is the error returned when attempting to create
	// a role in declarative-only mode.
	ErrorDeclarativeModeCreateNotAllowed = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1015",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.cannot_create_role_in_declarative_only_mode",
			DefaultValue: "Cannot create role in declarative-only mode",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.roleservice.cannot_create_role_in_declarative_only_mode_description",
			DefaultValue: "Role creation is not allowed when running in declarative-only mode. " +
				"Roles must be defined in declarative configuration files",
		},
	}
	// ErrorInvalidAssigneeType is the error returned when the assignee type query parameter is invalid.
	ErrorInvalidAssigneeType = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1016",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_assignee_type",
			DefaultValue: "Invalid assignee type",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_assignee_type_description",
			DefaultValue: "The type parameter must be 'user', 'group', or 'app'",
		},
	}
	// ErrorRoleIDConflict is the error returned when a role with the specified ID already exists.
	ErrorRoleIDConflict = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1018",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.role_id_conflict",
			DefaultValue: "Role ID conflict",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.role_id_conflict_description",
			DefaultValue: "A role with the specified ID already exists",
		},
	}
	// ResultLimitExceededInCompositeMode is the error returned when the total number of records exceeds
	// the maximum limit in composite mode (combining database and declarative resources).
	ResultLimitExceededInCompositeMode = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1017",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.result_limit_exceeded_in_composite_mode",
			DefaultValue: "Result limit exceeded in composite mode",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.result_limit_exceeded_in_composite_mode_description",
			DefaultValue: "The total number of records exceeds the maximum limit in composite mode",
		},
	}
	// ErrorMissingAssigneeID is the error returned when an assignee ID is required but absent.
	ErrorMissingAssigneeID = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1019",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.missing_assignee_id",
			DefaultValue: "Invalid request format",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.missing_assignee_id_description",
			DefaultValue: "Assignee ID is required",
		},
	}
	// ErrorRoleAssignmentNotFound is the error returned when the assignee does not hold the role.
	ErrorRoleAssignmentNotFound = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1020",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.role_assignment_not_found",
			DefaultValue: "Role assignment not found",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.role_assignment_not_found_description",
			DefaultValue: "The assignee does not hold this role",
		},
	}
	// ErrorInvalidSharingPolicy is returned when a sharing policy is not one the issuing
	// organization unit may write.
	ErrorInvalidSharingPolicy = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1021",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_sharing_policy",
			DefaultValue: "Invalid sharing policy",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_sharing_policy_description",
			DefaultValue: "The sharing policy is not one the issuing organization unit may write",
		},
	}
	// ErrorSharingPolicyNotFound is returned when the role holds no policy under the requested
	// id. A policy belonging to another resource answers the same way.
	ErrorSharingPolicyNotFound = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1022",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.sharing_policy_not_found",
			DefaultValue: "Sharing policy not found",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.sharing_policy_not_found_description",
			DefaultValue: "The role has no sharing policy with the specified id",
		},
	}
	// ErrorSharingPolicyExists is returned when the organization unit already holds a policy for
	// this role.
	ErrorSharingPolicyExists = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1023",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.sharing_policy_exists",
			DefaultValue: "Sharing policy already exists",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.sharing_policy_exists_description",
			DefaultValue: "This organization unit already has a sharing policy for the role; edit it instead",
		},
	}
	// ErrorSharingPolicyVersionMismatch is returned when an edit names a version the policy has
	// moved past.
	ErrorSharingPolicyVersionMismatch = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1024",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.sharing_policy_version_mismatch",
			DefaultValue: "Sharing policy version mismatch",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.sharing_policy_version_mismatch_description",
			DefaultValue: "The sharing policy changed since it was read; read it again and retry the edit",
		},
	}
	// ErrorSharingPolicyDeclared is returned when an edit or a delete is aimed at a policy a
	// resource file declares.
	ErrorSharingPolicyDeclared = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1025",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.sharing_policy_declared",
			DefaultValue: "Sharing policy is declared",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.sharing_policy_declared_description",
			DefaultValue: "The sharing policy is declared in a resource file and cannot be changed through the API",
		},
	}
	// ErrorRoleNotSharedToOU is returned when an organization unit cannot see the role, so
	// there are no terms to resolve for it.
	ErrorRoleNotSharedToOU = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1026",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.role_not_shared_to_ou",
			DefaultValue: "Role is not shared to the organization unit",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.roleservice.role_not_shared_to_ou_description",
			DefaultValue: "No sharing policy reaches the specified organization unit, so the role is not available " +
				"there",
		},
	}
	// ErrorMissingOUIDParameter is returned when an overlay-rules request does not say which
	// organization unit to resolve for.
	ErrorMissingOUIDParameter = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1027",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.missing_ou_id_parameter",
			DefaultValue: "Missing required parameter",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.missing_ou_id_parameter_description",
			DefaultValue: "The 'ouId' query parameter is required",
		},
	}
	// ErrorDeploymentWideSharingNotAllowed is returned when a create through the API states a
	// section whose reach is not bounded by where the issuing organization unit sits in the tree.
	ErrorDeploymentWideSharingNotAllowed = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1028",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.deployment_wide_sharing_not_allowed",
			DefaultValue: "Deployment-wide sharing is not allowed",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.roleservice.deployment_wide_sharing_not_allowed_description",
			DefaultValue: "A policy reaching all organization units or the roots of all other trees can only be " +
				"created from a declarative resource file or an import",
		},
	}
	// ErrorSharedRoleCannotMove is returned when a role that sharing policies govern is moved to
	// another organization unit.
	ErrorSharedRoleCannotMove = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1029",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.shared_role_cannot_move",
			DefaultValue: "Role with sharing policies cannot be moved",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.roleservice.shared_role_cannot_move_description",
			DefaultValue: "The role is shared into other organization units. Delete its sharing policies " +
				"before moving it to another organization unit",
		},
	}
	// ErrorAssigneeNotInOU is returned when an assignment names an assignee that the organization unit
	// the assignment is made in neither owns nor has shared with it.
	ErrorAssigneeNotInOU = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1030",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.assignee_not_in_ou",
			DefaultValue: "Assignee is not available in the organization unit",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.roleservice.assignee_not_in_ou_description",
			DefaultValue: "A role can only be assigned to users, applications and agents owned by or shared with " +
				"the organization unit the assignment is made in, and to groups owned by it",
		},
	}
	// ErrorSharedRoleFieldNotEditable is returned when an organization unit a role is shared with
	// changes something the role's sharing policies do not let it change.
	ErrorSharedRoleFieldNotEditable = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1031",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.shared_role_field_not_editable",
			DefaultValue: "Field cannot be changed in this organization unit",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.roleservice.shared_role_field_not_editable_description",
			DefaultValue: "An organization unit the role is shared with can only change what the role's " +
				"sharing policies make editable there",
		},
	}
	// ErrorRoleWithAssignmentsCannotMove is returned when a role that still has assignments is moved
	// to another organization unit.
	ErrorRoleWithAssignmentsCannotMove = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1032",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.role_with_assignments_cannot_move",
			DefaultValue: "Role with assignments cannot be moved",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.roleservice.role_with_assignments_cannot_move_description",
			DefaultValue: "The role is assigned in its organization unit. Remove its assignments before moving " +
				"it to another organization unit",
		},
	}
	// ErrorInvalidFilter is returned when a list filter is malformed or names an attribute that cannot
	// be filtered on.
	ErrorInvalidFilter = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1033",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_filter",
			DefaultValue: "Invalid filter",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key:          "error.roleservice.invalid_filter_description",
			DefaultValue: `The filter must be a single expression of the form ouId eq "<id>"`,
		},
	}
	// ErrorSharedRoleNotEditable is returned when a role is updated in an organization unit it is
	// shared with.
	ErrorSharedRoleNotEditable = tidcommon.ServiceError{
		Type: tidcommon.ClientErrorType,
		Code: "ROL-1034",
		Error: tidcommon.I18nMessage{
			Key:          "error.roleservice.shared_role_not_editable",
			DefaultValue: "Role cannot be edited in this organization unit",
		},
		ErrorDescription: tidcommon.I18nMessage{
			Key: "error.roleservice.shared_role_not_editable_description",
			DefaultValue: "A role's name, description and permissions can be changed only in the " +
				"organization unit that owns it, not in one it is shared with",
		},
	}
)

// Internal error constants for role management operations.
var (
	// ErrRoleNotFound is returned when the role is not found in the system.
	ErrRoleNotFound = errors.New("role not found")

	// ErrRoleDataCorrupted is returned by the file-based store when a stored entry cannot
	// be converted into a role (type assertion / parse failure). Exposed as a sentinel so
	// callers can use errors.Is to skip these benign cases without conflating them with
	// actionable I/O errors. The originating site already logs the underlying details.
	ErrRoleDataCorrupted = errors.New("role data corrupted")

	// errResultLimitExceededInCompositeMode is the internal sentinel error for composite mode limit exceeded.
	errResultLimitExceededInCompositeMode = errors.New("result limit exceeded in composite mode")
)

// sharingErrors answers the sharing framework's client errors in this service's own codes.
var sharingErrors = sharing.ErrorTranslation{
	PolicyNotFound:  ErrorSharingPolicyNotFound,
	PolicyExists:    ErrorSharingPolicyExists,
	VersionMismatch: ErrorSharingPolicyVersionMismatch,
	PolicyDeclared:  ErrorSharingPolicyDeclared,
	InvalidLimit:    ErrorInvalidLimit,
	InvalidOffset:   ErrorInvalidOffset,
	InvalidPolicy:   ErrorInvalidSharingPolicy,
}
