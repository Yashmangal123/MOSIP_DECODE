// Copyright 2025-2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package role

import (
	"context"
	"errors"
	"testing"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/suite"

	"github.com/thunder-id/thunderid/internal/group"
	oupkg "github.com/thunder-id/thunderid/internal/ou"
	"github.com/thunder-id/thunderid/internal/revocation"
	"github.com/thunder-id/thunderid/internal/sharing"
	"github.com/thunder-id/thunderid/internal/system/config"
	serverconst "github.com/thunder-id/thunderid/internal/system/constants"
	"github.com/thunder-id/thunderid/internal/system/resourcedependency"
	"github.com/thunder-id/thunderid/internal/system/security"
	"github.com/thunder-id/thunderid/internal/system/sysauthz"
	"github.com/thunder-id/thunderid/internal/system/utils"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"
	"github.com/thunder-id/thunderid/tests/mocks/entitymock"
	"github.com/thunder-id/thunderid/tests/mocks/entitytypemock"
	"github.com/thunder-id/thunderid/tests/mocks/groupmock"
	"github.com/thunder-id/thunderid/tests/mocks/oumock"
	"github.com/thunder-id/thunderid/tests/mocks/resourcemock"
	"github.com/thunder-id/thunderid/tests/mocks/sharingmock"
	"github.com/thunder-id/thunderid/tests/mocks/sysauthzmock"
	"github.com/thunder-id/thunderid/tests/mocks/transactionmock"
)

const (
	testUserID1 = "user1"
)

// fakeTransactioner is a light-weight test double to capture transaction usage.
type fakeTransactioner struct {
	transactCalls int
	err           error
}

func (f *fakeTransactioner) Transact(ctx context.Context, txFunc func(context.Context) error) error {
	f.transactCalls++
	if f.err != nil {
		return f.err
	}
	return txFunc(ctx)
}

// Test Suite
type RoleServiceTestSuite struct {
	suite.Suite
	mockStore             *roleStoreInterfaceMock
	mockEntityService     *entitymock.EntityServiceInterfaceMock
	mockGroupService      *groupmock.GroupServiceInterfaceMock
	mockOUService         *oumock.OrganizationUnitServiceInterfaceMock
	mockResourceService   *resourcemock.ResourceServiceInterfaceMock
	mockEntityTypeService *entitytypemock.EntityTypeServiceInterfaceMock
	mockSharingService    *sharingmock.SharingServiceInterfaceMock
	transactioner         *fakeTransactioner
	service               RoleServiceInterface
}

func TestRoleServiceTestSuite(t *testing.T) {
	suite.Run(t, new(RoleServiceTestSuite))
}

func (suite *RoleServiceTestSuite) SetupTest() {
	// Initialize config runtime with default values
	testConfig := &config.Config{
		DeclarativeResources: config.DeclarativeResources{
			Enabled: false,
		},
	}
	config.ResetServerRuntime()
	err := config.InitializeServerRuntime("/tmp/test", testConfig)
	if err != nil {
		suite.Fail("Failed to initialize runtime", err)
	}

	suite.mockStore = newRoleStoreInterfaceMock(suite.T())
	suite.mockEntityService = entitymock.NewEntityServiceInterfaceMock(suite.T())
	suite.mockGroupService = groupmock.NewGroupServiceInterfaceMock(suite.T())
	suite.mockOUService = oumock.NewOrganizationUnitServiceInterfaceMock(suite.T())
	suite.mockResourceService = resourcemock.NewResourceServiceInterfaceMock(suite.T())
	suite.mockEntityTypeService = entitytypemock.NewEntityTypeServiceInterfaceMock(suite.T())
	suite.transactioner = &fakeTransactioner{}
	suite.mockSharingService = sharingmock.NewSharingServiceInterfaceMock(suite.T())
	suite.service = newRoleService(
		suite.mockStore,
		suite.mockEntityService,
		suite.mockGroupService,
		suite.mockOUService,
		suite.mockResourceService,
		suite.transactioner,
		newAllowAllRoleAuthz(suite.T()),
		suite.mockSharingService,
	)
}

// TearDownTest cleans up after each test
func (suite *RoleServiceTestSuite) TearDownTest() {
	config.ResetServerRuntime()
}

// GetRoleList Tests
func (suite *RoleServiceTestSuite) TestGetRoleList_Success() {
	expectedRoles := []Role{
		{ID: "role1", Name: "Admin", OUID: "ou1"},
		{ID: "role2", Name: "User", OUID: "ou1"},
	}

	suite.mockStore.On("GetRoleListCount", mock.Anything).Return(2, nil)
	suite.mockStore.On("GetRoleList", mock.Anything, 10, 0).Return(expectedRoles, nil)
	suite.mockOUService.On("GetOrganizationUnitHandlesByIDs", mock.Anything,
		[]string{"ou1"}).Return(map[string]string{"ou1": "default"}, nil)

	result, err := suite.service.GetRoleList(context.Background(), 10, 0, nil)

	suite.Nil(err)
	suite.NotNil(result)
	suite.Equal(2, result.TotalResults)
	suite.Equal(2, result.Count)
	suite.Equal(1, result.StartIndex)
	suite.Equal(2, len(result.Roles))
	suite.Equal("role1", result.Roles[0].ID)
	suite.Equal("Admin", result.Roles[0].Name)
	suite.Equal("default", result.Roles[0].OUHandle)
	suite.Equal("role2", result.Roles[1].ID)
	suite.Equal("User", result.Roles[1].Name)
	suite.Equal("default", result.Roles[1].OUHandle)
}

// A plain list is every role in the deployment, each read under the organization unit owning it.
func (suite *RoleServiceTestSuite) TestGetRoleList_UnfilteredRolesAreOwned() {
	suite.mockStore.On("GetRoleListCount", mock.Anything).Return(1, nil)
	suite.mockStore.On("GetRoleList", mock.Anything, 10, 0).Return([]Role{{ID: "role1", OUID: "ou1"}}, nil)
	suite.mockOUService.On("GetOrganizationUnitHandlesByIDs", mock.Anything, []string{"ou1"}).
		Return(map[string]string{"ou1": "default"}, nil)

	result, err := suite.service.GetRoleList(context.Background(), 10, 0, nil)

	suite.Require().Nil(err)
	suite.True(result.Roles[0].IsOwnedByOU)
}

// An organization unit filter lists the roles it owns, then the ones shared with it, each shared
// role read under the filtered unit and closed to edits there.
func (suite *RoleServiceTestSuite) TestGetRoleList_InOU_OwnedThenShared() {
	filters := map[string]interface{}{"ouId": "ou-child"}
	suite.mockStore.On("GetRoleListCountByOUID", mock.Anything, "ou-child").Return(1, nil)
	suite.mockStore.On("GetRoleListByOUID", mock.Anything, "ou-child", 1, 0).
		Return([]Role{{ID: "own", Name: "Own", OUID: "ou-child"}}, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou-child").
		Return([]string{"shared-a", "shared-b"}, nil)
	suite.mockStore.On("GetRolesByIDs", mock.Anything, []string{"shared-a", "shared-b"}).
		Return([]Role{{ID: "shared-b", OUID: "ou-root"}, {ID: "shared-a", OUID: "ou-root"}}, nil)
	suite.mockOUService.On("GetOrganizationUnitHandlesByIDs", mock.Anything, []string{"ou-child"}).
		Return(map[string]string{"ou-child": "child"}, nil)

	result, err := suite.service.GetRoleList(context.Background(), 10, 0, filters)

	suite.Require().Nil(err)
	suite.Equal(3, result.TotalResults)
	suite.Require().Len(result.Roles, 3)
	suite.Equal("own", result.Roles[0].ID)
	suite.True(result.Roles[0].IsOwnedByOU)
	suite.False(result.Roles[0].IsReadOnly)
	for i, id := range []string{"shared-a", "shared-b"} {
		role := result.Roles[i+1]
		suite.Equal(id, role.ID)
		suite.False(role.IsOwnedByOU)
		suite.True(role.IsReadOnly)
		suite.Equal("ou-child", role.OUID)
		suite.Equal("child", role.OUHandle)
	}
}

// A page past the owned roles reads only the shared ones it holds, and its links keep the filter.
func (suite *RoleServiceTestSuite) TestGetRoleList_InOU_PageOfSharedOnly() {
	filters := map[string]interface{}{"ouId": "ou-child"}
	suite.mockStore.On("GetRoleListCountByOUID", mock.Anything, "ou-child").Return(1, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou-child").
		Return([]string{"shared-a", "shared-b"}, nil)
	suite.mockStore.On("GetRolesByIDs", mock.Anything, []string{"shared-b"}).
		Return([]Role{{ID: "shared-b", OUID: "ou-root"}}, nil)
	suite.mockOUService.On("GetOrganizationUnitHandlesByIDs", mock.Anything, []string{"ou-child"}).
		Return(map[string]string{"ou-child": "child"}, nil)

	result, err := suite.service.GetRoleList(context.Background(), 1, 2, filters)

	suite.Require().Nil(err)
	suite.Equal(3, result.TotalResults)
	suite.Require().Len(result.Roles, 1)
	suite.Equal("shared-b", result.Roles[0].ID)
	suite.mockStore.AssertNotCalled(suite.T(), "GetRoleListByOUID", mock.Anything, mock.Anything, mock.Anything,
		mock.Anything)
	suite.Require().NotEmpty(result.Links)
	suite.Contains(result.Links[0].Href, "filter=ouId+eq+%22ou-child%22")
}

// An organization unit that does not exist owns nothing and has nothing shared with it.
func (suite *RoleServiceTestSuite) TestGetRoleList_InUnknownOU_IsEmpty() {
	suite.mockStore.On("GetRoleListCountByOUID", mock.Anything, "gone").Return(0, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "gone").
		Return(nil, &oupkg.ErrorOrganizationUnitNotFound)

	result, err := suite.service.GetRoleList(context.Background(), 10, 0, map[string]interface{}{"ouId": "gone"})

	suite.Require().Nil(err)
	suite.Equal(0, result.TotalResults)
	suite.Empty(result.Roles)
}

func (suite *RoleServiceTestSuite) TestGetRoleList_InOU_Failures() {
	filters := map[string]interface{}{"ouId": "ou-child"}

	suite.Run("count", func() {
		suite.SetupTest()
		suite.mockStore.On("GetRoleListCountByOUID", mock.Anything, "ou-child").Return(0, errors.New("db"))
		_, err := suite.service.GetRoleList(context.Background(), 10, 0, filters)
		suite.Require().NotNil(err)
		suite.Equal(tidcommon.InternalServerError.Code, err.Code)
	})
	suite.Run("sharing", func() {
		suite.SetupTest()
		suite.mockStore.On("GetRoleListCountByOUID", mock.Anything, "ou-child").Return(0, nil)
		suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou-child").
			Return(nil, &tidcommon.InternalServerError)
		_, err := suite.service.GetRoleList(context.Background(), 10, 0, filters)
		suite.Require().NotNil(err)
		suite.Equal(tidcommon.InternalServerError.Code, err.Code)
	})
	suite.Run("page", func() {
		suite.SetupTest()
		suite.mockStore.On("GetRoleListCountByOUID", mock.Anything, "ou-child").Return(1, nil)
		suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou-child").
			Return(nil, nil)
		suite.mockStore.On("GetRoleListByOUID", mock.Anything, "ou-child", 1, 0).Return(nil, errors.New("db"))
		_, err := suite.service.GetRoleList(context.Background(), 10, 0, filters)
		suite.Require().NotNil(err)
		suite.Equal(tidcommon.InternalServerError.Code, err.Code)
	})
}

// Only a single organization unit filter is understood.
func (suite *RoleServiceTestSuite) TestGetRoleList_InvalidFilter() {
	for name, filters := range map[string]map[string]interface{}{
		"other attribute": {"name": "Admin"},
		"with another":    {"ouId": "ou1", "name": "Admin"},
		"empty value":     {"ouId": ""},
	} {
		suite.Run(name, func() {
			_, err := suite.service.GetRoleList(context.Background(), 10, 0, filters)
			suite.Require().NotNil(err)
			suite.Equal(ErrorInvalidFilter.Code, err.Code)
		})
	}
}

func (suite *RoleServiceTestSuite) TestGetRoleInOU() {
	owned := RoleWithPermissions{ID: "role1", Name: "Auditor", OUID: "ou1"}

	suite.Run("no organization unit reads the role itself", func() {
		suite.SetupTest()
		suite.mockStore.On("GetRole", mock.Anything, "role1").Return(owned, nil)
		suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").
			Return(oupkg.OrganizationUnit{ID: "ou1", Handle: "root"}, nil)

		role, err := suite.service.GetRoleInOU(context.Background(), "role1", "")

		suite.Require().Nil(err)
		suite.Equal("ou1", role.OUID)
		suite.True(role.IsOwnedByOU)
	})
	suite.Run("the owner reads the role itself", func() {
		suite.SetupTest()
		suite.mockStore.On("GetRole", mock.Anything, "role1").Return(owned, nil)
		suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").
			Return(oupkg.OrganizationUnit{ID: "ou1", Handle: "root"}, nil)

		role, err := suite.service.GetRoleInOU(context.Background(), "role1", "ou1")

		suite.Require().Nil(err)
		suite.True(role.IsOwnedByOU)
		suite.mockSharingService.AssertNotCalled(suite.T(), "IsVisible",
			mock.Anything, mock.Anything, mock.Anything, mock.Anything)
	})
	suite.Run("an organization unit it is shared with reads the shared role", func() {
		suite.SetupTest()
		suite.mockStore.On("GetRole", mock.Anything, "role1").Return(owned, nil)
		suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").
			Return(oupkg.OrganizationUnit{ID: "ou1", Handle: "root"}, nil)
		suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou-child").
			Return(oupkg.OrganizationUnit{ID: "ou-child", Handle: "child"}, nil)
		suite.mockSharingService.EXPECT().IsVisible(mock.Anything, RoleSharingType, "role1", "ou-child").
			Return(true, nil)

		role, err := suite.service.GetRoleInOU(context.Background(), "role1", "ou-child")

		suite.Require().Nil(err)
		suite.Equal("Auditor", role.Name)
		suite.Equal("ou-child", role.OUID)
		suite.Equal("child", role.OUHandle)
		suite.False(role.IsOwnedByOU)
	})
	suite.Run("a handle that cannot be read is left out rather than failing the read", func() {
		suite.SetupTest()
		suite.mockStore.On("GetRole", mock.Anything, "role1").Return(owned, nil)
		suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").
			Return(oupkg.OrganizationUnit{ID: "ou1", Handle: "root"}, nil)
		suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou-child").
			Return(oupkg.OrganizationUnit{}, &tidcommon.InternalServerError)
		suite.mockSharingService.EXPECT().IsVisible(mock.Anything, RoleSharingType, "role1", "ou-child").
			Return(true, nil)

		role, err := suite.service.GetRoleInOU(context.Background(), "role1", "ou-child")

		suite.Require().Nil(err)
		suite.Equal("ou-child", role.OUID)
		suite.Empty(role.OUHandle)
	})
	for name, answer := range map[string]struct {
		visible bool
		svcErr  *tidcommon.ServiceError
	}{
		"an organization unit it is not shared with finds nothing": {visible: false},
		"an organization unit that does not exist finds nothing":   {svcErr: &oupkg.ErrorOrganizationUnitNotFound},
	} {
		suite.Run(name, func() {
			suite.SetupTest()
			suite.mockStore.On("GetRole", mock.Anything, "role1").Return(owned, nil)
			suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").
				Return(oupkg.OrganizationUnit{ID: "ou1", Handle: "root"}, nil)
			suite.mockSharingService.EXPECT().IsVisible(mock.Anything, RoleSharingType, "role1", "stranger").
				Return(answer.visible, answer.svcErr)

			_, err := suite.service.GetRoleInOU(context.Background(), "role1", "stranger")

			suite.Require().NotNil(err)
			suite.Equal(ErrorRoleNotSharedToOU.Code, err.Code)
		})
	}
	suite.Run("a failed visibility check is a server error", func() {
		suite.SetupTest()
		suite.mockStore.On("GetRole", mock.Anything, "role1").Return(owned, nil)
		suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").
			Return(oupkg.OrganizationUnit{ID: "ou1", Handle: "root"}, nil)
		suite.mockSharingService.EXPECT().IsVisible(mock.Anything, RoleSharingType, "role1", "ou-child").
			Return(false, &tidcommon.InternalServerError)

		_, err := suite.service.GetRoleInOU(context.Background(), "role1", "ou-child")

		suite.Require().NotNil(err)
		suite.Equal(tidcommon.InternalServerError.Code, err.Code)
	})
	suite.Run("an unknown role", func() {
		suite.SetupTest()
		suite.mockStore.On("GetRole", mock.Anything, "missing").Return(RoleWithPermissions{}, ErrRoleNotFound)

		_, err := suite.service.GetRoleInOU(context.Background(), "missing", "ou-child")

		suite.Require().NotNil(err)
		suite.Equal(ErrorRoleNotFound.Code, err.Code)
	})
}

func (suite *RoleServiceTestSuite) TestGetRoleList_InvalidPagination() {
	testCases := []struct {
		name    string
		limit   int
		offset  int
		errCode string
	}{
		{"InvalidLimit_Zero", 0, 0, ErrorInvalidLimit.Code},
		{"InvalidLimit_TooLarge", serverconst.MaxPageSize + 1, 0, ErrorInvalidLimit.Code},
		{"InvalidOffset_Negative", 10, -1, ErrorInvalidOffset.Code},
	}

	for _, tc := range testCases {
		suite.T().Run(tc.name, func(t *testing.T) {
			result, err := suite.service.GetRoleList(context.Background(), tc.limit, tc.offset, nil)
			suite.Nil(result)
			suite.NotNil(err)
			suite.Equal(tc.errCode, err.Code)
		})
	}
}

func (suite *RoleServiceTestSuite) TestGetRoleList_StoreErrors() {
	testCases := []struct {
		name      string
		mockSetup func()
	}{
		{
			name: "CountError",
			mockSetup: func() {
				suite.mockStore.On("GetRoleListCount", mock.Anything).Return(0, errors.New("database error")).Once()
			},
		},
		{
			name: "GetListError",
			mockSetup: func() {
				suite.mockStore.On("GetRoleListCount", mock.Anything).Return(10, nil).Once()
				suite.mockStore.On("GetRoleList", mock.Anything,
					10, 0).
					Return([]Role{}, errors.New("database error")).Once()
			},
		},
	}

	for _, tc := range testCases {
		suite.Run(tc.name, func() {
			tc.mockSetup()

			result, err := suite.service.GetRoleList(context.Background(), 10, 0, nil)

			suite.Nil(result)
			suite.NotNil(err)
			suite.Equal(tidcommon.InternalServerError.Code, err.Code)
		})
	}
}

func (suite *RoleServiceTestSuite) TestGetRoleList_OUHandlesError() {
	expectedRoles := []Role{
		{ID: "role1", Name: "Admin", OUID: "ou1"},
	}

	suite.mockStore.On("GetRoleListCount", mock.Anything).Return(1, nil)
	suite.mockStore.On("GetRoleList", mock.Anything, 10, 0).Return(expectedRoles, nil)
	suite.mockOUService.On("GetOrganizationUnitHandlesByIDs", mock.Anything,
		[]string{"ou1"}).Return(nil, &tidcommon.ServiceError{Code: "INTERNAL_ERROR"})

	result, err := suite.service.GetRoleList(context.Background(), 10, 0, nil)

	suite.Nil(err)
	suite.NotNil(result)
	suite.Equal(1, result.Count)
	suite.Equal("role1", result.Roles[0].ID)
	suite.Equal("", result.Roles[0].OUHandle)
}

// CreateRole Tests
func (suite *RoleServiceTestSuite) TestCreateRole_Success() {
	request := RoleCreationDetail{
		Name:        "Test Role",
		Description: "Test Description",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1", "perm2"}}},
		Assignments: []RoleAssignment{
			{ID: testUserID1, Type: AssigneeTypeUser},
		},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1", Name: "Test OU", Handle: "default"}
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1", "perm2"}).Return([]string{}, nil)
	suite.mockEntityService.On("GetEntitiesByIDs", mock.Anything,
		[]string{testUserID1}).Return(
		[]providers.Entity{{ID: testUserID1, Category: providers.EntityCategoryUser, OUID: "ou1"}}, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockStore.On("CheckRoleNameExists", mock.Anything,
		"ou1", "Test Role").Return(false, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
		Return(nil, nil)
	suite.mockStore.On("CreateRole", mock.Anything,
		mock.AnythingOfType("string"),
		mock.AnythingOfType("RoleCreationDetail")).Return(nil)

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(err)
	suite.NotNil(result)
	suite.Equal("Test Role", result.Name)
	suite.Equal("Test Description", result.Description)
	suite.Equal("ou1", result.OUID)
	suite.Equal("default", result.OUHandle)
	suite.Equal(1, len(result.Permissions))
	suite.Equal(2, len(result.Permissions[0].Permissions))
	// Verify permission validation was called
	suite.mockResourceService.AssertCalled(suite.T(), "ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1", "perm2"})
}

func (suite *RoleServiceTestSuite) TestCreateRole_ValidationErrors() {
	testCases := []struct {
		name    string
		request RoleCreationDetail
		errCode string
	}{
		{
			name: "MissingName",
			request: RoleCreationDetail{
				OUID: "ou1",
				Permissions: []ResourcePermissions{{
					ResourceServerID: "rs1",
					Permissions:      []string{"perm1"},
				}},
			},
			errCode: ErrorInvalidRequestFormat.Code,
		},
		{
			name: "MissingOrgUnit",
			request: RoleCreationDetail{
				Name: "Role",
				Permissions: []ResourcePermissions{{
					ResourceServerID: "rs1",
					Permissions:      []string{"perm1"},
				}},
			},
			errCode: ErrorInvalidRequestFormat.Code,
		},
		{
			name: "InvalidAssignmentType",
			request: RoleCreationDetail{
				Name:        "Role",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
				Assignments: []RoleAssignment{{ID: testUserID1, Type: "invalid"}},
			},
			errCode: ErrorInvalidAssigneeType.Code,
		},
		{
			name: "EmptyAssignmentID",
			request: RoleCreationDetail{
				Name:        "Role",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
				Assignments: []RoleAssignment{{ID: "", Type: AssigneeTypeUser}},
			},
			errCode: ErrorInvalidRequestFormat.Code,
		},
	}

	for _, tc := range testCases {
		suite.T().Run(tc.name, func(t *testing.T) {
			result, err := suite.service.CreateRole(context.Background(), tc.request)
			suite.Nil(result)
			suite.NotNil(err)
			suite.Equal(tc.errCode, err.Code)
		})
	}
}

func (suite *RoleServiceTestSuite) TestCreateRole_PermissionValidationErrors() {
	testCases := []struct {
		name          string
		request       RoleCreationDetail
		setupMocks    func()
		expectedError *tidcommon.ServiceError
	}{
		{
			name: "InvalidPermissions",
			request: RoleCreationDetail{
				Name:        "Test Role",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
			},
			setupMocks: func() {
				ou := oupkg.OrganizationUnit{ID: "ou1"}
				suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil).Once()
				suite.mockResourceService.On("ValidatePermissions", mock.Anything,
					"rs1", []string{"perm1"}).
					Return([]string{"perm1"}, nil).Once()
			},
			expectedError: &ErrorInvalidPermissions,
		},
		{
			name: "PermissionValidationServiceError",
			request: RoleCreationDetail{
				Name:        "Test Role",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
			},
			setupMocks: func() {
				ou := oupkg.OrganizationUnit{ID: "ou1"}
				suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil).Once()
				suite.mockResourceService.On("ValidatePermissions", mock.Anything,
					"rs1", []string{"perm1"}).
					Return([]string{}, &tidcommon.ServiceError{Code: "INTERNAL_ERROR"}).Once()
			},
			expectedError: &tidcommon.InternalServerError,
		},
		{
			name: "EmptyResourceServerID",
			request: RoleCreationDetail{
				Name:        "Test Role",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{{ResourceServerID: "", Permissions: []string{"perm1"}}},
			},
			setupMocks: func() {
				ou := oupkg.OrganizationUnit{ID: "ou1"}
				suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil).Once()
				// Resource service should not be called for empty resource server ID
			},
			expectedError: &ErrorInvalidPermissions,
		},
		{
			name: "EmptyPermissionsArray",
			request: RoleCreationDetail{
				Name:        "Test Role",
				Description: "Test Description",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{},
			},
			setupMocks: func() {
				ou := oupkg.OrganizationUnit{ID: "ou1"}
				suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil).Once()
				suite.mockStore.On("CheckRoleNameExists", mock.Anything,
					"ou1", "Test Role").Return(false, nil).Once()
				suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
					Return(nil, nil)
				suite.mockStore.On("CreateRole", mock.Anything,
					mock.AnythingOfType("string"),
					mock.AnythingOfType("RoleCreationDetail")).Return(nil).Once()
				// Resource service should NOT be called for empty permissions
			},
			expectedError: nil, // Success case
		},
		{
			name: "MultipleResourceServers",
			request: RoleCreationDetail{
				Name:        "Test Role",
				Description: "Test Description",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{
					{ResourceServerID: "rs1", Permissions: []string{"perm1"}},
					{ResourceServerID: "rs2", Permissions: []string{"perm2"}},
				},
			},
			setupMocks: func() {
				ou := oupkg.OrganizationUnit{ID: "ou1"}
				suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil).Once()
				suite.mockResourceService.On("ValidatePermissions", mock.Anything,
					"rs1", []string{"perm1"}).
					Return([]string{}, nil).Once()
				suite.mockResourceService.On("ValidatePermissions", mock.Anything,
					"rs2", []string{"perm2"}).
					Return([]string{}, nil).Once()
				suite.mockStore.On("CheckRoleNameExists", mock.Anything,
					"ou1", "Test Role").Return(false, nil).Once()
				suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
					Return(nil, nil)
				suite.mockStore.On("CreateRole", mock.Anything,
					mock.AnythingOfType("string"),
					mock.AnythingOfType("RoleCreationDetail")).Return(nil).Once()
			},
			expectedError: nil, // Success case
		},
	}

	for _, tc := range testCases {
		suite.T().Run(tc.name, func(t *testing.T) {
			// Setup fresh mocks for this test case
			suite.SetupTest()
			tc.setupMocks()

			result, err := suite.service.CreateRole(context.Background(), tc.request)

			if tc.expectedError != nil {
				suite.Nil(result)
				suite.NotNil(err)
				suite.Equal(tc.expectedError.Code, err.Code)
			} else {
				suite.Nil(err)
				suite.NotNil(result)
			}
		})
	}
}

func (suite *RoleServiceTestSuite) TestCreateRole_OrganizationUnitNotFound() {
	request := RoleCreationDetail{
		Name:        "Test Role",
		OUID:        "nonexistent",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "nonexistent").
		Return(oupkg.OrganizationUnit{}, &oupkg.ErrorOrganizationUnitNotFound)

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorOrganizationUnitNotFound.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestCreateRole_InvalidUserID() {
	request := RoleCreationDetail{
		Name:        "Test Role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
		Assignments: []RoleAssignment{{ID: "invalid_user", Type: AssigneeTypeUser}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1"}
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockEntityService.On("GetEntitiesByIDs", mock.Anything,
		[]string{"invalid_user"}).
		Return([]providers.Entity{}, nil)

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorInvalidAssignmentID.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestCreateRole_InvalidGroupID() {
	request := RoleCreationDetail{
		Name:        "Test Role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
		Assignments: []RoleAssignment{{ID: "invalid_group", Type: AssigneeTypeGroup}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1"}
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockGroupService.On("ValidateGroupIDs", mock.Anything,
		[]string{"invalid_group"}).
		Return(&group.ErrorInvalidGroupMemberID)

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorInvalidAssignmentID.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestCreateRole_StoreError() {
	request := RoleCreationDetail{
		Name:        "Test Role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1"}
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("CheckRoleNameExists", mock.Anything,
		"ou1", "Test Role").Return(false, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
		Return(nil, nil)
	suite.mockStore.On("CreateRole", mock.Anything,
		mock.AnythingOfType("string"),
		mock.AnythingOfType("RoleCreationDetail")).Return(errors.New("database error"))

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestCreateRole_NameConflict() {
	request := RoleCreationDetail{
		Name:        "Test Role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1"}
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("CheckRoleNameExists", mock.Anything,
		"ou1", "Test Role").Return(true, nil)

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorRoleNameConflict.Code, err.Code)
}

// A role shared with an organization unit is listed there, so its name is taken there too.
func (suite *RoleServiceTestSuite) TestCreateRole_NameTakenBySharedRole() {
	request := RoleCreationDetail{
		Name:        "Test Role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(oupkg.OrganizationUnit{ID: "ou1"}, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("CheckRoleNameExists", mock.Anything, "ou1", "Test Role").Return(false, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
		Return([]string{"shared1"}, nil)
	suite.mockStore.On("GetRolesByIDs", mock.Anything, []string{"shared1"}).
		Return([]Role{{ID: "shared1", Name: "Test Role", OUID: "ou-parent"}}, nil)

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(result)
	suite.Require().NotNil(err)
	suite.Equal(ErrorRoleNameConflict.Code, err.Code)
	suite.mockStore.AssertNotCalled(suite.T(), "CreateRole", mock.Anything, mock.Anything, mock.Anything)
}

func (suite *RoleServiceTestSuite) TestCreateRole_CheckNameExistsError() {
	request := RoleCreationDetail{
		Name:        "Test Role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1"}
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("CheckRoleNameExists", mock.Anything,
		"ou1", "Test Role").
		Return(false, errors.New("database error"))

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

// CreateRole Declarative Mode Tests
func (suite *RoleServiceTestSuite) TestCreateRole_DeclarativeMode_Denied() {
	// Setup declarative-only mode
	testConfig := &config.Config{
		DeclarativeResources: config.DeclarativeResources{
			Enabled: true,
		},
		Role: config.RoleConfig{
			Store: "declarative",
		},
	}
	config.ResetServerRuntime()
	initErr := config.InitializeServerRuntime("/tmp/test", testConfig)
	if initErr != nil {
		suite.Fail("Failed to initialize runtime", initErr)
	}
	defer config.ResetServerRuntime()

	request := RoleCreationDetail{
		Name: "Test Role",
		OUID: "ou1",
	}

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorDeclarativeModeCreateNotAllowed.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_DeclarativeMode_Denied() {
	// Setup declarative-only mode
	testConfig := &config.Config{
		DeclarativeResources: config.DeclarativeResources{
			Enabled: true,
		},
		Role: config.RoleConfig{
			Store: "declarative",
		},
	}
	config.ResetServerRuntime()
	initErr := config.InitializeServerRuntime("/tmp/test", testConfig)
	if initErr != nil {
		suite.Fail("Failed to initialize runtime", initErr)
	}
	defer config.ResetServerRuntime()

	request := RoleUpdateDetail{
		Name:        "Updated Role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockStore.On("IsRoleDeclarative", mock.Anything, "role1").Return(true, nil)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorImmutableRole.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_DeclarativeCheckError_Refused() {
	config.GetServerRuntime().Config.Role.Store = string(serverconst.StoreModeComposite)
	request := RoleUpdateDetail{
		Name:        "Updated Role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockStore.On("IsRoleDeclarative", mock.Anything, "role1").Return(false, errors.New("db down"))

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.Require().NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
	suite.mockStore.AssertNotCalled(suite.T(), "UpdateRole", mock.Anything, mock.Anything, mock.Anything)
}

// GetRoleWithPermissions Tests
func (suite *RoleServiceTestSuite) TestGetRole_Success() {
	expectedRole := RoleWithPermissions{
		ID:          "role1",
		Name:        "Admin",
		Description: "Administrator role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1", "perm2"}}},
	}

	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(expectedRole, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything,
		"ou1").Return(oupkg.OrganizationUnit{ID: "ou1", Handle: "default"}, nil)

	result, err := suite.service.GetRoleWithPermissions(context.Background(), "role1")

	suite.Nil(err)
	suite.NotNil(result)
	suite.Equal(expectedRole.ID, result.ID)
	suite.Equal(expectedRole.Name, result.Name)
	suite.Equal("default", result.OUHandle)
}

func (suite *RoleServiceTestSuite) TestGetRole_OUHandleError() {
	expectedRole := RoleWithPermissions{
		ID:   "role1",
		Name: "Admin",
		OUID: "ou1",
	}

	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(expectedRole, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything,
		"ou1").Return(oupkg.OrganizationUnit{}, &tidcommon.ServiceError{Code: "INTERNAL_ERROR"})

	result, err := suite.service.GetRoleWithPermissions(context.Background(), "role1")

	suite.Nil(err)
	suite.NotNil(result)
	suite.Equal("role1", result.ID)
	suite.Equal("Admin", result.Name)
	suite.Equal("", result.OUHandle)
}

func (suite *RoleServiceTestSuite) TestGetRole_MissingID() {
	result, err := suite.service.GetRoleWithPermissions(context.Background(), "")

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorMissingRoleID.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestGetRole_NotFound() {
	suite.mockStore.On("GetRole", mock.Anything,
		"nonexistent").Return(RoleWithPermissions{}, ErrRoleNotFound)

	result, err := suite.service.GetRoleWithPermissions(context.Background(), "nonexistent")

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorRoleNotFound.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestGetRole_StoreError() {
	suite.mockStore.On("GetRole", mock.Anything,
		"role1").Return(RoleWithPermissions{}, errors.New("database error"))

	result, err := suite.service.GetRoleWithPermissions(context.Background(), "role1")

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

// TestGetRolesByNames_DedupesInputAndGroupsAmbiguousMatches confirms duplicate input names are
// deduped before the store call, and that more than one role sharing a name are both returned under
// that name rather than one silently overwriting the other.
func (suite *RoleServiceTestSuite) TestGetRolesByNames_DedupesInputAndGroupsAmbiguousMatches() {
	suite.mockStore.On("GetRolesByNames", mock.Anything, []string{"admins"}).
		Return([]Role{
			{ID: "role-1", Name: "admins", OUID: "ou-1"},
			{ID: "role-2", Name: "admins", OUID: "ou-2"},
		}, nil)

	result, err := suite.service.GetRolesByNames(context.Background(), []string{"admins", "admins"})

	suite.Nil(err)
	suite.Len(result["admins"], 2)
}

func (suite *RoleServiceTestSuite) TestGetRolesByNames_EmptyInputReturnsEmptyMap() {
	result, err := suite.service.GetRolesByNames(context.Background(), nil)

	suite.Nil(err)
	suite.Empty(result)
}

func (suite *RoleServiceTestSuite) TestGetRolesByNames_StoreError() {
	suite.mockStore.On("GetRolesByNames", mock.Anything, []string{"admins"}).
		Return(nil, errors.New("database error"))

	result, err := suite.service.GetRolesByNames(context.Background(), []string{"admins"})

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

// UpdateRole Tests
func (suite *RoleServiceTestSuite) TestUpdateRole_MissingRoleID() {
	request := RoleUpdateDetail{
		Name:        "New Name",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "", request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorMissingRoleID.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_ValidationErrors() {
	testCases := []struct {
		name    string
		request RoleUpdateDetail
		errCode string
	}{
		{
			name: "MissingName",
			request: RoleUpdateDetail{
				OUID: "ou1",
				Permissions: []ResourcePermissions{{
					ResourceServerID: "rs1",
					Permissions:      []string{"perm1"},
				}},
			},
			errCode: ErrorInvalidRequestFormat.Code,
		},
		{
			name: "MissingOrgUnit",
			request: RoleUpdateDetail{
				Name: "Role",
				Permissions: []ResourcePermissions{{
					ResourceServerID: "rs1",
					Permissions:      []string{"perm1"},
				}},
			},
			errCode: ErrorInvalidRequestFormat.Code,
		},
	}

	for _, tc := range testCases {
		suite.T().Run(tc.name, func(t *testing.T) {
			result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", tc.request)
			suite.Nil(result)
			suite.NotNil(err)
			suite.Equal(tc.errCode, err.Code)
		})
	}
}

func (suite *RoleServiceTestSuite) TestUpdateRole_GetRoleError() {
	request := RoleUpdateDetail{
		Name:        "New Name",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{}, errors.New("database error"))

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_OUNotFound() {
	request := RoleUpdateDetail{
		Name:        "New Name",
		OUID:        "nonexistent_ou",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockSharingService.EXPECT().IsVisible(mock.Anything, RoleSharingType, "role1", "nonexistent_ou").
		Return(false, &oupkg.ErrorOrganizationUnitNotFound)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "nonexistent_ou").
		Return(oupkg.OrganizationUnit{}, &oupkg.ErrorOrganizationUnitNotFound)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorOrganizationUnitNotFound.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_OUServiceError() {
	request := RoleUpdateDetail{
		Name:        "New Name",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").
		Return(oupkg.OrganizationUnit{}, &tidcommon.ServiceError{Code: "INTERNAL_ERROR"})

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_UpdateStoreError() {
	request := RoleUpdateDetail{
		Name:        "New Name",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1"}
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockStore.On("CheckRoleNameExistsExcludingID", mock.Anything,
		"ou1", "New Name", "role1").Return(false, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
		Return(nil, nil)
	suite.mockStore.On("UpdateRole", mock.Anything,
		mock.AnythingOfType("string"),
		mock.AnythingOfType("RoleUpdateDetail")).Return(errors.New("update error"))

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_Success() {
	// This test also verifies permission validation is called correctly during update
	request := RoleUpdateDetail{
		Name:        "New Name",
		Description: "Updated description",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1", "perm2"}}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1", Handle: "default"}
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1", "perm2"}).Return([]string{}, nil)
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockStore.On("CheckRoleNameExistsExcludingID", mock.Anything,
		"ou1", "New Name", "role1").Return(false, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
		Return(nil, nil)
	suite.mockStore.On("UpdateRole", mock.Anything,
		mock.AnythingOfType("string"),
		mock.AnythingOfType("RoleUpdateDetail")).Return(nil)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(err)
	suite.NotNil(result)
	suite.Equal("New Name", result.Name)
	suite.Equal("Updated description", result.Description)
	suite.Equal("default", result.OUHandle)
	suite.True(result.IsOwnedByOU)
	// Verify permission validation was called
	suite.mockResourceService.AssertCalled(suite.T(), "ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1", "perm2"})
}

func (suite *RoleServiceTestSuite) TestUpdateRole_RoleNotFound() {
	request := RoleUpdateDetail{
		Name:        "New Name",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	suite.mockStore.On("GetRole", mock.Anything, "nonexistent").Return(RoleWithPermissions{}, ErrRoleNotFound)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "nonexistent", request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorRoleNotFound.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_NameConflict() {
	request := RoleUpdateDetail{
		Name:        "Conflicting Name",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1"}
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockStore.On("CheckRoleNameExistsExcludingID", mock.Anything,
		"ou1", "Conflicting Name",
		"role1").Return(true, nil)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(ErrorRoleNameConflict.Code, err.Code)
}

// updateWithSharedRoles stubs an update of role1 in ou1, where ou1 owns no role named name and is
// shared one other role.
func (suite *RoleServiceTestSuite) updateWithSharedRoles(name string, shared []Role, sharedErr error) {
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(oupkg.OrganizationUnit{ID: "ou1"}, nil)
	suite.mockStore.On("CheckRoleNameExistsExcludingID", mock.Anything, "ou1", name, "role1").Return(false, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
		Return([]string{"shared1"}, nil)
	suite.mockStore.On("GetRolesByIDs", mock.Anything, []string{"shared1"}).Return(shared, sharedErr)
}

// Renaming a role to the name of one shared with its organization unit is refused.
func (suite *RoleServiceTestSuite) TestUpdateRole_NameTakenBySharedRole() {
	suite.updateWithSharedRoles("Shared Name", []Role{{ID: "shared1", Name: "Shared Name"}}, nil)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", RoleUpdateDetail{
		Name: "Shared Name", OUID: "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	})

	suite.Nil(result)
	suite.Require().NotNil(err)
	suite.Equal(ErrorRoleNameConflict.Code, err.Code)
	suite.mockStore.AssertNotCalled(suite.T(), "UpdateRole", mock.Anything, mock.Anything, mock.Anything)
}

// A shared role with another name leaves the name free.
func (suite *RoleServiceTestSuite) TestUpdateRole_NameFreeAmongSharedRoles() {
	suite.updateWithSharedRoles("New Name", []Role{{ID: "shared1", Name: "Other Name"}}, nil)
	suite.mockStore.On("UpdateRole", mock.Anything, "role1", mock.AnythingOfType("RoleUpdateDetail")).Return(nil)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", RoleUpdateDetail{
		Name: "New Name", OUID: "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	})

	suite.Require().Nil(err)
	suite.Equal("New Name", result.Name)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_SharedRoleNamesReadFailure() {
	suite.updateWithSharedRoles("New Name", nil, errors.New("db down"))

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", RoleUpdateDetail{
		Name: "New Name", OUID: "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	})

	suite.Nil(result)
	suite.Require().NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_CheckNameExistsError() {
	request := RoleUpdateDetail{
		Name:        "New Name",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1"}
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockStore.On("CheckRoleNameExistsExcludingID", mock.Anything,
		"ou1", "New Name", "role1").
		Return(false, errors.New("database error"))

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_PermissionValidationErrors() {
	testCases := []struct {
		name          string
		request       RoleUpdateDetail
		setupMocks    func()
		expectedError *tidcommon.ServiceError
	}{
		{
			name: "InvalidPermissionsOnUpdate",
			request: RoleUpdateDetail{
				Name:        "Updated Role",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
			},
			setupMocks: func() {
				// Permission validation happens before the role is read in UpdateRole
				suite.mockResourceService.On("ValidatePermissions", mock.Anything,
					"rs1", []string{"perm1"}).
					Return([]string{"perm1"}, nil).Once()
			},
			expectedError: &ErrorInvalidPermissions,
		},
		{
			name: "PermissionValidationServiceError",
			request: RoleUpdateDetail{
				Name:        "Updated Role",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
			},
			setupMocks: func() {
				// Permission validation happens before the role is read in UpdateRole
				suite.mockResourceService.On("ValidatePermissions", mock.Anything,
					"rs1", []string{"perm1"}).
					Return([]string{}, &tidcommon.ServiceError{Code: "INTERNAL_ERROR"}).Once()
			},
			expectedError: &tidcommon.InternalServerError,
		},
		{
			name: "EmptyResourceServerIDOnUpdate",
			request: RoleUpdateDetail{
				Name:        "Updated Role",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{{ResourceServerID: "", Permissions: []string{"perm1"}}},
			},
			setupMocks: func() {
				// Resource service should not be called for empty resource server ID
				// Early validation should fail before any other calls
			},
			expectedError: &ErrorInvalidPermissions,
		},
		{
			name: "MultipleResourceServersOnUpdate",
			request: RoleUpdateDetail{
				Name:        "Updated Role",
				Description: "Updated description",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{
					{ResourceServerID: "rs1", Permissions: []string{"perm1"}},
					{ResourceServerID: "rs2", Permissions: []string{"perm2"}},
				},
			},
			setupMocks: func() {
				ou := oupkg.OrganizationUnit{ID: "ou1"}
				suite.mockResourceService.On("ValidatePermissions", mock.Anything,
					"rs1", []string{"perm1"}).
					Return([]string{}, nil).Once()
				suite.mockResourceService.On("ValidatePermissions", mock.Anything,
					"rs2", []string{"perm2"}).
					Return([]string{}, nil).Once()
				suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil).Once()
				suite.mockStore.On("CheckRoleNameExistsExcludingID", mock.Anything,
					"ou1",
					"Updated Role", "role1").Return(false, nil).Once()
				suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
					Return(nil, nil)
				suite.mockStore.On("UpdateRole", mock.Anything,
					mock.AnythingOfType("string"),
					mock.AnythingOfType("RoleUpdateDetail")).Return(nil).Once()
			},
			expectedError: nil, // Success case
		},
		{
			name: "EmptyPermissionsArrayOnUpdate",
			request: RoleUpdateDetail{
				Name:        "Updated Role",
				Description: "Updated description",
				OUID:        "ou1",
				Permissions: []ResourcePermissions{},
			},
			setupMocks: func() {
				ou := oupkg.OrganizationUnit{ID: "ou1"}
				suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil).Once()
				suite.mockStore.On("CheckRoleNameExistsExcludingID", mock.Anything,
					"ou1",
					"Updated Role", "role1").Return(false, nil).Once()
				suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
					Return(nil, nil)
				suite.mockStore.On("UpdateRole", mock.Anything,
					mock.AnythingOfType("string"),
					mock.AnythingOfType("RoleUpdateDetail")).Return(nil).Once()
				// Resource service should NOT be called for empty permissions
			},
			expectedError: nil, // Success case
		},
	}

	for _, tc := range testCases {
		suite.T().Run(tc.name, func(t *testing.T) {
			// Setup fresh mocks for this test case
			suite.SetupTest()
			suite.mockStore.On("GetRole", mock.Anything, "role1").
				Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil).Maybe()
			tc.setupMocks()

			result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", tc.request)

			if tc.expectedError != nil {
				suite.Nil(result)
				suite.NotNil(err)
				suite.Equal(tc.expectedError.Code, err.Code)
			} else {
				suite.Nil(err)
				suite.NotNil(result)
			}
		})
	}
}

// DeleteRole Tests
func (suite *RoleServiceTestSuite) TestDeleteRole_Success() {
	suite.mockStore.On("IsRoleExist", mock.Anything,
		"role1").Return(true, nil)
	suite.mockSharingService.EXPECT().DeletePoliciesForResource(mock.Anything, RoleSharingType, "role1").
		Return(nil).Once()
	suite.mockStore.On("DeleteAssignmentsByRoleID", mock.Anything,
		"role1").Return(nil)
	suite.mockStore.On("DeleteRole", mock.Anything,
		"role1").Return(nil)

	err := suite.service.DeleteRole(context.Background(), "role1")

	suite.Nil(err)
}

func (suite *RoleServiceTestSuite) TestDeleteRole_WithAssignments() {
	suite.mockStore.On("IsRoleExist", mock.Anything,
		"role1").Return(true, nil)
	suite.mockSharingService.EXPECT().DeletePoliciesForResource(mock.Anything, RoleSharingType, "role1").
		Return(nil).Once()
	suite.mockStore.On("DeleteAssignmentsByRoleID", mock.Anything,
		"role1").Return(nil)
	suite.mockStore.On("DeleteRole", mock.Anything,
		"role1").Return(nil)

	err := suite.service.DeleteRole(context.Background(), "role1")

	suite.Nil(err)
}

func (suite *RoleServiceTestSuite) TestDeleteRole_NotFound_ReturnsNil() {
	suite.mockStore.On("IsRoleExist", mock.Anything,
		"nonexistent").Return(false, nil)

	err := suite.service.DeleteRole(context.Background(), "nonexistent")

	suite.Nil(err)
}

func (suite *RoleServiceTestSuite) TestDeleteRole_MissingID() {
	err := suite.service.DeleteRole(context.Background(), "")

	suite.NotNil(err)
	suite.Equal(ErrorMissingRoleID.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestDeleteRole_GetRoleError() {
	suite.mockStore.On("IsRoleExist", mock.Anything,
		"role1").Return(false, errors.New("database error"))

	err := suite.service.DeleteRole(context.Background(), "role1")

	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestDeleteRole_GetAssignmentsCountError() {
	suite.mockStore.On("IsRoleExist", mock.Anything,
		"role1").Return(true, nil)
	suite.mockSharingService.EXPECT().DeletePoliciesForResource(mock.Anything, RoleSharingType, "role1").
		Return(nil).Once()
	suite.mockStore.On("DeleteAssignmentsByRoleID", mock.Anything,
		"role1").Return(errors.New("database error"))

	err := suite.service.DeleteRole(context.Background(), "role1")

	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestDeleteRole_StoreError() {
	suite.mockStore.On("IsRoleExist", mock.Anything,
		"role1").Return(true, nil)
	suite.mockSharingService.EXPECT().DeletePoliciesForResource(mock.Anything, RoleSharingType, "role1").
		Return(nil).Once()
	suite.mockStore.On("DeleteAssignmentsByRoleID", mock.Anything,
		"role1").Return(nil)
	suite.mockStore.On("DeleteRole", mock.Anything,
		"role1").Return(errors.New("delete error"))

	err := suite.service.DeleteRole(context.Background(), "role1")

	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

// The role's sharing policies go before the role does, and a failure to remove them leaves the
// role in place to retry.
func (suite *RoleServiceTestSuite) TestDeleteRole_SharingPolicyRemovalFails() {
	suite.mockStore.On("IsRoleExist", mock.Anything, "role1").Return(true, nil)
	suite.mockSharingService.EXPECT().DeletePoliciesForResource(mock.Anything, RoleSharingType, "role1").
		Return(&tidcommon.InternalServerError).Once()

	err := suite.service.DeleteRole(context.Background(), "role1")

	suite.Require().NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
	suite.mockStore.AssertNotCalled(suite.T(), "DeleteAssignmentsByRoleID", mock.Anything, mock.Anything)
	suite.mockStore.AssertNotCalled(suite.T(), "DeleteRole", mock.Anything, mock.Anything)
}

// The policy purge runs in the transaction that deletes the role, so a failed role delete rolls it
// back and the role stays shared as it was.
func (suite *RoleServiceTestSuite) TestDeleteRole_PurgesPoliciesInTheRoleTransaction() {
	type txKey struct{}
	txr := transactionmock.NewTransactionerMock(suite.T())
	txr.EXPECT().Transact(mock.Anything, mock.Anything).
		RunAndReturn(func(ctx context.Context, txFunc func(context.Context) error) error {
			return txFunc(context.WithValue(ctx, txKey{}, true))
		}).Once()
	suite.service = newRoleService(suite.mockStore, suite.mockEntityService, suite.mockGroupService,
		suite.mockOUService, suite.mockResourceService, txr, newAllowAllRoleAuthz(suite.T()),
		suite.mockSharingService)
	inTx := mock.MatchedBy(func(ctx context.Context) bool { return ctx.Value(txKey{}) != nil })
	suite.mockStore.On("IsRoleExist", mock.Anything, "role1").Return(true, nil)
	suite.mockSharingService.EXPECT().DeletePoliciesForResource(inTx, RoleSharingType, "role1").Return(nil).Once()
	suite.mockStore.On("DeleteAssignmentsByRoleID", inTx, "role1").Return(nil)
	suite.mockStore.On("DeleteRole", inTx, "role1").Return(errors.New("db down"))

	err := suite.service.DeleteRole(context.Background(), "role1")

	suite.Require().NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

// DeleteRole Declarative Mode Tests
func (suite *RoleServiceTestSuite) TestDeleteRole_DeclarativeMode_Denied() {
	// Setup declarative-only mode
	testConfig := &config.Config{
		DeclarativeResources: config.DeclarativeResources{
			Enabled: true,
		},
		Role: config.RoleConfig{
			Store: "declarative",
		},
	}
	config.ResetServerRuntime()
	initErr := config.InitializeServerRuntime("/tmp/test", testConfig)
	if initErr != nil {
		suite.Fail("Failed to initialize runtime", initErr)
	}
	defer config.ResetServerRuntime()

	suite.mockStore.On("IsRoleExist", mock.Anything, "role1").Return(true, nil)
	suite.mockStore.On("IsRoleDeclarative", mock.Anything, "role1").Return(true, nil)

	err2 := suite.service.DeleteRole(context.Background(), "role1")

	suite.NotNil(err2)
	suite.Equal(ErrorImmutableRole.Code, err2.Code)
}

func (suite *RoleServiceTestSuite) TestDeleteRole_DeclarativeCheckError_Refused() {
	config.GetServerRuntime().Config.Role.Store = string(serverconst.StoreModeComposite)
	suite.mockStore.On("IsRoleExist", mock.Anything, "role1").Return(true, nil)
	suite.mockStore.On("IsRoleDeclarative", mock.Anything, "role1").Return(false, errors.New("db down"))

	err := suite.service.DeleteRole(context.Background(), "role1")

	suite.Require().NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
	suite.mockStore.AssertNotCalled(suite.T(), "DeleteRole", mock.Anything, mock.Anything)
}

// validateAssignmentIDs Tests
func (suite *RoleServiceTestSuite) TestValidateAssignmentIDs_UserServiceError() {
	request := RoleCreationDetail{
		Name:        "Test Role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
		Assignments: []RoleAssignment{{ID: "user1", Type: AssigneeTypeUser}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1"}
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockEntityService.On("GetEntitiesByIDs", mock.Anything,
		[]string{"user1"}).
		Return([]providers.Entity{}, errors.New("internal error"))

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestValidateAssignmentIDs_GroupServiceError() {
	request := RoleCreationDetail{
		Name:        "Test Role",
		OUID:        "ou1",
		Permissions: []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"perm1"}}},
		Assignments: []RoleAssignment{{ID: "group1", Type: AssigneeTypeGroup}},
	}

	ou := oupkg.OrganizationUnit{ID: "ou1"}
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").Return(ou, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"perm1"}).Return([]string{}, nil)
	suite.mockGroupService.On("ValidateGroupIDs", mock.Anything,
		[]string{"group1"}).
		Return(&tidcommon.ServiceError{Code: "INTERNAL_ERROR"})

	result, err := suite.service.CreateRole(context.Background(), request)

	suite.Nil(result)
	suite.NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

// Utility functions tests
func (suite *RoleServiceTestSuite) TestBuildPaginationLinks() {
	testCases := []struct {
		name        string
		base        string
		limit       int
		offset      int
		totalCount  int
		expectFirst bool
		expectPrev  bool
		expectNext  bool
		expectLast  bool
	}{
		{
			name:        "FirstPage",
			base:        "/roles",
			limit:       10,
			offset:      0,
			totalCount:  30,
			expectFirst: false,
			expectPrev:  false,
			expectNext:  true,
			expectLast:  true,
		},
		{
			name:        "MiddlePage",
			base:        "/roles",
			limit:       10,
			offset:      10,
			totalCount:  30,
			expectFirst: true,
			expectPrev:  true,
			expectNext:  true,
			expectLast:  true,
		},
		{
			name:        "LastPage",
			base:        "/roles",
			limit:       10,
			offset:      20,
			totalCount:  30,
			expectFirst: true,
			expectPrev:  true,
			expectNext:  false,
			expectLast:  false,
		},
		{
			name:        "SinglePage",
			base:        "/roles",
			limit:       10,
			offset:      0,
			totalCount:  5,
			expectFirst: false,
			expectPrev:  false,
			expectNext:  false,
			expectLast:  false,
		},
	}

	for _, tc := range testCases {
		suite.T().Run(tc.name, func(t *testing.T) {
			links := utils.BuildPaginationLinks(tc.base, tc.limit, tc.offset, tc.totalCount, "")

			hasFirst := false
			hasPrev := false
			hasNext := false
			hasLast := false

			for _, link := range links {
				switch link.Rel {
				case "first":
					hasFirst = true
				case "prev":
					hasPrev = true
				case "next":
					hasNext = true
				case "last":
					hasLast = true
				}
			}

			suite.Equal(tc.expectFirst, hasFirst, "first link mismatch")
			suite.Equal(tc.expectPrev, hasPrev, "prev link mismatch")
			suite.Equal(tc.expectNext, hasNext, "next link mismatch")
			suite.Equal(tc.expectLast, hasLast, "last link mismatch")
		})
	}
}

// GetAuthorizedPermissions Tests - Consolidated for efficiency while maintaining coverage
func (suite *RoleServiceTestSuite) TestGetAuthorizedPermissions() {
	testCases := []struct {
		name                 string
		userID               string
		groups               []string
		requestedPermissions []string
		mockReturn           []string
		mockError            error
		expectedPermissions  []string
		expectedError        *tidcommon.ServiceError
		skipMock             bool
	}{
		{
			name:                 "Success_UserAndGroups",
			userID:               testUserID1,
			groups:               []string{"group1", "group2"},
			requestedPermissions: []string{"perm1", "perm2", "perm3"},
			mockReturn:           []string{"perm1", "perm3"},
			expectedPermissions:  []string{"perm1", "perm3"},
		},
		{
			name:                 "Success_UserOnly_NilGroupsNormalized",
			userID:               testUserID1,
			groups:               nil, // Tests both nil and empty groups normalization
			requestedPermissions: []string{"perm1", "perm2"},
			mockReturn:           []string{"perm1"},
			expectedPermissions:  []string{"perm1"},
		},
		{
			name:                 "Success_GroupsOnly",
			userID:               "",
			groups:               []string{"group1", "group2"},
			requestedPermissions: []string{"perm1", "perm2"},
			mockReturn:           []string{"perm1"},
			expectedPermissions:  []string{"perm1"},
		},
		{
			name:                 "Success_NoAuthorizedPermissions",
			userID:               testUserID1,
			groups:               []string{"group1"},
			requestedPermissions: []string{"perm1", "perm2"},
			mockReturn:           []string{}, // User has no permissions
			expectedPermissions:  []string{},
		},
		{
			name:                 "Success_AllPermissionsAuthorized",
			userID:               testUserID1,
			groups:               []string{"group1"},
			requestedPermissions: []string{"perm1", "perm2"},
			mockReturn:           []string{"perm1", "perm2"}, // All permissions authorized
			expectedPermissions:  []string{"perm1", "perm2"},
		},
		{
			name:                 "EmptyAndNilRequestedPermissions_ReturnsEmpty",
			userID:               testUserID1,
			groups:               []string{"group1"},
			requestedPermissions: nil, // Also covers empty []string{} case
			expectedPermissions:  []string{},
			skipMock:             true, // No store call for empty permissions
		},
		{
			name:                 "MissingUserAndGroups_Error",
			userID:               "",
			groups:               nil, // Covers both nil and empty cases
			requestedPermissions: []string{"perm1", "perm2"},
			expectedError:        &ErrorMissingEntityOrGroups,
			skipMock:             true,
		},
		{
			name:                 "StoreError_ReturnsInternalError",
			userID:               testUserID1,
			groups:               []string{"group1"},
			requestedPermissions: []string{"perm1", "perm2"},
			mockError:            errors.New("database error"),
			expectedError:        &tidcommon.InternalServerError,
		},
	}

	for _, tc := range testCases {
		suite.Run(tc.name, func() {
			if !tc.skipMock {
				normalizedGroups := tc.groups
				if normalizedGroups == nil {
					normalizedGroups = []string{}
				}
				suite.mockStore.On("GetAuthorizedPermissionsByResourceServer", mock.Anything,
					tc.userID, normalizedGroups, []string{}, "", "",
					tc.requestedPermissions).
					Return(tc.mockReturn, tc.mockError).Once()
			}

			result, err := suite.service.GetAuthorizedPermissionsByResourceServer(
				context.Background(), tc.userID, tc.groups, nil, "", "",
				tc.requestedPermissions)

			if tc.expectedError != nil {
				suite.NotNil(err)
				suite.Equal(tc.expectedError.Code, err.Code)
				suite.Nil(result)
			} else {
				suite.Nil(err)
				suite.NotNil(result)
				if len(tc.requestedPermissions) == 0 {
					suite.Equal(0, len(result))
				} else {
					suite.Equal(len(tc.expectedPermissions), len(result))
					suite.Equal(tc.expectedPermissions, result)
				}
			}
		})
	}
}

// Tests for IsRoleDeclarative (public method)
func (suite *RoleServiceTestSuite) TestIsRoleDeclarative_ReturnsTrue() {
	suite.mockStore.On("IsRoleDeclarative", mock.Anything, "declarative-role").Return(true, nil)

	isDeclarative, err := suite.service.IsRoleDeclarative(context.Background(), "declarative-role")

	suite.Nil(err)
	suite.True(isDeclarative)
	suite.mockStore.AssertCalled(suite.T(), "IsRoleDeclarative", mock.Anything, "declarative-role")
}

func (suite *RoleServiceTestSuite) TestIsRoleDeclarative_ReturnsFalse() {
	suite.mockStore.On("IsRoleDeclarative", mock.Anything, "mutable-role").Return(false, nil)

	isDeclarative, err := suite.service.IsRoleDeclarative(context.Background(), "mutable-role")

	suite.Nil(err)
	suite.False(isDeclarative)
}

func (suite *RoleServiceTestSuite) TestIsRoleDeclarative_StoreReturnsError() {
	storeErr := errors.New("store error")
	suite.mockStore.On("IsRoleDeclarative", mock.Anything, "role-id").Return(false, storeErr)

	isDeclarative, err := suite.service.IsRoleDeclarative(context.Background(), "role-id")

	suite.NotNil(err)
	suite.False(isDeclarative)
	suite.Equal(&tidcommon.InternalServerError, err)
}

// TestResolveRoleOUHandle_OUHandleResolved verifies that when only ou_handle is set, it is
// resolved to ou_id via the OU service.
func (suite *RoleServiceTestSuite) TestResolveRoleOUHandle_OUHandleResolved() {
	suite.mockOUService.On("GetOrganizationUnitByPath", mock.Anything, "default").
		Return(oupkg.OrganizationUnit{ID: "ou-resolved"}, (*tidcommon.ServiceError)(nil)).Once()

	role := &RoleWithPermissionsAndAssignments{OUHandle: "default"}
	svcErr := suite.service.ResolveRoleOUHandle(context.Background(), role)

	suite.Nil(svcErr)
	suite.Equal("ou-resolved", role.OUID)
}

// TestResolveRoleOUHandle_OUIDAlreadySet verifies that no resolution happens when ou_id is set
// and ou_handle is empty.
func (suite *RoleServiceTestSuite) TestResolveRoleOUHandle_OUIDAlreadySet() {
	role := &RoleWithPermissionsAndAssignments{OUID: "ou-direct"}
	svcErr := suite.service.ResolveRoleOUHandle(context.Background(), role)

	suite.Nil(svcErr)
	suite.Equal("ou-direct", role.OUID)
}

// TestResolveRoleOUHandle_BothProvided verifies that when both ou_id and ou_handle are
// provided, ou_id is retained and the OU service is never called.
func (suite *RoleServiceTestSuite) TestResolveRoleOUHandle_BothProvided() {
	role := &RoleWithPermissionsAndAssignments{ID: "r1", Name: "Admin", OUID: "ou-direct", OUHandle: "default"}

	svcErr := suite.service.ResolveRoleOUHandle(context.Background(), role)

	suite.Nil(svcErr)
	suite.Equal("ou-direct", role.OUID)
	// AssertExpectations in t.Cleanup will confirm GetOrganizationUnitByPath was never invoked.
}

// TestResolveRoleOUHandle_OUHandleNotFound verifies that a not-found response from the OU
// service is surfaced as ErrorInvalidRequestFormat.
func (suite *RoleServiceTestSuite) TestResolveRoleOUHandle_OUHandleNotFound() {
	suite.mockOUService.On("GetOrganizationUnitByPath", mock.Anything, "missing").
		Return(oupkg.OrganizationUnit{}, &oupkg.ErrorOrganizationUnitNotFound).Once()

	role := &RoleWithPermissionsAndAssignments{OUHandle: "missing"}
	svcErr := suite.service.ResolveRoleOUHandle(context.Background(), role)

	suite.NotNil(svcErr)
	suite.Equal(ErrorInvalidRequestFormat.Code, svcErr.Code)
}

// TestResolveRoleOUHandle_NeitherProvided verifies that the call is a no-op when neither
// ou_id nor ou_handle is provided.
func (suite *RoleServiceTestSuite) TestResolveRoleOUHandle_NeitherProvided() {
	role := &RoleWithPermissionsAndAssignments{}
	svcErr := suite.service.ResolveRoleOUHandle(context.Background(), role)

	suite.Nil(svcErr)
	suite.Empty(role.OUID)
}

// TestResolveRoleOUHandle_NilOUService verifies that a clear error is returned when the OU
// service is nil and ou_handle is supplied (no nil-pointer panic).
func (suite *RoleServiceTestSuite) TestResolveRoleOUHandle_NilOUService() {
	svc := &roleService{ouService: nil}
	role := &RoleWithPermissionsAndAssignments{OUHandle: "default"}

	svcErr := svc.ResolveRoleOUHandle(context.Background(), role)

	suite.NotNil(svcErr)
	suite.Equal(tidcommon.InternalServerError.Code, svcErr.Code)
}

// TestRoleDeclarativeYAML_OUHandleParsed verifies that ou_handle is parsed off the YAML
// document into the role declarative resource.
func TestRoleDeclarativeYAML_OUHandleParsed(t *testing.T) {
	yamlData := []byte(`
id: role-1
name: Admin
ouHandle: default
permissions:
  - resourceServerId: rs1
    permissions:
      - read
`)
	role, err := parseToRole(yamlData)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if role.OUHandle != "default" {
		t.Errorf("OUHandle = %q, want %q", role.OUHandle, "default")
	}
	if role.OUID != "" {
		t.Errorf("OUID = %q, want empty (resolution happens later)", role.OUID)
	}
}

// CascadeDeleteDependencies Tests

func (suite *RoleServiceTestSuite) TestGetResourceDependencies_ReportsNoUsages() {
	deps, err := suite.service.GetResourceDependencies(
		context.Background(), resourcedependency.ResourceTypeResource, "res1")

	suite.NoError(err)
	suite.Empty(deps)
}

func (suite *RoleServiceTestSuite) TestCascadeDeleteDependencies_IgnoresUnrelatedResourceTypes() {
	for _, resourceType := range []string{
		resourcedependency.ResourceTypeUser,
		resourcedependency.ResourceTypeGroup,
		resourcedependency.ResourceTypeApplication,
	} {
		deleted, err := suite.service.CascadeDeleteDependencies(context.Background(), resourceType, "id1")

		suite.NoError(err)
		suite.Equal(0, deleted)
	}

	suite.mockStore.AssertNotCalled(suite.T(), "GetReferencedPermissions", mock.Anything)
}

func (suite *RoleServiceTestSuite) TestCascadeDeleteDependencies_RemovesOrphanedPermissions() {
	suite.mockStore.On("GetReferencedPermissions", mock.Anything).Return([]ResourcePermissions{
		{ResourceServerID: "rs1", Permissions: []string{"read", "write"}},
	}, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"read", "write"}).Return([]string{"write"}, nil)
	suite.mockStore.On("DeleteRolePermission", mock.Anything, "rs1", "write").Return(int64(2), nil)

	deleted, err := suite.service.CascadeDeleteDependencies(
		context.Background(), resourcedependency.ResourceTypeAction, "action1")

	suite.NoError(err)
	suite.Equal(2, deleted)
	suite.mockStore.AssertNotCalled(suite.T(), "DeleteRolePermission", mock.Anything, "rs1", "read")
}

func (suite *RoleServiceTestSuite) TestCascadeDeleteDependencies_KeepsValidPermissions() {
	suite.mockStore.On("GetReferencedPermissions", mock.Anything).Return([]ResourcePermissions{
		{ResourceServerID: "rs1", Permissions: []string{"read"}},
	}, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"read"}).Return([]string{}, nil)

	deleted, err := suite.service.CascadeDeleteDependencies(
		context.Background(), resourcedependency.ResourceTypeResource, "res1")

	suite.NoError(err)
	suite.Equal(0, deleted)
	suite.mockStore.AssertNotCalled(suite.T(), "DeleteRolePermission",
		mock.Anything, mock.Anything, mock.Anything)
}

// A deleted resource server invalidates every permission scoped to it, so all of them are removed
// while permissions of other resource servers are left alone.
func (suite *RoleServiceTestSuite) TestCascadeDeleteDependencies_RemovesAllPermissionsOfDeletedServer() {
	suite.mockStore.On("GetReferencedPermissions", mock.Anything).Return([]ResourcePermissions{
		{ResourceServerID: "rs1", Permissions: []string{"read", "write"}},
		{ResourceServerID: "rs2", Permissions: []string{"list"}},
	}, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"read", "write"}).Return([]string{"read", "write"}, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs2", []string{"list"}).Return([]string{}, nil)
	suite.mockStore.On("DeleteRolePermission", mock.Anything, "rs1", "read").Return(int64(1), nil)
	suite.mockStore.On("DeleteRolePermission", mock.Anything, "rs1", "write").Return(int64(1), nil)

	deleted, err := suite.service.CascadeDeleteDependencies(
		context.Background(), resourcedependency.ResourceTypeResourceServer, "rs1")

	suite.NoError(err)
	suite.Equal(2, deleted)
	suite.mockStore.AssertNotCalled(suite.T(), "DeleteRolePermission", mock.Anything, "rs2", "list")
}

func (suite *RoleServiceTestSuite) TestCascadeDeleteDependencies_StoreReadError() {
	suite.mockStore.On("GetReferencedPermissions", mock.Anything).
		Return([]ResourcePermissions{}, errors.New("database error"))

	deleted, err := suite.service.CascadeDeleteDependencies(
		context.Background(), resourcedependency.ResourceTypeResource, "res1")

	suite.Error(err)
	suite.Equal(0, deleted)
}

func (suite *RoleServiceTestSuite) TestCascadeDeleteDependencies_ValidationError() {
	suite.mockStore.On("GetReferencedPermissions", mock.Anything).Return([]ResourcePermissions{
		{ResourceServerID: "rs1", Permissions: []string{"read"}},
	}, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"read"}).Return([]string(nil), &tidcommon.InternalServerError)

	deleted, err := suite.service.CascadeDeleteDependencies(
		context.Background(), resourcedependency.ResourceTypeResource, "res1")

	suite.Error(err)
	suite.Equal(0, deleted)
}

func (suite *RoleServiceTestSuite) TestCascadeDeleteDependencies_DeleteError() {
	suite.mockStore.On("GetReferencedPermissions", mock.Anything).Return([]ResourcePermissions{
		{ResourceServerID: "rs1", Permissions: []string{"read"}},
	}, nil)
	suite.mockResourceService.On("ValidatePermissions", mock.Anything,
		"rs1", []string{"read"}).Return([]string{"read"}, nil)
	suite.mockStore.On("DeleteRolePermission", mock.Anything, "rs1", "read").
		Return(int64(0), errors.New("database error"))

	deleted, err := suite.service.CascadeDeleteDependencies(
		context.Background(), resourcedependency.ResourceTypeResource, "res1")

	suite.Error(err)
	suite.Equal(0, deleted)
}

// newAllowAllRoleAuthz returns an authz mock that permits every grant check, so that
// tests unrelated to the guard need not configure it.
func newAllowAllRoleAuthz(t *testing.T) sysauthz.SystemAuthorizationServiceInterface {
	mockAuthz := sysauthzmock.NewSystemAuthorizationServiceInterfaceMock(t)
	mockAuthz.On("CanGrantPermissions", mock.Anything, mock.Anything).
		Return((*tidcommon.ServiceError)(nil)).Maybe()
	mockAuthz.On("CanGrantMembership", mock.Anything, mock.Anything, mock.Anything).
		Return((*tidcommon.ServiceError)(nil)).Maybe()
	return mockAuthz
}

// RoleChangeValidationTestSuite tests the role service's pre-revocation validations.
type RoleChangeValidationTestSuite struct {
	suite.Suite
	store     *roleStoreInterfaceMock
	groups    *groupmock.GroupServiceInterfaceMock
	ous       *oumock.OrganizationUnitServiceInterfaceMock
	resources *resourcemock.ResourceServiceInterfaceMock
	authz     *sysauthzmock.SystemAuthorizationServiceInterfaceMock
	service   RoleServiceInterface
}

func TestRoleChangeValidationTestSuite(t *testing.T) {
	suite.Run(t, new(RoleChangeValidationTestSuite))
}

func (s *RoleChangeValidationTestSuite) SetupTest() {
	config.ResetServerRuntime()
	s.Require().NoError(config.InitializeServerRuntime("/tmp/test", &config.Config{
		Role: config.RoleConfig{Store: string(serverconst.StoreModeComposite)},
	}))
	s.store = newRoleStoreInterfaceMock(s.T())
	s.groups = groupmock.NewGroupServiceInterfaceMock(s.T())
	s.ous = oumock.NewOrganizationUnitServiceInterfaceMock(s.T())
	s.resources = resourcemock.NewResourceServiceInterfaceMock(s.T())
	s.authz = sysauthzmock.NewSystemAuthorizationServiceInterfaceMock(s.T())
	s.service = newRoleService(s.store, nil, s.groups, s.ous, s.resources, &fakeTransactioner{}, s.authz, nil)
}

func (s *RoleChangeValidationTestSuite) TearDownTest() {
	config.ResetServerRuntime()
}

func (s *RoleChangeValidationTestSuite) mutableRoleGranting(permissions []ResourcePermissions) {
	s.store.On("GetRole", mock.Anything, targetRoleID).
		Return(RoleWithPermissions{ID: targetRoleID, OUID: "ou-1", Permissions: permissions}, nil)
	s.ous.On("GetOrganizationUnit", mock.Anything, "ou-1").Return(oupkg.OrganizationUnit{ID: "ou-1"}, nil)
	s.store.On("IsRoleDeclarative", mock.Anything, targetRoleID).Return(false, nil)
}

func (s *RoleChangeValidationTestSuite) mutableRoleGrantingLicense() {
	s.mutableRoleGranting([]ResourcePermissions{{ResourceServerID: californiaRSID, Permissions: []string{"license"}}})
	stubResourceServer(s.resources, californiaRSID, californiaAud)
}

func (s *RoleChangeValidationTestSuite) assignedTo(assignments ...RoleAssignment) {
	s.store.On("GetRoleAssignmentsCount", mock.Anything, targetRoleID, mock.Anything).Return(len(assignments), nil)
	if len(assignments) > 0 {
		s.store.On("GetRoleAssignments", mock.Anything, targetRoleID, mock.Anything, serverconst.MaxPageSize, 0).
			Return(assignments, nil)
	}
}

func (s *RoleChangeValidationTestSuite) mayChangePermissions(permissions security.PermissionSet) {
	for resourceServerID, scopes := range permissions {
		s.resources.On("ValidatePermissions", mock.Anything, resourceServerID, scopes).Return([]string{}, nil)
	}
	s.authz.On("CanGrantPermissions", mock.Anything, permissions).Return(nil)
}

// groupConveying stubs a group whose own and ancestor roles grant one Californian scope.
func (s *RoleChangeValidationTestSuite) groupConveying(ancestors ...string) {
	s.groups.On("GetTransitiveAncestorGroups", mock.Anything, targetGroupID).Return(ancestors, nil)
	s.store.On("GetAllPermissionsForAssignees", mock.Anything, "", append([]string{targetGroupID}, ancestors...)).
		Return([]ResourcePermissions{{ResourceServerID: californiaRSID, Permissions: []string{"license"}}}, nil)
	stubResourceServer(s.resources, californiaRSID, californiaAud)
}

func (s *RoleChangeValidationTestSuite) mayRemoveMember(member group.Member) {
	s.groups.On("ValidateRemoveGroupMembers", mock.Anything, targetGroupID, []group.Member{member}).Return(nil)
}

func (s *RoleChangeValidationTestSuite) TestValidateDeleteRole_CoversEveryAssignee() {
	s.mutableRoleGrantingLicense()
	s.assignedTo(
		RoleAssignment{ID: targetUserID, Type: assigneeTypeEntity},
		RoleAssignment{ID: targetGroupID, Type: AssigneeTypeGroup})
	stubGroupEntities(s.groups, targetGroupID, "member-1")

	target, svcErr := s.service.ValidateDeleteRole(context.Background(), targetRoleID)

	s.Require().Nil(svcErr)
	s.ElementsMatch([]string{targetUserID, "member-1"}, target.EntityIDs)
	s.Equal([]revocation.AudienceScope{{Audience: californiaAud, Scope: "license"}}, target.Scopes)
}

func (s *RoleChangeValidationTestSuite) TestValidateDeleteRole_DeduplicatesAssignees() {
	s.mutableRoleGrantingLicense()
	s.assignedTo(
		RoleAssignment{ID: targetUserID, Type: assigneeTypeEntity},
		RoleAssignment{ID: targetGroupID, Type: AssigneeTypeGroup})
	stubGroupEntities(s.groups, targetGroupID, targetUserID)

	target, svcErr := s.service.ValidateDeleteRole(context.Background(), targetRoleID)

	s.Require().Nil(svcErr)
	s.Equal([]string{targetUserID}, target.EntityIDs)
}

func (s *RoleChangeValidationTestSuite) TestValidateDeleteRole_RoleWithoutAssignees() {
	s.mutableRoleGrantingLicense()
	s.assignedTo()

	target, svcErr := s.service.ValidateDeleteRole(context.Background(), targetRoleID)

	s.Require().Nil(svcErr)
	s.Empty(target.EntityIDs)
}

func (s *RoleChangeValidationTestSuite) TestValidateDeleteRole_RoleWithoutPermissionsSkipsTheAssignees() {
	s.mutableRoleGranting(nil)

	target, svcErr := s.service.ValidateDeleteRole(context.Background(), targetRoleID)

	s.Require().Nil(svcErr)
	s.Empty(target.Scopes)
	s.store.AssertNotCalled(s.T(), "GetRoleAssignmentsCount", mock.Anything, mock.Anything, mock.Anything)
}

func (s *RoleChangeValidationTestSuite) TestValidateDeleteRole_RefusesDeclarativeRole() {
	s.store.On("GetRole", mock.Anything, targetRoleID).Return(RoleWithPermissions{ID: targetRoleID}, nil)
	s.ous.On("GetOrganizationUnit", mock.Anything, "").Return(oupkg.OrganizationUnit{}, nil)
	s.store.On("IsRoleDeclarative", mock.Anything, targetRoleID).Return(true, nil)

	_, svcErr := s.service.ValidateDeleteRole(context.Background(), targetRoleID)

	s.Require().NotNil(svcErr)
	s.Equal(ErrorImmutableRole.Code, svcErr.Code)
}

func (s *RoleChangeValidationTestSuite) TestValidateDeleteRole_RequiresARole() {
	_, svcErr := s.service.ValidateDeleteRole(context.Background(), "")

	s.Require().NotNil(svcErr)
	s.Equal(ErrorMissingRoleID.Code, svcErr.Code)
}

func (s *RoleChangeValidationTestSuite) TestValidateDeleteRole_CarriesARoleReadFailure() {
	s.store.On("GetRole", mock.Anything, targetRoleID).Return(RoleWithPermissions{}, ErrRoleNotFound)

	_, svcErr := s.service.ValidateDeleteRole(context.Background(), targetRoleID)

	s.Require().NotNil(svcErr)
	s.Equal(ErrorRoleNotFound.Code, svcErr.Code)
}

func (s *RoleChangeValidationTestSuite) TestValidateDeleteRole_DeclarativeCheckFailureIsAServerError() {
	s.store.On("GetRole", mock.Anything, targetRoleID).Return(RoleWithPermissions{ID: targetRoleID}, nil)
	s.ous.On("GetOrganizationUnit", mock.Anything, "").Return(oupkg.OrganizationUnit{}, nil)
	s.store.On("IsRoleDeclarative", mock.Anything, targetRoleID).Return(false, errors.New("db down"))

	_, svcErr := s.service.ValidateDeleteRole(context.Background(), targetRoleID)

	s.Require().NotNil(svcErr)
	s.Equal(tidcommon.InternalServerError.Code, svcErr.Code)
}

func (s *RoleChangeValidationTestSuite) TestValidateDeleteRole_CarriesAResourceServerLookupFailure() {
	s.mutableRoleGranting([]ResourcePermissions{{ResourceServerID: californiaRSID, Permissions: []string{"license"}}})
	s.resources.On("GetResourceServer", mock.Anything, californiaRSID).Return(nil, &tidcommon.InternalServerError)

	_, svcErr := s.service.ValidateDeleteRole(context.Background(), targetRoleID)

	s.Require().NotNil(svcErr)
	s.Equal(tidcommon.InternalServerError.Code, svcErr.Code)
}

func (s *RoleChangeValidationTestSuite) TestValidateDeleteRole_AssignmentReadFailures() {
	cases := map[string]struct {
		setup func()
		want  tidcommon.ServiceError
	}{
		"count failure": {func() {
			s.store.On("GetRoleAssignmentsCount", mock.Anything, targetRoleID, mock.Anything).
				Return(0, errors.New("db down"))
		}, tidcommon.InternalServerError},
		"count over the composite limit": {func() {
			s.store.On("GetRoleAssignmentsCount", mock.Anything, targetRoleID, mock.Anything).
				Return(0, errResultLimitExceededInCompositeMode)
		}, ResultLimitExceededInCompositeMode},
		"page failure": {func() {
			s.store.On("GetRoleAssignmentsCount", mock.Anything, targetRoleID, mock.Anything).Return(1, nil)
			s.store.On("GetRoleAssignments", mock.Anything, targetRoleID, mock.Anything, serverconst.MaxPageSize, 0).
				Return(nil, errors.New("db down"))
		}, tidcommon.InternalServerError},
		"page over the composite limit": {func() {
			s.store.On("GetRoleAssignmentsCount", mock.Anything, targetRoleID, mock.Anything).Return(1, nil)
			s.store.On("GetRoleAssignments", mock.Anything, targetRoleID, mock.Anything, serverconst.MaxPageSize, 0).
				Return(nil, errResultLimitExceededInCompositeMode)
		}, ResultLimitExceededInCompositeMode},
		"group assignee expansion failure": {func() {
			s.assignedTo(RoleAssignment{ID: targetGroupID, Type: AssigneeTypeGroup})
			s.groups.On("GetTransitiveMemberEntities", mock.Anything, targetGroupID).
				Return(nil, &tidcommon.InternalServerError)
		}, tidcommon.InternalServerError},
	}
	for name, tc := range cases {
		s.Run(name, func() {
			s.SetupTest()
			s.mutableRoleGrantingLicense()
			tc.setup()

			_, svcErr := s.service.ValidateDeleteRole(context.Background(), targetRoleID)

			s.Require().NotNil(svcErr)
			s.Equal(tc.want.Code, svcErr.Code)
		})
	}
}

func (s *RoleChangeValidationTestSuite) TestValidateUpdateRolePermissions_RevokesOnlyTheDroppedPermissions() {
	s.mutableRoleGranting([]ResourcePermissions{
		{ResourceServerID: californiaRSID, Permissions: []string{"license", "permits"}}})
	stubResourceServer(s.resources, californiaRSID, californiaAud)
	s.assignedTo(RoleAssignment{ID: targetUserID, Type: assigneeTypeEntity})
	s.mayChangePermissions(security.PermissionSet{californiaRSID: {"license"}})

	target, svcErr := s.service.ValidateUpdateRolePermissions(context.Background(), targetRoleID,
		[]ResourcePermissions{{ResourceServerID: californiaRSID, Permissions: []string{"license"}}})

	s.Require().Nil(svcErr)
	s.Equal([]string{targetUserID}, target.EntityIDs)
	s.Equal([]revocation.AudienceScope{{Audience: californiaAud, Scope: "permits"}}, target.Scopes)
}

func (s *RoleChangeValidationTestSuite) TestValidateUpdateRolePermissions_DropsAScopeMovedToAnotherResourceServer() {
	s.mutableRoleGrantingLicense()
	s.assignedTo(RoleAssignment{ID: targetUserID, Type: assigneeTypeEntity})
	s.mayChangePermissions(security.PermissionSet{ohioRSID: {"license"}})

	target, svcErr := s.service.ValidateUpdateRolePermissions(context.Background(), targetRoleID,
		[]ResourcePermissions{{ResourceServerID: ohioRSID, Permissions: []string{"license"}}})

	s.Require().Nil(svcErr)
	s.Equal([]revocation.AudienceScope{{Audience: californiaAud, Scope: "license"}}, target.Scopes)
}

func (s *RoleChangeValidationTestSuite) TestValidateUpdateRolePermissions_NothingDroppedRevokesNothing() {
	s.mutableRoleGranting([]ResourcePermissions{{ResourceServerID: californiaRSID, Permissions: []string{"license"}}})
	s.mayChangePermissions(security.PermissionSet{californiaRSID: {"license", "permits"}})

	target, svcErr := s.service.ValidateUpdateRolePermissions(context.Background(), targetRoleID,
		[]ResourcePermissions{{ResourceServerID: californiaRSID, Permissions: []string{"license", "permits"}}})

	s.Require().Nil(svcErr)
	s.Require().NotNil(target)
	s.Empty(target.Scopes)
	s.store.AssertNotCalled(s.T(), "GetRoleAssignmentsCount", mock.Anything, mock.Anything, mock.Anything)
}

func (s *RoleChangeValidationTestSuite) TestValidateUpdateRolePermissions_RefusesAnUnknownPermission() {
	s.mutableRoleGranting(nil)
	s.resources.On("ValidatePermissions", mock.Anything, "rs-unknown", []string{"license"}).
		Return([]string{"license"}, nil)

	_, svcErr := s.service.ValidateUpdateRolePermissions(context.Background(), targetRoleID,
		[]ResourcePermissions{{ResourceServerID: "rs-unknown", Permissions: []string{"license"}}})

	s.Require().NotNil(svcErr)
	s.Equal(ErrorInvalidPermissions.Code, svcErr.Code)
	s.authz.AssertNotCalled(s.T(), "CanGrantPermissions", mock.Anything, mock.Anything)
}

func (s *RoleChangeValidationTestSuite) TestValidateUpdateRolePermissions_RefusesAnUngrantablePermission() {
	s.mutableRoleGranting(nil)
	s.resources.On("ValidatePermissions", mock.Anything, californiaRSID, []string{"license"}).Return([]string{}, nil)
	s.authz.On("CanGrantPermissions", mock.Anything, security.PermissionSet{californiaRSID: {"license"}}).
		Return(&tidcommon.ErrorUnauthorized)

	_, svcErr := s.service.ValidateUpdateRolePermissions(context.Background(), targetRoleID,
		[]ResourcePermissions{{ResourceServerID: californiaRSID, Permissions: []string{"license"}}})

	s.Require().NotNil(svcErr)
	s.Equal(tidcommon.ErrorUnauthorized.Code, svcErr.Code)
}

func (s *RoleChangeValidationTestSuite) TestValidateUpdateRolePermissions_RefusesDeclarativeRole() {
	s.store.On("GetRole", mock.Anything, targetRoleID).Return(RoleWithPermissions{ID: targetRoleID}, nil)
	s.ous.On("GetOrganizationUnit", mock.Anything, "").Return(oupkg.OrganizationUnit{}, nil)
	s.store.On("IsRoleDeclarative", mock.Anything, targetRoleID).Return(true, nil)

	_, svcErr := s.service.ValidateUpdateRolePermissions(context.Background(), targetRoleID, nil)

	s.Require().NotNil(svcErr)
	s.Equal(ErrorImmutableRole.Code, svcErr.Code)
	s.resources.AssertNotCalled(s.T(), "ValidatePermissions", mock.Anything, mock.Anything, mock.Anything)
}

func (s *RoleChangeValidationTestSuite) TestValidateGroupDeletion_CoversEveryMember() {
	s.groups.On("ValidateDeleteGroup", mock.Anything, targetGroupID).Return(nil)
	s.groupConveying("parent-group")
	stubGroupEntities(s.groups, targetGroupID, "member-1")

	target, svcErr := s.service.ValidateGroupDeletion(context.Background(), targetGroupID)

	s.Require().Nil(svcErr)
	s.Equal([]string{"member-1"}, target.EntityIDs)
	s.Equal([]revocation.AudienceScope{{Audience: californiaAud, Scope: "license"}}, target.Scopes)
	s.Empty(target.AssigneeType)
}

func (s *RoleChangeValidationTestSuite) TestValidateGroupMembershipRemoval_TargetsOnlyTheDepartingMember() {
	departing := group.Member{ID: targetUserID, Type: group.MemberTypeUser}
	stubDirectMember(s.groups, targetUserID, &departing)
	s.mayRemoveMember(departing)
	s.groupConveying()

	target, svcErr := s.service.ValidateGroupMembershipRemoval(context.Background(), targetGroupID, targetUserID)

	s.Require().Nil(svcErr)
	s.Equal([]string{targetUserID}, target.EntityIDs)
	s.Equal(string(group.MemberTypeUser), target.AssigneeType)
}

func (s *RoleChangeValidationTestSuite) TestValidateGroupMembershipRemoval_ExpandsADepartingGroup() {
	departing := group.Member{ID: "child-group", Type: group.MemberTypeGroup}
	stubDirectMember(s.groups, "child-group", &departing)
	s.mayRemoveMember(departing)
	s.groupConveying()
	stubGroupEntities(s.groups, "child-group", "member-1")

	target, svcErr := s.service.ValidateGroupMembershipRemoval(context.Background(), targetGroupID, "child-group")

	s.Require().Nil(svcErr)
	s.Equal([]string{"member-1"}, target.EntityIDs)
	s.Equal(string(group.MemberTypeGroup), target.AssigneeType)
}

func (s *RoleChangeValidationTestSuite) TestValidateGroupMembershipRemoval_RefusesANonMember() {
	stubDirectMember(s.groups, targetUserID, nil)

	_, svcErr := s.service.ValidateGroupMembershipRemoval(context.Background(), targetGroupID, targetUserID)

	s.Require().NotNil(svcErr)
	s.Equal(group.ErrorInvalidMemberID.Code, svcErr.Code)
	s.groups.AssertNotCalled(s.T(), "ValidateRemoveGroupMembers", mock.Anything, mock.Anything, mock.Anything)
}

func (s *RoleChangeValidationTestSuite) TestValidateGroupChanges_CarryTheGroupServiceRefusal() {
	for name, refusal := range map[string]*tidcommon.ServiceError{
		"declarative group":        &group.ErrorImmutableGroup,
		"member outside the OU":    &tidcommon.ErrorUnauthorized,
		"access check unavailable": &tidcommon.InternalServerError,
	} {
		s.Run(name+" on deletion", func() {
			s.SetupTest()
			s.groups.On("ValidateDeleteGroup", mock.Anything, targetGroupID).Return(refusal)

			_, svcErr := s.service.ValidateGroupDeletion(context.Background(), targetGroupID)

			s.Require().NotNil(svcErr)
			s.Equal(refusal.Code, svcErr.Code)
			s.groups.AssertNotCalled(s.T(), "GetTransitiveAncestorGroups", mock.Anything, mock.Anything)
		})
		s.Run(name+" on member removal", func() {
			s.SetupTest()
			departing := group.Member{ID: targetUserID, Type: group.MemberTypeUser}
			stubDirectMember(s.groups, targetUserID, &departing)
			s.groups.On("ValidateRemoveGroupMembers", mock.Anything, targetGroupID, []group.Member{departing}).
				Return(refusal)

			_, svcErr := s.service.ValidateGroupMembershipRemoval(context.Background(), targetGroupID, targetUserID)

			s.Require().NotNil(svcErr)
			s.Equal(refusal.Code, svcErr.Code)
			s.groups.AssertNotCalled(s.T(), "GetTransitiveAncestorGroups", mock.Anything, mock.Anything)
		})
	}
}

func (s *RoleChangeValidationTestSuite) TestValidateGroupMembershipRemoval_CarriesTheMemberListingFailure() {
	s.groups.On("GetDirectGroupMember", mock.Anything, targetGroupID, targetUserID).
		Return(nil, &group.ErrorGroupNotFound)

	_, svcErr := s.service.ValidateGroupMembershipRemoval(context.Background(), targetGroupID, targetUserID)

	s.Require().NotNil(svcErr)
	s.Equal(group.ErrorGroupNotFound.Code, svcErr.Code)
}

func (s *RoleChangeValidationTestSuite) TestValidateGroupDeletion_ScopeResolutionFailures() {
	cases := map[string]func(){
		"ancestor walk failure": func() {
			s.groups.On("GetTransitiveAncestorGroups", mock.Anything, targetGroupID).
				Return(nil, &tidcommon.InternalServerError)
		},
		"permission read failure": func() {
			s.groups.On("GetTransitiveAncestorGroups", mock.Anything, targetGroupID).Return([]string{}, nil)
			s.store.On("GetAllPermissionsForAssignees", mock.Anything, "", []string{targetGroupID}).
				Return(nil, errors.New("db down"))
		},
		"resource server lookup failure": func() {
			s.groups.On("GetTransitiveAncestorGroups", mock.Anything, targetGroupID).Return([]string{}, nil)
			s.store.On("GetAllPermissionsForAssignees", mock.Anything, "", []string{targetGroupID}).
				Return([]ResourcePermissions{{ResourceServerID: californiaRSID, Permissions: []string{"license"}}}, nil)
			s.resources.On("GetResourceServer", mock.Anything, californiaRSID).
				Return(nil, &tidcommon.InternalServerError)
		},
	}
	for name, setup := range cases {
		s.Run(name, func() {
			s.SetupTest()
			s.groups.On("ValidateDeleteGroup", mock.Anything, targetGroupID).Return(nil)
			setup()

			_, svcErr := s.service.ValidateGroupDeletion(context.Background(), targetGroupID)

			s.Require().NotNil(svcErr)
			s.Equal(tidcommon.InternalServerError.Code, svcErr.Code)
		})
	}
}

func (s *RoleChangeValidationTestSuite) TestValidateGroupChanges_CarryAMemberExpansionFailure() {
	s.Run("deletion", func() {
		s.SetupTest()
		s.groups.On("ValidateDeleteGroup", mock.Anything, targetGroupID).Return(nil)
		s.groupConveying()
		s.groups.On("GetTransitiveMemberEntities", mock.Anything, targetGroupID).
			Return(nil, &tidcommon.InternalServerError)

		_, svcErr := s.service.ValidateGroupDeletion(context.Background(), targetGroupID)

		s.Require().NotNil(svcErr)
		s.Equal(tidcommon.InternalServerError.Code, svcErr.Code)
	})
	s.Run("departing group", func() {
		s.SetupTest()
		departing := group.Member{ID: "child-group", Type: group.MemberTypeGroup}
		stubDirectMember(s.groups, "child-group", &departing)
		s.mayRemoveMember(departing)
		s.groupConveying()
		s.groups.On("GetTransitiveMemberEntities", mock.Anything, "child-group").
			Return(nil, &tidcommon.InternalServerError)

		_, svcErr := s.service.ValidateGroupMembershipRemoval(context.Background(), targetGroupID, "child-group")

		s.Require().NotNil(svcErr)
		s.Equal(tidcommon.InternalServerError.Code, svcErr.Code)
	})
}

// stubSharedRole makes role1 resolve to a role owned by ou-owner, as every sharing call first does.
func (suite *RoleServiceTestSuite) stubSharedRole() {
	suite.mockStore.On("GetRole", mock.Anything, "role1").
		Return(RoleWithPermissions{ID: "role1", Name: "Support Agent", OUID: "ou-owner"}, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou-owner").
		Return(oupkg.OrganizationUnit{ID: "ou-owner", Handle: "owner"}, nil).Maybe()
}

func (suite *RoleServiceTestSuite) useDeclarativeRoleStore() {
	config.ResetServerRuntime()
	suite.Require().NoError(config.InitializeServerRuntime("/tmp/test", &config.Config{
		DeclarativeResources: config.DeclarativeResources{Enabled: true},
		Role:                 config.RoleConfig{Store: "declarative"},
	}))
	suite.T().Cleanup(config.ResetServerRuntime)
}

// A create is recorded against the role's owner, which the caller does not state.
func (suite *RoleServiceTestSuite) TestCreateSharingPolicyPassesTheRolesOwner() {
	suite.stubSharedRole()
	req := sharing.PolicyRequest{ChildUnits: &sharing.ChildUnitsRequest{Mode: sharing.ChildUnitsAll}}
	suite.mockSharingService.EXPECT().
		CreatePolicy(mock.Anything, RoleSharingType, "role1", "ou-owner", req).
		Return(sharing.Policy{ID: "p1", ResourceType: RoleSharingType, ResourceID: "role1"}, nil)

	policy, svcErr := suite.service.CreateSharingPolicy(context.Background(), "role1", req)

	suite.Require().Nil(svcErr)
	suite.Equal("p1", policy.ID)
}

// An unknown role answers as one, not as a sharing failure.
func (suite *RoleServiceTestSuite) TestCreateSharingPolicyOnAnUnknownRoleIsNotFound() {
	suite.mockStore.On("GetRole", mock.Anything, "missing").Return(RoleWithPermissions{}, ErrRoleNotFound)

	_, svcErr := suite.service.CreateSharingPolicy(context.Background(), "missing", sharing.PolicyRequest{})

	suite.Require().NotNil(svcErr)
	suite.Equal(ErrorRoleNotFound.Code, svcErr.Code)
}

// A declared role's own sharing is declared with it, so its owner may not add a policy through the
// API. A sharee's policy is that sharee's decision and is not refused for it.
func (suite *RoleServiceTestSuite) TestCreateSharingPolicyRefusesTheOwnerOfADeclaredRole() {
	config.GetServerRuntime().Config.Role.Store = string(serverconst.StoreModeComposite)
	suite.stubSharedRole()
	suite.mockStore.On("IsRoleDeclarative", mock.Anything, "role1").Return(true, nil)

	_, svcErr := suite.service.CreateSharingPolicy(context.Background(), "role1",
		sharing.PolicyRequest{InitiatingOUID: "ou-owner"})
	suite.Require().NotNil(svcErr)
	suite.Equal(ErrorImmutableRole.Code, svcErr.Code)

	reshare := sharing.PolicyRequest{InitiatingOUID: "ou-child"}
	suite.mockSharingService.EXPECT().
		CreatePolicy(mock.Anything, RoleSharingType, "role1", "ou-owner", reshare).
		Return(sharing.Policy{ID: "p2"}, nil)
	policy, svcErr := suite.service.CreateSharingPolicy(context.Background(), "role1", reshare)
	suite.Require().Nil(svcErr)
	suite.Equal("p2", policy.ID)
}

// With roles loading from resource files only, every policy is declared there.
func (suite *RoleServiceTestSuite) TestSharingPolicyWritesAreRefusedInDeclarativeMode() {
	suite.useDeclarativeRoleStore()
	suite.stubSharedRole()
	suite.mockSharingService.EXPECT().GetPolicy(mock.Anything, "p1").
		Return(sharing.Policy{ID: "p1", ResourceType: RoleSharingType, ResourceID: "role1"}, nil)

	_, svcErr := suite.service.CreateSharingPolicy(context.Background(), "role1", sharing.PolicyRequest{})
	suite.Require().NotNil(svcErr)
	suite.Equal(ErrorImmutableRole.Code, svcErr.Code)

	_, svcErr = suite.service.UpdateSharingPolicy(context.Background(), "role1", "p1", sharing.PolicyRequest{})
	suite.Require().NotNil(svcErr)
	suite.Equal(ErrorImmutableRole.Code, svcErr.Code)

	svcErr = suite.service.DeleteSharingPolicy(context.Background(), "role1", "p1")
	suite.Require().NotNil(svcErr)
	suite.Equal(ErrorImmutableRole.Code, svcErr.Code)
}

// A policy id alone must not reach another resource's policy through this role's path.
func (suite *RoleServiceTestSuite) TestSharingPolicyOfAnotherResourceIsNotFound() {
	for _, tc := range []struct {
		name   string
		policy sharing.Policy
	}{
		{"another role's policy", sharing.Policy{ID: "p1", ResourceType: RoleSharingType, ResourceID: "role2"}},
		{"an application's policy", sharing.Policy{ID: "p1", ResourceType: "application", ResourceID: "role1"}},
	} {
		suite.Run(tc.name, func() {
			suite.SetupTest()
			suite.stubSharedRole()
			suite.mockSharingService.EXPECT().GetPolicy(mock.Anything, "p1").Return(tc.policy, nil)

			_, svcErr := suite.service.GetSharingPolicy(context.Background(), "role1", "p1")
			suite.Require().NotNil(svcErr)
			suite.Equal(ErrorSharingPolicyNotFound.Code, svcErr.Code)

			_, svcErr = suite.service.UpdateSharingPolicy(context.Background(), "role1", "p1", sharing.PolicyRequest{})
			suite.Require().NotNil(svcErr)
			suite.Equal(ErrorSharingPolicyNotFound.Code, svcErr.Code)

			suite.Nil(suite.service.DeleteSharingPolicy(context.Background(), "role1", "p1"),
				"a delete of a policy this role does not hold has nothing to do")
		})
	}
}

// An edit of the role's own policy reaches the framework.
func (suite *RoleServiceTestSuite) TestUpdateSharingPolicyReachesTheFramework() {
	suite.stubSharedRole()
	own := sharing.Policy{ID: "p1", ResourceType: RoleSharingType, ResourceID: "role1", Version: 1}
	req := sharing.PolicyRequest{Version: 1, ChildUnits: &sharing.ChildUnitsRequest{Mode: sharing.ChildUnitsAll}}
	suite.mockSharingService.EXPECT().GetPolicy(mock.Anything, "p1").Return(own, nil)
	suite.mockSharingService.EXPECT().UpdatePolicy(mock.Anything, "p1", req).
		Return(sharing.Policy{ID: "p1", Version: 2}, nil)

	policy, svcErr := suite.service.UpdateSharingPolicy(context.Background(), "role1", "p1", req)

	suite.Require().Nil(svcErr)
	suite.Equal(2, policy.Version)
}

func (suite *RoleServiceTestSuite) TestDeleteSharingPolicyRemovesTheRolesOwnPolicy() {
	suite.stubSharedRole()
	suite.mockSharingService.EXPECT().GetPolicy(mock.Anything, "p1").
		Return(sharing.Policy{ID: "p1", ResourceType: RoleSharingType, ResourceID: "role1"}, nil)
	suite.mockSharingService.EXPECT().DeletePolicy(mock.Anything, "p1").Return(nil)

	suite.Nil(suite.service.DeleteSharingPolicy(context.Background(), "role1", "p1"))
}

// A delete of a policy that is already gone succeeds, so a retried delete does not fail.
func (suite *RoleServiceTestSuite) TestDeleteSharingPolicyIsIdempotent() {
	suite.stubSharedRole()
	suite.mockSharingService.EXPECT().GetPolicy(mock.Anything, "gone").
		Return(sharing.Policy{}, &sharing.ErrorPolicyNotFound)

	suite.Nil(suite.service.DeleteSharingPolicy(context.Background(), "role1", "gone"))
}

// A policy declared in a resource file goes away with the file, not through the API.
func (suite *RoleServiceTestSuite) TestDeleteSharingPolicyRefusesADeclaredOne() {
	suite.stubSharedRole()
	suite.mockSharingService.EXPECT().GetPolicy(mock.Anything, "p1").Return(sharing.Policy{
		ID: "p1", ResourceType: RoleSharingType, ResourceID: "role1", Declared: true}, nil)

	svcErr := suite.service.DeleteSharingPolicy(context.Background(), "role1", "p1")

	suite.Require().NotNil(svcErr)
	suite.Equal(ErrorSharingPolicyDeclared.Code, svcErr.Code)
}

func (suite *RoleServiceTestSuite) TestListSharingPoliciesPagesTheRolesPolicies() {
	suite.stubSharedRole()
	suite.mockSharingService.EXPECT().GetPolicyList(mock.Anything, RoleSharingType, "role1", 10, 0).
		Return(sharing.PolicyList{TotalResults: 1, Policies: []sharing.Policy{{ID: "p1"}}}, nil)

	list, svcErr := suite.service.ListSharingPolicies(context.Background(), "role1", 10, 0)

	suite.Require().Nil(svcErr)
	suite.Equal(1, list.TotalResults)
}

func (suite *RoleServiceTestSuite) TestResolveSharingOverlayRequiresAnOrganizationUnit() {
	suite.stubSharedRole()

	_, svcErr := suite.service.ResolveSharingOverlay(context.Background(), "role1", "")

	suite.Require().NotNil(svcErr)
	suite.Equal(ErrorMissingOUIDParameter.Code, svcErr.Code)
}

func (suite *RoleServiceTestSuite) TestResolveSharingOverlayAnswersAReachedUnit() {
	suite.stubSharedRole()
	suite.mockSharingService.EXPECT().ResolveOverlayRules(mock.Anything, RoleSharingType, "role1", "ou-child").
		Return(sharing.ResolvedOverlay{OUID: "ou-child", Visible: true}, nil)

	overlay, svcErr := suite.service.ResolveSharingOverlay(context.Background(), "role1", "ou-child")

	suite.Require().Nil(svcErr)
	suite.True(overlay.Visible)
}

// An organization unit the role never reached, and an id naming no organization unit, answer alike.
func (suite *RoleServiceTestSuite) TestResolveSharingOverlayRefusesAnUnreachedUnit() {
	for _, tc := range []struct {
		name    string
		overlay sharing.ResolvedOverlay
		svcErr  *tidcommon.ServiceError
	}{
		{"an unreached unit", sharing.ResolvedOverlay{OUID: "stranger"}, nil},
		{"an unknown unit", sharing.ResolvedOverlay{}, &oupkg.ErrorOrganizationUnitNotFound},
	} {
		suite.Run(tc.name, func() {
			suite.SetupTest()
			suite.stubSharedRole()
			suite.mockSharingService.EXPECT().
				ResolveOverlayRules(mock.Anything, RoleSharingType, "role1", "stranger").
				Return(tc.overlay, tc.svcErr)

			_, svcErr := suite.service.ResolveSharingOverlay(context.Background(), "role1", "stranger")

			suite.Require().NotNil(svcErr)
			suite.Equal(ErrorRoleNotSharedToOU.Code, svcErr.Code)
		})
	}
}

// The framework's refusals come back in this package's vocabulary, and its failures as a server
// error.
func (suite *RoleServiceTestSuite) TestTranslateSharingError() {
	for _, tc := range []struct {
		name string
		from *tidcommon.ServiceError
		want string
	}{
		{"no such policy", &sharing.ErrorPolicyNotFound, ErrorSharingPolicyNotFound.Code},
		{"a second policy for one unit", &sharing.ErrorPolicyExists, ErrorSharingPolicyExists.Code},
		{"a stale version", &sharing.ErrorVersionMismatch, ErrorSharingPolicyVersionMismatch.Code},
		{"a declared policy", &sharing.ErrorPolicyDeclared, ErrorSharingPolicyDeclared.Code},
		{"a bad limit", &sharing.ErrorInvalidLimit, ErrorInvalidLimit.Code},
		{"a bad offset", &sharing.ErrorInvalidOffset, ErrorInvalidOffset.Code},
		{"a unit the issuer may not name", &sharing.ErrorInvalidTargetOU, ErrorInvalidSharingPolicy.Code},
		{"a section changing kind", &sharing.ErrorScopeFamilyChange, ErrorInvalidSharingPolicy.Code},
		{"a framework failure", &tidcommon.InternalServerError, tidcommon.InternalServerError.Code},
	} {
		suite.Run(tc.name, func() {
			translated := translateSharingError(tc.from)
			suite.Require().NotNil(translated)
			suite.Equal(tc.want, translated.Code)
		})
	}
	suite.Nil(translateSharingError(nil))
}

// moveTarget stubs a role owned by ou1 that ou2 cannot see, so an update naming ou2 moves the role
// there.
func (suite *RoleServiceTestSuite) moveTarget() {
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockSharingService.EXPECT().IsVisible(mock.Anything, RoleSharingType, "role1", "ou2").Return(false, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou2").
		Return(oupkg.OrganizationUnit{ID: "ou2"}, nil)
	suite.mockStore.On("CheckRoleNameExistsExcludingID", mock.Anything, "ou2", "Role", "role1").Return(false, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou2").
		Return(nil, nil)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_SharedRoleCannotMove() {
	request := RoleUpdateDetail{Name: "Role", OUID: "ou2", Permissions: []ResourcePermissions{}}
	suite.moveTarget()
	suite.mockSharingService.EXPECT().ListPolicies(mock.Anything, RoleSharingType, "role1").
		Return([]sharing.Policy{{ID: "p1"}}, nil)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.Require().NotNil(err)
	suite.Equal(ErrorSharedRoleCannotMove.Code, err.Code)
	suite.mockStore.AssertNotCalled(suite.T(), "UpdateRole", mock.Anything, mock.Anything, mock.Anything)
}

// A role still assigned in its owner is not moved: its assignees were checked against that unit.
func (suite *RoleServiceTestSuite) TestUpdateRole_AssignedRoleCannotMove() {
	request := RoleUpdateDetail{Name: "Role", OUID: "ou2", Permissions: []ResourcePermissions{}}
	suite.moveTarget()
	suite.mockSharingService.EXPECT().ListPolicies(mock.Anything, RoleSharingType, "role1").Return(nil, nil)
	suite.mockStore.On("GetRoleAssignmentsCount", mock.Anything, "role1", "").Return(1, nil)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.Require().NotNil(err)
	suite.Equal(ErrorRoleWithAssignmentsCannotMove.Code, err.Code)
	suite.mockStore.AssertNotCalled(suite.T(), "UpdateRole", mock.Anything, mock.Anything, mock.Anything)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_UnsharedUnassignedRoleMoves() {
	request := RoleUpdateDetail{Name: "Role", OUID: "ou2", Permissions: []ResourcePermissions{}}
	suite.moveTarget()
	suite.mockSharingService.EXPECT().ListPolicies(mock.Anything, RoleSharingType, "role1").Return(nil, nil)
	suite.mockStore.On("GetRoleAssignmentsCount", mock.Anything, "role1", "").Return(0, nil)
	suite.mockStore.On("UpdateRole", mock.Anything, "role1", mock.AnythingOfType("RoleUpdateDetail")).Return(nil)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Require().Nil(err)
	suite.Equal("ou2", result.OUID)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_VisibilityLookupFailure() {
	request := RoleUpdateDetail{Name: "Role", OUID: "ou2", Permissions: []ResourcePermissions{}}
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockSharingService.EXPECT().IsVisible(mock.Anything, RoleSharingType, "role1", "ou2").
		Return(false, &tidcommon.InternalServerError)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.Require().NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
	suite.mockStore.AssertNotCalled(suite.T(), "UpdateRole", mock.Anything, mock.Anything, mock.Anything)
}

// A role's name, description and permissions stay with the organization unit that owns it, so an
// update naming one the role is shared with is refused, whether or not it changes anything.
func (suite *RoleServiceTestSuite) TestUpdateRole_InSharedOU_Refused() {
	permissions := []ResourcePermissions{{ResourceServerID: "rs1", Permissions: []string{"read"}}}
	cases := map[string]RoleUpdateDetail{
		"unchanged":   {Name: "Role", Description: "desc", OUID: "ou-child", Permissions: permissions},
		"name":        {Name: "Renamed", Description: "desc", OUID: "ou-child", Permissions: permissions},
		"description": {Name: "Role", Description: "other", OUID: "ou-child", Permissions: permissions},
		"permissions": {Name: "Role", Description: "desc", OUID: "ou-child", Permissions: []ResourcePermissions{
			{ResourceServerID: "rs1", Permissions: []string{"read", "write"}},
		}},
	}
	for name, request := range cases {
		suite.Run(name, func() {
			suite.SetupTest()
			suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{
				ID: "role1", Name: "Role", Description: "desc", OUID: "ou1", Permissions: permissions,
			}, nil)
			suite.mockSharingService.EXPECT().IsVisible(mock.Anything, RoleSharingType, "role1", "ou-child").
				Return(true, nil)

			result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

			suite.Nil(result)
			suite.Require().NotNil(err)
			suite.Equal(ErrorSharedRoleNotEditable.Code, err.Code)
			suite.mockStore.AssertNotCalled(suite.T(), "UpdateRole", mock.Anything, mock.Anything, mock.Anything)
		})
	}
}

// A shared role can still be edited in place, and an update that keeps the role's organization unit
// does not list its policies.
func (suite *RoleServiceTestSuite) TestUpdateRole_SharedRoleUpdatedInPlace() {
	request := RoleUpdateDetail{Name: "Role", OUID: "ou1", Permissions: []ResourcePermissions{}}
	suite.mockStore.On("GetRole", mock.Anything, "role1").Return(RoleWithPermissions{ID: "role1", OUID: "ou1"}, nil)
	suite.mockOUService.On("GetOrganizationUnit", mock.Anything, "ou1").
		Return(oupkg.OrganizationUnit{ID: "ou1"}, nil)
	suite.mockStore.On("CheckRoleNameExistsExcludingID", mock.Anything, "ou1", "Role", "role1").Return(false, nil)
	suite.mockSharingService.EXPECT().ListVisibleResourceIDs(mock.Anything, RoleSharingType, "ou1").
		Return(nil, nil)
	suite.mockStore.On("UpdateRole", mock.Anything, "role1", mock.AnythingOfType("RoleUpdateDetail")).Return(nil)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(err)
	suite.NotNil(result)
}

func (suite *RoleServiceTestSuite) TestUpdateRole_SharingLookupFailure() {
	request := RoleUpdateDetail{Name: "Role", OUID: "ou2", Permissions: []ResourcePermissions{}}
	suite.moveTarget()
	suite.mockSharingService.EXPECT().ListPolicies(mock.Anything, RoleSharingType, "role1").
		Return(nil, &tidcommon.InternalServerError)

	result, err := suite.service.UpdateRoleWithPermissions(context.Background(), "role1", request)

	suite.Nil(result)
	suite.Require().NotNil(err)
	suite.Equal(tidcommon.InternalServerError.Code, err.Code)
}

func (suite *RoleServiceTestSuite) TestSharingCallsRefuseAMissingRoleID() {
	_, svcErr := suite.service.CreateSharingPolicy(context.Background(), "", sharing.PolicyRequest{})
	suite.Require().NotNil(svcErr)
	suite.Equal(ErrorMissingRoleID.Code, svcErr.Code)

	_, svcErr = suite.service.ResolveSharingOverlay(context.Background(), "", "ou1")
	suite.Require().NotNil(svcErr)
	suite.Equal(ErrorMissingRoleID.Code, svcErr.Code)
}
