// Copyright 2025 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package role

import (
	"context"
	"fmt"

	serverconst "github.com/thunder-id/thunderid/internal/system/constants"
	"github.com/thunder-id/thunderid/internal/system/database/provider"
	"github.com/thunder-id/thunderid/internal/system/deployment"
	"github.com/thunder-id/thunderid/internal/system/log"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"
)

const storeLoggerComponentName = "RoleStore"

var getDBProvider = provider.GetDBProvider

// roleStoreInterface defines the interface for role store operations.
type roleStoreInterface interface {
	GetRoleListCount(ctx context.Context) (int, error)
	GetRoleList(ctx context.Context, limit, offset int) ([]Role, error)
	GetRoleListCountByOUID(ctx context.Context, ouID string) (int, error)
	GetRoleListByOUID(ctx context.Context, ouID string, limit, offset int) ([]Role, error)
	CreateRole(ctx context.Context, id string, role RoleCreationDetail) error
	GetRole(ctx context.Context, id string) (RoleWithPermissions, error)
	GetRolesByNames(ctx context.Context, names []string) ([]Role, error)
	GetRolesByIDs(ctx context.Context, ids []string) ([]Role, error)
	IsRoleExist(ctx context.Context, id string) (bool, error)
	// The assignment reads take the organization unit the assignments were made in. An empty ouID
	// reads the assignments made in every organization unit.
	GetRoleAssignments(ctx context.Context, id, ouID string, limit, offset int) ([]RoleAssignment, error)
	GetRoleAssignmentsByType(ctx context.Context, id, ouID string,
		limit, offset int, assigneeType string) ([]RoleAssignment, error)
	GetRoleAssignmentsCount(ctx context.Context, id, ouID string) (int, error)
	GetRoleAssignmentsCountByType(ctx context.Context, id, ouID string, assigneeType string) (int, error)
	UpdateRole(ctx context.Context, id string, role RoleUpdateDetail) error
	DeleteRole(ctx context.Context, id string) error
	DeleteAssignmentsByRoleID(ctx context.Context, id string) error
	DeleteAssignmentsInOU(ctx context.Context, id, ouID string) error
	DeleteAssignmentsByAssignee(ctx context.Context, assigneeType, assigneeID string) (int64, error)
	AddAssignments(ctx context.Context, id string, assignments []RoleAssignment) error
	RemoveAssignments(ctx context.Context, id string, assignments []RoleAssignment) error
	CheckRoleNameExists(ctx context.Context, ouID, name string) (bool, error)
	CheckRoleNameExistsExcludingID(ctx context.Context, ouID, name, excludeRoleID string) (bool, error)
	// GetAuthorizedPermissionsByResourceServer counts only assignments made in assignmentOUID when
	// one is given, and assignments made anywhere otherwise.
	GetAuthorizedPermissionsByResourceServer(
		ctx context.Context, entityID string, groupIDs, roleIDs []string, assignmentOUID, resourceServerID string,
		requestedPermissions []string) ([]string, error)
	// GetAllPermissionsForAssignees returns every permission the entity and/or groups hold through
	// their assigned roles, grouped by resource server. It takes no filters: it enumerates.
	GetAllPermissionsForAssignees(
		ctx context.Context, entityID string, groupIDs []string) ([]ResourcePermissions, error)
	// GetUserRoles counts only the assignments made in assignmentOUID when one is given.
	GetUserRoles(ctx context.Context, entityID string, groupIDs []string, assignmentOUID string) ([]string, error)
	// GetReferencedPermissions returns the distinct permissions referenced by any role, grouped by
	// resource server. Used to detect permissions left dangling by a resource deletion.
	GetReferencedPermissions(ctx context.Context) ([]ResourcePermissions, error)
	// DeleteRolePermission removes the given permission from every role that holds it.
	DeleteRolePermission(ctx context.Context, resourceServerID, permission string) (int64, error)
	// GetEntityRoleIDs returns the set of role IDs assigned to the entity directly or via
	// group membership. Unlike GetUserRoles this does not require the role to exist in the
	// underlying store; it returns raw assignee->role bindings. Used by the composite store
	// to resolve permissions for declarative roles whose definitions live in the file store
	// while their assignments live in the DB. A non-empty assignmentOUID counts only the
	// assignments made there.
	GetEntityRoleIDs(ctx context.Context, entityID string, groupIDs []string, assignmentOUID string) ([]string, error)
	IsRoleDeclarative(ctx context.Context, roleID string) (bool, error)
}

// roleStore is the default implementation of roleStoreInterface.
type roleStore struct {
	dbProvider provider.DBProviderInterface
}

// newRoleStore creates a new instance of roleStore.
func newRoleStore() (roleStoreInterface, providers.Transactioner, error) {
	dbProvider := getDBProvider()
	client, err := dbProvider.GetConfigDBClient()
	if err != nil {
		return nil, nil, err
	}
	transactioner, err := client.GetTransactioner()
	if err != nil {
		return nil, nil, err
	}
	return &roleStore{
		dbProvider: dbProvider,
	}, transactioner, nil
}

// scope returns the deployment id this request acts for, falling back to the configured
// identifier for a context that never passed through the edge.
func (s *roleStore) scope(ctx context.Context) string {
	return deployment.Resolve(ctx)
}

// GetRoleListCount retrieves the total count of roles.
func (s *roleStore) GetRoleListCount(ctx context.Context) (int, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return 0, err
	}

	countResults, err := dbClient.QueryContext(ctx, queryGetRoleListCount, s.scope(ctx))
	if err != nil {
		return 0, fmt.Errorf("failed to execute count query: %w", err)
	}

	return parseCountResult(countResults)
}

// GetRoleList retrieves roles with pagination.
func (s *roleStore) GetRoleList(ctx context.Context, limit, offset int) ([]Role, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	results, err := dbClient.QueryContext(ctx, queryGetRoleList, limit, offset, s.scope(ctx))
	if err != nil {
		return nil, fmt.Errorf("failed to execute role list query: %w", err)
	}

	roles := make([]Role, 0)
	for _, row := range results {
		role, err := buildRoleBasicInfoFromResultRow(row)
		if err != nil {
			return nil, fmt.Errorf("failed to build role from result row: %w", err)
		}
		roles = append(roles, role)
	}

	return roles, nil
}

// GetRoleListCountByOUID retrieves the total count of roles belonging to the given organization unit.
func (s *roleStore) GetRoleListCountByOUID(ctx context.Context, ouID string) (int, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return 0, err
	}

	countResults, err := dbClient.QueryContext(ctx, queryGetRoleListCountByOUID, ouID, s.scope(ctx))
	if err != nil {
		return 0, fmt.Errorf("failed to execute count query: %w", err)
	}

	return parseCountResult(countResults)
}

// GetRoleListByOUID retrieves roles belonging to the given organization unit with pagination.
func (s *roleStore) GetRoleListByOUID(ctx context.Context, ouID string, limit, offset int) ([]Role, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	results, err := dbClient.QueryContext(ctx, queryGetRoleListByOUID, ouID, limit, offset, s.scope(ctx))
	if err != nil {
		return nil, fmt.Errorf("failed to execute role list query: %w", err)
	}

	roles := make([]Role, 0)
	for _, row := range results {
		role, err := buildRoleBasicInfoFromResultRow(row)
		if err != nil {
			return nil, fmt.Errorf("failed to build role from result row: %w", err)
		}
		roles = append(roles, role)
	}

	return roles, nil
}

// CreateRole creates a new role in the database.
func (s *roleStore) CreateRole(ctx context.Context, id string, role RoleCreationDetail) error {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return err
	}

	_, err = dbClient.ExecuteContext(ctx,
		queryCreateRole,
		id,
		role.OUID,
		role.Name,
		role.Description,
		s.scope(ctx),
	)
	if err != nil {
		return fmt.Errorf("failed to execute query: %w", err)
	}

	if err := addPermissionsToRole(ctx, dbClient, id, role.Permissions, s.scope(ctx)); err != nil {
		return err
	}

	// A role is created in its owner, so that is where the assignments it is created with are made.
	assignments := make([]RoleAssignment, 0, len(role.Assignments))
	for _, a := range role.Assignments {
		assignments = append(assignments, RoleAssignment{ID: a.ID, Type: a.Type, OUID: role.OUID})
	}
	if err := addAssignmentsToRole(ctx, dbClient, id, assignments, s.scope(ctx)); err != nil {
		return err
	}

	return nil
}

// GetRole retrieves a role by its id.
func (s *roleStore) GetRole(ctx context.Context, id string) (RoleWithPermissions, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return RoleWithPermissions{}, err
	}

	results, err := dbClient.QueryContext(ctx, queryGetRoleByID, id, s.scope(ctx))
	if err != nil {
		return RoleWithPermissions{}, fmt.Errorf("failed to execute query: %w", err)
	}

	if len(results) == 0 {
		return RoleWithPermissions{}, ErrRoleNotFound
	}

	if len(results) != 1 {
		return RoleWithPermissions{}, fmt.Errorf("unexpected number of results: %d", len(results))
	}

	row := results[0]
	roleBasicInfo, err := buildRoleBasicInfoFromResultRow(row)
	if err != nil {
		return RoleWithPermissions{}, err
	}

	permissions, err := s.getRolePermissions(ctx, dbClient, id)
	if err != nil {
		return RoleWithPermissions{}, fmt.Errorf("failed to get role permissions: %w", err)
	}

	return RoleWithPermissions{
		ID:          roleBasicInfo.ID,
		Name:        roleBasicInfo.Name,
		Description: roleBasicInfo.Description,
		OUID:        roleBasicInfo.OUID,
		Permissions: permissions,
	}, nil
}

// GetRolesByNames retrieves roles by a list of names, regardless of organization unit.
func (s *roleStore) GetRolesByNames(ctx context.Context, names []string) ([]Role, error) {
	if len(names) == 0 {
		return []Role{}, nil
	}

	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	query, args, err := buildGetRolesByNamesQuery(names, s.scope(ctx))
	if err != nil {
		return nil, fmt.Errorf("failed to build get roles by names query: %w", err)
	}

	results, err := dbClient.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to execute query: %w", err)
	}

	roles := make([]Role, 0, len(results))
	for _, row := range results {
		role, err := buildRoleBasicInfoFromResultRow(row)
		if err != nil {
			return nil, fmt.Errorf("failed to build role from result row: %w", err)
		}
		roles = append(roles, role)
	}

	return roles, nil
}

// GetRolesByIDs retrieves the roles with the given IDs. An ID naming no role is left out.
func (s *roleStore) GetRolesByIDs(ctx context.Context, ids []string) ([]Role, error) {
	if len(ids) == 0 {
		return []Role{}, nil
	}

	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	query, args, err := buildGetRolesByIDsQuery(ids, s.scope(ctx))
	if err != nil {
		return nil, fmt.Errorf("failed to build get roles by ids query: %w", err)
	}

	results, err := dbClient.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to execute query: %w", err)
	}

	roles := make([]Role, 0, len(results))
	for _, row := range results {
		role, err := buildRoleBasicInfoFromResultRow(row)
		if err != nil {
			return nil, fmt.Errorf("failed to build role from result row: %w", err)
		}
		roles = append(roles, role)
	}

	return roles, nil
}

// IsRoleExist checks if a role exists by its ID without fetching its details.
func (s *roleStore) IsRoleExist(ctx context.Context, id string) (bool, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return false, err
	}

	results, err := dbClient.QueryContext(ctx, queryCheckRoleExists, id, s.scope(ctx))
	if err != nil {
		return false, fmt.Errorf("failed to check role existence: %w", err)
	}

	return parseBoolFromCount(results)
}

// GetRoleAssignments retrieves assignments for a role with pagination.
func (s *roleStore) GetRoleAssignments(
	ctx context.Context, id, ouID string, limit, offset int,
) ([]RoleAssignment, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	var results []map[string]interface{}
	if ouID == "" {
		results, err = dbClient.QueryContext(ctx, queryGetRoleAssignments, id, limit, offset, s.scope(ctx))
	} else {
		results, err = dbClient.QueryContext(
			ctx, queryGetRoleAssignmentsInOU, id, ouID, limit, offset, s.scope(ctx))
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get role assignments: %w", err)
	}

	return parseAssignmentResults(results)
}

// GetRoleAssignmentsByType retrieves assignments for a role filtered by assignee type with pagination.
func (s *roleStore) GetRoleAssignmentsByType(
	ctx context.Context, id, ouID string, limit, offset int, assigneeType string,
) ([]RoleAssignment, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	var results []map[string]interface{}
	if ouID == "" {
		results, err = dbClient.QueryContext(
			ctx, queryGetRoleAssignmentsByType, id, limit, offset, s.scope(ctx), assigneeType)
	} else {
		results, err = dbClient.QueryContext(
			ctx, queryGetRoleAssignmentsByTypeInOU, id, assigneeType, ouID, limit, offset, s.scope(ctx))
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get role assignments: %w", err)
	}

	return parseAssignmentResults(results)
}

// parseAssignmentResults parses database query results into role assignments.
func parseAssignmentResults(results []map[string]interface{}) ([]RoleAssignment, error) {
	assignments := make([]RoleAssignment, 0)
	for _, row := range results {
		assigneeID, err := parseStringField(row, "assignee_id")
		if err != nil {
			return nil, err
		}
		assigneeType, err := parseStringField(row, "assignee_type")
		if err != nil {
			return nil, err
		}
		ouID, err := parseStringField(row, "assignment_ou_id")
		if err != nil {
			return nil, err
		}
		assignments = append(assignments, RoleAssignment{
			ID:   assigneeID,
			Type: AssigneeType(assigneeType),
			OUID: ouID,
		})
	}

	return assignments, nil
}

// GetRoleAssignmentsCount retrieves the total count of assignments for a role.
func (s *roleStore) GetRoleAssignmentsCount(ctx context.Context, id, ouID string) (int, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return 0, err
	}

	var countResults []map[string]interface{}
	if ouID == "" {
		countResults, err = dbClient.QueryContext(ctx, queryGetRoleAssignmentsCount, id, s.scope(ctx))
	} else {
		countResults, err = dbClient.QueryContext(ctx, queryGetRoleAssignmentsCountInOU, id, ouID, s.scope(ctx))
	}
	if err != nil {
		return 0, fmt.Errorf("failed to get role assignments count: %w", err)
	}

	return parseCountResult(countResults)
}

// GetRoleAssignmentsCountByType retrieves the total count of assignments for a role filtered by type.
func (s *roleStore) GetRoleAssignmentsCountByType(
	ctx context.Context, id, ouID string, assigneeType string,
) (int, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return 0, err
	}

	var countResults []map[string]interface{}
	if ouID == "" {
		countResults, err = dbClient.QueryContext(
			ctx, queryGetRoleAssignmentsCountByType, id, s.scope(ctx), assigneeType)
	} else {
		countResults, err = dbClient.QueryContext(
			ctx, queryGetRoleAssignmentsCountByTypeInOU, id, assigneeType, ouID, s.scope(ctx))
	}
	if err != nil {
		return 0, fmt.Errorf("failed to get role assignments count: %w", err)
	}

	return parseCountResult(countResults)
}

// UpdateRole updates an existing role.
func (s *roleStore) UpdateRole(ctx context.Context, id string, role RoleUpdateDetail) error {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return err
	}

	rowsAffected, err := dbClient.ExecuteContext(ctx,
		queryUpdateRole,
		role.OUID,
		role.Name,
		role.Description,
		id,
		s.scope(ctx),
	)
	if err != nil {
		return fmt.Errorf("failed to execute query: %w", err)
	}

	if rowsAffected == 0 {
		return ErrRoleNotFound
	}

	if err := updateRolePermissions(ctx, dbClient, id, role.Permissions, s.scope(ctx)); err != nil {
		return err
	}

	return nil
}

// DeleteRole deletes a role.
func (s *roleStore) DeleteRole(ctx context.Context, id string) error {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, storeLoggerComponentName))

	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return err
	}

	rowsAffected, err := dbClient.ExecuteContext(ctx, queryDeleteRole, id, s.scope(ctx))
	if err != nil {
		return fmt.Errorf("failed to execute query: %w", err)
	}

	if rowsAffected == 0 {
		logger.Debug(ctx, "Role not found with id: "+id)
	}

	return nil
}

// DeleteAssignmentsByRoleID deletes all assignments for a role. Used for cascade delete.
func (s *roleStore) DeleteAssignmentsByRoleID(ctx context.Context, id string) error {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return err
	}

	_, err = dbClient.ExecuteContext(ctx, queryDeleteAllRoleAssignments, id, s.scope(ctx))
	if err != nil {
		return fmt.Errorf("failed to delete assignments for role: %w", err)
	}
	return nil
}

// DeleteAssignmentsInOU deletes the assignments made in one organization unit for a role.
func (s *roleStore) DeleteAssignmentsInOU(ctx context.Context, id, ouID string) error {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return err
	}

	_, err = dbClient.ExecuteContext(ctx, queryDeleteRoleAssignmentsInOU, id, ouID, s.scope(ctx))
	if err != nil {
		return fmt.Errorf("failed to delete assignments for role in organization unit: %w", err)
	}
	return nil
}

// DeleteAssignmentsByAssignee deletes all role assignments for a given assignee principal across
// roles, returning the number removed.
func (s *roleStore) DeleteAssignmentsByAssignee(
	ctx context.Context, assigneeType, assigneeID string) (int64, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return 0, err
	}

	rowsAffected, err := dbClient.ExecuteContext(
		ctx, queryDeleteRoleAssignmentsByAssignee, assigneeType, assigneeID, s.scope(ctx))
	if err != nil {
		return 0, fmt.Errorf("failed to delete assignments for assignee: %w", err)
	}
	return rowsAffected, nil
}

// GetReferencedPermissions returns the distinct permissions referenced by any role, grouped by
// resource server.
func (s *roleStore) GetReferencedPermissions(ctx context.Context) ([]ResourcePermissions, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	results, err := dbClient.QueryContext(ctx, queryGetReferencedPermissions, s.scope(ctx))
	if err != nil {
		return nil, fmt.Errorf("failed to get referenced permissions: %w", err)
	}

	byResourceServer := make(map[string][]string)
	for _, row := range results {
		resourceServerID, ok := row["resource_server_id"].(string)
		if !ok {
			return nil, fmt.Errorf("failed to parse resource_server_id as string")
		}
		permission, ok := row["permission"].(string)
		if !ok {
			return nil, fmt.Errorf("failed to parse permission as string")
		}
		byResourceServer[resourceServerID] = append(byResourceServer[resourceServerID], permission)
	}

	return resourcePermissionsFromMap(byResourceServer), nil
}

// DeleteRolePermission removes the given permission from every role that holds it.
func (s *roleStore) DeleteRolePermission(
	ctx context.Context, resourceServerID, permission string) (int64, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return 0, err
	}

	rowsAffected, err := dbClient.ExecuteContext(
		ctx, queryDeleteRolePermissionByValue, resourceServerID, permission, s.scope(ctx))
	if err != nil {
		return 0, fmt.Errorf("failed to delete role permission: %w", err)
	}
	return rowsAffected, nil
}

// AddAssignments adds assignments to a role.
func (s *roleStore) AddAssignments(ctx context.Context, id string, assignments []RoleAssignment) error {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return err
	}

	return addAssignmentsToRole(ctx, dbClient, id, assignments, s.scope(ctx))
}

// RemoveAssignments removes assignments from a role.
func (s *roleStore) RemoveAssignments(ctx context.Context, id string, assignments []RoleAssignment) error {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return err
	}

	for _, assignment := range assignments {
		_, err := dbClient.ExecuteContext(
			ctx, queryDeleteRoleAssignmentsByIDs, id, assignment.OUID, assignment.Type, assignment.ID, s.scope(ctx))
		if err != nil {
			return fmt.Errorf("failed to remove assignment from role: %w", err)
		}
	}
	return nil
}

// getRolePermissions retrieves all permissions for a role.
func (s *roleStore) getRolePermissions(
	ctx context.Context, dbClient provider.DBClientInterface, id string) ([]ResourcePermissions, error) {
	results, err := dbClient.QueryContext(ctx, queryGetRolePermissions, id, s.scope(ctx))
	if err != nil {
		return nil, fmt.Errorf("failed to get role permissions: %w", err)
	}

	// Group permissions by resource server
	permMap := make(map[string][]string)
	var resourceServerOrder []string

	for _, row := range results {
		permission, ok := row["permission"].(string)
		if !ok {
			return nil, fmt.Errorf("failed to parse permission as string")
		}

		resourceServerID, ok := row["resource_server_id"].(string)
		if !ok {
			return nil, fmt.Errorf("failed to parse resource_server_id as string")
		}

		// Track order of resource servers as they appear
		if _, exists := permMap[resourceServerID]; !exists {
			resourceServerOrder = append(resourceServerOrder, resourceServerID)
		}

		permMap[resourceServerID] = append(permMap[resourceServerID], permission)
	}

	// Convert map to array of ResourcePermissions
	permissions := make([]ResourcePermissions, 0, len(permMap))
	for _, rsID := range resourceServerOrder {
		permissions = append(permissions, ResourcePermissions{
			ResourceServerID: rsID,
			Permissions:      permMap[rsID],
		})
	}

	return permissions, nil
}

// buildRoleSummaryFromResultRow constructs a Role from a database result row.
func buildRoleBasicInfoFromResultRow(row map[string]interface{}) (Role, error) {
	fields, err := parseStringFields(row, "id", "name", "description", "ou_id")
	if err != nil {
		return Role{}, err
	}

	return Role{
		ID:          fields[0],
		Name:        fields[1],
		Description: fields[2],
		OUID:        fields[3],
	}, nil
}

// addPermissionsToRole adds a list of permissions to a role.
func addPermissionsToRole(
	ctx context.Context,
	dbClient provider.DBClientInterface,
	id string,
	permissions []ResourcePermissions,
	deploymentID string,
) error {
	for _, resPerm := range permissions {
		for _, permission := range resPerm.Permissions {
			_, err := dbClient.ExecuteContext(
				ctx, queryCreateRolePermission, id, resPerm.ResourceServerID, permission, deploymentID)
			if err != nil {
				return fmt.Errorf("failed to add permission to role: %w", err)
			}
		}
	}
	return nil
}

// addAssignmentsToRole adds a list of assignments to a role.
func addAssignmentsToRole(
	ctx context.Context,
	dbClient provider.DBClientInterface,
	id string,
	assignments []RoleAssignment,
	deploymentID string,
) error {
	for _, assignment := range assignments {
		_, err := dbClient.ExecuteContext(
			ctx, queryCreateRoleAssignment, id, assignment.OUID, assignment.Type, assignment.ID, deploymentID)
		if err != nil {
			return fmt.Errorf("failed to add assignment to role: %w", err)
		}
	}
	return nil
}

// updateRolePermissions updates the permissions assigned to the role by first deleting existing permissions and
// then adding new ones.
func updateRolePermissions(
	ctx context.Context,
	dbClient provider.DBClientInterface,
	id string,
	permissions []ResourcePermissions,
	deploymentID string,
) error {
	_, err := dbClient.ExecuteContext(ctx, queryDeleteRolePermissions, id, deploymentID)
	if err != nil {
		return fmt.Errorf("failed to delete existing role permissions: %w", err)
	}

	err = addPermissionsToRole(ctx, dbClient, id, permissions, deploymentID)
	if err != nil {
		return fmt.Errorf("failed to assign permissions to role: %w", err)
	}
	return nil
}

// CheckRoleNameExists checks if a role with the given name exists in the specified organization unit.
func (s *roleStore) CheckRoleNameExists(ctx context.Context, ouID, name string) (bool, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return false, err
	}

	results, err := dbClient.QueryContext(ctx, queryCheckRoleNameExists, ouID, name, s.scope(ctx))
	if err != nil {
		return false, fmt.Errorf("failed to check role name existence: %w", err)
	}

	return parseBoolFromCount(results)
}

// CheckRoleNameExistsExcludingID checks if a role with the given name exists in the specified organization unit,
// excluding the role with the given ID.
func (s *roleStore) CheckRoleNameExistsExcludingID(
	ctx context.Context, ouID, name, excludeRoleID string) (bool, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return false, err
	}

	results, err := dbClient.QueryContext(
		ctx, queryCheckRoleNameExistsExcludingID, ouID, name, excludeRoleID, s.scope(ctx))
	if err != nil {
		return false, fmt.Errorf("failed to check role name existence: %w", err)
	}

	return parseBoolFromCount(results)
}

// GetAuthorizedPermissionsByResourceServer retrieves the permissions that an entity is authorized for based on
// their direct role assignments and group memberships, scoped to a resource server when provided.
// GetAllPermissionsForAssignees returns every permission granted to the entity and/or groups by
// their assigned database-backed roles, grouped by resource server.
func (s *roleStore) GetAllPermissionsForAssignees(
	ctx context.Context, entityID string, groupIDs []string,
) ([]ResourcePermissions, error) {
	if entityID == "" && len(groupIDs) == 0 {
		return []ResourcePermissions{}, nil
	}

	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	if groupIDs == nil {
		groupIDs = []string{}
	}

	query, args := buildAllPermissionsForAssigneesQuery(entityID, groupIDs, s.scope(ctx))

	results, err := dbClient.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to get all permissions for assignees: %w", err)
	}

	byResourceServer := make(map[string][]string)
	for _, row := range results {
		resourceServerID, ok := row["resource_server_id"].(string)
		if !ok {
			return nil, fmt.Errorf("failed to parse resource_server_id as string")
		}
		permission, ok := row["permission"].(string)
		if !ok {
			return nil, fmt.Errorf("failed to parse permission as string")
		}
		byResourceServer[resourceServerID] = append(byResourceServer[resourceServerID], permission)
	}

	return resourcePermissionsFromMap(byResourceServer), nil
}

func (s *roleStore) GetAuthorizedPermissionsByResourceServer(
	ctx context.Context,
	entityID string,
	groupIDs, roleIDs []string,
	assignmentOUID, resourceServerID string,
	requestedPermissions []string,
) ([]string, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	// Handle nil groupIDs/roleIDs slices
	if groupIDs == nil {
		groupIDs = []string{}
	}
	if roleIDs == nil {
		roleIDs = []string{}
	}

	// Build dynamic query based on provided parameters
	query, args := buildAuthorizedPermissionsQuery(
		entityID, groupIDs, roleIDs, assignmentOUID, resourceServerID, requestedPermissions, s.scope(ctx))

	results, err := dbClient.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to get authorized permissions: %w", err)
	}

	permissions := make([]string, 0)
	for _, row := range results {
		if permission, ok := row["permission"].(string); ok {
			permissions = append(permissions, permission)
		}
	}

	return permissions, nil
}

// GetUserRoles retrieves the names of roles assigned to an entity directly and/or through group membership.
func (s *roleStore) GetUserRoles(
	ctx context.Context, entityID string, groupIDs []string, assignmentOUID string,
) ([]string, error) {
	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	if groupIDs == nil {
		groupIDs = []string{}
	}

	query, args := buildUserRolesQuery(entityID, groupIDs, assignmentOUID, s.scope(ctx))

	results, err := dbClient.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to get entity roles: %w", err)
	}

	roles := make([]string, 0)
	for _, row := range results {
		if name, ok := row["name"].(string); ok {
			roles = append(roles, name)
		}
	}

	return roles, nil
}

// GetEntityRoleIDs retrieves the IDs of roles assigned to an entity directly and/or via
// group membership, without joining the ROLE table. This surfaces assignments to roles
// whose definitions live only in the file-based declarative store. Callers (notably the
// composite store) use this to resolve permissions for declarative roles whose permission
// rows are absent from the DB.
func (s *roleStore) GetEntityRoleIDs(
	ctx context.Context, entityID string, groupIDs []string, assignmentOUID string,
) ([]string, error) {
	if groupIDs == nil {
		groupIDs = []string{}
	}
	// Short-circuit before touching the DB when there's nothing to look up.
	if entityID == "" && len(groupIDs) == 0 {
		return []string{}, nil
	}

	dbClient, err := s.getConfigDBClient()
	if err != nil {
		return nil, err
	}

	query, args := buildEntityRoleIDsQuery(entityID, groupIDs, assignmentOUID, s.scope(ctx))

	results, err := dbClient.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to get entity role IDs: %w", err)
	}

	roleIDs := make([]string, 0, len(results))
	for _, row := range results {
		if id, ok := row["role_id"].(string); ok {
			roleIDs = append(roleIDs, id)
		}
	}

	return roleIDs, nil
}

// IsRoleDeclarative checks if a role is defined in declarative configuration.
func (s *roleStore) IsRoleDeclarative(ctx context.Context, roleID string) (bool, error) {
	// A role is considered declarative if:
	// 1. Store mode is "composite" or "declarative"
	// 2. The role exists in the declarative configuration
	storeMode := getRoleStoreMode()
	if storeMode == serverconst.StoreModeMutable {
		// Mutable mode: no roles are declarative
		return false, nil
	}

	// For declarative and composite modes, check if role is in declarative config
	// This would require integration with the declarative resource system
	// For now, return false as placeholder; actual implementation would check config
	return false, nil
}

// getConfigDBClient is a helper method to get the database client for the config database.
func (s *roleStore) getConfigDBClient() (provider.DBClientInterface, error) {
	dbClient, err := s.dbProvider.GetConfigDBClient()
	if err != nil {
		return nil, fmt.Errorf("failed to get database client: %w", err)
	}
	return dbClient, nil
}

// parseCountResult parses a count result from a database query result.
func parseCountResult(results []map[string]interface{}) (int, error) {
	if len(results) == 0 {
		return 0, nil
	}

	if countVal, ok := results[0]["total"].(int64); ok {
		return int(countVal), nil
	}
	return 0, fmt.Errorf("failed to parse total from query result")
}

// parseBoolFromCount parses a count result and returns true if count > 0.
func parseBoolFromCount(results []map[string]interface{}) (bool, error) {
	if len(results) == 0 {
		return false, nil
	}

	if countVal, ok := results[0]["count"].(int64); ok {
		return countVal > 0, nil
	}
	return false, fmt.Errorf("failed to parse count from query result")
}

// parseStringField extracts a string field from a database result row.
func parseStringField(row map[string]interface{}, fieldName string) (string, error) {
	value, ok := row[fieldName].(string)
	if !ok {
		return "", fmt.Errorf("failed to parse %s as string", fieldName)
	}
	return value, nil
}

// parseStringFields extracts multiple string fields from a database result row.
func parseStringFields(row map[string]interface{}, fieldNames ...string) ([]string, error) {
	result := make([]string, len(fieldNames))
	for i, fieldName := range fieldNames {
		value, err := parseStringField(row, fieldName)
		if err != nil {
			return nil, err
		}
		result[i] = value
	}
	return result, nil
}
