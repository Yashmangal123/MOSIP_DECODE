// Copyright 2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package user

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	"github.com/thunder-id/thunderid/internal/system/varname"
	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"

	"gopkg.in/yaml.v3"

	"github.com/thunder-id/thunderid/internal/entity"
	"github.com/thunder-id/thunderid/internal/entitytype"
	"github.com/thunder-id/thunderid/internal/sharing"
	"github.com/thunder-id/thunderid/internal/system/config"
	serverconst "github.com/thunder-id/thunderid/internal/system/constants"
	"github.com/thunder-id/thunderid/internal/system/cryptolib"
	declarativeresource "github.com/thunder-id/thunderid/internal/system/declarative_resource"
	"github.com/thunder-id/thunderid/internal/system/log"
	"github.com/thunder-id/thunderid/internal/system/valueref"
)

const (
	resourceTypeUser = "user"
	paramTypeUser    = "User"
)

// userExporter implements declarativeresource.ResourceExporter for users.
type userExporter struct {
	service           UserServiceInterface
	entityService     entity.EntityServiceInterface
	entityTypeService entitytype.EntityTypeServiceInterface
	sharingService    sharing.SharingServiceInterface
	// references writes a credential as a secret reference rather than a template placeholder, as a
	// control plane's export does for every other credential.
	references bool
}

// WriteValueReferences sets whether credentials are written as references or as placeholders.
func (e *userExporter) WriteValueReferences(references bool) {
	e.references = references
}

// newUserExporter creates a new user exporter.
func newUserExporter(
	service UserServiceInterface,
	entityService entity.EntityServiceInterface,
	entityTypeService entitytype.EntityTypeServiceInterface,
	sharingService sharing.SharingServiceInterface,
) *userExporter {
	return &userExporter{service: service, entityService: entityService, entityTypeService: entityTypeService,
		sharingService: sharingService}
}

// GetResourceType returns the resource type for users.
func (e *userExporter) GetResourceType() string {
	return resourceTypeUser
}

// GetParameterizerType returns the parameterizer type for users.
func (e *userExporter) GetParameterizerType() string {
	return paramTypeUser
}

// GetAllResourceIDs retrieves all user IDs from the database store.
// In composite mode, this excludes declarative (YAML-based) users.
func (e *userExporter) GetAllResourceIDs(ctx context.Context) ([]string, *tidcommon.ServiceError) {
	offset := 0
	limit := serverconst.MaxPageSize
	ids := []string{}

	for {
		users, err := e.service.GetUserList(ctx, limit, offset, nil, false)
		if err != nil {
			return nil, err
		}

		for _, user := range users.Users {
			isDeclarative, declErr := e.entityService.IsEntityDeclarative(ctx, user.ID)
			if declErr != nil {
				if errors.Is(declErr, entity.ErrEntityNotFound) {
					ids = append(ids, user.ID)
					continue
				}
				return nil, &tidcommon.InternalServerError
			}
			if !isDeclarative {
				ids = append(ids, user.ID)
			}
		}

		offset += len(users.Users)

		// Continue fetching while we get results; stop only on empty page
		if len(users.Users) == 0 {
			break
		}
	}

	return ids, nil
}

// GetResourceByID retrieves a user by its ID.
func (e *userExporter) GetResourceByID(
	ctx context.Context, id string) (interface{}, string, *tidcommon.ServiceError) {
	user, err := e.service.GetUser(ctx, id, false)
	if err != nil {
		return nil, "", err
	}

	// Extract username from attributes for identification
	var username string
	var attrs map[string]interface{}
	if len(user.Attributes) > 0 {
		if jsonErr := json.Unmarshal(user.Attributes, &attrs); jsonErr == nil {
			if un, ok := attrs["username"].(string); ok {
				username = un
			}
		}
	}

	// Convert User.Attributes (json.RawMessage) to map for export
	var attributesMap map[string]interface{}
	if len(user.Attributes) > 0 {
		if jsonErr := json.Unmarshal(user.Attributes, &attributesMap); jsonErr != nil {
			attributesMap = make(map[string]interface{})
		}
	} else {
		attributesMap = make(map[string]interface{})
	}

	credentials, svcErr := e.exportableCredentials(ctx, user.ID, user.Type, username)
	if svcErr != nil {
		return nil, "", svcErr
	}

	// A document that silently lost its sharing would re-import as a user shared nowhere, so this
	// fails the export rather than thinning it.
	replayable, sharingErr := e.sharingService.ExportPolicies(ctx, UserSharingType, user.ID)
	if sharingErr != nil {
		return nil, "", translateSharingError(sharingErr)
	}
	var policies []sharing.PolicyRequest
	for _, r := range replayable {
		policies = append(policies, r.Request)
	}

	exportUser := &userDeclarativeResource{
		ID:              user.ID,
		Type:            user.Type,
		OUID:            user.OUID,
		Attributes:      attributesMap,
		Credentials:     credentials,
		SharingPolicies: policies,
	}

	return exportUser, username, nil
}

// exportableCredentials describes the credentials an exported user carries: one placeholder for each
// credential the user's type declares and the user has set, a secret reference where the export
// writes references and a template placeholder where it writes templates.
//
// A stored credential is a one-way hash, so its value never leaves. The placeholder names it
// instead, and the importing server fills it from its own secret provider or environment before
// hashing it, which leaves the imported user able to sign in with it. A credential the user has not
// set is left out rather than exported empty, since it would otherwise demand a value on import for
// something the user never had. The user itself is exported either way.
//
// Only credentials the type declares are considered, which leaves out device-bound ones such as a
// passkey: those mean nothing on another deployment. The placeholder is written here because the
// parameterizer only walks a slice of properties and credentials are a map, so it would export any
// value here verbatim.
func (e *userExporter) exportableCredentials(
	ctx context.Context, userID, userType, username string,
) (map[string]interface{}, *tidcommon.ServiceError) {
	credentials := map[string]interface{}{}
	if username == "" {
		// The placeholder is named after the username, so there is nothing to name it after.
		return credentials, nil
	}

	declared, svcErr := e.entityTypeService.GetAttributes(ctx, entitytype.TypeCategoryUser, userType,
		entitytype.AttributeFilter{AllowCredential: true})
	if svcErr != nil {
		return nil, svcErr
	}

	for _, attribute := range declared {
		stored, err := e.entityService.GetCredentialsByType(ctx, userID, attribute.Attribute)
		if err != nil {
			log.GetLogger().Error(ctx, "Failed to read a user's credentials for export",
				log.MaskedString(log.LoggerKeyUserID, userID), log.Error(err))
			return nil, &tidcommon.InternalServerError
		}
		if len(stored) == 0 {
			continue
		}
		name := varname.DeriveVariableName(resourceTypeUser, username, attribute.Attribute)
		if e.references {
			// A control plane holds no values, so the credential names the secret the gateway holds,
			// which the gateway's import fills in before hashing.
			credentials[attribute.Attribute] = valueref.SecretReference(name)
			continue
		}
		credentials[attribute.Attribute] = fmt.Sprintf("{{.%s}}", name)
	}
	return credentials, nil
}

// ValidateResource validates a user resource.
func (e *userExporter) ValidateResource(ctx context.Context,
	resource interface{}, id string, logger *log.Logger,
) (string, *declarativeresource.ExportError) {
	user, ok := resource.(*userDeclarativeResource)
	if !ok {
		return "", declarativeresource.CreateTypeError(resourceTypeUser, id)
	}

	// Extract username for validation
	var username string
	if un, ok := user.Attributes["username"].(string); ok {
		username = un
	}

	if username == "" {
		logger.Warn(ctx, "USER_VALIDATION_ERROR: Missing username",
			log.MaskedString(log.LoggerKeyUserID, id))
		return "", &declarativeresource.ExportError{
			ResourceType: resourceTypeUser,
			ResourceID:   id,
			Code:         "USER_VALIDATION_ERROR",
			Error:        fmt.Sprintf("User '%s' validation failed: missing username", id),
		}
	}

	return username, nil
}

// ViewResource shows an exported user as a read of it returns it. A read never returns a user's
// credentials, so the view leaves out the ones the export carries.
func (e *userExporter) ViewResource(_ context.Context, document *yaml.Node) (interface{}, error) {
	return declarativeresource.DecodeView(document, func(exported *userDeclarativeResource) (
		interface{}, error) {
		attributes, err := json.Marshal(exported.Attributes)
		return &providers.User{
			ID:         exported.ID,
			OUID:       exported.OUID,
			Type:       exported.Type,
			Attributes: attributes,
		}, err
	})
}

// SecretFields names where an exported user holds its credentials: every key of the credentials
// map, since which credentials a user has is its type's to say.
func (e *userExporter) SecretFields() []string {
	return []string{"credentials.*"}
}

// GetResourceRules returns the parameterization rules for users.
func (e *userExporter) GetResourceRules() *declarativeresource.ResourceRules {
	return &declarativeresource.ResourceRules{
		Variables:             []string{},
		ArrayVariables:        []string{},
		DynamicPropertyFields: []string{"Credentials"},
	}
}

// makeUserDeclarativeConfig creates the declarative loader configuration for user resources.
// This provides user-specific parser and validator callbacks to the entity service.
// When userService is non-nil, ou_handle is resolved to ou_id during parsing.
func makeUserDeclarativeConfig(userService UserServiceInterface) entity.DeclarativeLoaderConfig {
	return entity.DeclarativeLoaderConfig{
		Directory: "users",
		Category:  providers.EntityCategoryUser,
		Parser:    makeUserParser(userService),
		Validator: makeUserValidator(),
	}
}

// makeUserSharingConfig creates the loader config the sharing framework reads a user's declared
// policies with. It names the users directory, because a policy is carried inside the user that
// declares it rather than in a document of its own.
func makeUserSharingConfig(userService UserServiceInterface) sharing.DeclarativeLoaderConfig {
	return sharing.DeclarativeLoaderConfig{
		ResourceType:  UserSharingType,
		DirectoryName: "users",
		Parser:        makeUserSharingParser(userService),
	}
}

// makeUserSharingParser returns a parser that reads the sharing half of one user document. A
// document may name its organization unit by handle, and only the service resolves that to the id a
// policy is declared against.
func makeUserSharingParser(
	userService UserServiceInterface,
) func([]byte) (*sharing.DeclaredResourcePolicies, error) {
	return func(data []byte) (*sharing.DeclaredResourcePolicies, error) {
		var userRes userDeclarativeResource
		if err := yaml.Unmarshal(data, &userRes); err != nil {
			return nil, fmt.Errorf("failed to parse user YAML: %w", err)
		}
		if len(userRes.SharingPolicies) == 0 {
			return &sharing.DeclaredResourcePolicies{ResourceID: userRes.ID}, nil
		}

		user := providers.User{ID: userRes.ID, OUID: userRes.OUID, OUHandle: userRes.OUHandle}
		if svcErr := userService.ResolveUserOUHandle(context.Background(), &user); svcErr != nil {
			return nil, fmt.Errorf(
				"organization unit with handle %q not found for user '%s'", user.OUHandle, user.ID)
		}
		name, _ := userRes.Attributes["username"].(string)
		if name == "" {
			name = user.ID
		}
		return &sharing.DeclaredResourcePolicies{
			ResourceID:   user.ID,
			ResourceName: name,
			OwningOUID:   user.OUID,
			Policies:     userRes.SharingPolicies,
		}, nil
	}
}

// makeUserParser creates a parser callback that converts YAML data into an Entity with credentials.
// When userService is non-nil, ou_handle is resolved to ou_id before producing the entity.
func makeUserParser(
	userService UserServiceInterface,
) func(data []byte) (*providers.Entity, json.RawMessage, json.RawMessage, error) {
	return func(data []byte) (*providers.Entity, json.RawMessage, json.RawMessage, error) {
		user, creds, err := parseToUser(data)
		if err != nil {
			return nil, nil, nil, err
		}

		if userService != nil {
			if svcErr := userService.ResolveUserOUHandle(context.Background(), &user); svcErr != nil {
				return nil, nil, nil, fmt.Errorf(
					"organization unit with handle %q not found for user '%s'", user.OUHandle, user.ID)
			}
		}

		e := userToEntity(&user)
		systemCreds, err := credentialsToJSON(creds)
		if err != nil {
			return nil, nil, nil, fmt.Errorf("failed to marshal credentials: %w", err)
		}

		return e, nil, systemCreds, nil
	}
}

// makeUserValidator creates a validator callback for declarative user resources.
func makeUserValidator() func(e *providers.Entity, svc entity.EntityServiceInterface) error {
	return func(e *providers.Entity, svc entity.EntityServiceInterface) error {
		if e.ID == "" {
			return fmt.Errorf("user ID is required")
		}
		if e.Type == "" {
			return fmt.Errorf("user type is required")
		}
		if e.OUID == "" {
			return fmt.Errorf("ouId or ouHandle is required for user '%s'", e.ID)
		}
		if len(e.Attributes) == 0 {
			return fmt.Errorf("user attributes are required")
		}

		var attrs map[string]interface{}
		if err := json.Unmarshal(e.Attributes, &attrs); err != nil {
			return fmt.Errorf("failed to parse user attributes: %w", err)
		}

		un, ok := attrs["username"].(string)
		if !ok || un == "" {
			return fmt.Errorf("username is required in user attributes")
		}

		// Check for duplicates in the store (covers both DB and already-loaded file resources)
		_, err := svc.GetEntityProfile(context.Background(), e.ID)
		if err == nil {
			return fmt.Errorf("duplicate user ID '%s': user already exists", e.ID)
		}
		if !errors.Is(err, entity.ErrEntityNotFound) {
			return fmt.Errorf("checking user existence for '%s': %w", e.ID, err)
		}

		return nil
	}
}

// userDeclarativeResource is a user as a resource file states it, with the sharing policies that
// govern it carried alongside.
type userDeclarativeResource struct {
	ID              string                  `yaml:"id"`
	Type            string                  `yaml:"type"`
	OUID            string                  `yaml:"ouId,omitempty"`
	OUHandle        string                  `yaml:"ouHandle,omitempty"`
	Attributes      map[string]interface{}  `yaml:"attributes"`
	Credentials     map[string]interface{}  `yaml:"credentials,omitempty"` // Flexible format for YAML
	SharingPolicies []sharing.PolicyRequest `yaml:"sharingPolicies,omitempty"`
}

// parseToUser parses YAML data into a User and its Credentials. The ou_handle from YAML is
// populated onto User.OUHandle so callers can resolve it to an ou_id via the user service.
func parseToUser(data []byte) (providers.User, Credentials, error) {
	var userRes userDeclarativeResource
	if err := yaml.Unmarshal(data, &userRes); err != nil {
		return providers.User{}, nil, err
	}

	// Convert attributes map to JSON
	attributesJSON, err := json.Marshal(userRes.Attributes)
	if err != nil {
		return providers.User{}, nil, fmt.Errorf("failed to marshal attributes: %w", err)
	}

	user := providers.User{
		ID:         userRes.ID,
		Type:       userRes.Type,
		OUID:       userRes.OUID,
		OUHandle:   userRes.OUHandle,
		Attributes: json.RawMessage(attributesJSON),
	}

	// Parse and hash credentials
	credentials, err := parseCredentials(userRes.Credentials)
	if err != nil {
		return providers.User{}, nil, fmt.Errorf("failed to parse credentials: %w", err)
	}

	return user, credentials, nil
}

// parseCredentials parses credentials from YAML and hashes plain text values.
// Supports two formats:
// 1. Simple format: credentials: { password: "plaintext" }
// 2. Full format: credentials: { password: [{ storageType: "hash", value: "hashed", ... }] }
func parseCredentials(credentialsMap map[string]interface{}) (Credentials, error) {
	if len(credentialsMap) == 0 {
		return make(Credentials), nil
	}

	credentials := make(Credentials)
	hashCfg, err := buildHashCfgForUser()
	if err != nil {
		return nil, fmt.Errorf("failed to initialize hash service: %w", err)
	}
	hashService, err := cryptolib.Initialize(hashCfg)
	if err != nil {
		return nil, fmt.Errorf("failed to initialize hash service: %w", err)
	}

	for credType, credValue := range credentialsMap {
		credentialType := CredentialType(credType)

		switch v := credValue.(type) {
		case string:
			// Simple format: plain text password that needs hashing
			if v == "" {
				continue
			}

			if credentialType.IsSystemManaged() {
				credentials[credentialType] = []Credential{{Value: v}}
				continue
			}

			hashedCred, err := hashService.Generate([]byte(v))
			if err != nil {
				return nil, fmt.Errorf("failed to hash credential %s: %w", credType, err)
			}

			credential := Credential{
				StorageType: "hash",
				StorageAlgo: hashedCred.Algorithm,
				StorageAlgoParams: cryptolib.CredParameters{
					Iterations:  hashedCred.Parameters.Iterations,
					Memory:      hashedCred.Parameters.Memory,
					Parallelism: hashedCred.Parameters.Parallelism,
					KeySize:     hashedCred.Parameters.KeySize,
					Salt:        hashedCred.Parameters.Salt,
				},
				Value: hashedCred.Hash,
			}

			credentials[credentialType] = []Credential{credential}

		case []interface{}:
			// Full format: array of credential objects
			var credList []Credential
			for _, item := range v {
				credMap, ok := item.(map[string]interface{})
				if !ok {
					// Try map[interface{}]interface{} (YAML unmarshaling)
					if credMapAny, ok := item.(map[interface{}]interface{}); ok {
						credMap = make(map[string]interface{})
						for k, val := range credMapAny {
							if keyStr, ok := k.(string); ok {
								credMap[keyStr] = val
							}
						}
					} else {
						return nil, fmt.Errorf("invalid credential format for %s", credType)
					}
				}

				cred, err := parseCredentialObject(credMap, hashService, credentialType)
				if err != nil {
					return nil, fmt.Errorf("failed to parse credential %s: %w", credType, err)
				}
				credList = append(credList, cred)
			}
			credentials[credentialType] = credList

		default:
			return nil, fmt.Errorf("unsupported credential format for %s", credType)
		}
	}

	return credentials, nil
}

// parseCredentialObject parses a single credential object.
// If the value is plain text and no hash info is provided, it will hash it.
func parseCredentialObject(
	credMap map[string]interface{},
	hashService cryptolib.HashServiceInterface,
	credentialType CredentialType,
) (Credential, error) {
	value, hasValue := credMap["value"].(string)
	if !hasValue || value == "" {
		return Credential{}, fmt.Errorf("credential value is required")
	}

	storageType, _ := credMap["storageType"].(string)
	storageAlgo, _ := credMap["storageAlgo"].(string)
	systemManaged, _ := credMap["systemManaged"].(bool)

	if credentialType.IsSystemManaged() || systemManaged || storageType == "system" {
		if storageType == "" {
			storageType = "system"
		}
		return Credential{
			StorageType: storageType,
			StorageAlgo: cryptolib.CredAlgorithm(storageAlgo),
			Value:       value,
		}, nil
	}

	// If storage type is not specified or is not "hash", treat as plain text and hash it
	if storageType == "" || storageType != "hash" {
		hashedCred, err := hashService.Generate([]byte(value))
		if err != nil {
			return Credential{}, fmt.Errorf("failed to hash credential: %w", err)
		}

		return Credential{
			StorageType: "hash",
			StorageAlgo: hashedCred.Algorithm,
			StorageAlgoParams: cryptolib.CredParameters{
				Iterations:  hashedCred.Parameters.Iterations,
				Memory:      hashedCred.Parameters.Memory,
				Parallelism: hashedCred.Parameters.Parallelism,
				KeySize:     hashedCred.Parameters.KeySize,
				Salt:        hashedCred.Parameters.Salt,
			},
			Value: hashedCred.Hash,
		}, nil
	}

	// Parse pre-hashed credential
	paramsMap, _ := credMap["storageAlgoParams"].(map[string]interface{})
	if paramsMap == nil {
		// Try map[interface{}]interface{} format
		if paramsMapAny, ok := credMap["storageAlgoParams"].(map[interface{}]interface{}); ok {
			paramsMap = make(map[string]interface{})
			for k, v := range paramsMapAny {
				if keyStr, ok := k.(string); ok {
					paramsMap[keyStr] = v
				}
			}
		}
	}

	iterations, _ := paramsMap["iterations"].(int)
	parallelism, _ := paramsMap["parallelism"].(int)
	memory, _ := paramsMap["memory"].(int)
	keySize, _ := paramsMap["keySize"].(int)
	salt, _ := paramsMap["salt"].(string)

	return Credential{
		StorageType: storageType,
		StorageAlgo: cryptolib.CredAlgorithm(storageAlgo),
		StorageAlgoParams: cryptolib.CredParameters{
			Iterations:  iterations,
			Parallelism: parallelism,
			Memory:      memory,
			KeySize:     keySize,
			Salt:        salt,
		},
		Value: value,
	}, nil
}

// buildHashCfgForUser constructs a cryptolib.HashConfig from the server's password hashing config.
func buildHashCfgForUser() (cryptolib.HashConfig, error) {
	cfg := config.GetServerRuntime().Config.Crypto.PasswordHashing
	alg := cryptolib.CredAlgorithm(strings.ToUpper(cfg.Algorithm))
	switch alg {
	case "", cryptolib.SHA256:
		return cryptolib.HashConfig{Algorithm: cryptolib.SHA256, SaltSize: cfg.SHA256.SaltSize}, nil
	case cryptolib.PBKDF2:
		return cryptolib.HashConfig{Algorithm: alg, SaltSize: cfg.PBKDF2.SaltSize,
			Iterations: cfg.PBKDF2.Iterations, KeySize: cfg.PBKDF2.KeySize}, nil
	case cryptolib.ARGON2ID:
		return cryptolib.HashConfig{Algorithm: alg, SaltSize: cfg.Argon2ID.SaltSize,
			Iterations: cfg.Argon2ID.Iterations, Memory: cfg.Argon2ID.Memory,
			Parallelism: cfg.Argon2ID.Parallelism, KeySize: cfg.Argon2ID.KeySize}, nil
	default:
		return cryptolib.HashConfig{}, fmt.Errorf("unrecognized password hashing algorithm %q", cfg.Algorithm)
	}
}
