// Copyright 2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package user

import (
	"context"
	"encoding/json"
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/stretchr/testify/suite"

	entitypkg "github.com/thunder-id/thunderid/internal/entity"
	"github.com/thunder-id/thunderid/internal/sharing"
	"github.com/thunder-id/thunderid/internal/system/config"
	serverconst "github.com/thunder-id/thunderid/internal/system/constants"
	"github.com/thunder-id/thunderid/internal/system/cryptolib"
	"github.com/thunder-id/thunderid/internal/system/log"
	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"
	"github.com/thunder-id/thunderid/tests/mocks/entitymock"
	"github.com/thunder-id/thunderid/tests/mocks/entitytypemock"
	"github.com/thunder-id/thunderid/tests/mocks/sharingmock"
)

// DeclarativeResourceTestSuite tests user declarative resource parsing and export.
type DeclarativeResourceTestSuite struct {
	suite.Suite
}

// TestDeclarativeResourceTestSuite runs the test suite.
func TestDeclarativeResourceTestSuite(t *testing.T) {
	suite.Run(t, new(DeclarativeResourceTestSuite))
}

// SetupTest initializes runtime config required for hashing.
func (suite *DeclarativeResourceTestSuite) SetupTest() {
	config.ResetServerRuntime()
	err := config.InitializeServerRuntime("test", &config.Config{
		Crypto: config.CryptoConfig{
			PasswordHashing: config.PasswordHashingConfig{
				Algorithm: string(cryptolib.SHA256),
				SHA256: config.SHA256Config{
					SaltSize: 16,
				},
			},
		},
	})
	suite.Require().NoError(err)
}

func (suite *DeclarativeResourceTestSuite) TestParseCredentials_SimpleFormatHashes() {
	credentials, err := parseCredentials(map[string]interface{}{
		"password": "secret",
	})

	suite.NoError(err)
	suite.Contains(credentials, CredentialType("password"))
	suite.Len(credentials["password"], 1)
	suite.Equal("hash", credentials["password"][0].StorageType)
	suite.NotEqual("secret", credentials["password"][0].Value)
	suite.NotEmpty(credentials["password"][0].StorageAlgo)
}

func (suite *DeclarativeResourceTestSuite) TestParseCredentials_SystemManagedPreserves() {
	credentials, err := parseCredentials(map[string]interface{}{
		string(CredentialTypePasskey): "raw-value",
	})

	suite.NoError(err)
	suite.Contains(credentials, CredentialTypePasskey)
	suite.Len(credentials[CredentialTypePasskey], 1)
	suite.Equal("raw-value", credentials[CredentialTypePasskey][0].Value)
}

func (suite *DeclarativeResourceTestSuite) TestParseCredentials_FullFormatPreserves() {
	credentials, err := parseCredentials(map[string]interface{}{
		"password": []interface{}{
			map[string]interface{}{
				"storageType": "hash",
				"storageAlgo": "argon2",
				"storageAlgoParams": map[string]interface{}{
					"iterations": 1,
					"keySize":    32,
					"salt":       "salt",
				},
				"value": "hashed-value",
			},
		},
	})

	suite.NoError(err)
	suite.Len(credentials["password"], 1)
	suite.Equal("hash", credentials["password"][0].StorageType)
	suite.Equal("hashed-value", credentials["password"][0].Value)
}

func (suite *DeclarativeResourceTestSuite) TestParseCredentials_InvalidFormat() {
	_, err := parseCredentials(map[string]interface{}{
		"password": 123,
	})
	suite.Error(err)
}

func (suite *DeclarativeResourceTestSuite) TestParseCredentialObject_HashesWhenNoStorageType() {
	hashService, err := cryptolib.Initialize(
		cryptolib.HashConfig{Algorithm: cryptolib.PBKDF2, SaltSize: 16, Iterations: 1, KeySize: 32},
	)
	suite.Require().NoError(err)
	cred, err := parseCredentialObject(map[string]interface{}{
		"value": "secret",
	}, hashService, CredentialType("password"))

	suite.NoError(err)
	suite.Equal("hash", cred.StorageType)
	suite.NotEqual("secret", cred.Value)
}

func (suite *DeclarativeResourceTestSuite) TestParseCredentialObject_SystemManagedMarker() {
	hashService, err := cryptolib.Initialize(
		cryptolib.HashConfig{Algorithm: cryptolib.PBKDF2, SaltSize: 16, Iterations: 1, KeySize: 32},
	)
	suite.Require().NoError(err)
	cred, err := parseCredentialObject(map[string]interface{}{
		"value":             "raw",
		"systemManaged":     true,
		"storageType":       "system",
		"storageAlgo":       "",
		"storageAlgoParams": map[string]interface{}{},
	}, hashService, CredentialTypePasskey)

	suite.NoError(err)
	suite.Equal("system", cred.StorageType)
	suite.Equal("raw", cred.Value)
}

func (suite *DeclarativeResourceTestSuite) TestParseToUser_HashesCredentials() {
	yamlData := []byte("" +
		"id: user-1\n" +
		"type: person\n" +
		"ouId: ou-1\n" +
		"attributes:\n" +
		"  username: alice\n" +
		"  email: alice@example.com\n" +
		"credentials:\n" +
		"  password: \"secret\"\n")

	_, creds, err := parseToUser(yamlData)
	suite.NoError(err)

	passwordCreds := creds["password"]
	suite.Len(passwordCreds, 1)
	suite.NotEqual("secret", passwordCreds[0].Value)
}

func (suite *DeclarativeResourceTestSuite) TestParseToUserWrapper() {
	yamlData := []byte("" +
		"id: user-1\n" +
		"type: person\n" +
		"ouId: ou-1\n" +
		"attributes:\n" +
		"  username: alice\n" +
		"  email: alice@example.com\n")

	user, _, err := parseToUser(yamlData)
	suite.NoError(err)
	suite.NotEmpty(user.ID)
}

func (suite *DeclarativeResourceTestSuite) TestUserExporter_Metadata() {
	exporter := newUserExporter(
		NewUserServiceInterfaceMock(suite.T()), entitymock.NewEntityServiceInterfaceMock(suite.T()),
		entitytypemock.NewEntityTypeServiceInterfaceMock(suite.T()), nil)

	suite.Equal(resourceTypeUser, exporter.GetResourceType())
	suite.Equal(paramTypeUser, exporter.GetParameterizerType())
}

func (suite *DeclarativeResourceTestSuite) TestUserExporter_GetAllResourceIDs() {
	ctx := context.Background()
	mockSvc := NewUserServiceInterfaceMock(suite.T())
	entityServiceMock := entitymock.NewEntityServiceInterfaceMock(suite.T())
	exporter := newUserExporter(
		mockSvc, entityServiceMock, entitytypemock.NewEntityTypeServiceInterfaceMock(suite.T()), nil)

	users := []providers.User{{ID: "user-1"}, {ID: "user-2"}}
	mockSvc.On("GetUserList", ctx, serverconst.MaxPageSize, 0, mock.Anything, false).
		Return(&UserListResponse{Users: users}, nil)
	entityServiceMock.On("IsEntityDeclarative", ctx, "user-1").Return(true, nil)
	entityServiceMock.On("IsEntityDeclarative", ctx, "user-2").Return(false, nil)
	mockSvc.On("GetUserList", ctx, serverconst.MaxPageSize, 2, mock.Anything, false).
		Return(&UserListResponse{Users: []providers.User{}}, nil)

	ids, err := exporter.GetAllResourceIDs(ctx)
	suite.Nil(err)
	suite.Equal([]string{"user-2"}, ids)
}

func (suite *DeclarativeResourceTestSuite) TestMakeUserParser_ParsesYAMLToEntityWithCredentials() {
	userYAML := []byte("" +
		"id: user-1\n" +
		"type: person\n" +
		"ouId: ou-1\n" +
		"attributes:\n" +
		"  username: alice\n" +
		"  email: alice@example.com\n" +
		"credentials:\n" +
		"  password: \"secret\"\n")

	parser := makeUserParser(nil)
	e, _, systemCreds, err := parser(userYAML)

	suite.NoError(err)
	suite.NotNil(e)
	suite.Equal("user-1", e.ID)
	suite.Equal("person", e.Type)
	suite.Equal("ou-1", e.OUID)
	suite.Equal(providers.EntityCategoryUser, e.Category)

	// Verify attributes preserved
	var attrs map[string]interface{}
	suite.NoError(json.Unmarshal(e.Attributes, &attrs))
	suite.Equal("alice", attrs["username"])

	// Verify credentials were parsed (password should be hashed)
	suite.NotNil(systemCreds)
	suite.NotEmpty(systemCreds)
}

func (suite *DeclarativeResourceTestSuite) TestGetResourceRules_IncludesCredentials() {
	exporter := newUserExporter(
		NewUserServiceInterfaceMock(suite.T()), entitymock.NewEntityServiceInterfaceMock(suite.T()),
		entitytypemock.NewEntityTypeServiceInterfaceMock(suite.T()), nil)

	rules := exporter.GetResourceRules()
	suite.Contains(rules.DynamicPropertyFields, "Credentials")
}

func (suite *DeclarativeResourceTestSuite) TestValidateResource_MissingUsername() {
	exporter := newUserExporter(
		NewUserServiceInterfaceMock(suite.T()), entitymock.NewEntityServiceInterfaceMock(suite.T()),
		entitytypemock.NewEntityTypeServiceInterfaceMock(suite.T()), nil)

	resource := &userDeclarativeResource{
		ID:         "user-1",
		Type:       "person",
		OUID:       "ou-1",
		Attributes: map[string]interface{}{},
	}

	_, err := exporter.ValidateResource(context.Background(), resource, "user-1", log.GetLogger())
	suite.NotNil(err)
}

func (suite *DeclarativeResourceTestSuite) TestMakeUserValidator_Success() {
	attrs, err := json.Marshal(map[string]interface{}{"username": "alice"})
	suite.Require().NoError(err)

	e := &providers.Entity{
		ID:         "user-1",
		Type:       "person",
		OUID:       "ou-1",
		Attributes: attrs,
	}

	svcMock := entitymock.NewEntityServiceInterfaceMock(suite.T())
	svcMock.On("GetEntityProfile", context.Background(), "user-1").
		Return((*providers.Entity)(nil), entitypkg.ErrEntityNotFound)

	validator := makeUserValidator()
	err = validator(e, svcMock)
	suite.NoError(err)
}

func (suite *DeclarativeResourceTestSuite) TestMakeUserValidator_DuplicateEntity() {
	attrs, err := json.Marshal(map[string]interface{}{"username": "alice"})
	suite.Require().NoError(err)

	e := &providers.Entity{
		ID:         "user-1",
		Type:       "person",
		OUID:       "ou-1",
		Attributes: attrs,
	}

	svcMock := entitymock.NewEntityServiceInterfaceMock(suite.T())
	svcMock.On("GetEntityProfile", context.Background(), "user-1").
		Return(&providers.Entity{Category: providers.EntityCategoryUser, ID: "user-1"}, nil)

	validator := makeUserValidator()
	err = validator(e, svcMock)
	suite.Error(err)
	suite.Contains(err.Error(), "duplicate user ID")
}

func (suite *DeclarativeResourceTestSuite) TestMakeUserValidator_DBError() {
	attrs, err := json.Marshal(map[string]interface{}{"username": "alice"})
	suite.Require().NoError(err)

	e := &providers.Entity{
		ID:         "user-1",
		Type:       "person",
		OUID:       "ou-1",
		Attributes: attrs,
	}

	svcMock := entitymock.NewEntityServiceInterfaceMock(suite.T())
	svcMock.On("GetEntityProfile", context.Background(), "user-1").
		Return((*providers.Entity)(nil), errors.New("db error"))

	validator := makeUserValidator()
	err = validator(e, svcMock)
	suite.Error(err)
	suite.Contains(err.Error(), "checking user existence")
}

func (suite *DeclarativeResourceTestSuite) TestParseCredentials_YAMLMapInterfaceFormat() {
	// Simulate YAML map[interface{}]interface{} for credentials
	credMap := map[interface{}]interface{}{
		"storageType": "hash",
		"storageAlgo": "argon2",
		"storageAlgoParams": map[interface{}]interface{}{
			"iterations": 2,
			"keySize":    64,
			"salt":       "salty",
		},
		"value": "hashed-value",
	}
	creds := map[string]interface{}{
		"password": []interface{}{credMap},
	}
	parsed, err := parseCredentials(creds)
	suite.NoError(err)
	suite.Len(parsed["password"], 1)
	suite.Equal("hash", parsed["password"][0].StorageType)
	suite.Equal("hashed-value", parsed["password"][0].Value)
	suite.Equal("argon2", string(parsed["password"][0].StorageAlgo))
	suite.Equal(2, parsed["password"][0].StorageAlgoParams.Iterations)
	suite.Equal(64, parsed["password"][0].StorageAlgoParams.KeySize)
	suite.Equal("salty", parsed["password"][0].StorageAlgoParams.Salt)
}

func (suite *DeclarativeResourceTestSuite) TestParseCredentialObject_YAMLMapInterfaceParams() {
	hashService, err := cryptolib.Initialize(
		cryptolib.HashConfig{Algorithm: cryptolib.PBKDF2, SaltSize: 16, Iterations: 1, KeySize: 32},
	)
	suite.Require().NoError(err)
	credMap := map[string]interface{}{
		"value":       "hashed-value",
		"storageType": "hash",
		"storageAlgo": "argon2",
		"storageAlgoParams": map[interface{}]interface{}{
			"iterations": 3,
			"keySize":    128,
			"salt":       "pepper",
		},
	}
	cred, err := parseCredentialObject(credMap, hashService, CredentialType("password"))
	suite.NoError(err)
	suite.Equal("hash", cred.StorageType)
	suite.Equal("hashed-value", cred.Value)
	suite.Equal("argon2", string(cred.StorageAlgo))
	suite.Equal(3, cred.StorageAlgoParams.Iterations)
	suite.Equal(128, cred.StorageAlgoParams.KeySize)
	suite.Equal("pepper", cred.StorageAlgoParams.Salt)
}

func (suite *DeclarativeResourceTestSuite) TestParseCredentials_InvalidCredentialMapType() {
	creds := map[string]interface{}{
		"password": []interface{}{123}, // not a map
	}
	_, err := parseCredentials(creds)
	suite.Error(err)
}

func (suite *DeclarativeResourceTestSuite) TestBuildHashCfgForUser_UnrecognizedAlgorithmErrors() {
	config.ResetServerRuntime()
	err := config.InitializeServerRuntime("test", &config.Config{
		Crypto: config.CryptoConfig{
			PasswordHashing: config.PasswordHashingConfig{
				Algorithm: "BCRYPT",
			},
		},
	})
	suite.Require().NoError(err)

	_, err = buildHashCfgForUser()
	suite.Error(err)
	suite.Contains(err.Error(), "BCRYPT")
}

// sharedUserYAML is a user document that declares one policy, its unit named by ouID or ouHandle.
func sharedUserYAML(unit string) []byte {
	return []byte("" +
		"id: user-1\n" +
		"type: person\n" +
		unit + "\n" +
		"attributes:\n" +
		"  username: alice\n" +
		"sharingPolicies:\n" +
		"  - id: user-1-policy-1\n" +
		"    childUnits:\n" +
		"      mode: selected\n" +
		"      units:\n" +
		"        - ouId: ou-eu\n" +
		"          reach: unit\n")
}

// A document that declares no sharing hands the framework nothing to hold, without consulting the
// service.
func (suite *DeclarativeResourceTestSuite) TestMakeUserSharingParser_DeclaresNothingWithoutPolicies() {
	parser := makeUserSharingParser(NewUserServiceInterfaceMock(suite.T()))

	declared, err := parser([]byte("id: user-1\ntype: person\nouId: ou-1\nattributes:\n  username: alice\n"))

	suite.Require().NoError(err)
	suite.Equal("user-1", declared.ResourceID)
	suite.Empty(declared.Policies)
}

// The policies are declared on the user, against the unit the user lives in.
func (suite *DeclarativeResourceTestSuite) TestMakeUserSharingParser_ReadsThePoliciesAgainstTheUsersUnit() {
	userSvc := NewUserServiceInterfaceMock(suite.T())
	userSvc.On("ResolveUserOUHandle", mock.Anything, mock.Anything).Return((*tidcommon.ServiceError)(nil))

	declared, err := makeUserSharingParser(userSvc)(sharedUserYAML("ouId: ou-1"))

	suite.Require().NoError(err)
	suite.Equal("user-1", declared.ResourceID)
	suite.Equal("alice", declared.ResourceName)
	suite.Equal("ou-1", declared.OwningOUID)
	suite.Equal([]sharing.PolicyRequest{{
		ID: "user-1-policy-1",
		ChildUnits: &sharing.ChildUnitsRequest{
			Mode:  sharing.ChildUnitsSelected,
			Units: []sharing.ChildUnitRequest{{OUID: "ou-eu", Reach: sharing.ReachUnit}},
		},
	}}, declared.Policies)
}

// A unit named by handle is resolved to the id the policies are declared against.
func (suite *DeclarativeResourceTestSuite) TestMakeUserSharingParser_ResolvesAUnitNamedByHandle() {
	userSvc := NewUserServiceInterfaceMock(suite.T())
	userSvc.On("ResolveUserOUHandle", mock.Anything, mock.MatchedBy(func(u *providers.User) bool {
		return u.OUHandle == "acme/customers"
	})).Run(func(args mock.Arguments) {
		args.Get(1).(*providers.User).OUID = "ou-customers"
	}).Return((*tidcommon.ServiceError)(nil))

	declared, err := makeUserSharingParser(userSvc)(sharedUserYAML("ouHandle: acme/customers"))

	suite.Require().NoError(err)
	suite.Equal("ou-customers", declared.OwningOUID)
}

// A handle no unit holds stops the load rather than declaring policies against no unit.
func (suite *DeclarativeResourceTestSuite) TestMakeUserSharingParser_RefusesAnUnknownHandle() {
	userSvc := NewUserServiceInterfaceMock(suite.T())
	userSvc.On("ResolveUserOUHandle", mock.Anything, mock.Anything).Return(&ErrorInvalidRequestFormat)

	_, err := makeUserSharingParser(userSvc)(sharedUserYAML("ouHandle: nowhere"))

	suite.Error(err)
	suite.Contains(err.Error(), "nowhere")
}

func (suite *DeclarativeResourceTestSuite) TestMakeUserSharingParser_RefusesMalformedYAML() {
	_, err := makeUserSharingParser(NewUserServiceInterfaceMock(suite.T()))([]byte("id: [unclosed"))

	suite.Error(err)
}

// sharingAnswers sets what the framework says the user's sharing is when the export asks.
func (c *credentialExport) sharingAnswers(
	t *testing.T, replayable []sharing.ReplayablePolicy, svcErr *tidcommon.ServiceError,
) {
	t.Helper()
	c.sharing = sharingmock.NewSharingServiceInterfaceMock(t)
	c.exporter = newUserExporter(c.users, c.entities, c.entityTypes, c.sharing)
	c.sharing.On("ExportPolicies", context.Background(), UserSharingType, "user-1").
		Return(replayable, svcErr).Once()
}

// A user's sharing travels with it, the owner's policy and the reshares alike, so an import elsewhere
// shares it the same way.
func TestAUsersSharingPoliciesAreExported(t *testing.T) {
	c := newCredentialExport(t, "alice")
	c.typeDeclaresCredentials()
	share := sharing.PolicyRequest{ChildUnits: &sharing.ChildUnitsRequest{
		Mode:  sharing.ChildUnitsSelected,
		Units: []sharing.ChildUnitRequest{{OUID: "ou-eu", Reach: sharing.ReachUnit}},
	}}
	reshare := sharing.PolicyRequest{
		InitiatingOUID: "ou-eu",
		ChildUnits:     &sharing.ChildUnitsRequest{Mode: sharing.ChildUnitsAll},
	}
	c.sharingAnswers(t, []sharing.ReplayablePolicy{
		{InitiatingOUID: "ou-1", Request: share},
		{InitiatingOUID: "ou-eu", Request: reshare},
	}, nil)

	user := c.exportUser(t)

	assert.Equal(t, []sharing.PolicyRequest{share, reshare}, user.SharingPolicies)
}

// A user shared nowhere is exported with no sharing section.
func TestAUserSharedNowhereExportsNoSharingPolicies(t *testing.T) {
	c := newCredentialExport(t, "alice")
	c.typeDeclaresCredentials()

	user := c.exportUser(t)

	assert.Nil(t, user.SharingPolicies)
}

// A failure to read the user's sharing fails the export, rather than exporting a user that would
// re-import shared nowhere.
func TestUnreadableSharingFailsTheUsersExport(t *testing.T) {
	c := newCredentialExport(t, "alice")
	c.typeDeclaresCredentials()
	c.sharingAnswers(t, nil, &tidcommon.InternalServerError)

	_, _, svcErr := c.exporter.GetResourceByID(context.Background(), "user-1")

	require.NotNil(t, svcErr)
	assert.Equal(t, tidcommon.InternalServerError.Code, svcErr.Code)
}
