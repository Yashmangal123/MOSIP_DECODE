// Copyright 2025-2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

package user

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"

	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"

	"github.com/thunder-id/thunderid/internal/sharing"
	serverconst "github.com/thunder-id/thunderid/internal/system/constants"
	"github.com/thunder-id/thunderid/internal/system/error/apierror"
	"github.com/thunder-id/thunderid/internal/system/log"
	"github.com/thunder-id/thunderid/internal/system/security"
	sysutils "github.com/thunder-id/thunderid/internal/system/utils"
)

const handlerLoggerComponentName = "UserHandler"

// userHandler is the handler for user management operations.
type userHandler struct {
	userService UserServiceInterface
}

// newUserHandler creates a new instance of userHandler with dependency injection.
func newUserHandler(userService UserServiceInterface) *userHandler {
	return &userHandler{
		userService: userService,
	}
}

// HandleUserListRequest handles the user list request.
func (uh *userHandler) HandleUserListRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	limit, offset, svcErr := parsePaginationParams(r.URL.Query())
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	if limit == 0 {
		limit = serverconst.DefaultPageSize
	}

	filters, svcErr := parseFilterParams(r.URL.Query())
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	// Parse include parameter to check if display names should be included.
	includeDisplay := r.URL.Query().Get(sysutils.QueryParamInclude) == sysutils.IncludeValueDisplay

	// Get the user list using the user service.
	userListResponse, svcErr := uh.userService.GetUserList(ctx, limit, offset, filters, includeDisplay)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, userListResponse)

	logger.Debug(ctx, "Successfully listed users with pagination",
		log.Int("limit", limit), log.Int("offset", offset),
		log.Int("totalResults", userListResponse.TotalResults),
		log.Int("count", userListResponse.Count),
		log.MaskedMap("filters", filters))
}

// HandleUserPostRequest handles the user request.
func (uh *userHandler) HandleUserPostRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	createRequest, err := sysutils.DecodeJSONBody[CreateUserRequest](r)
	if err != nil {
		var valErr *sysutils.ValidationError
		if errors.As(err, &valErr) {
			sysutils.WriteStructuredErrorResponse(w, http.StatusBadRequest, "Validation Failed", valErr.Errors)
			return
		}
		sysutils.WriteErrorResponse(ctx, w, http.StatusBadRequest, apierror.ErrorResponse{
			Code:        ErrorInvalidRequestFormat.Code,
			Message:     ErrorInvalidRequestFormat.Error,
			Description: ErrorInvalidRequestFormat.ErrorDescription,
		})
		return
	}

	user := &providers.User{
		OUID:       createRequest.OUID,
		Type:       createRequest.Type,
		Attributes: createRequest.Attributes,
	}

	// Create the user using the user service.
	createdUser, svcErr := uh.userService.CreateUser(ctx, user)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusCreated, createdUser)

	// Log the user creation response.
	logger.Debug(ctx, "User POST response sent", log.MaskedString(log.LoggerKeyUserID, createdUser.ID))
}

// HandleUserGetRequest handles the user request.
func (uh *userHandler) HandleUserGetRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	id := r.PathValue("id")
	if id == "" {
		errResp := apierror.ErrorResponse{
			Code:        ErrorMissingUserID.Code,
			Message:     ErrorMissingUserID.Error,
			Description: ErrorMissingUserID.ErrorDescription,
		}
		sysutils.WriteErrorResponse(ctx, w, http.StatusBadRequest, errResp)
		return
	}

	// Parse include parameter to check if display name should be included.
	includeDisplay := r.URL.Query().Get(sysutils.QueryParamInclude) == sysutils.IncludeValueDisplay

	// Get the user using the user service.
	user, svcErr := uh.userService.GetUser(ctx, id, includeDisplay)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, user)

	// Log the user response.
	logger.Debug(ctx, "User GET response sent", log.MaskedString(log.LoggerKeyUserID, id))
}

// HandleUserGroupsGetRequest handles the get user groups request.
func (uh *userHandler) HandleUserGroupsGetRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	id := r.PathValue("id")
	if id == "" {
		handleError(ctx, w, &ErrorMissingUserID)
		return
	}

	limit, offset, svcErr := parsePaginationParams(r.URL.Query())
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	if limit == 0 {
		limit = serverconst.DefaultPageSize
	}

	groupListResponse, svcErr := uh.userService.GetUserGroups(ctx, id, limit, offset)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, groupListResponse)

	logger.Debug(ctx, "Successfully retrieved user groups", log.MaskedString(log.LoggerKeyUserID, id),
		log.Int("limit", limit), log.Int("offset", offset),
		log.Int("totalResults", groupListResponse.TotalResults),
		log.Int("count", groupListResponse.Count))
}

// HandleUserUsagesGetRequest handles the get user usages request.
func (uh *userHandler) HandleUserUsagesGetRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	id := r.PathValue("id")
	if id == "" {
		handleError(ctx, w, &ErrorMissingUserID)
		return
	}

	result, svcErr := uh.userService.GetUserUsages(ctx, id)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, result)

	logger.Debug(ctx, "Successfully retrieved user usages", log.MaskedString(log.LoggerKeyUserID, id))
}

// HandleUserPutRequest handles the user request.
func (uh *userHandler) HandleUserPutRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	id := r.PathValue("id")
	if id == "" {
		sysutils.WriteErrorResponse(ctx, w, http.StatusBadRequest, apierror.ErrorResponse{
			Code:        ErrorMissingUserID.Code,
			Message:     ErrorMissingUserID.Error,
			Description: ErrorMissingUserID.ErrorDescription,
		})
		return
	}

	updateRequest, err := sysutils.DecodeJSONBody[providers.User](r)
	if err != nil {
		var valErr *sysutils.ValidationError
		if errors.As(err, &valErr) {
			sysutils.WriteStructuredErrorResponse(w, http.StatusBadRequest, "Validation Failed", valErr.Errors)
			return
		}
		sysutils.WriteErrorResponse(ctx, w, http.StatusBadRequest, apierror.ErrorResponse{
			Code:        ErrorInvalidRequestFormat.Code,
			Message:     ErrorInvalidRequestFormat.Error,
			Description: ErrorInvalidRequestFormat.ErrorDescription,
		})
		return
	}
	updateRequest.ID = id

	// Update the user using the user service.
	user, svcErr := uh.userService.UpdateUser(ctx, id, updateRequest)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, user)

	// Log the user response.
	logger.Debug(ctx, "User PUT response sent", log.MaskedString(log.LoggerKeyUserID, id))
}

// HandleUserDeleteRequest handles the delete user request.
func (uh *userHandler) HandleUserDeleteRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	id := r.PathValue("id")
	if id == "" {
		errResp := apierror.ErrorResponse{
			Code:        ErrorMissingUserID.Code,
			Message:     ErrorMissingUserID.Error,
			Description: ErrorMissingUserID.ErrorDescription,
		}
		sysutils.WriteErrorResponse(ctx, w, http.StatusBadRequest, errResp)
		return
	}

	// Delete the user using the user service.
	svcErr := uh.userService.DeleteUser(ctx, id)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusNoContent, nil)

	// Log the user response.
	logger.Debug(ctx, "User DELETE response sent", log.MaskedString(log.LoggerKeyUserID, id))
}

// HandleUserListByPathRequest handles the list users by OU path request.
func (uh *userHandler) HandleUserListByPathRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	path, pathValidationFailed := extractAndValidatePath(w, r)
	if pathValidationFailed {
		return
	}

	limit, offset, svcErr := parsePaginationParams(r.URL.Query())
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	if limit == 0 {
		limit = serverconst.DefaultPageSize
	}

	filters, svcErr := parseFilterParams(r.URL.Query())
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	// Parse include parameter to check if display names should be included.
	includeDisplay := r.URL.Query().Get(sysutils.QueryParamInclude) == sysutils.IncludeValueDisplay

	userListResponse, svcErr := uh.userService.GetUsersByPath(ctx, path, limit, offset, filters, includeDisplay)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, userListResponse)

	logger.Debug(ctx, "Successfully listed users by path", log.String("path", path),
		log.Int("limit", limit), log.Int("offset", offset),
		log.Int("totalResults", userListResponse.TotalResults),
		log.Int("count", userListResponse.Count),
		log.MaskedMap("filters", filters))
}

// HandleUserPostByPathRequest handles the create user by OU path request.
func (uh *userHandler) HandleUserPostByPathRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	path, pathValidationFailed := extractAndValidatePath(w, r)
	if pathValidationFailed {
		return
	}

	createRequest, err := sysutils.DecodeJSONBody[CreateUserByPathRequest](r)
	if err != nil {
		var valErr *sysutils.ValidationError
		if errors.As(err, &valErr) {
			sysutils.WriteStructuredErrorResponse(w, http.StatusBadRequest, "Validation Failed", valErr.Errors)
			return
		}
		sysutils.WriteErrorResponse(ctx, w, http.StatusBadRequest, apierror.ErrorResponse{
			Code:        ErrorInvalidRequestFormat.Code,
			Message:     ErrorInvalidRequestFormat.Error,
			Description: ErrorInvalidRequestFormat.ErrorDescription,
		})
		return
	}

	user, svcErr := uh.userService.CreateUserByPath(ctx, path, *createRequest)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusCreated, user)

	logger.Debug(ctx, "Successfully created user by path",
		log.String("path", path), log.String("userType", user.Type))
}

// HandleSelfUserGetRequest handles the self user retrieval.
func (uh *userHandler) HandleSelfUserGetRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	userID := security.GetSubject(ctx)
	if strings.TrimSpace(userID) == "" {
		handleError(ctx, w, &ErrorAuthenticationFailed)
		return
	}

	// Parse include parameter to check if display name should be included.
	includeDisplay := r.URL.Query().Get(sysutils.QueryParamInclude) == sysutils.IncludeValueDisplay

	user, svcErr := uh.userService.GetUser(ctx, userID, includeDisplay)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, withoutOperatorNote(user))

	logger.Debug(ctx, "Self user GET response sent", log.MaskedString(log.LoggerKeyUserID, userID))
}

// HandleSelfUserPutRequest handles the self user update.
func (uh *userHandler) HandleSelfUserPutRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	userID := security.GetSubject(ctx)
	if strings.TrimSpace(userID) == "" {
		handleError(ctx, w, &ErrorAuthenticationFailed)
		return
	}

	updateRequest, err := sysutils.DecodeJSONBody[UpdateSelfUserRequest](r)
	if err != nil {
		var valErr *sysutils.ValidationError
		if errors.As(err, &valErr) {
			sysutils.WriteStructuredErrorResponse(w, http.StatusBadRequest, "Validation Failed", valErr.Errors)
			return
		}
		handleError(ctx, w, &ErrorInvalidRequestFormat)
		return
	}

	if updateRequest == nil || len(updateRequest.Attributes) == 0 {
		handleError(ctx, w, &ErrorInvalidRequestFormat)
		return
	}

	updatedUser, svcErr := uh.userService.UpdateUserAttributes(ctx, userID, updateRequest.Attributes)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, withoutOperatorNote(updatedUser))

	logger.Debug(ctx, "Self user PUT response sent", log.MaskedString(log.LoggerKeyUserID, userID))
}

// HandleSelfUserMetadataGetRequest handles the self user metadata retrieval.
func (uh *userHandler) HandleSelfUserMetadataGetRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	userID := security.GetSubject(ctx)
	if strings.TrimSpace(userID) == "" {
		handleError(ctx, w, &ErrorAuthenticationFailed)
		return
	}

	userMetadata, svcErr := uh.userService.GetUserMetadata(ctx, userID)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	response := map[string]interface{}{
		"schema": userMetadata.Schema,
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, response)

	logger.Debug(ctx, "Self user metadata GET response sent", log.MaskedString(log.LoggerKeyUserID, userID))
}

// HandleSelfOrganizationUnitsGetRequest lists the organization units the signed-in user can access.
func (uh *userHandler) HandleSelfOrganizationUnitsGetRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	limit, offset, svcErr := parsePaginationParams(r.URL.Query())
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}
	if limit == 0 {
		limit = serverconst.DefaultPageSize
	}

	list, svcErr := uh.userService.GetAccessibleOrganizationUnits(ctx, r.URL.Query().Get("scope"), limit, offset)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, list)
}

// HandleSelfUserCredentialUpdateRequest handles the credential update for the authenticated user.
func (uh *userHandler) HandleSelfUserCredentialUpdateRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	userID := security.GetSubject(ctx)
	if strings.TrimSpace(userID) == "" {
		handleError(ctx, w, &ErrorAuthenticationFailed)
		return
	}

	updateRequest, err := sysutils.DecodeJSONBody[UpdateSelfUserRequest](r)
	if err != nil {
		var valErr *sysutils.ValidationError
		if errors.As(err, &valErr) {
			sysutils.WriteStructuredErrorResponse(w, http.StatusBadRequest, "Validation Failed", valErr.Errors)
			return
		}
		handleError(ctx, w, &ErrorInvalidRequestFormat)
		return
	}
	if updateRequest == nil {
		handleError(ctx, w, &ErrorInvalidRequestFormat)
		return
	}
	attrStr := strings.TrimSpace(string(updateRequest.Attributes))
	if len(updateRequest.Attributes) == 0 || attrStr == "{}" {
		handleError(ctx, w, &ErrorMissingCredentials)
		return
	}

	if svcErr := uh.userService.UpdateUserCredentials(ctx, userID, updateRequest.Attributes); svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusNoContent, nil)
	logger.Debug(ctx, "Self user credential update response sent",
		log.MaskedString(log.LoggerKeyUserID, userID))
}

// HandleUserCredentialUpdateRequest handles credential updates for a user by an admin.
func (uh *userHandler) HandleUserCredentialUpdateRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, handlerLoggerComponentName))

	id := r.PathValue("id")
	if strings.TrimSpace(id) == "" {
		handleError(ctx, w, &ErrorMissingUserID)
		return
	}

	updateRequest, err := sysutils.DecodeJSONBody[UpdateUserCredentialsRequest](r)
	if err != nil {
		var valErr *sysutils.ValidationError
		if errors.As(err, &valErr) {
			sysutils.WriteStructuredErrorResponse(w, http.StatusBadRequest, "Validation Failed", valErr.Errors)
			return
		}
		handleError(ctx, w, &ErrorInvalidRequestFormat)
		return
	}
	if updateRequest == nil {
		handleError(ctx, w, &ErrorInvalidRequestFormat)
		return
	}
	attrStr := strings.TrimSpace(string(updateRequest.Credentials))
	if len(updateRequest.Credentials) == 0 || attrStr == "{}" {
		handleError(ctx, w, &ErrorMissingCredentials)
		return
	}

	if svcErr := uh.userService.UpdateUserCredentials(ctx, id, updateRequest.Credentials); svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}

	sysutils.WriteSuccessResponse(ctx, w, http.StatusNoContent, nil)
	logger.Debug(ctx, "User credential update response sent",
		log.MaskedString(log.LoggerKeyUserID, id))
}

// parsePaginationParams parses limit and offset query parameters from the request.
func parsePaginationParams(query url.Values) (int, int, *tidcommon.ServiceError) {
	limit := 0
	offset := 0

	if limitStr := query.Get("limit"); limitStr != "" {
		if parsedLimit, err := strconv.Atoi(limitStr); err != nil {
			return 0, 0, &ErrorInvalidLimit
		} else if parsedLimit <= 0 {
			return 0, 0, &ErrorInvalidLimit
		} else {
			limit = parsedLimit
		}
	}

	if offsetStr := query.Get("offset"); offsetStr != "" {
		if parsedOffset, err := strconv.Atoi(offsetStr); err != nil {
			return 0, 0, &ErrorInvalidOffset
		} else if parsedOffset < 0 {
			return 0, 0, &ErrorInvalidOffset
		} else {
			offset = parsedOffset
		}
	}

	return limit, offset, nil
}

// handleError handles service errors and writes appropriate HTTP responses.
func handleError(ctx context.Context, w http.ResponseWriter, svcErr *tidcommon.ServiceError) {
	var statusCode int
	if svcErr.Type == tidcommon.ClientErrorType {
		switch svcErr.Code {
		case ErrorMissingUserID.Code,
			ErrorUserNotFound.Code,
			ErrorOrganizationUnitNotFound.Code,
			ErrorSharingPolicyNotFound.Code,
			ErrorUserNotSharedToOU.Code:
			statusCode = http.StatusNotFound
		case ErrorAttributeConflict.Code,
			ErrorUserHasBlockingDependencies.Code,
			ErrorSharingPolicyExists.Code,
			ErrorSharingPolicyVersionMismatch.Code,
			ErrorSharedUserCannotMove.Code:
			statusCode = http.StatusConflict
		case ErrorHandlePathRequired.Code,
			ErrorInvalidHandlePath.Code,
			ErrorMissingRequiredFields.Code,
			ErrorMissingCredentials.Code,
			ErrorEntityTypeNotFound.Code:
			statusCode = http.StatusBadRequest
		case ErrorAuthenticationFailed.Code:
			statusCode = http.StatusUnauthorized
		case tidcommon.ErrorUnauthorized.Code:
			statusCode = http.StatusForbidden
		default:
			statusCode = http.StatusBadRequest
		}
	} else {
		statusCode = http.StatusInternalServerError
	}

	errResp := apierror.ErrorResponse{
		Code:        svcErr.Code,
		Message:     svcErr.Error,
		Description: svcErr.ErrorDescription,
	}

	sysutils.WriteErrorResponse(ctx, w, statusCode, errResp)
}

// extractAndValidatePath extracts and validates the path parameter from the request.
func extractAndValidatePath(w http.ResponseWriter, r *http.Request) (string, bool) {
	path := r.PathValue("path")
	if path == "" {
		errResp := apierror.ErrorResponse{
			Code:        ErrorHandlePathRequired.Code,
			Message:     ErrorHandlePathRequired.Error,
			Description: ErrorHandlePathRequired.ErrorDescription,
		}
		sysutils.WriteErrorResponse(r.Context(), w, http.StatusBadRequest, errResp)
		return "", true
	}
	return path, false
}

// parseFilterParams parses and sanitizes filter query parameters from the request.
func parseFilterParams(query url.Values) (map[string]interface{}, *tidcommon.ServiceError) {
	if !query.Has("filter") {
		return make(map[string]interface{}), nil
	}

	filterStr := query.Get("filter")
	filterStr = strings.TrimSpace(filterStr)
	if filterStr == "" {
		return nil, &ErrorInvalidFilter
	}

	parsedFilter, err := parseFilterExpression(filterStr)
	if err != nil {
		return nil, &ErrorInvalidFilter
	}

	sanitized := sanitizeFilter(parsedFilter)

	return sanitized, nil
}

// parseFilterExpression parses filter expressions in the format: attribute eq "value"
func parseFilterExpression(filterStr string) (map[string]interface{}, error) {
	// Regex to match: attribute_name eq "value" or attribute_name eq value
	pattern := `^(\w+(?:\.\w+)*)\s+(eq)\s+(?:"([^"]*)"|(\w+|\d+))$`
	regex := regexp.MustCompile(pattern)

	matches := regex.FindStringSubmatch(filterStr)
	if len(matches) == 0 {
		return nil, fmt.Errorf("invalid filter format")
	}

	attribute := matches[1]
	operator := matches[2]

	if operator != "eq" {
		return nil, fmt.Errorf("unsupported operator: %s", operator)
	}

	// Get the value (either quoted string or unquoted value)
	if matches[3] != "" {
		return map[string]interface{}{attribute: matches[3]}, nil
	} else {
		value := matches[4] // Unquoted value
		// Try to convert numeric values
		if intVal, err := strconv.ParseInt(value, 10, 64); err == nil {
			return map[string]interface{}{attribute: intVal}, nil
		}
		// If not an integer, try to parse as float
		if floatVal, err := strconv.ParseFloat(value, 64); err == nil {
			return map[string]interface{}{attribute: floatVal}, nil
		}

		// Check for boolean values
		if bool, err := strconv.ParseBool(value); err == nil {
			return map[string]interface{}{attribute: bool}, nil
		}

		return nil, fmt.Errorf("invalid filter value")
	}
}

// withoutOperatorNote returns the user with the operator note cleared from its status.
func withoutOperatorNote(user *providers.User) *providers.User {
	if user == nil || user.Status == nil || user.Status.Details == nil || user.Status.Details.OperatorNote == "" {
		return user
	}
	details := *user.Status.Details
	details.OperatorNote = ""
	status := *user.Status
	status.Details = &details
	stripped := *user
	stripped.Status = &status
	return &stripped
}

// sanitizeFilter performs additional sanitization on parsed filters
func sanitizeFilter(filters map[string]interface{}) map[string]interface{} {
	sanitized := make(map[string]interface{})

	for key, value := range filters {
		sanitizedKey := sysutils.SanitizeString(key)

		if strValue, ok := value.(string); ok {
			sanitized[sanitizedKey] = sysutils.SanitizeString(strValue)
		} else {
			sanitized[sanitizedKey] = value
		}
	}

	return sanitized
}

// HandleSharingPolicyPostRequest records a sharing policy on a user.
func (uh *userHandler) HandleSharingPolicyPostRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	wire, ok := sharing.DecodePolicyBody[sharing.PolicyCreateBody](ctx, w, r, ErrorInvalidRequestFormat)
	if !ok {
		return
	}
	req := wire.ToPolicyRequest()
	// A reach not bounded by the issuer's place in the tree is a deployment decision, as for
	// applications; the framework refuses an edit that would introduce one.
	if req.IsDeploymentWide() {
		handleError(ctx, w, &ErrorDeploymentWideSharingNotAllowed)
		return
	}

	policy, svcErr := uh.userService.CreateSharingPolicy(ctx, r.PathValue("id"), req)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusCreated, sharing.ToPolicyResponse(policy))
}

// HandleSharingPolicyListRequest returns one page of a user's sharing policies.
func (uh *userHandler) HandleSharingPolicyListRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	limit, offset, svcErr := parsePaginationParams(r.URL.Query())
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}
	if limit == 0 {
		limit = serverconst.DefaultPageSize
	}

	userID := r.PathValue("id")
	list, svcErr := uh.userService.ListSharingPolicies(ctx, userID, limit, offset)
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, sharing.ToPolicyListResponse(
		list, "/users/"+userID+"/sharing-policies", limit, offset))
}

// HandleSharingPolicyGetRequest returns one of a user's sharing policies.
func (uh *userHandler) HandleSharingPolicyGetRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	policy, svcErr := uh.userService.GetSharingPolicy(ctx, r.PathValue("id"), r.PathValue("policyId"))
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, sharing.ToPolicyResponse(policy))
}

// HandleSharingPolicyPutRequest replaces a sharing policy's contents.
func (uh *userHandler) HandleSharingPolicyPutRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	wire, ok := sharing.DecodePolicyBody[sharing.PolicyUpdateBody](ctx, w, r, ErrorInvalidRequestFormat)
	if !ok {
		return
	}

	policy, svcErr := uh.userService.UpdateSharingPolicy(
		ctx, r.PathValue("id"), r.PathValue("policyId"), wire.ToPolicyRequest())
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, sharing.ToPolicyResponse(policy))
}

// HandleSharingPolicyDeleteRequest removes a sharing policy.
func (uh *userHandler) HandleSharingPolicyDeleteRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	if svcErr := uh.userService.DeleteSharingPolicy(ctx, r.PathValue("id"), r.PathValue("policyId")); svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// HandleOverlayRuleGetRequest answers what the organization unit named in ouId may do with the user.
func (uh *userHandler) HandleOverlayRuleGetRequest(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	overlay, svcErr := uh.userService.ResolveSharingOverlay(ctx, r.PathValue("id"), r.URL.Query().Get("ouId"))
	if svcErr != nil {
		handleError(ctx, w, svcErr)
		return
	}
	sysutils.WriteSuccessResponse(ctx, w, http.StatusOK, sharing.ToResolvedOverlayResponse(overlay))
}
