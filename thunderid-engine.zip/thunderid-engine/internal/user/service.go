// Copyright 2025-2026 The ThunderID Authors
// SPDX-License-Identifier: Apache-2.0

// Package user provides user management functionality.
package user

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"path"
	"slices"
	"sort"
	"strings"

	tidcommon "github.com/thunder-id/thunderid/pkg/thunderidengine/common"
	"github.com/thunder-id/thunderid/pkg/thunderidengine/providers"

	"github.com/thunder-id/thunderid/internal/entity"
	"github.com/thunder-id/thunderid/internal/entitytype"
	"github.com/thunder-id/thunderid/internal/identitygovernance"
	oupkg "github.com/thunder-id/thunderid/internal/ou"
	"github.com/thunder-id/thunderid/internal/sharing"
	serverconst "github.com/thunder-id/thunderid/internal/system/constants"
	declarativeresource "github.com/thunder-id/thunderid/internal/system/declarative_resource"
	"github.com/thunder-id/thunderid/internal/system/filter"
	"github.com/thunder-id/thunderid/internal/system/log"
	"github.com/thunder-id/thunderid/internal/system/resourcedependency"
	"github.com/thunder-id/thunderid/internal/system/security"
	"github.com/thunder-id/thunderid/internal/system/sysauthz"
	"github.com/thunder-id/thunderid/internal/system/utils"
)

const loggerComponentName = "UserService"

// UserServiceInterface defines the interface for the user service.
type UserServiceInterface interface {
	GetUserList(ctx context.Context, limit, offset int,
		filters map[string]interface{}, includeDisplay bool) (*UserListResponse, *tidcommon.ServiceError)
	GetUsersByPath(ctx context.Context, handlePath string, limit, offset int,
		filters map[string]interface{}, includeDisplay bool) (*UserListResponse, *tidcommon.ServiceError)
	CreateUser(ctx context.Context, user *providers.User) (*providers.User, *tidcommon.ServiceError)
	CreateUserByPath(ctx context.Context, handlePath string,
		request CreateUserByPathRequest) (*providers.User, *tidcommon.ServiceError)
	GetUser(ctx context.Context, userID string, includeDisplay bool) (*providers.User, *tidcommon.ServiceError)
	GetUserGroups(ctx context.Context, userID string,
		limit, offset int) (*UserGroupListResponse, *tidcommon.ServiceError)
	UpdateUser(ctx context.Context, userID string, user *providers.User) (*providers.User, *tidcommon.ServiceError)
	UpdateUserAttributes(ctx context.Context, userID string,
		attributes json.RawMessage) (*providers.User, *tidcommon.ServiceError)
	GetUserMetadata(ctx context.Context, userID string) (*entitytype.EntityType, *tidcommon.ServiceError)
	UpdateUserCredentials(ctx context.Context, userID string,
		credentials json.RawMessage) *tidcommon.ServiceError
	DeleteUser(ctx context.Context, userID string) *tidcommon.ServiceError
	ValidateDeleteUser(ctx context.Context, userID string) *tidcommon.ServiceError
	ResolveUserOUHandle(ctx context.Context, user *providers.User) *tidcommon.ServiceError
	SetDependencyRegistry(r resourcedependency.Registry)
	GetUserUsages(ctx context.Context, userID string) (
		*resourcedependency.DependenciesResponse, *tidcommon.ServiceError)
	CreateSharingPolicy(ctx context.Context, userID string,
		req sharing.PolicyRequest) (sharing.Policy, *tidcommon.ServiceError)
	GetSharingPolicy(ctx context.Context, userID, policyID string) (sharing.Policy, *tidcommon.ServiceError)
	ListSharingPolicies(ctx context.Context, userID string,
		limit, offset int) (sharing.PolicyList, *tidcommon.ServiceError)
	UpdateSharingPolicy(ctx context.Context, userID, policyID string,
		req sharing.PolicyRequest) (sharing.Policy, *tidcommon.ServiceError)
	DeleteSharingPolicy(ctx context.Context, userID, policyID string) *tidcommon.ServiceError
	ResolveSharingOverlay(ctx context.Context, userID, ouID string) (sharing.ResolvedOverlay, *tidcommon.ServiceError)
	GetAccessibleOrganizationUnits(ctx context.Context, scope string,
		limit, offset int) (*AccessibleOrganizationUnitListResponse, *tidcommon.ServiceError)
}

// userService is the default implementation of the UserServiceInterface.
type userService struct {
	authzService       sysauthz.SystemAuthorizationServiceInterface
	entityService      entity.EntityServiceInterface
	governance         identitygovernance.IdentityGovernanceServiceInterface
	ouService          oupkg.OrganizationUnitServiceInterface
	entityTypeService  entitytype.EntityTypeServiceInterface
	uuidGenerator      func() (string, error)
	dependencyRegistry resourcedependency.Registry
	valueCapturer      declarativeresource.ValueCapturer
	sharingService     sharing.SharingServiceInterface
}

// newUserService creates a new instance of userService with injected dependencies.
func newUserService(
	authzService sysauthz.SystemAuthorizationServiceInterface,
	entityService entity.EntityServiceInterface,
	ouService oupkg.OrganizationUnitServiceInterface,
	entityTypeService entitytype.EntityTypeServiceInterface,
	governance identitygovernance.IdentityGovernanceServiceInterface,
	valueCapturer declarativeresource.ValueCapturer,
	sharingService sharing.SharingServiceInterface,
) UserServiceInterface {
	return &userService{
		authzService:      authzService,
		entityService:     entityService,
		governance:        governance,
		ouService:         ouService,
		entityTypeService: entityTypeService,
		uuidGenerator:     utils.GenerateUUIDv7,
		valueCapturer:     valueCapturer,
		sharingService:    sharingService,
	}
}

// GetUserList retrieves a list of users with pagination and filtering. An organization unit filter
// lists the users that unit owns, followed by the ones shared into it.
func (us *userService) GetUserList(ctx context.Context, limit, offset int,
	filters map[string]interface{}, includeDisplay bool) (*UserListResponse, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))

	if err := validatePaginationParams(limit, offset); err != nil {
		return nil, err
	}

	listQuery := utils.FilterQueryParam(filters) + utils.DisplayQueryParam(includeDisplay)
	ouID, filters, err := filter.SplitOUIDFilter(filters)
	if err != nil {
		return nil, &ErrorInvalidFilter
	}
	// Other conditions cannot narrow the users shared into an organization unit yet, so they are
	// refused alongside one rather than applied to the owned users only.
	if ouID != "" && len(filters) > 0 {
		return nil, &ErrorInvalidFilter
	}

	// Resolve the set of organization units the caller is authorized to list users from.
	accessible, svcErr := us.authzService.GetAccessibleResources(
		ctx, security.ActionListUsers, security.ResourceTypeOU)
	if svcErr != nil {
		logger.Error(ctx, "Failed to resolve accessible resources for listing users",
			log.Any("error", svcErr))
		return nil, &tidcommon.InternalServerError
	}

	if ouID != "" {
		// An organization unit the caller cannot list users from has none to show.
		if !accessible.AllAllowed && !slices.Contains(accessible.IDs, ouID) {
			return buildUserListResponse([]providers.User{}, 0, limit, offset, listQuery), nil
		}
		users, totalCount, listErr := us.listUsersInOU(ctx, ouID, limit, offset, filters, includeDisplay, logger)
		if listErr != nil {
			return nil, listErr
		}
		return buildUserListResponse(users, totalCount, limit, offset, listQuery), nil
	}

	// Unfiltered path: system-level caller — return all users.
	if accessible.AllAllowed {
		return us.listAllUsers(ctx, limit, offset, filters, includeDisplay, listQuery, logger)
	}

	// Filtered path: return users belonging to the accessible OUs.
	return us.listUsersByOUIDs(ctx, accessible.IDs, limit, offset, filters, includeDisplay, listQuery, logger)
}

// listAllUsers retrieves users without OU filtering.
func (us *userService) listAllUsers(
	ctx context.Context, limit, offset int, filters map[string]interface{},
	includeDisplay bool, listQuery string, logger *log.Logger,
) (*UserListResponse, *tidcommon.ServiceError) {
	totalCount, err := us.entityService.GetEntityListCount(ctx, providers.EntityCategoryUser, filters)
	if err != nil {
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to get user list count", err)
	}

	entities, err := us.entityService.GetEntityList(ctx, providers.EntityCategoryUser, limit, offset, filters)
	if err != nil {
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to get user list", err)
	}

	users := us.usersWithAccess(ctx, entities)
	markOwned(users, true)
	if includeDisplay {
		us.populateUserDisplayNames(ctx, users, logger)
		us.populateOUHandles(ctx, users, logger)
	}

	return buildUserListResponse(users, totalCount, limit, offset, listQuery), nil
}

// listUsersByOUIDs retrieves users scoped to the given organization unit IDs.
func (us *userService) listUsersByOUIDs(
	ctx context.Context, ouIDs []string, limit, offset int, filters map[string]interface{},
	includeDisplay bool, listQuery string, logger *log.Logger,
) (*UserListResponse, *tidcommon.ServiceError) {
	if len(ouIDs) == 0 {
		return buildUserListResponse([]providers.User{}, 0, limit, offset, listQuery), nil
	}

	totalCount, err := us.entityService.GetEntityListCountByOUIDs(ctx, providers.EntityCategoryUser, ouIDs, filters)
	if err != nil {
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to get user list count", err)
	}

	entities, err := us.entityService.GetEntityListByOUIDs(
		ctx, providers.EntityCategoryUser, ouIDs, limit, offset, filters)
	if err != nil {
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to get user list", err)
	}

	users := us.usersWithAccess(ctx, entities)
	markOwned(users, true)
	if includeDisplay {
		us.populateUserDisplayNames(ctx, users, logger)
		us.populateOUHandles(ctx, users, logger)
	}

	return buildUserListResponse(users, totalCount, limit, offset, listQuery), nil
}

// listUsersInOU lists the users an organization unit owns, followed by the ones shared into it, and
// returns the total across every page.
func (us *userService) listUsersInOU(
	ctx context.Context, ouID string, limit, offset int, filters map[string]interface{},
	includeDisplay bool, logger *log.Logger,
) ([]providers.User, int, *tidcommon.ServiceError) {
	page, err := us.entityService.GetEntityPageInOU(
		ctx, providers.EntityCategoryUser, ouID, entity.OUEntityScopeAll, limit, offset, filters)
	if err != nil {
		return nil, 0, logErrorAndReturnServerError(ctx, logger, "Failed to list users in organization unit", err)
	}

	users := us.usersWithAccess(ctx, slices.Concat(page.Owned, page.Shared))
	markOwned(users[:len(page.Owned)], true)
	markOwned(users[len(page.Owned):], false)
	// A shared user is listed under the organization unit it is shared into, not the one owning it.
	for i := len(page.Owned); i < len(users); i++ {
		users[i].OUID = ouID
	}
	if includeDisplay {
		us.populateUserDisplayNames(ctx, users, logger)
		us.populateOUHandles(ctx, users, logger)
	}
	return users, page.TotalResults, nil
}

// buildUserListResponse constructs a paginated UserListResponse.
func buildUserListResponse(
	users []providers.User, totalCount, limit, offset int, listQuery string,
) *UserListResponse {
	return &UserListResponse{
		TotalResults: totalCount,
		StartIndex:   offset + 1,
		Count:        len(users),
		Users:        users,
		Links:        utils.BuildPaginationLinks("/users", limit, offset, totalCount, listQuery),
	}
}

// GetUsersByPath retrieves a list of users by hierarchical handle path.
func (us *userService) GetUsersByPath(
	ctx context.Context, handlePath string, limit, offset int, filters map[string]interface{},
	includeDisplay bool,
) (*UserListResponse, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))
	logger.Debug(ctx, "Getting users by path", log.String("path", handlePath))

	serviceError := validateAndProcessHandlePath(handlePath)
	if serviceError != nil {
		return nil, serviceError
	}
	// The path names the organization unit, and a filter cannot narrow the users shared into it yet,
	// so a filter is refused rather than applied to the owned users only.
	if len(filters) > 0 {
		return nil, &ErrorInvalidFilter
	}

	ou, svcErr := us.ouService.GetOrganizationUnitByPath(ctx, handlePath)
	if svcErr != nil {
		return nil, mapOUServiceError(ctx,
			svcErr,
			logger,
			"resolving organization unit by path",
			map[string]*tidcommon.ServiceError{
				oupkg.ErrorOrganizationUnitNotFound.Code: &ErrorOrganizationUnitNotFound,
				oupkg.ErrorInvalidHandlePath.Code:        &ErrorInvalidHandlePath,
			},
			log.String("path", handlePath),
		)
	}
	oUID := ou.ID

	// Check if caller is authorized to list users in the resolved OU.
	if svcErr := us.checkUserAccess(ctx, security.ActionListUsers, oUID, ""); svcErr != nil {
		return nil, svcErr
	}

	if err := validatePaginationParams(limit, offset); err != nil {
		return nil, err
	}

	users, totalCount, svcErr := us.listUsersInOU(ctx, oUID, limit, offset, nil, includeDisplay, logger)
	if svcErr != nil {
		return nil, svcErr
	}

	return &UserListResponse{
		TotalResults: totalCount,
		StartIndex:   offset + 1,
		Count:        len(users),
		Users:        users,
		Links: buildTreePaginationLinks(
			handlePath, limit, offset, totalCount, utils.DisplayQueryParam(includeDisplay)),
	}, nil
}

// CreateUser creates the user.
func (us *userService) CreateUser(
	ctx context.Context, user *providers.User,
) (*providers.User, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))

	if user == nil {
		return nil, &ErrorInvalidRequestFormat
	}
	if user.LinkedAccount != nil && (user.LinkedAccount.IdpID == "" || user.LinkedAccount.Sub == "") {
		return nil, &ErrorInvalidRequestFormat
	}

	// Check if caller is authorized to create users in the target OU.
	if svcErr := us.checkUserAccess(ctx, security.ActionCreateUser, user.OUID, ""); svcErr != nil {
		return nil, svcErr
	}

	if svcErr := us.validateOrganizationUnitForUserType(ctx, user.Type, user.OUID, logger); svcErr != nil {
		return nil, svcErr
	}

	// Schema validation and uniqueness checks are handled by entity service in CreateEntity.

	var err error
	if user.ID == "" {
		user.ID, err = us.uuidGenerator()
		if err != nil {
			logger.Error(ctx, "Failed to generate UUID", log.Error(err))
			return nil, &tidcommon.InternalServerError
		}
	}

	e := userToEntity(user)
	submitted := user.Attributes
	created, err := us.entityService.CreateEntity(ctx, e, nil, user.LinkedAccount)
	if err != nil {
		if svcErr := mapEntityError(err); svcErr != nil {
			return nil, svcErr
		}
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to create user", err)
	}

	// Sync cleaned attributes back — entity service removed credential fields from Attributes.
	user.Attributes = created.Attributes
	us.captureSubmittedCredentials(ctx, user, submitted)

	logger.Debug(ctx, "Successfully created user", log.MaskedString(log.LoggerKeyUserID, user.ID))
	return user, nil
}

// CreateUserByPath creates a new user under the organization unit specified by the handle path.
func (us *userService) CreateUserByPath(
	ctx context.Context, handlePath string, request CreateUserByPathRequest,
) (*providers.User, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))
	logger.Debug(ctx, "Creating user by path",
		log.String("path", handlePath), log.String("type", request.Type))

	serviceError := validateAndProcessHandlePath(handlePath)
	if serviceError != nil {
		return nil, serviceError
	}

	ou, svcErr := us.ouService.GetOrganizationUnitByPath(ctx, handlePath)
	if svcErr != nil {
		return nil, mapOUServiceError(ctx,
			svcErr,
			logger,
			"resolving organization unit by path",
			map[string]*tidcommon.ServiceError{
				oupkg.ErrorOrganizationUnitNotFound.Code: &ErrorOrganizationUnitNotFound,
				oupkg.ErrorInvalidHandlePath.Code:        &ErrorInvalidHandlePath,
			},
			log.String("path", handlePath),
		)
	}

	user := &providers.User{
		OUID:       ou.ID,
		Type:       request.Type,
		Attributes: request.Attributes,
	}

	return us.CreateUser(ctx, user)
}

// GetUser retrieves a user by ID.
func (us *userService) GetUser(
	ctx context.Context, userID string, includeDisplay bool,
) (*providers.User, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))
	logger.Debug(ctx, "Retrieving user", log.MaskedString(log.LoggerKeyUserID, userID))

	if userID == "" {
		return nil, &ErrorMissingUserID
	}

	e, err := us.entityService.GetEntity(ctx, userID)
	if err != nil {
		if errors.Is(err, entity.ErrEntityNotFound) {
			logger.Debug(ctx, "User not found", log.MaskedString(log.LoggerKeyUserID, userID))
			return nil, &ErrorUserNotFound
		}
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to retrieve user", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}
	if e.Category != providers.EntityCategoryUser {
		return nil, &ErrorUserNotFound
	}
	user := entityToUser(e)

	// Check authz using the user's OU ID (fetched from store).
	if svcErr := us.checkUserAccess(ctx, security.ActionReadUser, user.OUID, userID); svcErr != nil {
		return nil, svcErr
	}
	access := us.governance.ReadEntityAccess(ctx, *e)
	user.Status = &access.Status
	user.LastLoginAt = access.LastLoginAt

	if includeDisplay {
		displayAttrPaths := entitytype.ResolveDisplayAttributePaths(
			ctx, entitytype.TypeCategoryUser, []string{user.Type}, us.entityTypeService, logger)
		user.Display = utils.ResolveDisplay(
			user.ID, user.Type, user.Attributes, displayAttrPaths)

		handleMap, svcErr := us.ouService.GetOrganizationUnitHandlesByIDs(ctx, []string{user.OUID})
		if svcErr != nil {
			logger.Warn(ctx, "Failed to resolve OU handle for user, skipping",
				log.Any("error", svcErr))
		} else if handle, ok := handleMap[user.OUID]; ok {
			user.OUHandle = handle
		}
	}

	logger.Debug(ctx, "Successfully retrieved user", log.MaskedString(log.LoggerKeyUserID, userID))
	return &user, nil
}

// GetUserMetadata retrieves the schema metadata for the authenticated user's type.
func (us *userService) GetUserMetadata(
	ctx context.Context, userID string,
) (*entitytype.EntityType, *tidcommon.ServiceError) {
	user, svcErr := us.GetUser(ctx, userID, false)
	if svcErr != nil {
		return nil, svcErr
	}

	schema, svcErr := us.entityTypeService.GetEntityTypeSchema(ctx, entitytype.TypeCategoryUser, user.Type)
	if svcErr != nil {
		return nil, svcErr
	}

	return schema, nil
}

// GetUserGroups retrieves groups of a user with pagination.
func (as *userService) GetUserGroups(ctx context.Context, userID string, limit, offset int) (
	*UserGroupListResponse, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))

	if userID == "" {
		return nil, &ErrorMissingUserID
	}

	if err := validatePaginationParams(limit, offset); err != nil {
		return nil, err
	}

	// Fetch user to resolve the OU ID for the authorization check.
	userEntity, err := as.entityService.GetEntityProfile(ctx, userID)
	if err != nil {
		if errors.Is(err, entity.ErrEntityNotFound) {
			logger.Debug(ctx, "User not found", log.MaskedString(log.LoggerKeyUserID, userID))
			return nil, &ErrorUserNotFound
		}
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to retrieve user", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}
	if userEntity.Category != providers.EntityCategoryUser {
		return nil, &ErrorUserNotFound
	}

	// Check authz using the user's OU ID.
	if svcErr := as.checkUserAccess(
		ctx, security.ActionReadUser, userEntity.OUID, userID); svcErr != nil {
		return nil, svcErr
	}

	totalCount, err := as.entityService.GetGroupCountForEntity(ctx, userID)
	if err != nil {
		logger.Error(ctx, "Failed to get group count for user",
			log.MaskedString(log.LoggerKeyUserID, userID), log.Error(err))
		return nil, &tidcommon.InternalServerError
	}

	entityGroups, err := as.entityService.GetEntityGroups(ctx, userID, limit, offset)
	if err != nil {
		logger.Error(ctx, "Failed to get user groups",
			log.MaskedString(log.LoggerKeyUserID, userID), log.Error(err))
		return nil, &tidcommon.InternalServerError
	}
	path := fmt.Sprintf("/users/%s/groups", userID)
	links := utils.BuildPaginationLinks(path, limit, offset, totalCount, "")

	response := &UserGroupListResponse{
		TotalResults: totalCount,
		Groups:       entityGroups,
		StartIndex:   offset + 1,
		Count:        len(entityGroups),
		Links:        links,
	}

	return response, nil
}

// UpdateUser update the user for given user id.
func (us *userService) UpdateUser(
	ctx context.Context, userID string, user *providers.User) (*providers.User, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))
	logger.Debug(ctx, "Updating user", log.MaskedString(log.LoggerKeyUserID, userID))

	if userID == "" {
		return nil, &ErrorMissingUserID
	}

	if user == nil {
		return nil, &ErrorInvalidRequestFormat
	}

	// Fetch the existing user to obtain its OU ID for the authorization check.
	existingEntity, err := us.entityService.GetEntityProfile(ctx, userID)
	if err != nil {
		if errors.Is(err, entity.ErrEntityNotFound) {
			logger.Debug(ctx, "User not found", log.MaskedString(log.LoggerKeyUserID, userID))
			return nil, &ErrorUserNotFound
		}
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to retrieve user", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}
	if existingEntity.Category != providers.EntityCategoryUser {
		return nil, &ErrorUserNotFound
	}
	existingUser := entityToUser(existingEntity)

	// Check authz using the existing user's OU ID.
	if svcErr := us.checkUserAccess(
		ctx, security.ActionUpdateUser, existingUser.OUID, userID); svcErr != nil {
		return nil, svcErr
	}

	// If the user is moving to a different OU, require authorization for the destination OU as well.
	if user.OUID != existingUser.OUID {
		if svcErr := us.checkUserAccess(
			ctx, security.ActionUpdateUser, user.OUID, userID); svcErr != nil {
			return nil, svcErr
		}
	}

	// Check if user is declarative (immutable)
	if svcErr := us.checkUserDeclarative(ctx, userID, logger); svcErr != nil {
		return nil, svcErr
	}

	// A shared user stays in its organization unit: its policies were issued against that unit.
	if user.OUID != existingUser.OUID {
		policies, svcErr := us.sharingService.ListPolicies(ctx, UserSharingType, userID)
		if svcErr != nil {
			return nil, translateSharingError(svcErr)
		}
		if len(policies) > 0 {
			return nil, &ErrorSharedUserCannotMove
		}
	}

	// Ensure the user object has the correct ID
	user.ID = userID

	if svcErr := us.validateOrganizationUnitForUserType(
		ctx, user.Type, user.OUID, logger,
	); svcErr != nil {
		return nil, svcErr
	}

	// Reject credential fields: this endpoint is for attribute and user metadata updates only.
	// Credentials must go through the dedicated update-credentials endpoint.
	if len(user.Attributes) > 0 {
		schemaCredentialInfos, svcErr := us.entityTypeService.GetAttributes(ctx,
			entitytype.TypeCategoryUser, user.Type, entitytype.AttributeFilter{AllowCredential: true})
		if svcErr != nil {
			if svcErr.Code == entitytype.ErrorEntityTypeNotFound.Code {
				return nil, &ErrorEntityTypeNotFound
			}
			return nil, logErrorAndReturnServerError(ctx, logger, "Failed to get credential attributes from schema",
				fmt.Errorf("schema service error: %s", svcErr.ErrorDescription.DefaultValue),
				log.MaskedString(log.LoggerKeyUserID, userID))
		}
		if len(schemaCredentialInfos) > 0 {
			var attrs map[string]any
			if err := json.Unmarshal(user.Attributes, &attrs); err != nil {
				return nil, &ErrorInvalidRequestFormat
			}
			for _, credInfo := range schemaCredentialInfos {
				if _, ok := attrs[credInfo.Attribute]; ok {
					return nil, &ErrorCredentialUpdateNotAllowed
				}
			}
		}
	}

	e := userToEntity(user)
	e.SystemAttributes = existingEntity.SystemAttributes
	updated, err := us.entityService.UpdateEntity(ctx, userID, e)
	if err != nil {
		if svcErr := mapEntityError(err); svcErr != nil {
			return nil, svcErr
		}
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to update user", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}

	// Sync cleaned attributes back — entity service removed credential fields from Attributes.
	user.Attributes = updated.Attributes
	// The status is derived from the updated entity, never taken from the request.
	access := us.governance.ReadEntityAccess(ctx, *updated)
	user.Status = &access.Status
	user.LastLoginAt = access.LastLoginAt
	logger.Debug(ctx, "Successfully updated user", log.MaskedString(log.LoggerKeyUserID, userID))
	return user, nil
}

// UpdateUserAttributes updates only the attributes of a user while preserving immutable fields.
func (us *userService) UpdateUserAttributes(
	ctx context.Context, userID string, attributes json.RawMessage,
) (*providers.User, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))
	logger.Debug(ctx, "Updating user attributes", log.MaskedString(log.LoggerKeyUserID, userID))

	if strings.TrimSpace(userID) == "" {
		return nil, &ErrorMissingUserID
	}

	if len(attributes) == 0 {
		return nil, &ErrorInvalidRequestFormat
	}

	// Pre-fetch user to get the type for credential field lookup (outside transaction).
	existingEntity, getErr := us.entityService.GetEntity(ctx, userID)
	if getErr != nil {
		if errors.Is(getErr, entity.ErrEntityNotFound) {
			logger.Debug(ctx, "User not found", log.MaskedString(log.LoggerKeyUserID, userID))
			return nil, &ErrorUserNotFound
		}
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to get user", getErr,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}
	if existingEntity.Category != providers.EntityCategoryUser {
		return nil, &ErrorUserNotFound
	}
	existingUser := entityToUser(existingEntity)

	// Reject credential fields here: this endpoint is for attribute updates only.
	// Credentials must go through UpdateUserCredentials, which enforces its own authz and validation.
	if us.entityTypeService == nil {
		logger.Error(ctx, "Entity type service is not configured for user operations")
		return nil, &tidcommon.InternalServerError
	}
	schemaCredentialInfos, svcErr := us.entityTypeService.GetAttributes(ctx,
		entitytype.TypeCategoryUser, existingUser.Type, entitytype.AttributeFilter{AllowCredential: true})
	if svcErr != nil {
		if svcErr.Code == entitytype.ErrorEntityTypeNotFound.Code {
			return nil, &ErrorEntityTypeNotFound
		}
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to get credential attributes from schema",
			fmt.Errorf("schema service error: %s", svcErr.ErrorDescription.DefaultValue),
			log.MaskedString(log.LoggerKeyUserID, userID))
	}
	if len(schemaCredentialInfos) > 0 {
		var attrs map[string]any
		if err := json.Unmarshal(attributes, &attrs); err != nil {
			return nil, &ErrorInvalidRequestFormat
		}
		for _, credInfo := range schemaCredentialInfos {
			if _, ok := attrs[credInfo.Attribute]; ok {
				return nil, &ErrorInvalidRequestFormat
			}
		}
	}

	// Check authz outside the transaction so a denial is returned directly without a rollback.
	if svcErr := us.checkUserAccess(
		ctx, security.ActionUpdateUser, existingUser.OUID, userID); svcErr != nil {
		return nil, svcErr
	}

	// Check if user is declarative (immutable)
	if svcErr := us.checkUserDeclarative(ctx, userID, logger); svcErr != nil {
		return nil, svcErr
	}

	existingUser.Attributes = attributes

	if err := us.entityService.UpdateAttributes(ctx, userID, attributes); err != nil {
		if svcErr := mapEntityError(err); svcErr != nil {
			return nil, svcErr
		}
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to update user attributes", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}

	access := us.governance.ReadEntityAccess(ctx, *existingEntity)
	existingUser.Status = &access.Status
	existingUser.LastLoginAt = access.LastLoginAt

	logger.Debug(ctx, "Successfully updated user attributes", log.MaskedString(log.LoggerKeyUserID, userID))
	return &existingUser, nil
}

// UpdateUserCredentials updates schema-defined credentials for a user.
func (us *userService) UpdateUserCredentials(
	ctx context.Context,
	userID string,
	credentials json.RawMessage,
) *tidcommon.ServiceError {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))
	logger.Debug(ctx, "Updating user credentials", log.MaskedString(log.LoggerKeyUserID, userID))

	if strings.TrimSpace(userID) == "" {
		return &ErrorAuthenticationFailed
	}

	if len(credentials) == 0 {
		return &ErrorMissingCredentials
	}

	// Parse credentials to extract credential types
	var credentialsMap map[string]json.RawMessage
	if err := json.Unmarshal(credentials, &credentialsMap); err != nil {
		logger.Debug(ctx, "Failed to parse credentials", log.Error(err))
		return &ErrorInvalidRequestFormat
	}

	if len(credentialsMap) == 0 {
		return &ErrorMissingCredentials
	}

	// Reject system-managed credential types (e.g., passkey). Only schema-defined
	// credentials may be updated through this endpoint.
	for credTypeStr := range credentialsMap {
		if CredentialType(credTypeStr).IsSystemManaged() {
			return &ErrorInvalidCredential
		}
	}

	// Fetch user outside the transaction to resolve the OU ID for the authorization check.
	existingEntity, err := us.entityService.GetEntityProfile(ctx, userID)
	if err != nil {
		if errors.Is(err, entity.ErrEntityNotFound) {
			logger.Debug(ctx, "User not found", log.MaskedString(log.LoggerKeyUserID, userID))
			return &ErrorUserNotFound
		}
		return logErrorAndReturnServerError(ctx, logger, "Failed to retrieve user", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}
	if existingEntity.Category != providers.EntityCategoryUser {
		return &ErrorUserNotFound
	}
	existingUser := entityToUser(existingEntity)

	// Check authz outside the transaction so a denial is returned directly without a rollback.
	if svcErr := us.checkUserAccess(
		ctx, security.ActionUpdateUser, existingUser.OUID, userID); svcErr != nil {
		return svcErr
	}

	// Check if user is declarative (immutable)
	if svcErr := us.checkUserDeclarative(ctx, userID, logger); svcErr != nil {
		return svcErr
	}

	// Normalize credential values to plaintext strings. Entity service enforces the
	// schema-credential allowlist and non-empty checks.
	plaintextCreds := make(map[string]string, len(credentialsMap))
	for credTypeStr, credValue := range credentialsMap {
		if len(credValue) == 0 {
			return &ErrorMissingCredentials
		}
		var stringValue string
		if err := json.Unmarshal(credValue, &stringValue); err != nil {
			return &ErrorInvalidRequestFormat
		}
		plaintextCreds[credTypeStr] = stringValue
	}

	plaintextJSON, err := json.Marshal(plaintextCreds)
	if err != nil {
		return logErrorAndReturnServerError(ctx, logger, "Failed to marshal credentials", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}
	if err = us.entityService.UpdateCredentials(ctx, userID, plaintextJSON); err != nil {
		if svcErr := mapEntityError(err); svcErr != nil {
			return svcErr
		}
		return logErrorAndReturnServerError(ctx, logger, "Failed to update user credentials", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}

	logger.Debug(ctx, "Successfully updated user credentials",
		log.MaskedString(log.LoggerKeyUserID, userID),
		log.Int("credentialTypesCount", len(credentialsMap)))
	us.captureCredentials(ctx, &existingUser, existingUser.Attributes, plaintextCreds)
	return nil
}

// ValidateDeleteUser checks whether the caller may delete the user and whether the target is deletable,
// without changing persistent state.
func (us *userService) ValidateDeleteUser(ctx context.Context, userID string) *tidcommon.ServiceError {
	if userID == "" {
		return &ErrorMissingUserID
	}
	existingEntity, err := us.entityService.GetEntityProfile(ctx, userID)
	if err != nil {
		if errors.Is(err, entity.ErrEntityNotFound) {
			return &ErrorUserNotFound
		}
		return &tidcommon.InternalServerError
	}
	if existingEntity.Category != providers.EntityCategoryUser {
		return &ErrorUserNotFound
	}
	if svcErr := us.checkUserAccess(ctx, security.ActionDeleteUser,
		entityToUser(existingEntity).OUID, userID); svcErr != nil {
		return svcErr
	}
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))
	if svcErr := us.checkUserDeclarative(ctx, userID, logger); svcErr != nil {
		return svcErr
	}
	return us.ensureNoBlockingDependencies(ctx, userID, logger)
}

// DeleteUser deletes the user with the given ID.
func (us *userService) DeleteUser(ctx context.Context, userID string) *tidcommon.ServiceError {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))
	logger.Debug(ctx, "Deleting user", log.MaskedString(log.LoggerKeyUserID, userID))

	if userID == "" {
		return &ErrorMissingUserID
	}

	// Fetch the user to resolve the OU ID for the authorization check.
	existingEntity, err := us.entityService.GetEntityProfile(ctx, userID)
	if err != nil {
		if errors.Is(err, entity.ErrEntityNotFound) {
			logger.Debug(ctx, "User not found", log.MaskedString(log.LoggerKeyUserID, userID))
			return &ErrorUserNotFound
		}
		return logErrorAndReturnServerError(ctx, logger, "Failed to retrieve user", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}
	if existingEntity.Category != providers.EntityCategoryUser {
		return &ErrorUserNotFound
	}
	existingUser := entityToUser(existingEntity)

	// Check authz using the user's OU ID.
	if svcErr := us.checkUserAccess(
		ctx, security.ActionDeleteUser, existingUser.OUID, userID); svcErr != nil {
		return svcErr
	}

	// Check if user is declarative (immutable)
	if svcErr := us.checkUserDeclarative(ctx, userID, logger); svcErr != nil {
		return svcErr
	}

	// Refuse deletion while other resources block it (e.g. agents owned by the user).
	if svcErr := us.ensureNoBlockingDependencies(ctx, userID, logger); svcErr != nil {
		return svcErr
	}

	// Remove dependents that must be deleted with the user (e.g. role assignments). Run before the
	// entity delete so a cleanup failure aborts the operation and leaves the user retriable. The
	// registry is guaranteed non-nil here because ensureNoBlockingDependencies fails closed otherwise.
	if _, err = us.dependencyRegistry.CascadeDelete(ctx, resourcedependency.ResourceTypeUser, userID); err != nil {
		return logErrorAndReturnServerError(ctx, logger, "Failed to cascade-delete user dependencies", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}

	// The sharing policies recorded against the user go with it, in the same position as the cascade
	// above: nothing else removes them, and a user later created with this id would come back already
	// shared. Reshares go with the policy beneath them.
	if svcErr := us.sharingService.DeletePoliciesForResource(ctx, UserSharingType, userID); svcErr != nil {
		return translateSharingError(svcErr)
	}

	err = us.entityService.DeleteEntity(ctx, userID)
	if err != nil {
		if errors.Is(err, entity.ErrEntityNotFound) {
			logger.Debug(ctx, "User not found", log.MaskedString(log.LoggerKeyUserID, userID))
			return &ErrorUserNotFound
		}
		return logErrorAndReturnServerError(ctx, logger, "Failed to delete user", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}

	logger.Debug(ctx, "Successfully deleted user", log.MaskedString(log.LoggerKeyUserID, userID))
	return nil
}

// ensureNoBlockingDependencies refuses deletion when other resources depend on the user in a way
// that forbids it (behaviorOnDelete == restrict), such as agents that list the user as their owner.
// Because deletion is destructive, it fails closed: if dependency data cannot be determined, the
// deletion is refused rather than allowed.
func (us *userService) ensureNoBlockingDependencies(
	ctx context.Context, userID string, logger *log.Logger) *tidcommon.ServiceError {
	if us.dependencyRegistry == nil {
		logger.Error(ctx, "Dependency registry not set; refusing to delete user",
			log.MaskedString(log.LoggerKeyUserID, userID))
		return &tidcommon.InternalServerError
	}

	deps, err := us.dependencyRegistry.GetDependencies(ctx, resourcedependency.ResourceTypeUser, userID)
	if err != nil {
		return logErrorAndReturnServerError(ctx, logger, "Failed to evaluate user dependencies", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}
	// Fail closed: nil TotalResults means a provider failed to report, so usage is unknown.
	if deps == nil || deps.TotalResults == nil {
		logger.Error(ctx, "User dependency data unavailable; refusing to delete user",
			log.MaskedString(log.LoggerKeyUserID, userID))
		return &tidcommon.InternalServerError
	}

	blocking := resourcedependency.BlockingUsages(deps)
	if len(blocking) == 0 {
		return nil
	}

	logger.Debug(ctx, "User has blocking dependencies; deletion refused",
		log.MaskedString(log.LoggerKeyUserID, userID), log.Int("blockingCount", len(blocking)))
	dependencies := summarizeBlockingUsages(blocking)
	return tidcommon.CustomServiceError(ErrorUserHasBlockingDependencies, tidcommon.I18nMessage{
		Key: "error.userservice.user_has_blocking_dependencies_description",
		DefaultValue: fmt.Sprintf(
			"The user cannot be deleted because %s depend on it. Remove or reassign them first.", dependencies),
		Params: map[string]string{"dependencies": dependencies},
	})
}

// summarizeBlockingUsages renders a deterministic, human-readable summary of blocking dependencies
// grouped by resource type, e.g. "2 agent(s)".
func summarizeBlockingUsages(usages []resourcedependency.ResourceDependency) string {
	counts := make(map[string]int)
	for _, u := range usages {
		counts[u.ResourceType]++
	}
	types := make([]string, 0, len(counts))
	for rt := range counts {
		types = append(types, rt)
	}
	sort.Strings(types)
	parts := make([]string, 0, len(types))
	for _, rt := range types {
		parts = append(parts, fmt.Sprintf("%d %s(s)", counts[rt], rt))
	}
	return strings.Join(parts, ", ")
}

// SetDependencyRegistry injects the dependency registry. Called by servicemanager after the
// provider services are initialized to avoid a cyclic import.
func (us *userService) SetDependencyRegistry(r resourcedependency.Registry) {
	us.dependencyRegistry = r
}

// GetUserUsages returns the resources that reference this user, such as agents that list the user
// as their owner. It is informational — it drives the pre-delete confirmation dialog and does not
// gate deletion on the server.
func (us *userService) GetUserUsages(
	ctx context.Context, userID string,
) (*resourcedependency.DependenciesResponse, *tidcommon.ServiceError) {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))

	if userID == "" {
		return nil, &ErrorMissingUserID
	}

	existingEntity, err := us.entityService.GetEntityProfile(ctx, userID)
	if err != nil {
		if errors.Is(err, entity.ErrEntityNotFound) {
			return nil, &ErrorUserNotFound
		}
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to retrieve user", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}
	if existingEntity.Category != providers.EntityCategoryUser {
		return nil, &ErrorUserNotFound
	}

	if us.dependencyRegistry == nil {
		logger.Warn(ctx, "Dependency registry not set; returning unknown dependencies",
			log.MaskedString(log.LoggerKeyUserID, userID))
		return &resourcedependency.DependenciesResponse{
			TotalResults: nil,
			Count:        0,
			Summary:      nil,
			Usages:       []resourcedependency.ResourceDependency{},
		}, nil
	}

	result, err := us.dependencyRegistry.GetDependencies(ctx, resourcedependency.ResourceTypeUser, userID)
	if err != nil {
		return nil, logErrorAndReturnServerError(ctx, logger, "Failed to get user usages", err,
			log.MaskedString(log.LoggerKeyUserID, userID))
	}

	return result, nil
}

// populateUserDisplayNames resolves display names for a slice of users in-place.
// It batch-fetches display attribute paths from the entity type service and extracts the
// display value from each user's attributes. Falls back to user ID if extraction fails.
func (us *userService) populateUserDisplayNames(ctx context.Context, users []providers.User, logger *log.Logger) {
	// Collect user types for display attribute resolution.
	userTypes := make([]string, 0, len(users))
	for _, u := range users {
		userTypes = append(userTypes, u.Type)
	}

	displayAttrPaths := entitytype.ResolveDisplayAttributePaths(
		ctx, entitytype.TypeCategoryUser, userTypes, us.entityTypeService, logger)

	// Resolve display for each user.
	for i := range users {
		users[i].Display = utils.ResolveDisplay(
			users[i].ID, users[i].Type, users[i].Attributes, displayAttrPaths)
	}
}

// populateOUHandles resolves OU handles for a slice of users in-place.
func (us *userService) populateOUHandles(ctx context.Context, users []providers.User, logger *log.Logger) {
	ouIDs := make([]string, 0, len(users))
	seen := make(map[string]bool, len(users))
	for _, u := range users {
		if u.OUID != "" && !seen[u.OUID] {
			ouIDs = append(ouIDs, u.OUID)
			seen[u.OUID] = true
		}
	}

	handleMap, svcErr := us.ouService.GetOrganizationUnitHandlesByIDs(ctx, ouIDs)
	if svcErr != nil {
		logger.Warn(ctx, "Failed to resolve OU handles, skipping", log.Any("error", svcErr))
		return
	}

	for i := range users {
		if handle, ok := handleMap[users[i].OUID]; ok {
			users[i].OUHandle = handle
		}
	}
}

// validateOrganizationUnitForUserType ensures that the organization unit ID is valid and belongs to the user type.
func (us *userService) validateOrganizationUnitForUserType(
	ctx context.Context, userType, oUID string, logger *log.Logger,
) *tidcommon.ServiceError {
	if strings.TrimSpace(userType) == "" {
		return &ErrorEntityTypeNotFound
	}

	if strings.TrimSpace(oUID) == "" {
		return &ErrorInvalidOUID
	}

	if us.ouService == nil {
		logger.Error(ctx, "Organization unit service is not configured for user operations")
		return &tidcommon.InternalServerError
	}

	exists, svcErr := us.ouService.IsOrganizationUnitExists(ctx, oUID)
	if svcErr != nil {
		return mapOUServiceError(ctx,
			svcErr,
			logger,
			"verifying organization unit existence",
			map[string]*tidcommon.ServiceError{
				oupkg.ErrorOrganizationUnitNotFound.Code: &ErrorOrganizationUnitNotFound,
				oupkg.ErrorInvalidRequestFormat.Code:     &ErrorInvalidOUID,
				oupkg.ErrorMissingOUID.Code:              &ErrorInvalidOUID,
			},
			log.String("oUID", oUID),
		)
	}
	if !exists {
		return &ErrorOrganizationUnitNotFound
	}

	if us.entityTypeService == nil {
		logger.Error(ctx, "Entity type service is not configured for user operations")
		return &tidcommon.InternalServerError
	}

	entityType, svcErr := us.entityTypeService.GetEntityTypeByHandle(ctx,
		entitytype.TypeCategoryUser, userType)
	if svcErr != nil {
		if svcErr.Code == entitytype.ErrorEntityTypeNotFound.Code {
			return &ErrorEntityTypeNotFound
		}
		logger.Error(ctx, "Failed to retrieve user type",
			log.String("userType", userType), log.Any("error", svcErr))
		return &tidcommon.InternalServerError
	}

	if entityType == nil {
		logger.Error(ctx, "Entity type service returned nil response", log.String("userType", userType))
		return &tidcommon.InternalServerError
	}

	if entityType.OUID == oUID {
		return nil
	}

	isParent, svcErr := us.ouService.IsParent(ctx, entityType.OUID, oUID)
	if svcErr != nil {
		return mapOUServiceError(ctx,
			svcErr,
			logger,
			"validating organization unit hierarchy",
			map[string]*tidcommon.ServiceError{
				oupkg.ErrorOrganizationUnitNotFound.Code: &ErrorOrganizationUnitNotFound,
			},
			log.String("userType", userType),
			log.String("oUID", oUID),
			log.String("schemaOUID", entityType.OUID),
		)
	}

	if !isParent {
		logger.Debug(ctx, "Organization unit mismatch for user type",
			log.String("userType", userType),
			log.String("oUID", oUID),
			log.String("schemaOUID", entityType.OUID))
		return &ErrorOrganizationUnitMismatch
	}

	return nil
}

// markOwned records on each user whether the listed organization unit owns it.
func markOwned(users []providers.User, owned bool) {
	for i := range users {
		users[i].IsOwnedByOU = new(owned)
	}
}

// usersWithAccess converts entities to users with the access facts governance derived for each, in one
// read.
func (us *userService) usersWithAccess(ctx context.Context, entities []providers.Entity) []providers.User {
	reads := us.governance.ReadAccess(ctx, entities)
	users := entitiesToUsers(entities)
	for i := range users {
		users[i].Status = &reads[i].Status
		users[i].LastLoginAt = reads[i].LastLoginAt
	}
	return users
}

// validateAndProcessHandlePath validates and processes the handle path.
func validateAndProcessHandlePath(handlePath string) *tidcommon.ServiceError {
	if strings.TrimSpace(handlePath) == "" {
		return &ErrorInvalidHandlePath
	}

	handles := strings.Split(strings.Trim(handlePath, "/"), "/")
	if len(handles) == 0 {
		return &ErrorInvalidHandlePath
	}

	for _, handle := range handles {
		if strings.TrimSpace(handle) == "" {
			return &ErrorInvalidHandlePath
		}
	}
	return nil
}

// validatePaginationParams validates pagination parameters.
func validatePaginationParams(limit, offset int) *tidcommon.ServiceError {
	if limit < 1 || limit > serverconst.MaxPageSize {
		return &ErrorInvalidLimit
	}
	if offset < 0 {
		return &ErrorInvalidOffset
	}
	return nil
}

// logErrorAndReturnServerError logs the error and returns a server error.
func logErrorAndReturnServerError(ctx context.Context,
	logger *log.Logger,
	message string,
	err error,
	additionalFields ...log.Field,
) *tidcommon.ServiceError {
	fields := additionalFields
	if err != nil {
		fields = append(fields, log.Error(err))
	}
	logger.Error(ctx, message, fields...)
	return &tidcommon.InternalServerError
}

// mapEntityError maps entity service errors to user service errors.
// Returns nil if the error is not a recognized entity error.
func mapEntityError(err error) *tidcommon.ServiceError {
	switch {
	case errors.Is(err, entity.ErrEntityNotFound):
		return &ErrorUserNotFound
	case errors.Is(err, entity.ErrAuthenticationFailed):
		return &ErrorAuthenticationFailed
	case errors.Is(err, entity.ErrSchemaValidationFailed):
		return &ErrorSchemaValidationFailed
	case errors.Is(err, entity.ErrAttributeConflict):
		return &ErrorAttributeConflict
	case errors.Is(err, entity.ErrInvalidCredential):
		return &ErrorInvalidCredential
	default:
		return nil
	}
}

// mapOUServiceError converts organization unit service errors to user service errors.
func mapOUServiceError(ctx context.Context,
	svcErr *tidcommon.ServiceError,
	logger *log.Logger,
	context string,
	mappings map[string]*tidcommon.ServiceError,
	fields ...log.Field,
) *tidcommon.ServiceError {
	if svcErr == nil {
		return nil
	}

	if mappedErr, ok := mappings[svcErr.Code]; ok {
		return mappedErr
	}

	if svcErr.Type == tidcommon.ClientErrorType {
		logFields := append([]log.Field{}, fields...)
		logFields = append(logFields, log.Any("error", svcErr))
		logger.Error(ctx, fmt.Sprintf("Unexpected organization unit client error while %s", context),
			logFields...)
		return &tidcommon.InternalServerError
	}

	logFields := append([]log.Field{}, fields...)
	logFields = append(logFields, log.Any("error", svcErr))
	logger.Error(ctx, fmt.Sprintf("Organization unit service error while %s", context), logFields...)
	return &tidcommon.InternalServerError
}

// checkUserDeclarative checks if a user is declarative and returns an error if it is.
func (us *userService) checkUserDeclarative(
	ctx context.Context, userID string, logger *log.Logger,
) *tidcommon.ServiceError {
	isDeclarative, err := us.entityService.IsEntityDeclarative(ctx, userID)
	if err != nil {
		if errors.Is(err, entity.ErrEntityNotFound) {
			return &ErrorUserNotFound
		}
		logger.Error(ctx, "Failed to check if user is declarative",
			log.MaskedString(log.LoggerKeyUserID, userID), log.Error(err))
		return &tidcommon.InternalServerError
	}
	if isDeclarative {
		return &ErrorCannotModifyDeclarativeResource
	}
	return nil
}

// checkUserAccess validates that the caller is authorized to perform the given action on a user.
func (us *userService) checkUserAccess(
	ctx context.Context, action security.Action, ouID string, resourceID string,
) *tidcommon.ServiceError {
	logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))

	allowed, svcErr := us.authzService.IsActionAllowed(ctx, action,
		&sysauthz.ActionContext{ResourceType: security.ResourceTypeUser, OUID: ouID, ResourceID: resourceID})
	if svcErr != nil {
		logger.Error(ctx, "Failed to check authorization for action",
			log.String("action", string(action)), log.Any("error", svcErr))
		return &tidcommon.InternalServerError
	}
	if !allowed {
		return &tidcommon.ErrorUnauthorized
	}
	return nil
}

// sharingErrors answers the sharing framework's client errors in this service's own codes.
var sharingErrors = sharing.ErrorTranslation{
	PolicyNotFound:  ErrorSharingPolicyNotFound,
	PolicyExists:    ErrorSharingPolicyExists,
	VersionMismatch: ErrorSharingPolicyVersionMismatch,
	PolicyDeclared:  ErrorSharingPolicyDeclared,
	InvalidLimit:    ErrorInvalidLimit,
	InvalidOffset:   ErrorInvalidOffset,
	InvalidPolicy:   ErrorInvalidSharingPolicy,
}

// translateSharingError maps a sharing framework error into this service's own codes.
func translateSharingError(svcErr *tidcommon.ServiceError) *tidcommon.ServiceError {
	return sharingErrors.Translate(svcErr)
}

// checkSharingAccess authorizes a sharing call against one organization unit. It names no resource,
// so the self-service rule letting users act on their own record does not apply: sharing a user is
// an administrator's decision, never the user's own.
func (us *userService) checkSharingAccess(
	ctx context.Context, action security.Action, ouID string,
) *tidcommon.ServiceError {
	return us.checkUserAccess(ctx, action, ouID, "")
}

// checkSharingReadAccess allows a read when the caller may read users in any of the given
// organization units.
func (us *userService) checkSharingReadAccess(ctx context.Context, ouIDs ...string) *tidcommon.ServiceError {
	denied := &tidcommon.ErrorUnauthorized
	for _, ouID := range ouIDs {
		svcErr := us.checkSharingAccess(ctx, security.ActionReadUser, ouID)
		if svcErr == nil {
			return nil
		}
		if svcErr.Code != tidcommon.ErrorUnauthorized.Code {
			return svcErr
		}
	}
	return denied
}

// requireSharing resolves the user a sharing call names and returns its owning organization unit.
// The user is read without the caller's authorization, because a sharing call is authorized against
// the organization unit whose decision it concerns, which need not be the user's own.
func (us *userService) requireSharing(ctx context.Context, userID string) (string, *tidcommon.ServiceError) {
	if userID == "" {
		return "", &ErrorMissingUserID
	}
	user, svcErr := us.GetUser(security.WithRuntimeContext(ctx), userID, false)
	if svcErr != nil {
		return "", svcErr
	}
	return user.OUID, nil
}

// requireOwnPolicy fetches a policy and refuses one belonging to another resource. Without it a
// policy id alone would reach any policy in the deployment through any user's path.
func (us *userService) requireOwnPolicy(
	ctx context.Context, userID, policyID string,
) (string, sharing.Policy, *tidcommon.ServiceError) {
	owningOUID, svcErr := us.requireSharing(ctx, userID)
	if svcErr != nil {
		return "", sharing.Policy{}, svcErr
	}
	policy, svcErr := us.sharingService.GetPolicy(ctx, policyID)
	if svcErr != nil {
		return "", sharing.Policy{}, translateSharingError(svcErr)
	}
	if policy.ResourceType != UserSharingType || policy.ResourceID != userID {
		return "", sharing.Policy{}, &ErrorSharingPolicyNotFound
	}
	return owningOUID, policy, nil
}

// CreateSharingPolicy records which organization units a user reaches. A policy is the initiating
// organization unit's decision, so that unit is the one the caller must be allowed to act for: the
// owner for a share, or a unit the user already reached for a reshare.
func (us *userService) CreateSharingPolicy(
	ctx context.Context, userID string, req sharing.PolicyRequest,
) (sharing.Policy, *tidcommon.ServiceError) {
	owningOUID, svcErr := us.requireSharing(ctx, userID)
	if svcErr != nil {
		return sharing.Policy{}, svcErr
	}
	initiatingOUID := req.InitiatingOUID
	if initiatingOUID == "" {
		initiatingOUID = owningOUID
	}
	if svcErr := us.checkSharingAccess(ctx, security.ActionUpdateUser, initiatingOUID); svcErr != nil {
		return sharing.Policy{}, svcErr
	}
	// Users that load from resource files only have all their sharing declared there.
	if isDeclarativeModeEnabled() {
		return sharing.Policy{}, &ErrorCannotModifyDeclarativeResource
	}
	// A declared user's own sharing is declared with it; a unit it is shared into may still reshare.
	if initiatingOUID == owningOUID {
		logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))
		if svcErr := us.checkUserDeclarative(ctx, userID, logger); svcErr != nil {
			return sharing.Policy{}, svcErr
		}
	}
	policy, svcErr := us.sharingService.CreatePolicy(ctx, UserSharingType, userID, owningOUID, req)
	return policy, translateSharingError(svcErr)
}

// GetSharingPolicy returns one of the user's sharing policies. The owner sees every decision about
// its user; any other organization unit sees its own.
func (us *userService) GetSharingPolicy(
	ctx context.Context, userID, policyID string,
) (sharing.Policy, *tidcommon.ServiceError) {
	owningOUID, policy, svcErr := us.requireOwnPolicy(ctx, userID, policyID)
	if svcErr != nil {
		return sharing.Policy{}, svcErr
	}
	if svcErr := us.checkSharingReadAccess(ctx, owningOUID, policy.InitiatingOUID); svcErr != nil {
		return sharing.Policy{}, svcErr
	}
	return policy, nil
}

// ListSharingPolicies returns one page of the user's sharing policies. A caller who may read users
// in the owning organization unit sees them all; any other caller sees the ones its own
// organization units made.
func (us *userService) ListSharingPolicies(
	ctx context.Context, userID string, limit, offset int,
) (sharing.PolicyList, *tidcommon.ServiceError) {
	if limit < 1 || limit > serverconst.MaxPageSize {
		return sharing.PolicyList{}, &ErrorInvalidLimit
	}
	// An offset this close to MaxInt would overflow the page bounds, the start index and the links.
	if offset < 0 || offset > math.MaxInt-limit {
		return sharing.PolicyList{}, &ErrorInvalidOffset
	}

	owningOUID, svcErr := us.requireSharing(ctx, userID)
	if svcErr != nil {
		return sharing.PolicyList{}, svcErr
	}
	svcErr = us.checkSharingAccess(ctx, security.ActionReadUser, owningOUID)
	if svcErr == nil {
		list, svcErr := us.sharingService.GetPolicyList(ctx, UserSharingType, userID, limit, offset)
		return list, translateSharingError(svcErr)
	}
	if svcErr.Code != tidcommon.ErrorUnauthorized.Code {
		return sharing.PolicyList{}, svcErr
	}
	return us.listOwnSharingPolicies(ctx, userID, limit, offset)
}

// listOwnSharingPolicies pages, in memory, the policies the caller's own organization units made.
// A user holds at most one policy per organization unit, so the full set is small.
func (us *userService) listOwnSharingPolicies(
	ctx context.Context, userID string, limit, offset int,
) (sharing.PolicyList, *tidcommon.ServiceError) {
	policies, svcErr := us.sharingService.ListPolicies(ctx, UserSharingType, userID)
	if svcErr != nil {
		return sharing.PolicyList{}, translateSharingError(svcErr)
	}
	own := make([]sharing.Policy, 0, len(policies))
	for _, p := range policies {
		svcErr := us.checkSharingAccess(ctx, security.ActionReadUser, p.InitiatingOUID)
		if svcErr == nil {
			own = append(own, p)
			continue
		}
		if svcErr.Code != tidcommon.ErrorUnauthorized.Code {
			return sharing.PolicyList{}, svcErr
		}
	}
	// A caller who made none of them has no standing to read the user's sharing at all.
	if len(own) == 0 {
		return sharing.PolicyList{}, &tidcommon.ErrorUnauthorized
	}

	page := own[min(offset, len(own)):min(offset+limit, len(own))]
	return sharing.PolicyList{
		TotalResults: len(own),
		StartIndex:   offset + 1,
		Count:        len(page),
		Policies:     page,
	}, nil
}

// UpdateSharingPolicy replaces a sharing policy's contents. Only the organization unit whose
// decision it is may change it.
func (us *userService) UpdateSharingPolicy(
	ctx context.Context, userID, policyID string, req sharing.PolicyRequest,
) (sharing.Policy, *tidcommon.ServiceError) {
	_, policy, svcErr := us.requireOwnPolicy(ctx, userID, policyID)
	if svcErr != nil {
		return sharing.Policy{}, svcErr
	}
	if svcErr := us.checkSharingAccess(ctx, security.ActionUpdateUser, policy.InitiatingOUID); svcErr != nil {
		return sharing.Policy{}, svcErr
	}
	if isDeclarativeModeEnabled() {
		return sharing.Policy{}, &ErrorCannotModifyDeclarativeResource
	}
	updated, svcErr := us.sharingService.UpdatePolicy(ctx, policyID, req)
	return updated, translateSharingError(svcErr)
}

// DeleteSharingPolicy removes a sharing policy and everything that depended on it. A policy that is
// not there is already gone, so the call succeeds.
func (us *userService) DeleteSharingPolicy(ctx context.Context, userID, policyID string) *tidcommon.ServiceError {
	_, policy, svcErr := us.requireOwnPolicy(ctx, userID, policyID)
	if svcErr != nil {
		if svcErr.Code == ErrorSharingPolicyNotFound.Code {
			return nil
		}
		return svcErr
	}
	if svcErr := us.checkSharingAccess(ctx, security.ActionUpdateUser, policy.InitiatingOUID); svcErr != nil {
		return svcErr
	}
	if isDeclarativeModeEnabled() {
		return &ErrorCannotModifyDeclarativeResource
	}
	if policy.Declared {
		return &ErrorSharingPolicyDeclared
	}
	return translateSharingError(us.sharingService.DeletePolicy(ctx, policyID))
}

// ResolveSharingOverlay answers which of the user's templated fields one organization unit may
// override, and on what terms. A user declares no templated fields yet, so the rules are empty. The
// owner may ask about any organization unit; any other unit may ask about itself.
func (us *userService) ResolveSharingOverlay(
	ctx context.Context, userID, ouID string,
) (sharing.ResolvedOverlay, *tidcommon.ServiceError) {
	owningOUID, svcErr := us.requireSharing(ctx, userID)
	if svcErr != nil {
		return sharing.ResolvedOverlay{}, svcErr
	}
	if ouID == "" {
		return sharing.ResolvedOverlay{}, &ErrorMissingOUIDParameter
	}
	if svcErr := us.checkSharingReadAccess(ctx, owningOUID, ouID); svcErr != nil {
		return sharing.ResolvedOverlay{}, svcErr
	}
	overlay, svcErr := us.sharingService.ResolveOverlayRules(ctx, UserSharingType, userID, ouID)
	if svcErr != nil {
		// An id naming no organization unit leaves nothing to resolve either.
		if svcErr.Code == oupkg.ErrorOrganizationUnitNotFound.Code {
			return sharing.ResolvedOverlay{}, &ErrorUserNotSharedToOU
		}
		return sharing.ResolvedOverlay{}, translateSharingError(svcErr)
	}
	if !overlay.Visible {
		return sharing.ResolvedOverlay{}, &ErrorUserNotSharedToOU
	}
	return overlay, nil
}

// buildTreePaginationLinks builds pagination links for user responses.
func buildTreePaginationLinks(handlePath string, limit, offset, totalResults int, displayQuery string) []utils.Link {
	treePath := fmt.Sprintf("/users/tree/%s", path.Clean(handlePath))
	return utils.BuildPaginationLinks(treePath, limit, offset, totalResults, displayQuery)
}

// ResolveUserOUHandle resolves ou_handle to an OU ID on the given user in-place.
// Called by the declarative loader parser so that file-based users support ou_handle.
// If both ou_id and ou_handle are provided, ou_id wins and a warning is logged.
func (us *userService) ResolveUserOUHandle(
	ctx context.Context, user *providers.User,
) *tidcommon.ServiceError {
	if user.OUID != "" && user.OUHandle != "" {
		logger := log.GetLogger().With(log.String(log.LoggerKeyComponentName, loggerComponentName))
		logger.Warn(ctx, "Both ouId and ouHandle provided for user; ouHandle ignored",
			log.MaskedString(log.LoggerKeyUserID, user.ID))
		return nil
	}
	if user.OUID == "" && user.OUHandle != "" {
		if us.ouService == nil {
			return &tidcommon.InternalServerError
		}
		ou, svcErr := us.ouService.GetOrganizationUnitByPath(
			security.WithRuntimeContext(ctx), user.OUHandle)
		if svcErr != nil {
			return &ErrorInvalidRequestFormat
		}
		user.OUID = ou.ID
	}
	return nil
}

// GetAccessibleOrganizationUnits lists the organization units the signed-in user can access: the one
// it lives in and every one it is shared into, narrowed by scope relative to the current one.
func (us *userService) GetAccessibleOrganizationUnits(
	ctx context.Context, scope string, limit, offset int,
) (*AccessibleOrganizationUnitListResponse, *tidcommon.ServiceError) {
	if scope != "" && scope != accessibleOUScopeSiblings {
		return nil, &ErrorInvalidScope
	}
	if limit < 1 || limit > serverconst.MaxPageSize {
		return nil, &ErrorInvalidLimit
	}
	// An offset this close to MaxInt would overflow the page bounds, the start index and the links.
	if offset < 0 || offset > math.MaxInt-limit {
		return nil, &ErrorInvalidOffset
	}

	userID := security.GetSubject(ctx)
	if strings.TrimSpace(userID) == "" {
		return nil, &ErrorAuthenticationFailed
	}
	// Units are read on the user's behalf: listing them would otherwise need a permission the user
	// does not hold, and these are units the user can already access.
	internalCtx := security.WithRuntimeContext(ctx)
	user, svcErr := us.GetUser(internalCtx, userID, false)
	if svcErr != nil {
		return nil, svcErr
	}
	reached, svcErr := us.sharingService.ListResourceSharedOUIDs(ctx, UserSharingType, userID)
	if svcErr != nil {
		return nil, translateSharingError(svcErr)
	}
	// The reach comes in no particular order, so it is sorted for a page to fall in the same place on
	// every request.
	slices.Sort(reached)
	current := security.GetOUID(ctx)
	if current == "" {
		current = user.OUID
	}

	units := newOUReader(us.ouService)
	accessible := make([]oupkg.OrganizationUnit, 0, len(reached)+1)
	for _, ouID := range append([]string{user.OUID}, reached...) {
		ou, found, svcErr := units.get(internalCtx, ouID)
		if svcErr != nil {
			return nil, svcErr
		}
		// A unit removed since it was shared is no longer anywhere to go.
		if !found {
			continue
		}
		accessible = append(accessible, ou)
	}

	inScope := accessible
	if scope == accessibleOUScopeSiblings {
		currentUnit, found, svcErr := units.get(internalCtx, current)
		if svcErr != nil {
			return nil, svcErr
		}
		inScope = make([]oupkg.OrganizationUnit, 0, len(accessible))
		for _, ou := range accessible {
			if found && sameParent(ou.Parent, currentUnit.Parent) {
				inScope = append(inScope, ou)
			}
		}
	}

	page := inScope[min(offset, len(inScope)):min(offset+limit, len(inScope))]
	items := make([]AccessibleOrganizationUnit, 0, len(page))
	for _, ou := range page {
		items = append(items, AccessibleOrganizationUnit{ID: ou.ID, Handle: ou.Handle, Name: ou.Name,
			LogoURL: ou.LogoURL})
	}

	scopeQuery := ""
	if scope != "" {
		scopeQuery = "&scope=" + scope
	}
	return &AccessibleOrganizationUnitListResponse{
		Current:           current,
		TotalResults:      len(inScope),
		StartIndex:        offset + 1,
		Count:             len(items),
		OrganizationUnits: items,
		Links: utils.BuildPaginationLinks(
			"/users/me/ous", limit, offset, len(inScope), scopeQuery),
	}, nil
}

// sameParent reports whether two units sit under the same parent, top-level units included.
func sameParent(a, b *string) bool {
	if a == nil || b == nil {
		return a == nil && b == nil
	}
	return *a == *b
}

// ouReader reads organization units for one request, each at most once.
type ouReader struct {
	ouService oupkg.OrganizationUnitServiceInterface
	units     map[string]oupkg.OrganizationUnit
	missing   map[string]struct{}
}

// newOUReader returns a reader over the given organization unit service.
func newOUReader(ouService oupkg.OrganizationUnitServiceInterface) *ouReader {
	return &ouReader{
		ouService: ouService,
		units:     make(map[string]oupkg.OrganizationUnit),
		missing:   make(map[string]struct{}),
	}
}

// get returns one organization unit, reporting whether it exists.
func (r *ouReader) get(
	ctx context.Context, ouID string,
) (oupkg.OrganizationUnit, bool, *tidcommon.ServiceError) {
	if ou, ok := r.units[ouID]; ok {
		return ou, true, nil
	}
	if _, ok := r.missing[ouID]; ok {
		return oupkg.OrganizationUnit{}, false, nil
	}
	ou, svcErr := r.ouService.GetOrganizationUnit(ctx, ouID)
	if svcErr != nil {
		if svcErr.Code == oupkg.ErrorOrganizationUnitNotFound.Code {
			r.missing[ouID] = struct{}{}
			return oupkg.OrganizationUnit{}, false, nil
		}
		return oupkg.OrganizationUnit{}, false, &tidcommon.InternalServerError
	}
	r.units[ouID] = ou
	return ou, true, nil
}
